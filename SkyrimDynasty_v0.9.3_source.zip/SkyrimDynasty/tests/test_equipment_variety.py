"""Check integration of the native rules exercised by CTest."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class VarietyIntegration(unittest.TestCase):
    def test_only_committed_kits_enter_history_and_saved_kits_are_retained(self):
        source=(ROOT/'SKSEPlugin/src/Loadouts.cpp').read_text()
        body=source.split('GeneticsEngine::GenerateLoadout',1)[1].split('GeneticsEngine::RemoveInvalidLoadoutItems',1)[0]
        self.assertIn('if(e.items.empty()||reroll)',body)
        self.assertIn('auto recent=equipmentHistory_',body)
        self.assertIn('recent.insert(recent.end(),other.items.begin(),other.items.end())',body)
        self.assertIn('settings_.coherentGear,recent)',body)
        order=[body.index(x) for x in ['if(!torso)','e.items=std::move(chosen)','RememberEquipment(equipmentHistory_,e.items)']]
        self.assertEqual(order,sorted(order))
    def test_history_serializes_resolves_and_clears_between_saves(self):
        features=(ROOT/'SKSEPlugin/src/Features.cpp').read_text()
        self.assertIn('{"equipmentHistory",equipmentHistory_}',features)
        self.assertIn('Equipment::DecodeEquipmentHistory(j)',features)
        self.assertIn('stream->ResolveFormID(old,resolved)',features)
        genetics=(ROOT/'SKSEPlugin/src/Genetics.cpp').read_text()
        for name in ['void GeneticsEngine::Load(', 'void GeneticsEngine::Revert(']:
            body=genetics.split(name,1)[1]
            self.assertIn('equipmentHistory_.clear()',body)
if __name__=='__main__':unittest.main()
