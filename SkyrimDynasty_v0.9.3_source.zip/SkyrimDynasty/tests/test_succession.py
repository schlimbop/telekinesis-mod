"""Run the real inventory helper and check succession ordering at its call site."""
from pathlib import Path
from types import SimpleNamespace
import unittest
from test_lifecycle import load_function, SOURCE

class Actor:
    def __init__(self, items): self.items=list(items); self.events=[]
    def UnequipAll(self): self.events.append('unequip')
    def RemoveAllItems(self, target, ownership, quests):
        self.events.append(('remove',target,ownership,quests))
        movable=[item for item in self.items if quests or not item.quest]
        self.items=[item for item in self.items if item not in movable]
        if target is not None: target.items.extend(movable)

class SuccessionTests(unittest.TestCase):
    def transfer(self, old, new):
        player=Actor(old); heir=Actor(new)
        env=dict(PlayerRef=player)
        load_function('ReplaceSuccessorInventory',env)
        env['ReplaceSuccessorInventory'](heir)
        self.assertEqual(player.items,new)
        self.assertEqual(heir.items,[])
        self.assertEqual(player.events,['unequip',('remove',None,False,True)])
        self.assertEqual(heir.events,[('remove',player,True,True)])
        return player
    def test_replaces_gold_keys_quest_items_and_old_equipment(self):
        self.transfer([SimpleNamespace(quest=q,kind=k) for q,k in [(True,'quest'),(False,'gold'),(False,'key'),(False,'sword')]],
            [SimpleNamespace(quest=False,kind='heir sword'),SimpleNamespace(quest=True,kind='heir quest')])
    def test_empty_heir_leaves_empty_inventory(self):
        self.transfer([SimpleNamespace(quest=True),SimpleNamespace(quest=False)],[])
    def test_shared_base_form_does_not_keep_predecessor_instances(self):
        old=SimpleNamespace(quest=False,base='Sword',temper=99,enchant='fire')
        heir=SimpleNamespace(quest=False,base='Sword',temper=5,enchant='frost')
        player=self.transfer([old],[heir])
        self.assertIs(player.items[0],heir)
    def test_validation_equipment_snapshot_and_magic_run_before_heir_consumption(self):
        body=SOURCE.split('Bool Function ContinueAsHeir(Int aiIndex)',1)[1].split('EndFunction',1)[0]
        markers=['DynastyNative.AdoptHeir(heir)','PlayerRef.SetRace(heir.GetRace())',
            'heir.GetWornItemId','ReplaceSuccessorInventory(heir)','PlayerRef.EquipItemById',
            'ApplySuccessorLevel(heir)','DynastyNative.CopyHeirSpells(heir)','heir.Disable()',
            'ReleaseHeirSlot(aiIndex)','heir.Delete()']
        positions=[body.index(m) for m in markers]
        self.assertEqual(positions,sorted(positions))
        self.assertIn('if worn[32] != None && !(worn[32] as Spell)',body)
        self.assertIn('if worn[33] != None && !(worn[33] as Spell)',body)
    def test_native_uses_live_spellbooks_and_clears_equipped_favourites(self):
        root=Path(__file__).resolve().parents[1]
        body=(root/'SKSEPlugin/src/Talents.cpp').read_text().split('void GeneticsEngine::CopyHeirSpells',1)[1].split('void GeneticsEngine::ClearTalents',1)[0]
        self.assertIn('player->VisitSpells(predecessor)',body)
        self.assertIn('heir->VisitSpells(successor)',body)
        self.assertIn('SynchronizeSpells(predecessor.known, successor.known',body)
        for marker in ['InterruptCast(false)','DeselectSpell(spell)','RemoveFavorite(spell)','RemoveSpell(spell)','AddSpell(spell)']:
            self.assertIn(marker,body)

if __name__=='__main__':unittest.main()
