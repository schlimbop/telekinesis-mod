#include "SuccessionSpells.h"
#include <cstdlib>
#include <iostream>
#include <set>
#include <random>
void Check(bool value) { if (!value) { std::cerr << "Succession spellbook mismatch\n"; std::exit(1); } }
int main() {
    int forms[512]{};
    std::mt19937 rng(901);
    for (int trial = 0; trial < 2000; ++trial) {
        std::vector<int*> current, successor;
        std::set<int*> actual, expected, removed, added;
        for (auto& form : forms) {
            if (rng() % 2) { current.push_back(&form); actual.insert(&form); }
            if (rng() % 2) { successor.push_back(&form); expected.insert(&form); }
        }
        if (trial == 0) { successor.clear(); expected.clear(); }
        if (trial == 1) { current.clear(); actual.clear(); }
        if (trial == 2) { successor = current; expected = actual; }
        // Repeated base/race/added entries and missing forms must be harmless.
        auto duplicate = current; current.insert(current.end(), duplicate.begin(), duplicate.end());
        duplicate = successor; successor.insert(successor.end(), duplicate.begin(), duplicate.end());
        current.push_back(nullptr); successor.push_back(nullptr);
        Dynasty::SynchronizeSpells(current, successor,
            [&](int* spell) { Check(removed.insert(spell).second); Check(!expected.contains(spell)); Check(actual.erase(spell) == 1); },
            [&](int* spell) { Check(added.insert(spell).second); Check(actual.insert(spell).second); });
        Check(actual == expected);
    }
    std::cout << "2000 successor spellbooks passed: empty, shared, duplicated and 512-entry books\n";
}
