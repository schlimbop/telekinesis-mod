"""Execute shipped eligibility and fallback interaction code with mock actors."""
from types import SimpleNamespace as NS
import unittest
from test_lifecycle import load_function, SOURCE

class Actor:
    def __init__(self, sex=1, **state):
        self.sex=sex;self.dead=False;self.child=False;self.combat=False
        self.loaded=True;self.disabled=False;self.distance=150;self.base=self
        self.__dict__.update(state)
    def GetActorBase(self):return self.base
    def GetLeveledActorBase(self):return getattr(self,'leveled_base',self.base)
    def GetSex(self):return self.sex
    def IsDead(self):return self.dead
    def IsChild(self):return self.child
    def IsInCombat(self):return self.combat
    def Is3DLoaded(self):return self.loaded
    def IsDisabled(self):return self.disabled
    def GetDistance(self,actor):return self.distance
    def IsHostileToActor(self,actor):raise AssertionError('Hostility must not restrict access')

class PartnerAccess(unittest.TestCase):
    def setUp(self):
        self.player=Actor(0);self.target=Actor();self.births=[];self.keys=[];self.shown=0
        self.menu=False;self.controls=True;self.choice=0;self.during_prompt=lambda:None
        self.env=dict(PlayerRef=self.player,ChildHeirBaseMale=object(),ChildHeirBaseFemale=object(),
            BreedingKey=48,shortcutBusy=False,birthBusy=False,successionBusy=False,
            __papyrus_globals__=['BreedingKey','shortcutBusy'],
            Game=NS(GetCurrentCrosshairRef=lambda:self.target,IsActivateControlsEnabled=lambda:self.controls,
                GetFormFromFile=lambda form,plugin:NS(Show=self.show)),
            Utility=NS(IsInMenuMode=lambda:self.menu),
            TryCreateHeirFromDialogue=self.births.append,
            UnregisterForAllKeys=lambda:self.keys.append('clear'),RegisterForKey=self.keys.append)
        for name in ['IsEligiblePartner','CanUseBreedingShortcut','PromptBreeding','TryBreedingShortcut',
                'RegisterBreedingShortcut','SetBreedingKey','GetBreedingKey']:
            load_function(name,self.env)
    def show(self):self.shown+=1;self.during_prompt();return self.choice
    def press(self):self.env['TryBreedingShortcut'](self.env['BreedingKey'])
    def test_guards_enemy_and_mod_factions_are_not_restricted(self):
        for faction in ['Guard','Bandit','Thalmor','Forsworn','Vampire','Mod-added enemy']:
            a=Actor(faction=faction,hostile=True);self.target=a
            self.assertTrue(self.env['IsEligiblePartner'](a));self.press()
            self.assertIs(self.births[-1],a)
        self.assertEqual(self.shown,6)
    def test_leveled_guard_uses_generated_female_sex_instead_of_editor_template(self):
        female=Actor();male=Actor(0)
        guard=Actor(0,leveled_base=female);self.target=guard
        self.assertTrue(self.env['IsEligiblePartner'](guard));self.press()
        self.assertEqual(self.births,[guard])
        self.assertFalse(self.env['IsEligiblePartner'](Actor(1,leveled_base=male)))
        self.assertTrue(self.env['IsEligiblePartner'](Actor(1,leveled_base=None)))
        self.assertFalse(self.env['IsEligiblePartner'](Actor(base=self.env['ChildHeirBaseFemale'],leveled_base=female)))
    def test_player_or_partner_combat_blocks_both_entry_points(self):
        for player_combat,partner_combat in [(False,True),(True,False),(True,True)]:
            self.player.combat=player_combat;self.target.combat=partner_combat
            self.assertFalse(self.env['IsEligiblePartner'](self.target));self.press()
        self.assertEqual(self.births,[]);self.assertEqual(self.shown,0)
    def test_dead_child_male_missing_base_self_and_private_juveniles_rejected(self):
        for target in [None,self.player,Actor(dead=True),Actor(child=True),Actor(0),Actor(base=None),
                Actor(base=self.env['ChildHeirBaseMale']),Actor(base=self.env['ChildHeirBaseFemale'])]:
            self.target=target
            self.assertFalse(self.env['IsEligiblePartner'](target));self.press()
        self.assertEqual(self.births,[]);self.assertEqual(self.shown,0)
        self.target=Actor();self.player.dead=True;self.press();self.assertEqual(self.shown,0)
    def test_shortcut_requires_nearby_loaded_enabled_target(self):
        for target in [Actor(distance=251),Actor(loaded=False),Actor(disabled=True)]:
            self.target=target;self.press()
        self.player.loaded=False;self.target=Actor();self.press()
        self.assertEqual(self.shown,0);self.assertEqual(self.births,[])
    def test_menu_disabled_controls_and_wrong_key_do_not_prompt(self):
        self.menu=True;self.press();self.menu=False
        self.controls=False;self.press();self.controls=True
        self.env['TryBreedingShortcut'](49)
        self.assertEqual(self.shown,0)
    def test_confirmation_preserves_exact_target_instead_of_new_crosshair(self):
        original=self.target
        self.during_prompt=lambda:setattr(self,'target',Actor())
        self.press();self.assertEqual(self.births,[original])
    def test_combat_or_distance_change_during_prompt_is_rechecked(self):
        for actor,field,value in [(self.player,'combat',True),(self.target,'combat',True),(self.target,'distance',251)]:
            previous=getattr(actor,field)
            self.during_prompt=lambda actor=actor,field=field,value=value:setattr(actor,field,value)
            self.press();setattr(actor,field,previous)
        self.assertEqual(self.births,[]);self.assertFalse(self.env['shortcutBusy'])
    def test_cancel_busy_and_missing_prompt_do_not_create_heir(self):
        self.choice=1;self.press();self.assertEqual(self.births,[])
        for key in ['birthBusy','successionBusy','shortcutBusy']:
            self.env[key]=True;self.press();self.env[key]=False
        self.assertEqual(self.shown,1)
        self.env['Game'].GetFormFromFile=lambda *args:None
        self.press();self.assertEqual(self.births,[])
    def test_held_key_cannot_reenter_confirmation(self):
        self.during_prompt=lambda:self.env['PromptBreeding'](self.target)
        self.press();self.assertEqual(self.shown,1);self.assertEqual(self.births,[self.target])
    def test_remapping_and_disabling_replace_previous_registration(self):
        self.env['RegisterBreedingShortcut']();self.assertEqual(self.keys,['clear',48])
        self.env['SetBreedingKey'](59);self.assertEqual(self.env['GetBreedingKey'](),59)
        self.assertEqual(self.keys[-2:],['clear',59])
        for key in [-1,0,512]:
            self.env['SetBreedingKey'](key);self.assertEqual(self.env['GetBreedingKey'](),-1)
            self.assertEqual(self.keys[-1],'clear')
            self.press();self.assertEqual(self.births,[])
    def test_saved_game_restores_registration_and_all_spawns_recheck_policy(self):
        init=SOURCE.split('Event OnInit()',1)[1].split('EndEvent',1)[0]
        recovery=SOURCE.split('Function RecoverSuccessionOnLoad()',1)[1].split('EndFunction',1)[0]
        self.assertIn('RegisterBreedingShortcut()',init)
        self.assertIn('RegisterBreedingShortcut()',recovery)
        self.assertIn('shortcutBusy = False',recovery)
        creation=SOURCE.split('Actor Function CreateHeir(',1)[1].split('EndFunction',1)[0]
        self.assertLess(creation.index('if !IsEligiblePartner(akPartner)'),creation.index('PlayerRef.PlaceAtMe'))

if __name__=='__main__':unittest.main()
