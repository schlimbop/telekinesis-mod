#include "FamilyCodec.h"
#include "PerkRules.h"
#include "PerkCodec.h"
#include "LoadoutRules.h"
#include "EquipmentFilters.h"
#include "EquipmentHistoryCodec.h"
#include <cstdlib>
#include <iostream>
#include <map>
#include <set>
#include <limits>
using namespace Dynasty;
void Check(bool value,const char* what){if(!value){std::cerr<<what<<'\n';std::exit(1);}}
int main() {
    std::mt19937_64 rng(900);int mutations=0,maternal=0;
    for(int i=0;i<20000;++i) {
        auto groups=FamilyDominance(rng);for(auto v:groups)Check((v>=.149F&&v<=.351F)||(v>=.649F&&v<=.851F),"coherent dominant-parent group weights");
        maternal+=groups[3]>.5F;bool changed=false;float allele=FaceAllele(.2F,.2F,rng,&changed);
        Check(changed==(allele!=.2F),"mutation provenance matches actual stored allele");mutations+=changed;
        Personality a{true,.1F,.2F,.8F},b{true,.9F,.9F,.2F};auto p=BreedPersonality(a,b,rng);
        Check(ValidPersonality(p),"bounded inherited personality");Check(PersonalityAggression(p)>=0&&PersonalityAggression(p)<=1,"never frenzy or very aggressive");
        Check(PersonalityConfidence(p)>=1&&PersonalityConfidence(p)<=4,"companion confidence range");
    }
    Check(maternal>9600&&maternal<10400&&mutations>1700&&mutations<2300,"balanced parent groups and bounded mutation rate");
    Check(kFaceGroup[2]==kFaceGroup[3]&&kFaceGroup[3]==kFaceGroup[4]&&kFaceGroup[7]==kFaceGroup[8]&&kFaceGroup[8]==kFaceGroup[17],"jaw and eye coordinates share dominance");
    FamilyDNA d;d.recorded=true;d.parentA="Parent A";d.parentB="Parent B";d.maternal=FamilyDominance(rng);d.mutations[3]=3;
    d.presetSources={1,2,0};d.raceSource=2;d.eyeSource=1;d.hairSource=3;d.skinMaternal=.4F;
    auto decoded=DecodeFamilyDNA(nlohmann::json::parse(EncodeFamilyDNA(d).dump()));
    Check(ValidFamilyDNA(decoded)&&decoded.maternal==d.maternal&&decoded.mutations==d.mutations&&decoded.presetSources==d.presetSources&&decoded.parentA==d.parentA,"actual family provenance save roundtrip");
    Check(!DecodeFamilyDNA(nullptr).recorded,"legacy saves have unknown provenance, not invented history");
    auto bad=EncodeFamilyDNA(d);bad["mutations"][3]=4294967297ULL;Check(!DecodeFamilyDNA(bad).recorded,"mutation integer overflow rejected");
    bad=EncodeFamilyDNA(d);bad["raceSource"]=4294967297ULL;Check(!DecodeFamilyDNA(bad).recorded,"source integer overflow rejected");
    bad=EncodeFamilyDNA(d);bad["maternal"][0]=2.0;Check(!DecodeFamilyDNA(bad).recorded,"invalid dominance rejected");
    auto personality=BreedPersonality({true,0,0,0},{true,1,1,1},rng);
    Check(DecodePersonality(EncodePersonality(personality)).bravery==personality.bravery,"personality persistence");
    Check(!DecodePersonality({{"version",1},{"aggression",3},{"bravery",.5},{"distance",.5}}).recorded,"unsafe personality rejected");
    Check(SafePerkEntry(2,1,3,0)&&SafePerkEntry(2,2,2,38),"numeric weapon/spell modifiers eligible");
    for(int type:{0,1})Check(!SafePerkEntry(type,1,3,0),"quest and ability perks excluded");
    for(int data:{0,3,4,5,6,7})Check(!SafePerkEntry(2,data,3,0),"scriptable/list/spell/activation perk data excluded");
    for(int point:{9,14,51,52,53,54,67,69,74,81})Check(!SafePerkEntry(2,1,3,point),"unsafe entry points excluded");
    Check(SafePerkCondition(14)&&SafePerkCondition(277)&&SafePerkCondition(80)&&SafePerkCondition(448)&&!SafePerkCondition(58),"perk prerequisites are local skill/level/perk checks");
    Check(PerkSkillWeight(1,0)>0&&PerkSkillWeight(1,14)==0&&PerkSkillWeight(2,2)>0&&PerkSkillWeight(3,14)>0&&PerkSkillWeight(4,9)>0&&PerkSkillWeight(5,4)>0,"role appropriate skill trees");
    Check(CreditPerkPoints(5,3)==8&&CreditPerkPoints(65534,5)==65535&&CreditPerkPoints(2,0)==2,"one point per earned level and bank saturation");
    auto earned=DecodeEarnedPerks({{"perkPoints",4},{"earnedPerks",{0xFE001800U,0x100U,0x100U}}});
    Check(earned.points==4&&earned.perks==std::vector<std::uint32_t>{0x100U,0xFE001800U},"earned perk persistence preserves ESL IDs and deduplicates");
    Check(DecodeEarnedPerks(nlohmann::json::object()).perks.empty(),"legacy earned perks empty");
    for(auto value:{nlohmann::json(-1),nlohmann::json(4294967297ULL),nlohmann::json("123"),nlohmann::json(0)}) {
        bool rejected=false;try{DecodeEarnedPerks({{"earnedPerks",{value}}});}catch(const std::exception&){rejected=true;}Check(rejected,"invalid saved perk ID rejected");
    }
    using namespace Equipment;
    auto filters=DecodeFilters({{"maxGoldValue",1000},{"excludedPlugins",{"BadGear.ESP"}},{"excludedForms",{{{"plugin","Gear.esl"},{"localFormID","0x800"}}}}});
    Check(filters.plugins==std::vector<std::string>{"badgear.esp"}&&filters.forms[0].second==0x800&&filters.maxGoldValue==1000,"stable plugin/local-ID exclusions");
    Check(WithinValueLimit(999,1000,0)&&!WithinValueLimit(1001,1000,0)&&!WithinValueLimit(600,0,500)&&WithinValueLimit(999999,0,0),"file/menu value ceilings intersect and zero means unlimited");
    const std::vector<nlohmann::json> invalidFilters{
        {{"maxGoldValue",-1}},{{"maxGoldValue","500"}},{{"excludedPlugins",{"../bad.esp"}}},
        {{"excludedForms",{{{"plugin","Good.esp"},{"localFormID","0x1000000"}}}}}
    };
    for(const auto& badFilter:invalidFilters) {
        bool rejected=false;try{DecodeFilters(badFilter);}catch(const std::exception&){rejected=true;}Check(rejected,"malformed equipment filter rejected");
    }
    std::vector<Item> pool;std::uint32_t id=1;
    for(int type=0;type<3;++type)for(std::uint32_t family:{11U,22U})for(auto mask:{4U,8U,128U,2U})pool.push_back({id++,mask,Kind::Armor,type,.5F,false,family});
    for(int type=1;type<=9;++type)pool.push_back({id++,0,Kind::Weapon,type,.5F,false});
    pool.push_back({id++,0,Kind::Ammo,0,.5F,false});pool.push_back({id++,0,Kind::Ammo,0,.5F,true});
    std::map<std::uint32_t,Item> lookup;for(const auto& i:pool)lookup[i.id]=i;
    int familyMatches=0,pieces=0;std::set<int> weaponTypes[6],armorTypes[6];std::set<std::vector<std::uint32_t>> kits;
    for(int n=0;n<10000;++n) {
        const int role=1+n%5;auto kit=Select(pool,role,.5F,rng);kits.insert(kit);
        std::uint32_t mask=0,family=0;int armorType=-1,weapon=0;
        for(auto item:kit) {
            const auto& i=lookup.at(item);
            if(i.kind==Kind::Weapon){weapon=i.type;weaponTypes[role].insert(weapon);}
            if(i.kind==Kind::Armor) {Check(!(mask&i.mask),"no equipment slot overlap");mask|=i.mask;
                if(i.mask&4){armorType=i.type;family=i.family;armorTypes[role].insert(armorType);}
                else {Check(i.type==armorType,"consistent armor class");++pieces;familyMatches+=i.family==family;}
            }
            if(i.kind==Kind::Ammo)Check(i.bolt==(weapon==9)&&(weapon==7||weapon==9),"matching ammunition");
        }
        Check(mask&4,"torso covered");
    }
    Check(kits.size()>350&&familyMatches>pieces*.55,"soft material preference with broad random kits");
    for(int role=1;role<=5;++role)Check(weaponTypes[role].size()==9&&armorTypes[role].size()==3,"every role reaches every weapon type and torso class");
    Check(DecodeEquipmentHistory(nlohmann::json::object()).empty(),"legacy equipment history empty");
    std::vector<std::uint32_t> history;
    for(std::uint32_t n=1;n<=1000;++n)RememberEquipment(history,{n});
    Check(history.size()==kEquipmentHistoryLimit&&history.front()==489&&history.back()==1000,"bounded equipment history keeps newest entries");
    auto saved=nlohmann::json{{"equipmentHistory",history}};
    Check(DecodeEquipmentHistory(saved)==history,"history round trip preserves order and duplicates");
    Check(DecodeEquipmentHistory({{"equipmentHistory",{1,1,UINT32_MAX}}})==std::vector<std::uint32_t>{1,1,UINT32_MAX},"history keeps valid counts and full form IDs");
    std::vector<nlohmann::json> badHistory{
        {{"equipmentHistory",-1}},{{"equipmentHistory",{0}}},{{"equipmentHistory",{-1}}},
        {{"equipmentHistory",{4294967296ULL}}},{{"equipmentHistory",{"12"}}},{{"equipmentHistory",{1.5}}},
        {{"equipmentHistory",std::vector<int>(513,1)}}};
    for(const auto& bad:badHistory){bool rejected=false;try{DecodeEquipmentHistory(bad);}catch(const std::exception&){rejected=true;}Check(rejected,"invalid equipment history rejected");}
    std::cout<<"Family features passed: 20,000 DNA/personality rolls, perk safety/save rules, filter validation and 10,000 coherent kits\n";
}
