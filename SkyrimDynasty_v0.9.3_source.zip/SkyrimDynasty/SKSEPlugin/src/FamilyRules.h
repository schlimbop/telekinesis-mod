#pragma once
#include "InheritanceRules.h"
#include <array>
#include <string>
namespace Dynasty {
inline constexpr std::array<int,19> kFaceGroup{0,0,1,1,1,2,2,3,3,4,4,4,5,5,6,6,6,3,7};
inline constexpr std::array<const char*,8> kFaceGroupNames{"Nose","Jaw","Cheeks","Eyes","Brows","Mouth","Chin","Other"};
struct FamilyDNA {
    bool recorded{false}; std::string parentA,parentB;
    std::array<float,8> maternal{};
    std::array<std::uint8_t,19> mutations{};
    std::array<int,3> presetSources{};
    int raceSource{},eyeSource{},hairSource{}; // 0: both/default, 1: A, 2: B, 3: mutation (hair).
    float skinMaternal{};
};
inline std::array<float,8> FamilyDominance(std::mt19937_64& rng) {
    std::array<float,8> groups{};
    for(auto& value:groups)value=std::uniform_real_distribution<float>(0.15F,0.35F)(rng)+(Chance(0.5,rng)?0.5F:0.0F);
    return groups;
}
inline bool ValidFamilyDNA(const FamilyDNA& d) {
    if(!d.recorded||d.parentA.size()>256||d.parentB.size()>256||d.raceSource<0||d.raceSource>2||
        d.eyeSource<0||d.eyeSource>2||d.hairSource<0||d.hairSource>3||!std::isfinite(d.skinMaternal)||d.skinMaternal<0||d.skinMaternal>1)return false;
    for(int v:d.presetSources)if(v<0||v>2)return false;
    for(float v:d.maternal)if(!std::isfinite(v)||v<0||v>1)return false;
    return std::all_of(d.mutations.begin(),d.mutations.end(),[](auto v){return v<=3;});
}
struct Personality {
    bool recorded{false};float aggression{},bravery{},distance{};
};
inline bool ValidPersonality(const Personality& p) {
    return p.recorded&&std::isfinite(p.aggression)&&std::isfinite(p.bravery)&&std::isfinite(p.distance)&&
        p.aggression>=0&&p.aggression<=1&&p.bravery>=0&&p.bravery<=1&&p.distance>=0&&p.distance<=1;
}
inline Personality BreedPersonality(const Personality& a,const Personality& b,std::mt19937_64& rng) {
    auto trait=[&](float x,float y){return std::clamp(std::lerp(x,y,std::uniform_real_distribution<float>(0.25F,0.75F)(rng))+
        std::normal_distribution<float>(0.0F,0.10F)(rng),0.0F,1.0F);};
    return {true,trait(a.aggression,b.aggression),trait(a.bravery,b.bravery),trait(a.distance,b.distance)};
}
inline int PersonalityAggression(const Personality& p){return p.aggression>=0.5F?1:0;}
inline int PersonalityConfidence(const Personality& p){return std::clamp(int(std::lround(p.bravery*4)),1,4);}
}
