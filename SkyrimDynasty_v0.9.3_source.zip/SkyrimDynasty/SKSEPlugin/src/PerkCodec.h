#pragma once
#include <nlohmann/json.hpp>
#include <algorithm>
#include <cstdint>
#include <stdexcept>
#include <vector>
#include "FamilyCodec.h"
namespace Dynasty {
struct EarnedPerkState {int points{};std::vector<std::uint32_t> perks;};
inline EarnedPerkState DecodeEarnedPerks(const nlohmann::json& j) {
    EarnedPerkState state;if(j.contains("perkPoints"))state.points=BoundedInteger(j.at("perkPoints"),0,65535);
    if(j.contains("earnedPerks")) {
        const auto& list=j.at("earnedPerks");if(!list.is_array()||list.size()>4096)throw std::invalid_argument("Too many earned perks");
        for(const auto& value:list) {
            if(!value.is_number_integer())throw std::invalid_argument("Invalid perk ID");
            auto id=value.get<std::uint64_t>();if(!id||id>UINT32_MAX)throw std::out_of_range("Perk ID out of range");
            state.perks.push_back(static_cast<std::uint32_t>(id));
        }
        std::sort(state.perks.begin(),state.perks.end());state.perks.erase(std::unique(state.perks.begin(),state.perks.end()),state.perks.end());
    }
    return state;
}
}
