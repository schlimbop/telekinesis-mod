#pragma once
#include "LoadoutRules.h"
#include <nlohmann/json.hpp>
#include <stdexcept>
namespace Dynasty::Equipment {
inline std::vector<std::uint32_t> DecodeEquipmentHistory(const nlohmann::json& j) {
    std::vector<std::uint32_t> history;
    if(!j.contains("equipmentHistory"))return history;
    const auto& list=j.at("equipmentHistory");
    if(!list.is_array()||list.size()>kEquipmentHistoryLimit)throw std::invalid_argument("Invalid equipment history length");
    for(const auto& value:list) {
        if(!value.is_number_integer())throw std::invalid_argument("Invalid equipment history form");
        const auto id=value.get<std::uint64_t>();
        if(!id||id>UINT32_MAX)throw std::out_of_range("Equipment history form out of range");
        history.push_back(static_cast<std::uint32_t>(id));
    }
    return history;
}
}
