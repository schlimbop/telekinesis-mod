#include "Genetics.h"
namespace Dynasty {
void GeneticsEngine::CapturePersonality(RE::Actor* actor,RE::Actor* a,RE::Actor* b) {
    std::lock_guard lock(mutex_);if(!actor||!a||!b)return;
    auto read=[&](RE::Actor* parent) {
        if(auto e=extras_.find(parent->GetFormID());e!=extras_.end()&&ValidPersonality(e->second.personality))return e->second.personality;
        const auto* base=parent->GetActorBase();
        auto av=[&](int n){float v=parent->AsActorValueOwner()->GetBaseActorValue(static_cast<RE::ActorValue>(6+n));return std::isfinite(v)?std::clamp(v,0.0F,100.0F):15.0F;};
        const float ranged=av(2)+(av(12)+av(13)+av(14)+av(15)+av(16))/5;
        const float melee=av(0)+av(1);
        return Personality{true,base?std::clamp(float(base->GetAggressionLevel())/3.0F,0.0F,1.0F):0.0F,
            base?std::clamp(float(base->GetConfidenceLevel())/4.0F,0.0F,1.0F):0.5F,ranged/(ranged+melee+1)};
    };
    extras_[actor->GetFormID()].personality=BreedPersonality(read(a),read(b),rng_);
}
}
