#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
#include <unordered_map>
#include <limits>
namespace Dynasty::Equipment {
enum class Kind { Armor, Weapon, Ammo };
struct Item { std::uint32_t id{},mask{}; Kind kind{}; int type{}; float quality{}; bool bolt{}; std::uint32_t family{}; std::uint64_t visual{}; };
// Head/body/hands/feet cannot be hidden unless a matching rendered addon replaces them.
inline bool ArmorModelCovers(std::uint32_t mask,std::uint32_t visible) {
    constexpr std::uint32_t bodyParts=1U|4U|8U|128U;
    return (mask&visible)!=0 && (visible&(mask&bodyParts))==(mask&bodyParts);
}
inline bool CanGenerateArmor(std::uint32_t mask,std::uint32_t visible) {
    // Full-head replacement helmets hide the inherited head in the reported setup.
    // Keep generated faces visible; ordinary open-face helmets/circlets remain eligible.
    return !(mask&1U) && ArmorModelCovers(mask,visible);
}
inline bool TwoHanded(int t) { return t==5||t==6||t==7||t==9; }
inline bool RoleWeapon(int role,int type) {
    if(role==1)return type==1||type==3||type==4||type==5||type==6;
    if(role==2)return type==7||type==9;
    if(role==3)return type==8;
    if(role==4)return type==1||type==2;
    if(role==5)return type==2||type==3||type==4;
    return true;
}
inline bool PhysicalArmor(const Item& i){return (i.mask&(1U|2U|4U|8U|128U))!=0;}
inline constexpr std::size_t kEquipmentHistoryLimit=512;
inline void RememberEquipment(std::vector<std::uint32_t>& history,const std::vector<std::uint32_t>& chosen) {
    for(auto id:chosen)if(id)history.push_back(id);
    if(history.size()>kEquipmentHistoryLimit)history.erase(history.begin(),history.end()-kEquipmentHistoryLimit);
}
inline std::uint64_t AppearanceKey(const Item& i) {return i.visual?i.visual:(std::uint64_t(i.kind)<<32)|i.id;}
template<class RNG> std::vector<std::uint32_t> Select(const std::vector<Item>& pool,int role,float quality,RNG& rng,bool coherent=true,const std::vector<std::uint32_t>& recent={}) {
    std::vector<std::uint32_t> result; std::uint32_t occupied=0; int weapon=0,armorType=-1;std::uint32_t family=0;
    std::unordered_map<std::uint32_t,std::uint64_t> visuals;
    for(const auto& i:pool)visuals[i.id]=AppearanceKey(i);
    std::unordered_map<std::uint64_t,std::size_t> usage;
    for(auto id:recent)if(auto it=visuals.find(id);it!=visuals.end())++usage[it->second];
    auto pick=[&](auto eligible) -> const Item* {
        std::vector<const Item*> choices;std::vector<double> weights;
        std::unordered_map<std::uint64_t,std::size_t> variants;
        std::size_t least=std::numeric_limits<std::size_t>::max();
        for(const auto& item:pool)if(eligible(item)) {
            auto key=AppearanceKey(item);auto used=usage[key];
            if(used<least){choices.clear();variants.clear();least=used;}
            if(used==least){choices.push_back(&item);++variants[key];}
        }
        for(const auto* item:choices) {
            double w=0.5+0.5*std::exp(-2.0*std::abs(item->quality-quality));
            if(item->kind==Kind::Weapon)w*=RoleWeapon(role,item->type)?1.5:1.0;
            else if(item->kind==Kind::Armor) {
                const int favored=role==1?2:role==2||role==4?1:0;
                w*=item->type==favored?1.25:1.0;
                if(coherent&&family&&item->family==family)w*=1.5;
            }
            // Enchantment duplicates sharing a visible model cannot swamp unique designs.
            weights.push_back(w/double(variants[AppearanceKey(*item)]));
        }
        if(choices.empty())return nullptr;
        auto* selected=choices[std::discrete_distribution<std::size_t>(weights.begin(),weights.end())(rng)];
        ++usage[AppearanceKey(*selected)];return selected;
    };
    if(auto* w=pick([&](const Item& i){return i.kind==Kind::Weapon;})){result.push_back(w->id);weapon=w->type;}
    auto armorCompatible=[&](const Item& i){return !coherent||armorType<0||!PhysicalArmor(i)||i.type==armorType||i.type==0;};
    auto armor=[&](std::uint32_t wanted) {
        if(occupied&wanted)return;
        auto available=[&](const Item& i){return i.kind==Kind::Armor&&(i.mask&wanted)&&!(i.mask&occupied)&&armorCompatible(i)&&(!(i.mask&512)||(!TwoHanded(weapon)&&weapon!=8));};
        const bool sameClass=coherent&&armorType>=0&&std::any_of(pool.begin(),pool.end(),[&](const Item& i){return available(i)&&i.type==armorType;});
        if(auto* a=pick([&](const Item& i){return available(i)&&(!sameClass||i.type==armorType);})) {
            result.push_back(a->id);occupied|=a->mask;if(wanted==4){armorType=a->type;family=a->family;}
        }
    };
    // Cover the torso first. Multi-slot outfits cannot be overwritten by accessories.
    armor(4);for(auto slot:{128U,8U,1U,2U,32U,64U,512U})armor(slot);
    // Mod accessories can occupy any biped slot, not just the vanilla jewellery slots.
    for(int n=0;n<3;++n)if(auto* a=pick([&](const Item& i){return i.kind==Kind::Armor&&armorCompatible(i)&&!(i.mask&occupied)&&(!(i.mask&512)||(!TwoHanded(weapon)&&weapon!=8));})) {
        result.push_back(a->id);occupied|=a->mask;
    }
    if(weapon==7||weapon==9)if(auto* a=pick([&](const Item& i){return i.kind==Kind::Ammo&&i.bolt==(weapon==9);})){result.push_back(a->id);}
    return result;
}
}
