#pragma once
#include <unordered_set>
#include <vector>

namespace Dynasty {
template<class Spell, class Remove, class Add>
void SynchronizeSpells(const std::vector<Spell*>& current, const std::vector<Spell*>& successor,
    Remove remove, Add add) {
    const std::unordered_set<Spell*> wanted(successor.begin(), successor.end());
    const std::unordered_set<Spell*> owned(current.begin(), current.end());
    for (auto* spell : owned) {
        if (spell && !wanted.contains(spell)) remove(spell);
    }
    for (auto* spell : wanted) {
        if (spell && !owned.contains(spell)) add(spell);
    }
}
}
