#include "Genetics.h"
#include "PerkRules.h"
#include <unordered_set>
#include <mutex>
#include <cmath>
namespace Dynasty {
namespace {
struct Candidate { RE::BGSPerk* perk{};RE::BGSPerk* previous{};int skill{};std::vector<RE::BGSPerk*> branches; };
std::vector<Candidate> catalog;std::once_flag catalogOnce;
bool Safe(RE::BGSPerk* p) {
    if(!p||p->IsDeleted()||!p->GetName()||!*p->GetName()||!p->data.playable||p->data.hidden||p->data.trait||p->perkEntries.empty())return false;
    for(auto* entry:p->perkEntries) {
        if(!entry||entry->GetType()!=RE::PERK_ENTRY_TYPE::kEntryPoint)return false;
        auto* numeric=static_cast<RE::BGSEntryPointPerkEntry*>(entry);
        if(!numeric->functionData||!SafePerkEntry(int(entry->GetType()),int(numeric->functionData->GetType()),
            int(numeric->entryData.function.underlying()),int(numeric->entryData.entryPoint.underlying())))return false;
    }
    std::unordered_set<RE::TESConditionItem*> visited;
    for(auto* c=p->perkConditions.head;c;c=c->next) {
        if(!visited.insert(c).second||visited.size()>128||!SafePerkCondition(int(c->data.functionData.function.underlying()))||
            c->data.object!=RE::CONDITIONITEMOBJECT::kSelf||c->data.flags.usesAliases||c->data.flags.usePackData||
            c->data.flags.global||c->data.flags.swapTarget)return false;
    }
    return true;
}
void ScanPerks() {
    for(int skill=0;skill<18;++skill) {
        auto* info=RE::ActorValueList::GetActorValueInfo(static_cast<RE::ActorValue>(6+skill));
        if(!info||!info->perkTree)continue;
        std::vector<RE::BGSSkillPerkTreeNode*> todo{info->perkTree};std::unordered_set<RE::BGSSkillPerkTreeNode*> visited;
        while(!todo.empty()&&visited.size()<4096&&catalog.size()<4096) {
            auto* node=todo.back();todo.pop_back();if(!node||!visited.insert(node).second)continue;
            for(auto* child:node->children)if(child)todo.push_back(child);
            std::vector<RE::BGSPerk*> branches;
            for(auto* parent:node->parents)if(parent&&parent->perk)branches.push_back(parent->perk);
            std::unordered_set<RE::BGSPerk*> ranks;RE::BGSPerk* previous=nullptr;
            for(auto* p=node->perk;p&&ranks.size()<64&&ranks.insert(p).second;p=p->nextPerk) {
                if(Safe(p))catalog.push_back({p,previous,skill,branches});
                previous=p;
            }
        }
    }
    SKSE::log::info("Safe earned perk catalog: {} skill-tree ranks",catalog.size());
}
bool Owned(RE::Actor* a,RE::BGSPerk* p) {
    if(!p)return false;
    std::unordered_set<RE::BGSPerk*> seen;
    for(auto* rank=p;rank&&seen.size()<64&&seen.insert(rank).second;rank=rank->nextPerk)
        if(a->HasPerk(rank)||a->GetActorBase()->GetPerkIndex(rank).has_value())return true;
    return false;
}
}
void GeneticsEngine::EarnPerks(RE::Actor* actor,int points) {
    std::lock_guard lock(mutex_);
    if(!actor||actor->IsPlayerRef()||actor->IsDead()||!GetGenome(actor))return;
    auto e=extras_.find(actor->GetFormID());auto t=talents_.find(actor->GetFormID());
    if(e==extras_.end()||t==talents_.end()||e->second.slot<0||e->second.slot>=32)return;
    auto* data=RE::TESDataHandler::GetSingleton();auto* base=actor->GetActorBase();
    if(!data||!base||(data->LookupForm<RE::TESNPC>(0x900+e->second.slot,"DynastyHeirs.esp")!=base&&
        data->LookupForm<RE::TESNPC>(0x940+e->second.slot,"DynastyHeirs.esp")!=base))return;
    auto& feature=e->second;feature.perkPoints=CreditPerkPoints(feature.perkPoints,points);
    if(!feature.perkPoints)return;
    std::call_once(catalogOnce,ScanPerks);
    for(int spent=0;spent<64&&feature.perkPoints&&feature.earnedPerks.size()<4096;++spent) {
        std::vector<RE::BGSPerk*> choices;std::vector<double> weights;
        for(const auto& c:catalog) {
            int weight=PerkSkillWeight(feature.role,c.skill);
            if(!weight||c.perk->data.level>actor->GetLevel()||Owned(actor,c.perk)||
                (c.previous&&!Owned(actor,c.previous)))continue;
            if(!c.branches.empty()&&!std::any_of(c.branches.begin(),c.branches.end(),[&](auto* p){return Owned(actor,p);}))continue;
            if(c.perk->perkConditions.head&&!c.perk->perkConditions.IsTrue(actor,actor))continue;
            const float value=actor->AsActorValueOwner()->GetBaseActorValue(static_cast<RE::ActorValue>(6+c.skill));
            if(!std::isfinite(value))continue;
            choices.push_back(c.perk);weights.push_back(weight*(1.0+std::clamp(value,0.0F,100.0F)/25.0));
        }
        if(choices.empty())break;
        auto* perk=choices[std::discrete_distribution<std::size_t>(weights.begin(),weights.end())(rng_)];
        feature.earnedPerks.push_back(perk->GetFormID());
        ApplyPerks(base,t->second,feature.earnedPerks);
        if(!base->GetPerkIndex(perk).has_value()){feature.earnedPerks.pop_back();break;}
        --feature.perkPoints;actor->ApplyPerksFromBase();
        SKSE::log::info("Earned perk {:08X} ({}) for heir {:08X}",perk->GetFormID(),perk->GetName(),actor->GetFormID());
    }
}
}
