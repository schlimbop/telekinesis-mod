#pragma once
#include <algorithm>
namespace Dynasty {
inline int PerkSkillWeight(int role,int skill) {
    switch(role) {
    case 1:return skill==0||skill==1?4:skill==3||skill==5||skill==6?2:0;
    case 2:return skill==2?4:skill==6||skill==9?2:0;
    case 3:return skill>=12&&skill<=16?4:skill==10||skill==17?1:0;
    case 4:return skill==0||skill==9?4:skill==2||skill==6||skill==7||skill==8?2:0;
    case 5:return skill==4||skill==10||skill==17?4:0;
    default:return skill>=0&&skill<18?1:0;
    }
}
inline bool SafePerkCondition(int function) {return function==14||function==277||function==80||function==448;}
inline bool SafePerkEntry(int type,int data,int function,int point) {
    if(type!=2||(data!=1&&data!=2)||!((function>=1&&function<=7)||(function>=12&&function<=14)))return false;
    switch(point) {
    case 0:case 1:case 2:case 4:case 6:case 10:case 15:case 17:case 18:case 20:case 21:
    case 23:case 24:case 25:case 26:case 27:case 28:case 29:case 30:case 31:case 32:case 33:
    case 34:case 35:case 36:case 37:case 38:case 39:case 40:case 41:case 42:case 47:case 48:
    case 49:case 50:case 57:case 58:case 66:case 68:case 71:case 75:case 76:case 77:case 78:
    case 79:case 80:case 83:case 85:case 88:case 89:return true;
    default:return false;
    }
}
inline int CreditPerkPoints(int current,int gained){return std::clamp(std::clamp(current,0,65535)+std::clamp(gained,0,65535),0,65535);}
}
