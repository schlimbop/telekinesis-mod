#pragma once
#include "FamilyRules.h"
#include <nlohmann/json.hpp>
#include <stdexcept>
namespace Dynasty {
inline int BoundedInteger(const nlohmann::json& j,int low,int high) {
    if(!j.is_number_integer())throw std::invalid_argument("Expected integer");
    if(j.is_number_unsigned()) {auto v=j.get<std::uint64_t>();if(v<std::uint64_t(low)||v>std::uint64_t(high))throw std::out_of_range("Integer too large");return int(v);}
    auto v=j.get<std::int64_t>();if(v<low||v>high)throw std::out_of_range("Integer out of range");return int(v);
}
inline nlohmann::json EncodeFamilyDNA(const FamilyDNA& d) {
    if(!ValidFamilyDNA(d))return nullptr;
    return {{"version",1},{"parentA",d.parentA},{"parentB",d.parentB},{"maternal",d.maternal},{"mutations",d.mutations},
        {"raceSource",d.raceSource},{"eyeSource",d.eyeSource},{"hairSource",d.hairSource},{"skinMaternal",d.skinMaternal},{"presetSources",d.presetSources}};
}
inline FamilyDNA DecodeFamilyDNA(const nlohmann::json& j) {
    try {
        if(!j.is_object()||j.at("version")!=1)return {};
        FamilyDNA d;d.recorded=true;d.parentA=j.at("parentA");d.parentB=j.at("parentB");
        d.maternal=j.at("maternal").get<std::array<float,8>>();
        const auto& mutations=j.at("mutations");if(!mutations.is_array()||mutations.size()!=19)return {};
        for(int i=0;i<19;++i)d.mutations[i]=static_cast<std::uint8_t>(BoundedInteger(mutations[i],0,3));
        d.raceSource=BoundedInteger(j.at("raceSource"),0,2);d.eyeSource=BoundedInteger(j.at("eyeSource"),0,2);d.hairSource=BoundedInteger(j.at("hairSource"),0,3);d.skinMaternal=j.at("skinMaternal");const auto& sources=j.at("presetSources");if(!sources.is_array()||sources.size()!=3)return {};
        for(int i=0;i<3;++i)d.presetSources[i]=BoundedInteger(sources[i],0,2);
        return ValidFamilyDNA(d)?d:FamilyDNA{};
    }catch(const std::exception&){return {};}
}
inline nlohmann::json EncodePersonality(const Personality& p) {
    return ValidPersonality(p)?nlohmann::json{{"version",1},{"aggression",p.aggression},{"bravery",p.bravery},{"distance",p.distance}}:nlohmann::json(nullptr);
}
inline Personality DecodePersonality(const nlohmann::json& j) {
    try {if(!j.is_object()||j.at("version")!=1)return {};Personality p{true,j.at("aggression"),j.at("bravery"),j.at("distance")};return ValidPersonality(p)?p:Personality{};}
    catch(const std::exception&){return {};}
}
}
