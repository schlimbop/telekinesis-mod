#pragma once
#include <nlohmann/json.hpp>
#include <algorithm>
#include <charconv>
#include <cctype>
#include <cstdint>
#include <string>
#include <vector>
#include <stdexcept>
namespace Dynasty::Equipment {
inline std::string LowerPlugin(std::string text) {
    std::transform(text.begin(),text.end(),text.begin(),[](unsigned char c){return char(std::tolower(c));});return text;
}
struct Filters { int maxGoldValue{}; std::vector<std::string> plugins;std::vector<std::pair<std::string,std::uint32_t>> forms; };
inline Filters DecodeFilters(const nlohmann::json& j) {
    if(!j.is_object())throw std::invalid_argument("Equipment filters must be an object");
    Filters f;
    if(j.contains("maxGoldValue")) {
        if(!j["maxGoldValue"].is_number_integer())throw std::invalid_argument("maxGoldValue must be an integer");
        auto v=j["maxGoldValue"].get<std::int64_t>();if(v<0||v>100000000)throw std::invalid_argument("maxGoldValue out of range");f.maxGoldValue=int(v);
    }
    if(j.contains("excludedPlugins")) {
        auto list=j["excludedPlugins"].get<std::vector<std::string>>();if(list.size()>4096)throw std::invalid_argument("Too many plugin exclusions");
        for(auto name:list){if(name.empty()||name.size()>260||name.find_first_of("/\\:")!=std::string::npos)throw std::invalid_argument("Invalid plugin name");f.plugins.push_back(LowerPlugin(name));}
    }
    if(j.contains("excludedForms")) {
        const auto& list=j["excludedForms"];if(!list.is_array()||list.size()>4096)throw std::invalid_argument("Invalid form exclusions");
        for(const auto& item:list) {
            auto plugin=item.at("plugin").get<std::string>(),local=item.at("localFormID").get<std::string>();
            if(plugin.empty()||plugin.size()>260||plugin.find_first_of("/\\:")!=std::string::npos)throw std::invalid_argument("Invalid form plugin");
            if(local.starts_with("0x")||local.starts_with("0X"))local.erase(0,2);
            std::uint32_t id{};auto [end,ec]=std::from_chars(local.data(),local.data()+local.size(),id,16);
            if(ec!=std::errc{}||end!=local.data()+local.size()||local.empty()||id>0xFFFFFF||!id)throw std::invalid_argument("Invalid local form ID");
            f.forms.push_back({plugin,id});
        }
    }
    return f;
}
inline bool WithinValueLimit(std::uint32_t value,int fileLimit,int menuLimit) {
    return (fileLimit<=0||value<=std::uint32_t(fileLimit))&&(menuLimit<=0||value<=std::uint32_t(menuLimit));
}
}
