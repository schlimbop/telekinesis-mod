# v0.7.1 crash diagnosis

Report: crash-2026-10-10-02-35-23.log; Skyrim 1.7.104; SkyrimDynasty.dll+0034E26; Appearance.cpp:125 in ReadFace, called by CaptureAppearance/CreateGenome on the Papyrus VM thread. The original PDB's inline symbol name was misleading; the source location and caller establish tint iteration, before rendering or equipment.

The selected tint-list pointer was 0x21. CommonLibSSE-NG v10.1.0 GetTintList reads overlayTintMasks at B30 for every AE runtime >=1.6.629. Skyrim >=1.7.99 shifts this to B38; B30 is then within the base tint array. The version-aware GetPlayerRuntimeData correctly moves its block from 3E0 to 3E8. The mod uses that accessor for tint-list selection in both parental capture and successor application.

The regression executable uses the actual pinned CommonLib header and mocked runtime module, with synthetic player storage at independently specified offsets. It covers 1.5.97, 1.6.353, 1.6.629, 1.6.1170, 1.7.99 and 1.7.104, original and overlay lists, and a poisoned B30 value of 0x21. This proves accessor selection in isolation; it does not substitute for a Skyrim gameplay run.
