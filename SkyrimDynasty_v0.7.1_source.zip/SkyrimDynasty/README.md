# Skyrim Dynasty 0.7.1

Choose Breeding when speaking to a living adult female NPC who is not hostile or fighting. A named adult heir is summoned beside the player immediately, with the conjuration portal and sound. Player and speaker are the genetic parents. No Creation Kit assembly is needed.

## Breeding crash fix

The v0.7.0 crash report on Skyrim 1.7.104 identified an invalid pointer (0x21) while reading player skin tints. CommonLib v10.1.0's GetTintList omits the extra player layout shift introduced in 1.7.99. Both parental capture and succession now select the tint list through GetPlayerRuntimeData, which accounts for the shift. Regression checks cover six SE/AE runtime layouts, original/overlay lists, and the exact stale-pointer value. Appearance inheritance, equipment and save formats are unchanged. A Skyrim gameplay retest is still required.

## Appearance and equipment update

The saved phenotype now includes 19 independently sampled facial traits, separately inherited nose/eye/mouth presets, eye parts, hair style, hair colour, skin tone and varied parental weight/height. Continuous traits draw from both parents with a small bounded variation; siblings no longer always receive the identical arithmetic midpoint. The same phenotype is saved and restored, rather than rerolled on loading.

Skin tone is inherited independently of the racial face shape. A human/elf pairing can therefore produce an elf-shaped head with a lighter inherited skin tone. Compatible human/elf eye parts can cross racial cosmetic restrictions (including Dunmer irises); opposite-sex eye counterparts match iris textures. Hair uses compatible inherited parts or a counterpart with matching identifiers/style when available. Beast and human mesh families are kept separate. Race remains one parent's race; this is not a new hybrid race or an arbitrary skeletal mesh merger.

The loaded face shader is converted to native RGB skin tint, then the same inherited RGB colour is applied to head and body. Face texture families follow the body race. Hair colour is refreshed on the loaded mesh. Rendering refresh runs on the game thread after 3D creation, on loading and after a NiNode rebuild. No global face patches or additional Papyrus Extender installation are required.

Twelve complete armour/weapon sets cover leather, hide, iron, steel, scaled, elven, dwarven, orcish, archer and mage equipment. Each heir gets one saved choice. Armour is a persistent default outfit; weapons/ammunition are supplied and equipped after the actor's 3D loads. Existing heirs without a saved loadout are equipped on upgrade. The update does not repeatedly refill equipment or overwrite later player inventory choices.

Inherited skills/perks, follower recruitment, wait-here, residence, home/dismissal, mortality, summon arrival and choosing a living adult heir on player defeat remain. There are 32 living slots with no lifetime birth cap.

## Upgrade

Fully replace the previous Dynasty version in Vortex. Install SkyrimDynasty_v0.7.1_Vortex.zip, enable/deploy and keep DynastyHeirs.esp enabled. Restart through matching SKSE64 with Address Library. Keep ESS and SKSE co-save files together. Existing v0.6 face data is migrated once from available saved parents; missing-parent fallback keeps the saved face. Fresh births always use the new phenotype. Removing an old deployed template FaceGen override is necessary if one remains from v0.5.

## Validation and limits

Offline checks and compilation cannot establish visual correctness in a running mod list. See VALIDATION.txt for actual build status and TESTING.md for the visual checks still needed. RaceMenu-exclusive sculpts/overlays/body sliders and custom exported face geometry outside native NPC records are not inherited by this build. Native body weight/height are inherited; arbitrary BodySlide presets are not reconstructed. Unsupported custom mesh/texture combinations may need compatibility work.

Source and build scripts are included under Source in the installer. The native renderer incorporates GPL-3.0 code adapted from powerof3 Papyrus Extender; see LICENSE and THIRD_PARTY_NOTICES.txt.
