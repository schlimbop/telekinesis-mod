# Skyrim Dynasty 0.8.4

Choose **Breeding** in ordinary dialogue with a living adult female NPC who is neither hostile nor fighting. A named adult heir is summoned beside the player with a conjuration portal and sound. Player and speaker are the genetic parents. No Creation Kit assembly is needed.

## Inherited levels and companion growth

New adult heirs start at the rounded average of both parents' current levels, with a random variation of up to 10% (at least one level), bounded to the engine's 1�65535 range. The template's bootstrap level no longer determines a visible heir's level.

An heir earns one level for every player level gained while following. Recruitment starts tracking at the current player level; time spent waiting, at home or dismissed gives no retroactive levels. Polling uses the existing five-second follower update. Leaving the party credits any final pending gains. Succession resets every heir's tracking baseline so changing the player level cannot grant free levels.

Health, magicka and stamina each start at a base of 100. Each level above one supplies ten total base-stat points, split according to the inherited physical and magical skills. This stat allocation stays individual and stable. Each earned companion level trains the six strongest skills that are still below 100 by one point each, preserving existing live training before adding the gains. Perks continue to use parental inheritance; companion levels do not invent new perks. Mortal/non-essential status is unchanged.

Level, birth level, stats, allocation and tracking baseline persist in the SKSE co-save. Existing heirs upgrade once using the average of their available parents' current levels, without sibling variation; historical birth levels cannot be recovered from old saves. With one available parent its level is used; with neither, the heir retains its current level. Existing base resources are never reduced by this migration, so an injured heir is not killed by a smaller health budget. Faces and inventory are preserved. Succession transfers the selected heir's actual level, current skills and base stats after the race/level change.

## Face DNA and arrival update

Each new heir has a 50/50 chance of receiving either parent's race (same-race parents retain that race). The selected race supplies a compatible skeleton, skin and head family, while skin tone and compatible eye features still inherit independently.

The 19 facial DNA loci each sample one allele from each parent. Each inherited allele has a 10% chance of a small bounded mutation, stored in the genome so it can pass to later generations. Nose, eye and mouth presets normally inherit from a parent, with a 15% chance to select another valid preset for the chosen race. An incompatible parental preset now selects randomly among valid presets instead of collapsing to the first default. Parent capture reads the player's actual actor-base sliders.

Hair is randomised among playable installed head parts compatible with the heir's race and sex. Hair colour normally comes from either parent, with a 5% chance of a different colour from the selected race's palette. There is a 25% chance of facial paint/tattoo tint from that race's registered masks, including mod masks registered on the race. Paint colours can come from parental paint or the asset palette. These rolls happen once at birth and persist across saves; existing heirs are not rerolled.

Painted faces receive a runtime DDS tint texture built from the same inherited RGB used for the body, with paint blended only where its mask applies. This preserves face/body tone outside the painted region and avoids the old RGB-only material discarding paint. Masks can be loaded from loose files or BSAs. Generated textures are local cache data, not bundled game assets; reloads reconstruct them and retired heirs' cache files are cleaned up.

Summon arrival resolves its vanilla portal, shader and sound on every call, repairing stale saved quest properties. The adult is equipped before being revealed inside the portal, with the effect and sound at its arrival position beside the player. The existing MCM effect toggle remains respected.

## Head visibility and equipment replacement fix

The random equipment generator now checks that armor addons for the heir's race/sex actually cover the head, body, hands and feet slots hidden by the item. An item cannot claim the head slot while using only a ring model. This fixes a concrete incompatibility found with Cheat Room's slot-remapping rings. Generated kits also exclude full-head replacement helmets (slot 30): removing armour restored the user's missing heads, and ordinary full-face helmets were present in the saved kits. Open-face helmets, circlets and compatible mod accessories remain eligible. This is a deliberate visibility restriction on random kits; manually traded equipment is not globally altered. Purely malformed meshes cannot be fully validated from plugin records.

Existing heirs automatically lose invalid items from their generated kit on load; their remaining inventory is retained and their meshes refresh. The inherited face/genome is preserved. This repair targets previously generated equipment, not arbitrary items manually equipped later.

The speech command **Replace everything you carry with a fresh equipment set** now discards the heir's entire current inventory, including traded items, after generating a valid replacement. It updates the outfit, clears old items, then adds exactly the new kit and ammunition. A failed generation or missing outfit leaves the current inventory in place. Ordinary loading never performs this full reset.

## Follower fix retained

Follow me now assigns Skyrim's real Follow procedure targeting the player. Each active follower occupies one of 32 optional persistent quest aliases; neither those aliases nor the actor bases grant essential/protected status. Heirs remain mortal and multiple heirs can accompany the player without taking the vanilla single-follower quest slot.

Following actors path normally nearby. A lightweight player check every five seconds recovers followers separated by an interior door, worldspace transition, or more than 8192 game units. Location changes request an earlier check. Catch-up places followers near the player without replaying birth effects or regenerating inventory. Wait, residence, dismissal, death and succession clear the follow alias. Loading a save upgrades already-following heirs automatically.

This release requires the matching newly compiled 0.8.4 DLL and scripts included in the installer.

## Features

- New heirs receive individual equipment drawn from playable weapons, armour and ammunition in the entire installed load order, including DLC, ESP and ESL mods. There are no preset-kit restrictions. Armour must have a model for the heir's sex/race; pieces cannot overlap occupied slots; ranged weapons receive matching arrows or bolts and two-handed weapons cannot be combined with shields. Every eligible item keeps a nonzero selection chance. Quality biases value without excluding tiers.
- Warrior, archer, mage, rogue and craftsman roles are weighted by inherited skills. Each heir receives an individually varied ground combat style. Dialogue can change the role. Mages can receive suitable installed Destruction combat spells; scripted and high-skill effects are excluded. Craftsman is a cautious combat role, not an autonomous crafting/economy simulator.
- Ordinary heir activation opens speech dialogue for following, waiting, trading equipment, assigning residence, going home, dismissal, ancestry, abilities and combat roles. The old activation command popup is no longer used. Enable subtitles; Fuz Ro D-oh is recommended for silent responses.
- Residents can wander locally and use available beds and eating furniture on daily schedules. Assigned locations must have usable navigation and furniture. Dismissed heirs return to their assigned home. Recall is available in the MCM and orders the heir to wait beside you.
- The optional SkyUI MCM configures living capacity (1–32), inherited skill/external morph strength, gear quality bias, female probability, summon effects, story-perk filtering and combat variation. Settings are stored in the SKSE co-save. Lowering capacity does not remove living heirs.
- The MCM includes a paged genealogy journal with parentage, generation, skills, residence and alive/dead/successor status. Historical entries are compact records; deaths do not retain every actor reference. There is no fixed lifetime entry/birth cap.
- The succession choice previews ancestry, role, strongest skills, inherited perk count and actual equipped items. The MCM's recall action lets you inspect a living heir's appearance before defeat. On defeat, choose a living adult; identity, inherited appearance, skills/perks and actual equipment transfer and their NPC slot is freed.

## Appearance inheritance

Native inheritance retains 19 diploid facial traits with heritable mutations, parental/valid mutated nose-eye-mouth presets, eye parts, random compatible hair, mostly inherited hair RGB, skin RGB, weight and height. The saved phenotype is stable across loads. The loaded face receives the same RGB skin colour as the body, and texture families follow the inherited race. Human/elf pairings can combine an elf-shaped head with a lighter skin tone and compatible red eyes. A parental race still supplies the skeleton/head family; this does not create a new hybrid mesh.

The optional RaceMenu bridge adds live BodyMorph slider inheritance when a compatible SKEE BodyMorph v4/v5 interface is available. Morph-enabled BodySlide meshes are required. It only writes its own `SkyrimDynasty` morph key. A compatible provider exposing the public Preset v1 interface can additionally supply custom face sliders and matched-topology sculpts. Stock upstream RaceMenu does not expose that Preset interface in its interface map, so custom sculpt transfer is **not guaranteed by installing RaceMenu**. The log reports both detected interfaces. Baked replacement faces, arbitrary overlays and body presets without live morph data cannot be reconstructed universally.

The v0.7.1 player-tint layout crash fix remains, including regression checks for Skyrim 1.7.104. The build uses CommonLib runtime accessors rather than the stale GetTintList offset.

## Installation and upgrading

Fully replace the previous Dynasty version in Vortex with `SkyrimDynasty_v0.8.4_Vortex.zip`, enable/deploy and leave `DynastyHeirs.esp` enabled. Restart through matching SKSE64 with Address Library. SkyUI is needed for the MCM; core birth and heir dialogue do not require it. RaceMenu is optional and must support your exact Skyrim runtime. Back up the ESS/SKSE save pair and keep the files together.

Existing v0.6/v0.7 heirs keep their current equipment and inventory changes. New heirs use the installed-item generator. Existing heirs can change combat role or explicitly choose a fresh installed-item kit through dialogue; historical events before this version cannot be reconstructed if the old actor/genome has already been removed. Existing v0.6 native appearance data retains its migration path. Old deployed template FaceGen overrides from v0.5 must be removed if still present.

There are 32 reusable living slots and no lifetime birth cap. Heirs remain mortal and non-essential/non-protected. Summon arrival, courier-style greeting, follower commands, residence, save persistence and succession remain supported.

## Verification

See `VALIDATION.txt` for performed checks and `TESTING.md` for the in-game acceptance checks still needed. No gameplay or visual correctness is claimed from compilation. Corresponding source/build scripts are included under `Source`; see `LICENSE` and `THIRD_PARTY_NOTICES.txt`.
