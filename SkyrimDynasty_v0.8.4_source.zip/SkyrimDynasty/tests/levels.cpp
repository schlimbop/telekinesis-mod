#include "LevelCodec.h"
#include <cstdlib>
#include <iostream>
#include <limits>
#include <random>
using namespace Dynasty;
void Check(bool ok,const char* why) {if(!ok){std::cerr<<why<<'\n';std::exit(1);}}
bool Near(float a,float b){return std::abs(a-b)<0.01F;}
int main() {
    std::array<float,18> skills;skills.fill(30.0F);
    Check(InheritedLevel(20,60,0)==40,"parent average");
    Check(InheritedLevel(20,60,-1)==36&&InheritedLevel(20,60,1)==44,"sibling range");
    Check(InheritedLevel(1,1,-1)==1&&InheritedLevel(65535,65535,1)==65535,"level boundaries");
    std::mt19937_64 rng(822);std::uniform_real_distribution<float> variation(-1,1);
    int low=0,high=0;
    for(int i=0;i<20000;++i){int l=InheritedLevel(20,60,variation(rng));Check(l>=36&&l<=44,"birth range");low+=l<40;high+=l>40;}
    Check(low>7000&&high>7000,"siblings vary both directions");
    auto warrior=skills,mage=skills;
    for(int i:{0,1,2,3,5,6,9})warrior[i]=90;
    for(int i:{12,13,14,15,16})mage[i]=90;
    auto w=NewLevelProgress(40,60,warrior),m=NewLevelProgress(40,60,mage);
    Check(ValidLevelProgress(w)&&ValidLevelProgress(m),"birth stats valid");
    Check(m.stats[1]>w.stats[1]&&w.stats[0]>m.stats[0]&&w.stats[2]>m.stats[2],"inherited specialties weight stats");
    Check(Near(w.stats[0]+w.stats[1]+w.stats[2],300+39*10),"ten total stat points per level");
    auto legacy=NewLevelProgress(1,20,skills);
    PreserveLegacyStats(legacy,{240.0F,10.0F,200.0F});
    Check(legacy.stats==std::array<float,3>{240,100,200},"legacy upgrade never lowers an existing base resource");
    PreserveLegacyStats(legacy,{1.0e10F,std::numeric_limits<float>::quiet_NaN(),-50});
    Check(legacy.stats[0]==1.0e10F&&legacy.stats[1]==100&&ValidLevelProgress(legacy),"finite mod stats retained, invalid stats ignored");
    Check(DecodeLevelProgress(EncodeLevelProgress(legacy)).stats==legacy.stats,"legacy resource floor persists");
    auto p=w;
    Check(EarnHeirLevels(p,60,true)==0,"recruitment gives no retroactive levels");
    Check(EarnHeirLevels(p,61,true)==1&&p.level==41,"following level");
    Check(EarnHeirLevels(p,61,true)==0,"same tick no duplicate");
    Check(EarnHeirLevels(p,64,true)==3&&p.level==44,"multiple gains between ticks");
    Check(EarnHeirLevels(p,65,false)==1&&p.level==45,"final gains credited at dismissal");
    Check(EarnHeirLevels(p,75,false)==0&&p.level==45,"home wait dismissed do not gain");
    Check(EarnHeirLevels(p,80,true)==0,"recruitment after absence does not catch up");
    Check(EarnHeirLevels(p,81,true)==1,"recruited heir resumes earning");
    Check(EarnHeirLevels(p,20,true,true)==0&&p.level==46,"succession drop rebases");
    Check(EarnHeirLevels(p,21,true)==1,"new character earns normally");
    Check(EarnHeirLevels(p,150,true,true)==0&&p.level==47,"succession rise gives no free levels");
    Check(EarnHeirLevels(p,151,true)==1,"growth after higher succession");
    Check(EarnHeirLevels(p,10,true)==0,"external player level reduction");
    Check(ValidLevelProgress(p),"progress remains valid");
    auto capped=NewLevelProgress(65534,1,skills);capped.following=true;
    Check(EarnHeirLevels(capped,65535,true)==1&&capped.level==65535,"uint16 saturation without overflow");
    Check(EarnHeirLevels(capped,65535,true)==0&&ValidLevelProgress(capped),"capped state remains valid");
    auto empty=skills;empty.fill(0);GrowHeirSkills(empty,65535);
    for(float v:empty)Check(v==100,"all uncapped skills eventually progress");
    auto single=skills,batch=skills;single[14]=batch[14]=99.5F;
    for(int i=0;i<12;++i)GrowHeirSkills(single,1);GrowHeirSkills(batch,12);
    Check(single==batch,"batched growth equals individual levels");
    auto trained=skills;trained[4]=70;GrowHeirSkills(trained,1);
    Check(trained[4]==71,"live external skill training retained");
    const auto encoded=EncodeLevelProgress(p);auto decoded=DecodeLevelProgress(nlohmann::json::parse(encoded.dump()));
    Check(decoded.level==p.level&&decoded.birthLevel==p.birthLevel&&decoded.following==p.following&&
        decoded.lastPlayerLevel==p.lastPlayerLevel&&decoded.stats==p.stats&&decoded.growth==p.growth,"actual save roundtrip");
    Check(EarnHeirLevels(decoded,10,true)==0,"reload no duplicate XP");
    for(const auto& bad:{nlohmann::json(nullptr),nlohmann::json::object(),nlohmann::json::array()})
        Check(DecodeLevelProgress(bad).level==0,"missing legacy record requests migration");
    for(const char* key:{"level","birthLevel","lastPlayerLevel"})for(auto badValue:{nlohmann::json(0),nlohmann::json(-1),nlohmann::json(65536),nlohmann::json(4294967297ULL),nlohmann::json(18446744073709551615ULL),nlohmann::json("12")}) {
        auto bad=encoded;bad[key]=badValue;Check(DecodeLevelProgress(bad).level==0,"invalid saved level rejected");
    }
    auto bad=encoded;bad["stats"][0]=std::numeric_limits<float>::infinity();Check(DecodeLevelProgress(bad).level==0,"nonfinite stats rejected");
    bad=encoded;bad["growth"]={10,10,10};Check(DecodeLevelProgress(bad).level==0,"invalid stat budget rejected");
    bad=encoded;bad["following"]=1;Check(DecodeLevelProgress(bad).level==0,"invalid follow flag rejected");
    bad=encoded;bad["birthLevel"]=65535;Check(DecodeLevelProgress(bad).level==0,"birth cannot exceed current level");
    std::cout<<"Heir level rules: 20,000 births, progression, migration/save validation and succession baselines passed\n";
}
