#pragma once
#include "LevelRules.h"
#include <nlohmann/json.hpp>
namespace Dynasty {
inline nlohmann::json EncodeLevelProgress(const LevelProgress& p) {
    if(!ValidLevelProgress(p))return nullptr;
    return {{"version",1},{"level",p.level},{"birthLevel",p.birthLevel},{"lastPlayerLevel",p.lastPlayerLevel},
        {"following",p.following},{"stats",p.stats},{"growth",p.growth}};
}
inline LevelProgress DecodeLevelProgress(const nlohmann::json& j) {
    LevelProgress p;
    try {
        if(!j.is_object()||j.at("version")!=1||!j.at("following").is_boolean())return {};
        auto integer=[&](const char* key) {
            if(!j.at(key).is_number_integer())return 0;
            auto v=j.at(key).get<std::int64_t>();return v>=1&&v<=kMaxHeirLevel?int(v):0;
        };
        p.level=integer("level");p.birthLevel=integer("birthLevel");p.lastPlayerLevel=integer("lastPlayerLevel");
        p.following=j.at("following");p.stats=j.at("stats").get<std::array<float,3>>();
        p.growth=j.at("growth").get<std::array<float,3>>();
        if(!ValidLevelProgress(p))return {};
    }catch(const nlohmann::json::exception&){return {};}
    return p;
}
}
