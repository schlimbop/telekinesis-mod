#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <numeric>
namespace Dynasty {
inline constexpr int kMaxHeirLevel = 65535;
struct LevelProgress {
    int level{}, birthLevel{}, lastPlayerLevel{};
    bool following{false};
    std::array<float,3> stats{}, growth{}; // Health, magicka, stamina; base values only.
};
inline int InheritedLevel(int a, int b, float variation) {
    const float average = (std::clamp(a,1,kMaxHeirLevel) + std::clamp(b,1,kMaxHeirLevel)) * 0.5F;
    const float spread = std::max(1.0F, average * 0.10F);
    return std::clamp(int(std::lround(average + std::clamp(variation,-1.0F,1.0F)*spread)),1,kMaxHeirLevel);
}
inline std::array<float,3> LevelStatGrowth(const std::array<float,18>& skills) {
    auto skill = [&](int i) { return std::isfinite(skills[i]) ? std::clamp(skills[i],0.0F,100.0F)/100.0F : 0.0F; };
    const float physical = (skill(0)+skill(1)+skill(2)+skill(3)+skill(5)+skill(6)+skill(9))/7.0F;
    const float magic = (skill(12)+skill(13)+skill(14)+skill(15)+skill(16))/5.0F;
    std::array<float,3> result{2.0F+physical,0.5F+2.5F*magic,1.0F+physical};
    const float total=std::accumulate(result.begin(),result.end(),0.0F);
    for(auto& value:result)value*=10.0F/total;
    return result;
}
inline LevelProgress NewLevelProgress(int level, int playerLevel, const std::array<float,18>& skills) {
    LevelProgress p;p.level=p.birthLevel=std::clamp(level,1,kMaxHeirLevel);
    p.lastPlayerLevel=std::clamp(playerLevel,1,kMaxHeirLevel);p.growth=LevelStatGrowth(skills);
    for(int i=0;i<3;++i)p.stats[i]=100.0F+(p.level-1)*p.growth[i];
    return p;
}
inline bool ValidLevelProgress(const LevelProgress& p) {
    if(p.level<1||p.level>kMaxHeirLevel||p.birthLevel<1||p.birthLevel>p.level||
       p.lastPlayerLevel<1||p.lastPlayerLevel>kMaxHeirLevel)return false;
    for(int i=0;i<3;++i)if(!std::isfinite(p.stats[i])||p.stats[i]<100.0F||p.stats[i]>655450.0F||
        !std::isfinite(p.growth[i])||p.growth[i]<=0.0F||p.growth[i]>10.0F)return false;
    return std::abs(std::accumulate(p.growth.begin(),p.growth.end(),0.0F)-10.0F)<0.01F;
}
inline int EarnHeirLevels(LevelProgress& p, int playerLevel, bool following, bool resetBaseline=false) {
    playerLevel=std::clamp(playerLevel,1,kMaxHeirLevel);
    // Credit a departing follower's final gains, then stop tracking until re-recruited.
    const int gained=!resetBaseline&&p.following?std::clamp(playerLevel-p.lastPlayerLevel,0,kMaxHeirLevel-p.level):0;
    p.level+=gained;p.lastPlayerLevel=playerLevel;p.following=following;
    for(int i=0;i<3;++i)p.stats[i]+=gained*p.growth[i];
    return gained;
}
inline void GrowHeirSkills(std::array<float,18>& skills,int levels) {
    for(auto& v:skills)v=std::isfinite(v)?std::clamp(v,0.0F,100.0F):0.0F;
    for(int step=0;step<std::clamp(levels,0,kMaxHeirLevel);++step) {
        std::array<int,18> order{};std::iota(order.begin(),order.end(),0);
        std::stable_sort(order.begin(),order.end(),[&](int a,int b){return skills[a]>skills[b];});
        int trained=0;
        for(int i:order)if(skills[i]<100.0F) {skills[i]=std::min(100.0F,skills[i]+1.0F);if(++trained==6)break;}
        if(!trained)break;
    }
}
}
