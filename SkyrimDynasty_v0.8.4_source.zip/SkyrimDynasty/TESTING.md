# In-game acceptance checks still required

1. Fully replace the old version in Vortex, deploy and restart through matching SKSE. Back up ESS/SKSE files together.
2. On Skyrim 1.7.104 repeat Breeding with Danica Pure-Spring (the reported crash partner). Confirm an adult arrives without crashing, beside the player inside the portal/sound. Repeat with another vanilla mother and a mod-added female. Dead, child, hostile and fighting actors must not offer Breeding.
3. Generate siblings with human and Dunmer parents. Compare facial shape, eyes, hair, tone, weight and height. Inspect face/neck/body in daylight for matching RGB. Exit/reload and change cells: traits must remain stable.
4. With at least one installed playable armour/weapon mod, generate varied heirs. Confirm mod-added items can appear, torso coverage, no conflicting slots, arrow/bolt match and no two-handed shield combinations. Inspect SkyrimDynasty.log for installed equipment pool size. Gear quality is probabilistic.
5. Trade equipment through speech, then save/reload and unload/reload the cell. Inventory must not be replenished or replaced. Existing v0.7 heirs must retain their old kits. Change combat role and verify AI preference and mage casting in a suitable encounter.
6. Test follow, wait, home assignment, return home and dismissal through dialogue. At an accessible residence test sleep at night, eating times and daytime wandering. MCM recall should bring the heir beside the player and order waiting.
7. In SkyUI MCM change each setting, save/exit/reload and verify persistence. Lower the cap below existing population: no heir should be deleted, and new births should stop until under cap. Kill an heir and verify the slot can be reused. Use the journal to inspect generation/parents, dead history and residence.
8. Use living-heir inspection/recall for appearance preview. On defeat inspect candidate details and choose a different heir. Confirm actual traded equipment, appearance, skills/perks and identity transfer; the consumed NPC disappears and its slot is reusable. Confirm player story/quest perks are retained.
9. With a runtime-compatible RaceMenu and morph-enabled body, inspect the bridge availability log. Give parents distinct live sliders and check the heir's body and save persistence. Custom face/sculpt transfer is conditional on an exposed Preset interface and matching topology; no such transfer is expected from an unavailable interface.
10. Core birth/dialogue should still work without SkyUI or RaceMenu. Check the game's logs for script errors, missing forms or failed interfaces. Logs establish execution; gameplay/screenshots establish visible correctness.

## Follower regression acceptance (gameplay pending)

1. Upgrade a save from 0.8.0 with at least three heirs already following. Load it and confirm all three resume following without re-recruitment.
2. Recruit several additional heirs through Follow me. Walk/run away, enter/exit an inn, move between interiors sharing the same Location, and fast-travel between holds and worldspaces. Confirm each living follower appears near you within five seconds of resumed gameplay and continues moving normally.
3. Cross adjacent exterior cell borders on foot. Nearby heirs should path naturally instead of teleporting whenever a cell boundary is crossed.
4. Order different heirs to Wait here, assign a home, Go home and Dismiss. Repeat doors/fast travel. None of these heirs should catch up or rejoin without recruitment. Re-recruit them and confirm they move again.
5. Fight with several recruited heirs. Confirm they fight as teammates and remain killable by both the player and enemies. Kill one follower; after death, travel and confirm its corpse never catches up. Create another heir in the freed slot and verify it follows only after recruitment.
6. Save/reload while following, waiting and at home. Confirm each state, identity and equipment persist. Perform succession into a following heir; confirm the consumed NPC never reappears as a follower.
7. Repeat with a vanilla mercenary recruited too; verify heir recruitment does not replace the vanilla follower or make an heir essential/protected.

## Head visibility and clean inventory replacement (gameplay pending)

1. With Cheat Room installed, generate mixed-sex heirs with several mothers. Verify no slot-remapping ring is selected as a head/body garment; open-face helmets/circlets and mod accessories still appear; full-head replacement helmets are not generated.
2. Upgrade a save with a generated full-face helmet or head-hiding ring. Load the save and verify only invalid generated equipment is removed; the head returns with the same inherited face and remaining gear/inventory. Save/reload and verify the repair does not repeat/refill gear.
3. Give an heir spare weapons, armor and stacks of ammunition. Use Replace everything you carry with a fresh equipment set. Confirm old/traded items are gone and only one fresh kit plus its ammunition remains. Repeat and check no old items accumulate.
4. Load/reload a normal heir who has traded equipment. Confirm ordinary loading preserves inventory; a full inventory reset only occurs through the explicit replacement speech command.
5. If an affected heir remains headless, remove all headgear through trading and inspect the resulting SkyrimDynasty.log. Coverage filtering does not prove rendering or rule out external dismemberment/mesh defects.

## Face DNA, hair, paint and summon update (gameplay pending)

1. On an existing save, choose Breeding with effects enabled. Verify an equipped adult arrives next to the player inside the portal with sound, without a sustained invisible state. Repeat MCM recall. Toggle effects off and confirm arrivals remain visible without effects.
2. Generate multiple siblings with the same two parents. Compare nose/eyes/mouth, jaw and other sliders, hair and paint; reload and verify the same saved appearances remain. Inspect parent/player slider data and Appearance DNA messages in SkyrimDynasty.log.
3. Repeat with parents of two different races, checking that either parental race can occur. A short sequence is not guaranteed to split exactly in half; the native test checks the fair race rule over 20,000 births.
4. Compare painted and unpainted heirs in daylight. Face/neck/body tone outside the paint must match; paint should remain visible after cell changes, gear swaps and save/reload. Check a racial facial-tattoo mask added by a mod if available.
5. Produce a further generation using an heir as a parent. Confirm stored mutant alleles remain usable and the new heir has its own random hairstyle. Existing saved heirs must not change appearance merely because this update is installed.
6. Check unavailable/missing paint-mask fallback in the log. A mask failure must leave a visible, matching-colour head, never a black face or crash. Body-overlay tattoos and unexposed/baked custom sculpts remain outside native support.

## Inherited levels and growth (gameplay pending)

1. Generate siblings from parents with known levels, e.g. 20 and 60. Confirm new heirs have levels 36�44 rather than a fixed 10, inherited skills and individual health/magicka/stamina budgets. Confirm the level is correct on arrival, in dialogue and in the succession preview.
2. Recruit several heirs, gain one player level, and wait five seconds of active gameplay. Confirm each gains exactly one level, ten total base-stat points and one point in six uncapped skills. Repeat polling, cell changes and save/reload: no duplicate gains or perk/inventory refill should occur.
3. Leave different heirs waiting, at home and dismissed while gaining levels. Re-recruit them and confirm no absent-period catch-up; gain another player level and verify only followers gain. Test changing follow/wait immediately after a player level increase.
4. Upgrade an existing save with following and waiting heirs. Verify one-time migration using available parents, unchanged faces/inventory/perks and stable levels after subsequent saves. Verify an injured legacy heir survives migration and existing base resources are never reduced. Test one missing parent and both parents absent; the latter retains the current heir level.
5. Take over an heir with a different level through succession. Confirm player level, inherited/current skills and base resources equal the selected heir after race conversion. Other heirs keep their levels without a free gain; following heirs can earn the next player level normally.
6. Check that heirs remain mortal, normal damage/temporary buffs still work, no full healing occurs on each poll, and living-slot recycling gives the next heir fresh birth stats and tracking rather than a deceased heir's values.
