#include "Genetics.h"
#include "InheritanceRules.h"
#include "PlayerAppearance.h"
#include "FaceTint.h"
#include <cmath>
#include <cctype>
#include <memory>
#include <sstream>

namespace Dynasty {
namespace {
using HP = RE::BGSHeadPart;
using Part = HP::HeadPartType;
std::uint32_t Pack(RE::Color c) {
    return std::uint32_t(c.red) | (std::uint32_t(c.green) << 8) |
        (std::uint32_t(c.blue) << 16) | (std::uint32_t(c.alpha) << 24);
}
RE::Color Unpack(std::uint32_t c) {
    return RE::Color(c & 255, (c >> 8) & 255, (c >> 16) & 255, 255);
}
RE::Color Blend(RE::Color a, RE::Color b, float mix) {
    RE::Color result;
    for (std::size_t i = 0; i < 3; ++i)
        result[i] = static_cast<std::uint8_t>(std::clamp(std::lerp(float(a[i]), float(b[i]), mix), 0.0F, 255.0F));
    result.alpha = 255;
    return result;
}
RE::FormID ID(RE::TESForm* form) { return form ? form->GetFormID() : 0; }
bool Owned(RE::TESNPC* base) {
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!base || !data) return false;
    for (auto first : {0x900U, 0x940U})
        for (unsigned i = 0; i < 32; ++i)
            if (data->LookupForm<RE::TESNPC>(first + i, "DynastyHeirs.esp") == base) return true;
    return false;
}
std::string Lower(const char* text) {
    std::string out = text ? text : "";
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) { return char(std::tolower(c)); });
    return out;
}
bool SameHeadFamily(RE::TESRace* a, RE::TESRace* b, RE::SEX sex) {
    if (!a || !b) return false;
    if (a == b) return true;
    auto* pa = a->GetHeadPartByType(Part::kFace, sex);
    auto* pb = b->GetHeadPartByType(Part::kFace, sex);
    if (!pa || !pb) return false;
    auto mesh = Lower(pa->GetModel());
    return !mesh.empty() && mesh == Lower(pb->GetModel()) &&
        Lower(pa->morphs[HP::MorphIndex::kRaceMorph].GetModel()) ==
        Lower(pb->morphs[HP::MorphIndex::kRaceMorph].GetModel());
}
bool Compatible(HP* part, RE::TESRace* race, RE::SEX sex, RE::TESRace* donor = nullptr) {
    if (!part || part->IsExtraPart()) return false;
    const auto flag = sex == RE::SEX::kFemale ? HP::Flag::kFemale : HP::Flag::kMale;
    if (part->flags.any(HP::Flag::kMale, HP::Flag::kFemale) && !part->flags.any(flag)) return false;
    if (!part->validRaces || part->validRaces->HasForm(race)) return true;
    // Face diffuse/normal maps must follow the same racial skin family as the body.
    if (part->type == Part::kFace) return false;
    // Human/elf cosmetic restrictions do not imply incompatible mesh topology.
    // Never put a beast head/eyes on a human skeleton merely to retain a colour.
    return donor && part->validRaces->HasForm(donor) && SameHeadFamily(race, donor, sex);
}
std::string StyleName(HP* part) {
    auto name = Lower(part->GetFormEditorID());
    for (const std::string word : {"female", "male"}) {
        auto pos = name.find(word);
        if (pos != std::string::npos) name.erase(pos, word.size());
    }
    return name;
}
HP* Counterpart(HP* source, RE::TESRace* race, RE::TESRace* donor, RE::SEX sex,
    std::mt19937_64& rng) {
    if (Compatible(source, race, sex, donor)) return source;
    if (!source) return nullptr;
    std::vector<HP*> best;
    int bestScore = -1;
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!data) return nullptr;
    for (auto* part : data->GetFormArray<HP>()) {
        if (!Compatible(part, race, sex, donor) || part->type != source->type) continue;
        int score = 0;
        // Opposite-sex eyes preserve the actual iris texture rather than defaulting blue.
        if (source->textureSet && part->textureSet) {
            if (Lower(source->textureSet->GetTexturePath(RE::BSTextureSet::Texture::kDiffuse)) ==
                Lower(part->textureSet->GetTexturePath(RE::BSTextureSet::Texture::kDiffuse))) score += 100;
        }
        auto from = StyleName(source), to = StyleName(part);
        if (!from.empty() && from == to) score += 200;
        for (const std::string word : {"long", "short", "braid", "ponytail", "bald", "shaved", "mohawk"})
            if (from.find(word) != std::string::npos && to.find(word) != std::string::npos) score += 20;
        if (score > bestScore) { best.clear(); bestScore = score; }
        if (score == bestScore) best.push_back(part);
    }
    if (best.empty() || (source->type==Part::kEyes && bestScore<100)) return nullptr;
    return best[std::uniform_int_distribution<std::size_t>(0, best.size() - 1)(rng)];
}
FaceGenome ReadFace(RE::Actor* actor) {
    FaceGenome out;
    auto* base = actor->GetActorBase();
    auto* face = actor==RE::PlayerCharacter::GetSingleton()?base:base->GetRootFaceNPC();
    out.sex = base->GetSex();
    out.race = ID(actor->GetRace());
    out.bodyColor = Pack(face->bodyTintColor);
    out.weight = std::clamp(base->weight, 0.0F, 100.0F);
    if (face->faceData) {
        for (unsigned i = 0; i < 19; ++i) {
            float v = NormaliseFaceMorph(face->faceData->morphs[i]);
            out.morphs[i] = {v, v}; out.expression[i] = v;
        }
        std::copy_n(face->faceData->parts, 4, out.presets.begin());
    }
    if (face->headRelatedData) {
        out.hairColor = ID(face->headRelatedData->hairColor);
        out.faceTexture = ID(face->headRelatedData->faceDetails);
    }
    if (auto* race = actor->GetRace(); race && race->faceRelatedData[out.sex] && !out.hairColor)
        out.hairColor = ID(race->faceRelatedData[out.sex]->defaultHairColor);
    if (auto* colour = RE::TESForm::LookupByID<RE::BGSColorForm>(out.hairColor)) out.hairRGB = Pack(colour->color);
    auto** parts = face->HasOverlays() ? face->GetBaseOverlays() : face->headParts;
    auto count = face->HasOverlays() ? face->GetNumBaseOverlays() : std::uint32_t(std::max<int>(0, face->numHeadParts));
    if (parts) for (unsigned i = 0; i < std::min(count, 64U); ++i)
        if (parts[i] && !parts[i]->IsExtraPart()) out.headParts.push_back(ID(parts[i]));
    if (face->tintLayers) for (auto* layer : *face->tintLayers)
        if (layer && out.tints.size() < 128) out.tints.push_back(*layer);
    if (actor == RE::PlayerCharacter::GetSingleton()) {
        if (auto* masks = PlayerTintMasks(RE::PlayerCharacter::GetSingleton()))
            for (auto* mask : *masks)
                if (mask && mask->type == RE::TintMask::Type::kSkinTone) out.bodyColor = Pack(mask->color);
    }
    return out;
}
HP* RandomHair(RE::TESRace* race, RE::SEX sex, std::mt19937_64& rng, RE::FormID exclude=0) {
    std::vector<HP*> choices;
    if (auto* data=RE::TESDataHandler::GetSingleton()) for (auto* part:data->GetFormArray<HP>()) {
        if (part && part->GetFormID()!=exclude && !part->IsDeleted() && part->type==Part::kHair && part->flags.any(HP::Flag::kPlayable) &&
            Compatible(part,race,sex) && part->GetModel() && *part->GetModel()) choices.push_back(part);
    }
    return choices.empty()?nullptr:choices[std::uniform_int_distribution<std::size_t>(0,choices.size()-1)(rng)];
}
using TintAsset = RE::TESRace::FaceRelatedData::TintAsset;
using TintType = TintAsset::TintLayer::SkinTone;
bool FacePaint(FaceGenome& result, const FaceGenome& a, const FaceGenome& b, std::mt19937_64& rng,bool force=false,std::uint16_t exclude=UINT16_MAX) {
    auto* race=RE::TESForm::LookupByID<RE::TESRace>(result.race);
    auto* face=race?race->faceRelatedData[result.sex]:nullptr;
    if (!face || !face->tintMasks || (!force&&!Chance(kFacePaintChance,rng))) return false;
    std::vector<TintAsset*> choices;
    for (auto* asset:*face->tintMasks) if (asset && asset->texture.skinTone==TintType::kPaint &&
        !asset->texture.file.textureName.empty()) choices.push_back(asset);
    if (choices.empty()) return false;
    if(force&&std::any_of(choices.begin(),choices.end(),[&](const auto* asset){return asset->texture.index!=exclude;}))
        std::erase_if(choices,[&](const auto* asset){return asset->texture.index==exclude;});
    auto* asset=choices[std::uniform_int_distribution<std::size_t>(0,choices.size()-1)(rng)];
    std::vector<RE::Color> colours;
    for (const auto* parent:{&a,&b}) {
        auto* pr=RE::TESForm::LookupByID<RE::TESRace>(parent->race);
        auto* pf=pr?pr->faceRelatedData[parent->sex]:nullptr;
        if (!pf || !pf->tintMasks) continue;
        for (const auto& layer:parent->tints) if (layer.interpolationValue) for(auto* candidate:*pf->tintMasks)
            if (candidate && candidate->texture.index==layer.tintIndex && candidate->texture.skinTone==TintType::kPaint)
                colours.push_back(layer.tintColor);
    }
    // Installed racial paint/tattoo palettes remain available without a painted parent.
    for (auto* colour:asset->presets.colors) if (colour) colours.push_back(colour->color);
    if (colours.empty() && asset->texture.presetDefault) colours.push_back(asset->texture.presetDefault->color);
    if (colours.empty()) colours.push_back(RE::Color(35,35,35,255));
    RE::TESNPC::Layer layer{};
    layer.tintIndex=asset->texture.index;
    layer.tintColor=colours[std::uniform_int_distribution<std::size_t>(0,colours.size()-1)(rng)];
    layer.interpolationValue=std::uniform_int_distribution<std::uint16_t>(65,100)(rng);
    result.tints.push_back(layer);
    return true;
}
void RepairParts(FaceGenome& face) {
    std::erase_if(face.headParts,[](auto id){auto* p=RE::TESForm::LookupByID<HP>(id);return !p||p->IsDeleted();});
    auto* race=RE::TESForm::LookupByID<RE::TESRace>(face.race);if(!race)return;
    for(auto type:{Part::kFace,Part::kEyes,Part::kHair,Part::kEyebrows}) {
        const bool present=std::any_of(face.headParts.begin(),face.headParts.end(),[&](auto id){auto* p=RE::TESForm::LookupByID<HP>(id);return p&&p->type==type;});
        if(!present)if(auto* fallback=race->GetHeadPartByType(type,face.sex))face.headParts.push_back(ID(fallback));
    }
}
} // namespace

bool GeneticsEngine::CaptureAppearance(RE::Actor* heir, RE::Actor* parentA, RE::Actor* parentB) {
    std::lock_guard lock(mutex_);
    if (!heir || !parentA || !parentB || !heir->GetActorBase() ||
        !parentA->GetActorBase() || !parentB->GetActorBase()) return false;
    auto read = [&](RE::Actor* actor) {
        auto it = faces_.find(actor->GetFormID());
        return it == faces_.end() || it->second.needsMigration ? ReadFace(actor) : it->second;
    };
    const auto a = read(parentA), b = read(parentB);
    std::bernoulli_distribution coin(0.5);
    std::uniform_real_distribution<float> dominance(0.0F, 1.0F);
    std::normal_distribution<float> variation(0.0F, 0.012F);
    const auto inheritedRace = ParentalRace(a.race, b.race, rng_);
    auto* race = RE::TESForm::LookupByID<RE::TESRace>(inheritedRace);
    const auto sex = heir->GetActorBase()->GetSex();
    if (!race || race->IsChildRace() || !race->faceRelatedData[sex]) return false;
    FamilyDNA family;family.recorded=true;family.maternal=FamilyDominance(rng_);
    family.parentA=std::string(parentA->GetDisplayFullName()?parentA->GetDisplayFullName():"Parent A").substr(0,256);
    family.parentB=std::string(parentB->GetDisplayFullName()?parentB->GetDisplayFullName():"Parent B").substr(0,256);
    family.raceSource=a.race==b.race?0:inheritedRace==a.race?1:2;
    family.skinMaternal=dominance(rng_);
    FaceGenome result;
    result.race = inheritedRace; result.sex = sex;
    result.weight = std::clamp(std::lerp(a.weight, b.weight, dominance(rng_)) + variation(rng_) * 100.0F, 0.0F, 100.0F);
    // One shared RGB value is used for the rendered face, neck, hands and body.
    result.bodyColor = Pack(Blend(Unpack(a.bodyColor), Unpack(b.bodyColor), family.skinMaternal));
    const auto& hairParent = coin(rng_) ? a : b;
    family.hairSource=&hairParent==&a?1:2;
    result.hairColor = hairParent.hairColor;
    result.hairRGB = hairParent.hairRGB;
    if (!result.hairColor) {
        const auto& fallback=a.hairColor?a:b;
        result.hairColor=fallback.hairColor;result.hairRGB=fallback.hairRGB;family.hairSource=&fallback==&a?1:2;
    }
    auto* raceFace = race->faceRelatedData[sex];
    bool hairMutation = false;
    if (Chance(kHairColourMutationChance,rng_) && raceFace->availableHairColors) {
        std::vector<RE::BGSColorForm*> colours;
        for (auto* colour:*raceFace->availableHairColors)
            if (colour && colour->GetFormID()!=result.hairColor && Pack(colour->color)!=result.hairRGB) colours.push_back(colour);
        if (!colours.empty()) {
            auto* colour=colours[std::uniform_int_distribution<std::size_t>(0,colours.size()-1)(rng_)];
            result.hairColor=ID(colour); result.hairRGB=Pack(colour->color); hairMutation=true;
        }
    }
    if(hairMutation)family.hairSource=3;
    result.faceTexture = ID(raceFace->defaultFaceDetailsTextureSet);
    // Race supplies a coherent skin/texture family. Tone is inherited independently.
    result.skin = ID(race->skin); result.farSkin = 0;
    for (unsigned i = 0; i < 19; ++i) {
        bool mutatedA=false,mutatedB=false;
        result.morphs[i] = {FaceAllele(a.morphs[i].a,a.morphs[i].b,rng_,&mutatedA), FaceAllele(b.morphs[i].a,b.morphs[i].b,rng_,&mutatedB)};
        family.mutations[i]=static_cast<std::uint8_t>((mutatedA?1:0)|(mutatedB?2:0));
        result.expression[i] = InheritedTrait(result.morphs[i].a, result.morphs[i].b,
            family.maternal[kFaceGroup[i]], std::clamp(variation(rng_), -0.03F, 0.03F));
    }
    for (unsigned i = 0; i < 4; ++i) {
        if(i==1){result.presets[i]=-1;continue;}
        const unsigned group=i==0?0:i==2?3:5;
        const bool maternal=family.maternal[group]>0.5F;
        const int preferred=(maternal?b:a).presets[i];
        result.presets[i]=FacePreset(preferred,preferred,raceFace->availableMorphs[i].morphFlags,rng_);
        family.presetSources[i==0?0:i==2?1:2]=result.presets[i]==preferred?(maternal?2:1):0;
    }
    for (unsigned type = 0; type < unsigned(Part::kTotal); ++type) {
        if (type == unsigned(Part::kScar)) continue;
        const bool maternal=type==unsigned(Part::kEyes)?family.maternal[3]>0.5F:
            type==unsigned(Part::kEyebrows)?family.maternal[4]>0.5F:coin(rng_);
        const auto& first = maternal ? b : a;
        const auto& second = &first == &a ? b : a;
        HP* selected = type==unsigned(Part::kHair)?RandomHair(race,sex,rng_):nullptr;
        for (const auto* candidate : {&first, &second}) {
            if (selected) break;
            auto* donor = RE::TESForm::LookupByID<RE::TESRace>(candidate->race);
            for (auto id : candidate->headParts) {
                auto* part = RE::TESForm::LookupByID<HP>(id);
                if (part && part->type == static_cast<Part>(type)) {
                    selected = Counterpart(part, race, donor, sex, rng_);
                    if (selected) {if(type==unsigned(Part::kEyes))family.eyeSource=candidate==&a?1:2;break;}
                }
            }
            if (selected) break;
        }
        if (!selected) selected = race->GetHeadPartByType(static_cast<Part>(type), sex);
        if (selected) result.headParts.push_back(ID(selected));
    }
    if (!std::any_of(result.headParts.begin(),result.headParts.end(),[](auto id){auto* p=RE::TESForm::LookupByID<HP>(id);return p&&p->type==Part::kFace;})) return false;
    if (raceFace->tintMasks) for (auto* asset : *raceFace->tintMasks) {
        if (!asset || asset->texture.skinTone != RE::TESRace::FaceRelatedData::TintAsset::TintLayer::SkinTone::kSkinTone) continue;
        RE::TESNPC::Layer layer{};
        layer.tintIndex = asset->texture.index;
        layer.tintColor = Unpack(result.bodyColor); layer.interpolationValue = 100;
        result.tints.push_back(layer);
        break;
    }
    FacePaint(result,a,b,rng_);
    SKSE::log::info("Appearance DNA {:08X}: 10% allele / 15% preset mutation; hair mutation {}; {} tint layers",
        heir->GetFormID(),hairMutation,result.tints.size());
    SKSE::log::info("Inherited phenotype {:08X}: parents {:08X}/{:08X}; race {:08X}; skin {:08X}; hair {:08X}; nose/eye/mouth {}/{}/{}; jaw {:.3f}",
        heir->GetFormID(), parentA->GetFormID(), parentB->GetFormID(), result.race, result.bodyColor,
        result.hairColor, result.presets[0], result.presets[2], result.presets[3], result.expression[3]);
    extras_[heir->GetFormID()].family=std::move(family);
    faces_[heir->GetFormID()] = std::move(result);
    return true;
}

RE::TESRace* GeneticsEngine::InheritedRace(RE::Actor* actor) const {
    std::lock_guard lock(mutex_);
    if (!actor) return nullptr;
    auto it = faces_.find(actor->GetFormID());
    return it == faces_.end() ? nullptr : RE::TESForm::LookupByID<RE::TESRace>(it->second.race);
}

bool GeneticsEngine::ApplyAppearance(RE::Actor* actor) {
    std::lock_guard lock(mutex_);
    if (!actor) return false;
    auto it = faces_.find(actor->GetFormID());
    auto* base = actor->GetActorBase();
    if (it == faces_.end() || !base || (!Owned(base) && actor != RE::PlayerCharacter::GetSingleton())) return false;
    if (it->second.needsMigration) {
        auto genome = GetGenome(actor);
        auto* a = genome ? RE::TESForm::LookupByID<RE::Actor>(genome->parentAFormID) : nullptr;
        auto* b = genome ? RE::TESForm::LookupByID<RE::Actor>(genome->parentBFormID) : nullptr;
        if (a && b && CaptureAppearance(actor, a, b)) {
            it = faces_.find(actor->GetFormID());
            SKSE::log::info("Migrated v0.6 parental phenotype for {:08X}", actor->GetFormID());
        } else {
            it->second.needsMigration = false;
            it->second.sex = base->GetSex();
        }
    }
    RepairParts(it->second);
    const auto& face = it->second;
    auto* race = RE::TESForm::LookupByID<RE::TESRace>(face.race);
    if (!race) return false;
    std::vector<HP*> parts;
    for (auto id : face.headParts) {
        auto* part = RE::TESForm::LookupByID<HP>(id);
        if (part) {
            parts.push_back(part);
            for (auto* extra : part->extraParts)
                if (extra && std::find(parts.begin(), parts.end(), extra) == parts.end()) parts.push_back(extra);
        }
    }
    if (parts.empty() || parts.size() > 127 || !std::any_of(parts.begin(),parts.end(),[](auto* p){return p->type==Part::kFace;})) return false;
    auto** allocated = RE::calloc<HP*>(parts.size());
    if (!allocated) return false;
    std::copy(parts.begin(), parts.end(), allocated);
    // Skyrim can render an overlay list instead of headParts; update both before replacing the owned array.
    if(base->HasOverlays())for(auto* part:parts)
        if(!part->IsExtraPart()&&part->type!=Part::kMisc&&base->GetCurrentHeadPartByType(part->type.get())!=part)
            base->ChangeHeadPart(part);
    RE::free(base->headParts);
    base->headParts = allocated;
    base->numHeadParts = static_cast<std::int8_t>(parts.size());
    base->faceNPC = nullptr;
    if (auto genome = GetGenome(actor)) {
        if (genome->sex == Sex::Female) base->actorData.actorBaseFlags.set(RE::ACTOR_BASE_DATA::Flag::kFemale);
        else base->actorData.actorBaseFlags.reset(RE::ACTOR_BASE_DATA::Flag::kFemale);
    }
    base->race = race;
    if (!base->faceData) base->faceData = RE::calloc<RE::TESNPC::FaceData>(1);
    if (!base->faceData) return false;
    for (unsigned i = 0; i < 19; ++i)
        base->faceData->morphs[i] = face.expression[i];
    std::copy(face.presets.begin(), face.presets.end(), base->faceData->parts);
    base->weight = face.weight;
    base->bodyTintColor = Unpack(face.bodyColor);
    base->skin = RE::TESForm::LookupByID<RE::TESObjectARMO>(face.skin);
    base->farSkin = RE::TESForm::LookupByID<RE::TESObjectARMO>(face.farSkin);
    base->SetHairColor(RE::TESForm::LookupByID<RE::BGSColorForm>(face.hairColor));
    base->SetFaceTexture(RE::TESForm::LookupByID<RE::BGSTextureSet>(face.faceTexture));
    if (!base->tintLayers) {
        // This object becomes owned by TESNPC; use Skyrim's allocator.
        auto* layers = RE::calloc<RE::BSTArray<RE::TESNPC::Layer*>>(1);
        if (!layers) return false;
        base->tintLayers = std::construct_at(layers);
    }
    for (auto* layer : *base->tintLayers) RE::free(layer);
    base->tintLayers->clear();
    for (const auto& saved : face.tints) {
        auto* layer = RE::calloc<RE::TESNPC::Layer>(1);
        if (layer) { *layer = saved; base->tintLayers->push_back(layer); }
    }
    if (actor != RE::PlayerCharacter::GetSingleton()) {
        // Levelled/non-unique NPCs use live FaceGen, not a stale exported head NIF.
        base->actorData.actorBaseFlags.reset(RE::ACTOR_BASE_DATA::Flag::kUnique);
        base->actorData.actorBaseFlags.set(RE::ACTOR_BASE_DATA::Flag::kIsChargenFacePreset);
    }
    if (actor == RE::PlayerCharacter::GetSingleton()) {
        // Player rendering reads a separate per-player tint list, not NPC tintLayers.
        auto* player = RE::PlayerCharacter::GetSingleton();
        auto* masks = PlayerTintMasks(player);
        auto* racialFace = race->faceRelatedData[base->GetSex()];
        if (masks) for (auto* mask : *masks) {
            if (!mask) continue;
            mask->alpha = 0.0F; // Do not retain the predecessor's cosmetics.
            if (mask->type == RE::TintMask::Type::kSkinTone) {
                mask->color = Unpack(face.bodyColor);
                mask->alpha = 1.0F;
                continue;
            }
            if (!racialFace || !racialFace->tintMasks) continue;
            for (const auto& layer : face.tints) {
                for (auto* asset : *racialFace->tintMasks) {
                    if (asset && asset->texture.index == layer.tintIndex &&
                        asset->texture.skinTone.underlying() == mask->type.underlying()) {
                        mask->color = layer.tintColor;
                        mask->alpha = layer.interpolationValue / 100.0F;
                    }
                }
            }
        }
    }
    base->AddChange(RE::TESNPC::ChangeFlags::kFace | RE::TESNPC::ChangeFlags::kRace);
    SKSE::log::info("Applied parental face: actor {:08X}, race {:08X}, {} head parts, {} tint layers",
        actor->GetFormID(), face.race, parts.size(), face.tints.size());
    return true; // Papyrus queues the 3D update after this function returns.
}

// RGB skin material refresh follows the engine API pattern used by Papyrus Extender.
// See THIRD_PARTY_NOTICES.txt for attribution and GPL-3.0 licensing. Only our heirs/successor enter here.
bool GeneticsEngine::RefreshAppearance(RE::Actor* actor) {
    std::lock_guard lock(mutex_);
    if (!actor || !actor->Is3DLoaded() || !ApplyAppearance(actor)) return false;
    ApplyExternalLook(actor);
    auto it = faces_.find(actor->GetFormID());
    if (it == faces_.end()) return false;
    const auto& face = it->second;
    auto* base = actor->GetActorBase();
    auto* root = actor->Get3D(false);
    auto* faceNode = actor->GetFaceNode();
    auto* part = base->GetCurrentHeadPartByType(Part::kFace);
    if (!root || !faceNode || !part) return false;
    // Same native call as SKSE RegenerateHead: rebuild the inherited face morphs.
    RE::BSFaceGenManager::GetSingleton()->PrepareHeadPartForShaders(faceNode, part, base);
    const RE::NiColor skin(Unpack(face.bodyColor));
    const auto paintTexture = BuildFaceTintTexture(actor->GetFormID(), face);
    bool tinted = false;
    RE::BSVisit::TraverseScenegraphGeometries(faceNode, [&](RE::BSGeometry* geometry) {
        auto* shader = geometry->lightingShaderProp_cast();
        auto* material = shader ? static_cast<RE::BSLightingShaderMaterialBase*>(shader->material) : nullptr;
        if (material && (material->GetFeature() == RE::BSShaderMaterial::Feature::kFaceGen ||
            material->GetFeature() == RE::BSShaderMaterial::Feature::kFaceGenRGBTint)) {
            if (!paintTexture.empty() && ApplyFaceTintTexture(geometry, shader, material, paintTexture)) {
                tinted=true;
                return RE::BSVisit::BSVisitControl::kContinue;
            }
            auto* rgb = RE::BSLightingShaderMaterialBase::CreateMaterial<RE::BSLightingShaderMaterialFacegenTint>();
            if (rgb) {
                rgb->CopyBaseMembers(material);
                rgb->tintColor = skin;
                shader->SetFlags(RE::BSShaderProperty::EShaderPropertyFlag8::kFace, false);
                shader->SetFlags(RE::BSShaderProperty::EShaderPropertyFlag8::kFaceGenRGBTint, true);
                shader->SetMaterial(rgb, true);
                shader->SetupGeometry(geometry);
                shader->FinishSetupGeometry(geometry);
                rgb->~BSLightingShaderMaterialFacegenTint();
                RE::MemoryManager::GetSingleton()->GetThreadScrapHeap()->Deallocate(rgb);
                tinted = true;
            }
        }
        return RE::BSVisit::BSVisitControl::kContinue;
    });
    root->UpdateBodyTint(skin);
    root->UpdateHairColor(RE::NiColor(Unpack(face.hairRGB)));
    base->UpdateNeck(faceNode);
    SKSE::log::info("Rendered phenotype {:08X}: matched head/body RGB {:08X}; face material {}",
        actor->GetFormID(), face.bodyColor, tinted ? "ready" : "unavailable");
    return tinted;
}

bool GeneticsEngine::RepairAppearance(RE::Actor* actor,int mode) {
    std::lock_guard lock(mutex_);
    if(!actor||actor->IsDead()||actor->IsPlayerRef()||!Owned(actor->GetActorBase())||mode<0||mode>2)return false;
    auto it=faces_.find(actor->GetFormID());if(it==faces_.end())return false;
    FaceGenome candidate=it->second;auto* race=RE::TESForm::LookupByID<RE::TESRace>(candidate.race);
    if(!race||!race->faceRelatedData[candidate.sex])return false;
    RepairParts(candidate);
    if(mode==1) {
        RE::FormID current{};for(auto id:candidate.headParts)if(auto* p=RE::TESForm::LookupByID<HP>(id);p&&p->type==Part::kHair)current=id;
        auto* hair=RandomHair(race,candidate.sex,rng_,current);if(!hair)return false;
        std::erase_if(candidate.headParts,[](auto id){auto* p=RE::TESForm::LookupByID<HP>(id);return p&&p->type==Part::kHair;});
        candidate.headParts.push_back(ID(hair));
    }else if(mode==2) {
        auto* rf=race->faceRelatedData[candidate.sex];
        std::uint16_t oldPaint=UINT16_MAX;
        std::erase_if(candidate.tints,[&](const auto& layer){if(!rf->tintMasks)return false;
            const bool paint=std::any_of(rf->tintMasks->begin(),rf->tintMasks->end(),[&](auto* a){return a&&a->texture.index==layer.tintIndex&&a->texture.skinTone==TintType::kPaint;});
            if(paint)oldPaint=layer.tintIndex;return paint;});
        if(!FacePaint(candidate,it->second,it->second,rng_,true,oldPaint))return false;
    }
    it->second=std::move(candidate);ForgetFaceTintTexture(actor->GetFormID());
    extras_[actor->GetFormID()].lookApplied=false;
    auto handle=actor->GetHandle();
    SKSE::GetTaskInterface()->AddTask([handle,mode](){
        auto heir=handle.get();if(!heir||!heir->Is3DLoaded()||heir->IsDead())return;
        auto& engine=GeneticsEngine::GetSingleton();
        auto* oldHair=heir->GetActorBase()->GetCurrentHeadPartByType(Part::kHair);
        if(!engine.ApplyAppearance(heir.get()))return;
        auto* newHair=heir->GetActorBase()->GetHeadPartByType(Part::kHair);
        // Read both at execution time so rapid requests cannot leave a stale intermediate hairstyle.
        if(oldHair&&newHair&&oldHair!=newHair)heir->ChangeHeadPart(oldHair,newHair);
        engine.RefreshAppearance(heir.get());
        SKSE::log::info("Applied cosmetic repair {:08X}: mode {}",heir->GetFormID(),mode);
    });
    return true;
}

std::string GeneticsEngine::DNAReport(RE::Actor* actor) const {
    std::lock_guard lock(mutex_);if(!actor)return "Unavailable";
    auto it=faces_.find(actor->GetFormID());if(it==faces_.end())return "No saved appearance DNA.";
    const auto& f=it->second;std::ostringstream out;
    auto* race=RE::TESForm::LookupByID<RE::TESRace>(f.race);
    out<<(actor->GetDisplayFullName()?actor->GetDisplayFullName():"Heir")<<" | "<<(race?race->GetName():"Missing race")<<"\n";
    auto e=extras_.find(actor->GetFormID());const auto* d=e!=extras_.end()&&ValidFamilyDNA(e->second.family)?&e->second.family:nullptr;
    if(d) {
        out<<"A: "<<d->parentA<<" | B: "<<d->parentB<<"\nRace from "<<(d->raceSource==0?"both parents":d->raceSource==1?"A":"B");
        out<<"; eyes from "<<(d->eyeSource==0?"racial fallback":d->eyeSource==1?"A":"B")<<"; hair colour "<<(d->hairSource==3?"mutation":d->hairSource==1?"from A":"from B");
        out<<"\nPreset origins nose/eyes/mouth: ";for(int source:d->presetSources)out<<(source==1?"A":source==2?"B":"new/compatible fallback")<<"; ";
        out<<"\nSkin blend: "<<int(d->skinMaternal*100)<<"% B\nFacial group contribution (% B): ";
        for(int i=0;i<7;++i)out<<kFaceGroupNames[i]<<" "<<int(d->maternal[i]*100)<<"%; ";
    }else out<<"Legacy face: parent-of-origin history was not recorded. Saved alleles remain available.";
    out<<"\nSkin RGB "<<(f.bodyColor&255)<<","<<((f.bodyColor>>8)&255)<<","<<((f.bodyColor>>16)&255);
    out<<" | presets nose/eyes/mouth "<<f.presets[0]<<"/"<<f.presets[2]<<"/"<<f.presets[3];
    out<<"\nNative facial sliders are shown; unavailable custom sculpts/body overlays are not reconstructed.";
    return out.str();
}

std::string GeneticsEngine::DNATraitName(int index) const {
    constexpr std::array names{"Nose length","Nose height","Jaw height","Jaw width","Jaw depth","Cheek height","Cheek depth","Eye height","Eye spacing","Brow height","Brow spacing","Brow depth","Lip height","Lip depth","Chin width","Chin height","Chin depth","Eye depth","Other morph"};
    return index>=0&&index<19?names[index]:"Unavailable";
}
std::string GeneticsEngine::DNATrait(RE::Actor* actor,int index) const {
    std::lock_guard lock(mutex_);if(!actor||index<0||index>=19)return "Unavailable";
    auto f=faces_.find(actor->GetFormID());if(f==faces_.end())return "Unavailable";
    auto e=extras_.find(actor->GetFormID());const auto bits=e!=extras_.end()&&ValidFamilyDNA(e->second.family)?e->second.family.mutations[index]:0;
    return std::format("{:.2f}{} / {:.2f}{} = {:.2f}",f->second.morphs[index].a,bits&1?"*":"",f->second.morphs[index].b,bits&2?"*":"",f->second.expression[index]);
}

void GeneticsEngine::SaveAppearance(SKSE::SerializationInterface* stream) const {
    if (!stream->OpenRecord('DYFA', 2)) return;
    auto count = static_cast<std::uint32_t>(faces_.size());
    stream->WriteRecordData(count);
    for (const auto& [id, f] : faces_) {
        stream->WriteRecordData(id); stream->WriteRecordData(f.morphs); stream->WriteRecordData(f.expression);
        stream->WriteRecordData(f.sex); stream->WriteRecordData(f.presets);
        for (auto form : {f.race, f.hairColor, f.faceTexture, f.skin, f.farSkin}) stream->WriteRecordData(form);
        stream->WriteRecordData(f.bodyColor); stream->WriteRecordData(f.hairRGB); stream->WriteRecordData(f.weight);
        auto parts = static_cast<std::uint32_t>(f.headParts.size()); stream->WriteRecordData(parts);
        for (auto form : f.headParts) stream->WriteRecordData(form);
        auto tints = static_cast<std::uint32_t>(f.tints.size()); stream->WriteRecordData(tints);
        for (const auto& t : f.tints) {
            stream->WriteRecordData(Pack(t.tintColor)); stream->WriteRecordData(t.tintIndex);
            stream->WriteRecordData(t.preset); stream->WriteRecordData(t.interpolationValue);
        }
    }
}
void GeneticsEngine::LoadAppearance(SKSE::SerializationInterface* stream, std::uint32_t version) {
    if (version < 1 || version > 2) return;
    auto read = [&](auto& value) { return stream->ReadRecordData(value) == sizeof(value); };
    auto resolve = [&](RE::FormID& id) {
        if (!id) return;
        RE::FormID result{};
        id = stream->ResolveFormID(id, result) ? result : 0;
    };
    std::uint32_t count{};
    if (!read(count) || count > 128) return;
    for (unsigned n = 0; n < count; ++n) {
        RE::FormID id{}; FaceGenome f;
        if (!read(id) || !read(f.morphs)) return;
        if (version >= 2) {
            if (!read(f.expression) || !read(f.sex)) return;
            if (f.sex != RE::SEX::kMale && f.sex != RE::SEX::kFemale) return;
        } else {
            f.needsMigration = true;
            for (unsigned i = 0; i < 19; ++i) f.expression[i] = ExpressFaceMorph(f.morphs[i].a, f.morphs[i].b);
        }
        if (!read(f.presets)) return;
        for (auto* form : {&f.race, &f.hairColor, &f.faceTexture, &f.skin, &f.farSkin})
            if (!read(*form)) return;
        if (!read(f.bodyColor)) return;
        if (version >= 2) {
            if (!read(f.hairRGB)) return;
        } else {
            RE::FormID hairID = f.hairColor; resolve(hairID);
            if (auto* colour = RE::TESForm::LookupByID<RE::BGSColorForm>(hairID)) f.hairRGB = Pack(colour->color);
        }
        if (!read(f.weight)) return;
        std::uint32_t size{};
        if (!read(size) || size > 64) return;
        for (unsigned i = 0; i < size; ++i) {
            RE::FormID form{}; if (!read(form)) return; resolve(form);
            if (form) f.headParts.push_back(form);
        }
        if (!read(size) || size > 128) return;
        for (unsigned i = 0; i < size; ++i) {
            RE::TESNPC::Layer t{}; std::uint32_t color{};
            if (!read(color) || !read(t.tintIndex) || !read(t.preset) || !read(t.interpolationValue)) return;
            t.tintColor = Unpack(color); t.interpolationValue = std::min<std::uint16_t>(100, t.interpolationValue);
            f.tints.push_back(t);
        }
        resolve(id);
        for (auto* form : {&f.race, &f.hairColor, &f.faceTexture, &f.skin, &f.farSkin}) resolve(*form);
        bool valid = std::isfinite(f.weight) && f.weight >= 0.0F && f.weight <= 100.0F;
        for (auto& locus : f.morphs) {
            valid &= std::isfinite(locus.a) && std::isfinite(locus.b) &&
                std::abs(locus.a) <= 1.0F && std::abs(locus.b) <= 1.0F;
        }
        for (float value : f.expression) valid &= std::isfinite(value) && std::abs(value) <= 1.0F;
        if (valid && id && f.race) faces_[id] = std::move(f);
    }
}
}
