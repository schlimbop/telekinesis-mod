#pragma once
#include <cctype>
#include <cstdint>
namespace Dynasty::Equipment {
inline void HashAppearanceNumber(std::uint64_t& hash,std::uint64_t value) {
    for(int i=0;i<8;++i){hash=(hash^(value&255U))*1099511628211ULL;value>>=8;}
}
inline void HashAppearancePath(std::uint64_t& hash,const char* path) {
    if(path)for(;*path;++path){auto c=static_cast<unsigned char>(*path);if(c=='/')c='\\';hash=(hash^std::tolower(c))*1099511628211ULL;}
    HashAppearanceNumber(hash,0);
}
}
