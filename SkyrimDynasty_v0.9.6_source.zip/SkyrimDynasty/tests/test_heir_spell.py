from pathlib import Path
from types import SimpleNamespace as NS
import struct,unittest,sys
from test_lifecycle import load_function,SOURCE
from test_partner_access import Actor
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from esp import records
class HeirSpellTests(unittest.TestCase):
    def setUp(self):
        self.player=Actor(0);self.male=object();self.female=object()
        self.env=dict(PlayerRef=self.player,ChildHeirBaseMale=self.male,ChildHeirBaseFemale=self.female)
        load_function('IsEligibleSpellPartner',self.env)
    def test_adult_female_dead_combat_and_hostile_states_are_allowed(self):
        for dead in [False,True]:
            for combat in [False,True]:
                self.player.combat=combat
                self.assertTrue(self.env['IsEligibleSpellPartner'](Actor(dead=dead,combat=combat,hostile=True)))
    def test_children_private_juveniles_males_self_and_missing_targets_are_rejected(self):
        for target in [None,self.player,Actor(child=True),Actor(0),Actor(base=None),Actor(base=self.male),Actor(base=self.female)]:
            self.assertFalse(self.env['IsEligibleSpellPartner'](target))
    def test_leveled_generated_female_guard_is_allowed(self):
        self.assertTrue(self.env['IsEligibleSpellPartner'](Actor(0,leveled_base=Actor(1))))
        self.assertFalse(self.env['IsEligibleSpellPartner'](Actor(1,leveled_base=Actor(0))))
    def test_shared_create_path_checks_spell_policy_before_placing_and_uses_target_anchor(self):
        body=SOURCE.split('Actor Function CreateHeir(',1)[1].split('EndFunction',1)[0]
        self.assertLess(body.index('abSpell && !IsEligibleSpellPartner'),body.index('PlayerRef.PlaceAtMe'))
        self.assertIn('SummonBesideTarget(heir, akPartner, True)',body)
        self.assertIn('DynastyNative.CreateGenome(heir, PlayerRef, akPartner)',body)
        spell=(ROOT/'Data/Scripts/Source/DynastyHeirSpell.psc').read_text()
        self.assertIn('akCaster != Game.GetPlayer()',spell)
        self.assertIn('TryCreateHeirFromSpell(akTarget)',spell)
    def test_spell_is_granted_once_for_new_and_existing_games(self):
        added=[];spell=object();self.player.HasSpell=lambda f:False
        self.player.AddSpell=lambda *args:added.append(args)
        self.env['Game']=NS(GetFormFromFile=lambda *args:spell)
        load_function('EnsureHeirSpell',self.env);self.env['EnsureHeirSpell']()
        self.assertEqual(added,[(spell,False)])
        self.player.HasSpell=lambda f:True;self.env['EnsureHeirSpell']();self.assertEqual(len(added),1)
        self.assertIn('EnsureHeirSpell()',SOURCE.split('Function InitialiseArrays()',1)[1].split('EndFunction',1)[0])
    def test_aimed_nonhostile_script_effect_has_projectile_and_no_combat_dead_restrictions(self):
        forms={i:(t,f) for t,i,_,f in records(ROOT/'Data/DynastyHeirs.esp')}
        spell=forms[0x0100082A][1];effect=forms[0x0100082B][1]
        self.assertEqual(spell[b'EFID'],struct.pack('<I',0x0100082B))
        self.assertEqual(struct.unpack_from('<II',spell[b'SPIT'],16),(1,3))
        data=effect[b'DATA'];flags=struct.unpack_from('<I',data)[0]
        self.assertFalse(flags&5);self.assertTrue(flags&0x10000000)
        self.assertEqual(struct.unpack_from('<I',data,64)[0],1)
        self.assertNotEqual(struct.unpack_from('<I',data,72)[0],0)
        self.assertEqual(struct.unpack_from('<II',data,80),(1,3))
        self.assertNotIn(b'CTDA',effect);self.assertIn(b'DynastyHeirSpell',effect[b'VMAD'])
        self.assertEqual(forms[0x01000829][0],b'OTFT');self.assertNotIn(b'INAM',forms[0x01000829][1])
    def test_spell_summon_forces_portal_sound_and_moves_beside_requested_anchor(self):
        events=[];anchor=object();heir=NS(IsDead=lambda:False,SetAlpha=lambda *a:None,MoveTo=lambda *a:events.append(a),Enable=lambda *a:None,Is3DLoaded=lambda:True)
        env=dict(PlayerRef=NS(PlaceAtMe=lambda *a:None),Game=NS(GetForm=lambda i:NS(Play=lambda *a:events.append(('effect',i)) or -1)),
            DynastyNative=NS(GetSetting=lambda k:False,RefreshAppearance=lambda a:None),EquipRandomAdultLoadout=lambda a:None,
            Utility=NS(Wait=lambda t:None),Sound=NS(StopInstance=lambda n:None))
        load_function('SummonBesideTarget',env);env['SummonBesideTarget'](heir,anchor,True)
        self.assertEqual(events[0],(anchor,120.0,0.0,0.0,True))
        self.assertIn(('effect',0x4e793),events);self.assertIn(('effect',0xcf79f),events)
    def test_cosmetic_changes_are_forced_and_mesh_replacement_runs_on_game_thread(self):
        cpp=(ROOT/'SKSEPlugin/src/Appearance.cpp').read_text().split('bool GeneticsEngine::RepairAppearance',1)[1]
        self.assertIn('rng_,true,oldPaint',cpp);self.assertIn('oldHair!=newHair',cpp)
        self.assertLess(cpp.index('GetTaskInterface()->AddTask'),cpp.index('heir->ChangeHeadPart'))
        self.assertIn('base->ChangeHeadPart(part)',(ROOT/'SKSEPlugin/src/Appearance.cpp').read_text())
        self.assertIn('GetHeadPartByType(Part::kHair)',cpp)
        self.assertIn('asset->texture.index!=exclude',(ROOT/'SKSEPlugin/src/Appearance.cpp').read_text())
if __name__=='__main__':unittest.main()
