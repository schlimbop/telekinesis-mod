Scriptname DynastyHeirSpell extends ActiveMagicEffect

Event OnEffectStart(Actor akTarget, Actor akCaster)
    if akCaster != Game.GetPlayer()
        return
    endif
    DynastyLifecycleQuest manager = Game.GetFormFromFile(0x800, "DynastyHeirs.esp") as DynastyLifecycleQuest
    if manager != None
        manager.TryCreateHeirFromSpell(akTarget)
    endif
EndEvent
