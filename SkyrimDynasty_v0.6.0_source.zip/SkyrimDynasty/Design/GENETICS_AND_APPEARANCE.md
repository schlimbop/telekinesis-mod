# Genetics and appearance model



Each heir has a diploid genome. Every continuous locus stores two float alleles.



Implemented loci:

- jaw width

- chin height

- nose length

- nose width

- eye spacing

- eye size

- cheek height

- brow height

- body height

- intelligence

- physique

- magical affinity



For every child locus:

1. choose one allele from parent A;

2. choose one allele from parent B;

3. apply a 2% mutation chance;

4. store both alleles;

5. derive phenotype only when a visual/gameplay output is needed.



Current phenotype weighting:

`0.70 * allele A + 0.30 * allele B`



The exact child genome is transferred to the adult actor reference, rather than rerolled at adulthood.



## Implemented visible inheritance



Body height is already mapped from the genome into an actor-reference scale in the range 0.94–1.06.



## Face bridge



The remaining major feature is per-reference RaceMenu/NiOverride morph application.



Planned abstract mapping:

- jawWidth -> jaw width morph

- chinHeight -> chin height morph

- noseLength -> nose length morph

- noseWidth -> nose width morph

- eyeSpacing -> eye distance morph

- eyeSize -> eye size morph

- cheekHeight -> cheek height morph

- browHeight -> brow height morph



The genetics layer intentionally stores abstract values instead of RaceMenu slider names so compatibility tables can later support vanilla heads, High Poly Head, and other head meshes.



## Names



Names are not genetic data. A random Skyrim-style name is generated at birth, assigned to the individual reference with `SetDisplayName()`, and copied unchanged into the adult reference.



## Adult talent and equipment inheritance (0.5.0)



Talents.cpp captures the 18 parental base skills and perk union at birth. Skills

blend 50/50 with uniform +/-5 variation (clamped 0..100). A perk held by both

parents is inherited; a perk held by one is a coin flip. A separate versioned DYTL

co-save record preserves these choices without altering the original DYNG genome

layout. TransferGenome transfers both records to the adult. Skills initialize once;

perks are added to the adult slot's unique base before spawn and restored after

load. Revert removes only runtime perks added by this plugin. Random equipment is

ordinary saved inventory, generated once at adult promotion from four FormLists.


## Reusable living slots and succession (0.5.0)

The manager's heirCount is now a high-water index for scanning stable slots,
not a lifetime birth counter or public living count. GetHeirCount counts living
references. SlotBusy reserves birth/promotion/retirement against overlapping
callbacks. Release clears references, parents, timestamps, greetings, behavior,
home markers and native actor records, while leaving ordinary corpses lootable.
Before reusing an adult base, PrepareAdult removes every perk added by the prior
owner. RestoreInheritedPerks does not reset a living actor's training/equipment.

AdoptHeir validates a living owned adult and genome before changing player data.
It copies the logical genome and current skills/perks to the existing player
reference; the NPC's records are released only after succession succeeds. This
keeps the inherited logical identity for subsequent breeding. Live actor state
remains in Papyrus/normal saves; DYNG/DYTL retain the native genetic/talent data.
CopyHeirAppearance copies head-part arrays and face morph data rather than storing
a pointer to a reusable NPC base as the player's faceNPC. Full inherited facial
expression and RaceMenu tint/overlay handling remain unfinished.
