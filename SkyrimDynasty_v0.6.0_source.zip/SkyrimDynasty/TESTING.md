# Skyrim runtime acceptance checks — not yet performed



1. Install the completed native installer on a separate test profile. Confirm

   DYNA_LifecycleQuest and DYNA_BreedingDialogueQuest are running on a fresh game.

2. Speak to Lydia and ordinary female NPCs in several towns, plus a mod-added NPC

   using a custom voice. Breeding must appear without NPC patches. Test either

   player sex. Verify one selection creates one child, with player and speaker

   FormIDs as the parents even when other NPCs are nearby.

3. No topic for male, child, dead, hostile or fighting speakers. Test hostility

   outside combat (including a calmed hostile) and combat against a third party.

   If eligibility changes after display, selection must create nothing.

4. Record player/mother base skills and perks at birth. Change the parents later.

   At adulthood, verify each saved skill sample is the original parental average

   plus its one-time [-5,+5] variation. Verify inherited perks come only from the

   birth-time union, all joint perks are present and one-parent perks are sampled.

   Test a mod-added ordinary combat perk and its actual NPC effect.

5. Create siblings with different mothers/perks. Verify separate adult base IDs

   and no sibling or vanilla NPC gains the other heir's perk array.

6. Before 10 days the child stays non-adult. After the threshold the next hourly

   poll promotes it. Genome ID and name remain identical. Confirm a coherent

   random gear set, with arrows for archers; drop/loot items normally.

7. Save/reload before and after promotion. Parent changes must not reroll skills

   or perks. Equipment must not reroll or duplicate. Changed adult skills remain

   changed after load. Load another save/new game and check no old perk pollution.

8. Confirm Travel then ForceGreet introduction, serial greeting queue, completion

   and release. Activate adults for Follow, Wait, Home, Go home, Dismiss and Talk

   normally. Reload in each state; verify normal mortality and the 32-living-heir cap.

9. Missing native plugin or failed genome creation must leave no registered heir.

10. Check visible template faces for missing FaceGen/dark-face errors. This does

    not prove inherited parental likeness: that renderer is still unfinished.


11. Birth outdoors and indoors: portal and sound start beside the player; the
    child appears under the effect, and the portal is removed. Repeat at adult
    promotion. Check narrow rooms, terrain and player movement during arrival.
12. Create several living children, then fill all 32 slots. Birth 33 is refused.
    Kill a juvenile and an adult with ordinary damage and verify neither is
    essential/protected or engine child-immune. Loot the corpse. New births work
    after either death, before and after reload; repeat beyond 32 lifetime births.
13. Kill the currently greeting heir. Its alias clears and another pending heir
    greets normally. Reuse that slot with a different mother and opposite sex:
    no old perks, home marker, name or greeting state may leak into the replacement.
14. With two adult heirs, suffer fatal damage. Browse both names forward/backward.
    Choose one: continue at their location, with their genome/name/sex/race,
    skills/perks/stats/level and exact equipped items. No duplicate NPC remains.
    The free slot must allow another birth. Repeat for a later generation.
15. Verify Normal death and defeat with only juveniles use normal death. Test a
    candidate dying during selection; no invalid/child successor may be consumed.
    Failure to adopt must retain the NPC and offer another candidate/normal death.
16. Save/reload after succession and verify identity, talents, gear, living count,
    followers/homes and Breeding still work. Load a pre-succession save to check
    appearance/perks/essential state do not leak across saves. Verify quest
    continuity and predecessor quest items remain on the player reference.
17. Test falls, drowning, killmoves, scripted death and conflict with other death
    mods separately. Check bleedout recovery and that no transition leaves the
    player ghosted or essential with no remaining adult heir.
