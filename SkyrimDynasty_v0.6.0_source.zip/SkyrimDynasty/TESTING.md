# Skyrim runtime checks — 0.6.0

Offline checks do not replace these in-game checks. Use the same .ess/.skse pair when saving and loading.

1. Replace the old Vortex version and verify no old Dynasty template FaceGen assets remain deployed. On an existing save which previously reported the false 32-child cap, speak to a valid partner. Confirm a full-grown heir appears beside the player immediately, with portal, sound, body shader and a random equipment set. No juvenile should be created.
2. Create several heirs with the same and different mothers. Confirm different names, independent inventory, adult command menus, following/waiting/residence/dismissal and the approach/greeting.
3. Use parents with visibly different jaw, nose, eye, chin, skin, hair and body-weight settings in Skyrim's native character creator. Verify resemblance from both parents, sex-compatible head parts, selected racial mesh family, and absence of black-face/neck issues. Repeat with a normal mod-added humanoid race. Custom sculpt/overlay geometry outside native records is not supported.
4. Save, quit to desktop and reload. Confirm face, name, skills, perks, inventory, home and behaviour are unchanged. Repeat after revisiting unloaded cells and after recycling a dead sibling's slot.
5. Reach the 32 living-heir cap, kill one heir and create another. Confirm only the living count is limited; other siblings remain unchanged. Repeat several times and confirm corpses remain lootable without forced lifetime persistence.
6. With living adult heirs, enter player bleedout and select the desired heir. Confirm skills, owned perks, name, sex/race, inherited face and equipment transfer, the NPC is consumed, quest progress continues and that NPC's slot is available. Save and reload again. Also test Normal death and no-adult-heir behaviour.
7. Test female/male NPCs, adult/child races, dead actors, combat and hostility. The Breeding option must only appear for the eligible female adults. Custom mods must correctly flag their child races.
8. Inspect Documents/My Games/Skyrim Special Edition/SKSE/SkyrimDynasty.log for inheritance/face messages. If creation fails, record the exact notification and this log; missing native plugin, missing adult templates and failed inheritance now have different messages.
