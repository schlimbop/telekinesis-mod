"""Generate six new records from an owned, unmodified Skyrim.esm (read-only).

Only whitelisted record fields are copied; no textures, meshes, or master overrides.
Record layouts: TES5Edit's wbDefinitionsTES5.pas, SPEL/MGEF/TES4 definitions.
"""
from pathlib import Path
import argparse
import struct as s
import zlib

HEADER = s.Struct('<4sIIIIHH')
U32 = s.Struct('<I')

def subrecords(payload):
    cursor = 0
    extended = None
    while cursor < len(payload):
        if cursor + 6 > len(payload):
            raise ValueError('Truncated subrecord header')
        tag, size = s.unpack_from('<4sH', payload, cursor)
        cursor += 6
        if tag == b'XXXX':
            if size != 4 or cursor + 4 > len(payload):
                raise ValueError('Invalid extended subrecord')
            extended = U32.unpack_from(payload, cursor)[0]
            cursor += 4
            continue
        if extended is not None:
            size, extended = extended, None
        if cursor + size > len(payload):
            raise ValueError('Truncated subrecord')
        yield tag, payload[cursor:cursor+size]
        cursor += size
    if extended is not None:
        raise ValueError('Orphan XXXX')

def records(path, wanted=None):
    with Path(path).open('rb') as stream:
        def walk(end):
            while stream.tell() < end:
                start = stream.tell()
                header = stream.read(24)
                if len(header) != 24:
                    raise ValueError('Truncated record header')
                tag, size, flags, form, _, version, _ = HEADER.unpack(header)
                if tag == b'GRUP':
                    if size < 24 or start+size > end:
                        raise ValueError('Invalid group length')
                    yield from walk(start+size)
                    continue
                if stream.tell()+size > end:
                    raise ValueError('Record crosses group boundary')
                if wanted is not None and tag not in wanted:
                    stream.seek(size, 1)
                    continue
                payload = stream.read(size)
                if flags & 0x40000:
                    expected = U32.unpack_from(payload)[0]
                    payload = zlib.decompress(payload[4:])
                    if len(payload) != expected:
                        raise ValueError('Invalid compressed size')
                entries = list(subrecords(payload))
                fields = dict(entries)
                fields[b"_entries"] = entries
                if tag == b'SPEL':
                    fields[b'_EFIDS'] = [v for k, v in entries if k == b'EFID']
                yield tag, form, flags, fields
        yield from walk(Path(path).stat().st_size)

def sub(tag, value):
    if isinstance(value, str):
        value = value.encode('utf-8') + b'\0'
    if len(value) > 65535:
        return b'XXXX\x04\x00' + U32.pack(len(value)) + tag + b'\0\0' + value
    return tag + s.pack('<H', len(value)) + value

def record(tag, form, fields, flags=0):
    payload = b''.join(sub(key, value) for key, value in fields)
    return HEADER.pack(tag, len(payload), flags, form, 0, 44, 0) + payload

def group(tag, items):
    data = b''.join(items)
    return s.pack('<4sI4sIHHI', b'GRUP', 24+len(data), tag, 0, 0, 0, 0) + data

def editor_id(fields):
    return fields.get(b'EDID', b'').rstrip(b'\0').decode('ascii')

