"""Copy only the four owned vanilla FaceGen templates into unique heir slots.
Read-only BSA extraction (SSE version 105); requires the small lz4 Python package.
These generated local assets are not part of the portable public source archive.
"""
from pathlib import Path
import argparse, json, struct as s
import lz4.frame, lz4.block
ROOT=Path(__file__).resolve().parents[1]

def select(archive,wanted):
    with Path(archive).open('rb') as f:
        magic,ver,off,flags,folders,files,fnlen,namelen,types=s.unpack('<4s8I',f.read(36))
        if magic!=b'BSA\0' or ver!=105:raise ValueError('Expected SSE BSA version 105')
        f.seek(off);folderdata=[s.unpack('<QIIQ',f.read(24)) for _ in range(folders)]
        descriptors=[]
        for hash,count,unused,position in folderdata:
            length=f.read(1)[0];name=f.read(length).rstrip(b'\0').decode('utf-8').lower()
            for _ in range(count):
                h,size,offset=s.unpack('<QII',f.read(16));descriptors.append((name,size,offset))
        names=f.read(namelen).split(b'\0');assert len(descriptors)==files
        found={}
        for (folder,size,offset),name in zip(descriptors,names):
            path=folder+'\\'+name.decode('utf-8').lower()
            if path not in wanted:continue
            f.seek(offset);data=f.read(size&0x3fffffff)
            if flags&0x100:data=data[1+data[0]:]
            compressed=bool(flags&4)^bool(size&0x40000000)
            if compressed:
                expected=s.unpack_from('<I',data)[0];body=data[4:]
                data=lz4.frame.decompress(body) if body[:4]==b'\x04\x22\x4d\x18' else lz4.block.decompress(body,uncompressed_size=expected)
                assert len(data)==expected
            found[path]=data
        return found

def generate(game_data):
    game_data=Path(game_data);mapping=json.loads((ROOT/'face_sources.json').read_text())
    sources=sorted(set(mapping.values()));wanted=set()
    for id in sources:
        wanted.add(f'meshes\\actors\\character\\facegendata\\facegeom\\skyrim.esm\\{id.lower()}.nif')
        wanted.add(f'textures\\actors\\character\\facegendata\\facetint\\skyrim.esm\\{id.lower()}.dds')
    found={}
    for path in game_data.glob('Skyrim - *.bsa'):
        if not ('Meshes' in path.name or 'Textures' in path.name):continue
        found.update(select(path,wanted-found.keys()))
        if wanted<=found.keys():break
    if wanted-found.keys():raise ValueError('Missing owned FaceGen assets: '+repr(wanted-found.keys()))
    for dest,src in mapping.items():
        for category,section,extension in [('meshes','facegeom','nif'),('textures','facetint','dds')]:
            key=f'{category}\\actors\\character\\facegendata\\{section}\\skyrim.esm\\{src.lower()}.{extension}'
            out=ROOT/'Data'/category/'actors/character/facegendata'/section/'DynastyHeirs.esp'/f'{dest.lower()}.{extension}'
            out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(found[key])
    print(f'Prepared {len(mapping)*2} matching FaceGen/tint assets from {len(sources)} owned templates.')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('game_data');a=p.parse_args();generate(a.game_data)
