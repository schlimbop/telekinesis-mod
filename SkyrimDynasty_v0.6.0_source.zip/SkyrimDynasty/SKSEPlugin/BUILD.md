# Windows DLL build

Use Visual Studio 2022 C++ tools, CMake and vcpkg. The included GitHub Actions
workflow provisions these on windows-2022 and fetches pinned CommonLibSSE-NG
v10.1.0, matching the proven telekinesis build approach.

Configure SKSEPlugin with the vcpkg toolchain, x64-windows-static triplet and
MultiThreaded MSVC runtime, then build Release and run CTest. See the workflow
for exact commands. The resulting DLL/PDB can be downloaded and packaged locally
with tools/package.py after the build succeeds. Native compilation has not yet
been verified for this version.

An engine-independent executable in tests/inheritance.cpp exercises the actual
skill/perk rule helpers used by Talents.cpp. It can also be built using
-DYNA_RULES_ONLY=ON on a C++20-capable system.
