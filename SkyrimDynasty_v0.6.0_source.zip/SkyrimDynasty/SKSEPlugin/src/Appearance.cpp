#include "Genetics.h"
#include "InheritanceRules.h"
#include <cstring>
#include <cmath>
#include <memory>

namespace Dynasty {
namespace {
using HP = RE::BGSHeadPart;
std::uint32_t Pack(RE::Color c) {
    return std::uint32_t(c.red) | (std::uint32_t(c.green) << 8) |
        (std::uint32_t(c.blue) << 16) | (std::uint32_t(c.alpha) << 24);
}
RE::Color Unpack(std::uint32_t c) {
    return RE::Color(c & 255, (c >> 8) & 255, (c >> 16) & 255, (c >> 24) & 255);
}
RE::Color Blend(RE::Color a, RE::Color b) {
    RE::Color result;
    for (std::size_t i = 0; i < 4; ++i) result[i] = (std::uint16_t(a[i]) + b[i]) / 2;
    return result;
}
RE::FormID ID(RE::TESForm* form) { return form ? form->GetFormID() : 0; }
bool Owned(RE::TESNPC* base) {
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!base || !data) return false;
    for (auto first : {0x900U, 0x940U})
        for (unsigned i = 0; i < 32; ++i)
            if (data->LookupForm<RE::TESNPC>(first + i, "DynastyHeirs.esp") == base) return true;
    return false;
}
bool Compatible(HP* part, RE::TESRace* race, RE::SEX sex) {
    if (!part || part->IsExtraPart()) return false;
    const auto flag = sex == RE::SEX::kFemale ? HP::Flag::kFemale : HP::Flag::kMale;
    if (part->flags.any(HP::Flag::kMale, HP::Flag::kFemale) && !part->flags.any(flag)) return false;
    return !part->validRaces || part->validRaces->HasForm(race);
}
FaceGenome ReadFace(RE::Actor* actor) {
    FaceGenome out;
    auto* base = actor->GetActorBase();
    auto* face = base->GetRootFaceNPC();
    out.race = ID(actor->GetRace());
    out.skin = ID(base->skin);
    out.farSkin = ID(base->farSkin);
    out.bodyColor = Pack(face->bodyTintColor);
    out.weight = std::clamp(base->weight, 0.0F, 100.0F);
    if (face->faceData) {
        for (unsigned i = 0; i < 19; ++i) {
            float v = NormaliseFaceMorph(face->faceData->morphs[i]);
            out.morphs[i] = {v, v};
        }
        std::copy_n(face->faceData->parts, 4, out.presets.begin());
    }
    if (face->headRelatedData) {
        out.hairColor = ID(face->headRelatedData->hairColor);
        out.faceTexture = ID(face->headRelatedData->faceDetails);
    }
    auto** parts = face->HasOverlays() ? face->GetBaseOverlays() : face->headParts;
    auto count = face->HasOverlays() ? face->GetNumBaseOverlays() : std::uint32_t(std::max<int>(0, face->numHeadParts));
    if (parts) for (unsigned i = 0; i < std::min(count, 64U); ++i)
        if (parts[i] && !parts[i]->IsExtraPart()) out.headParts.push_back(ID(parts[i]));
    if (face->tintLayers) for (auto* layer : *face->tintLayers)
        if (layer && out.tints.size() < 128) out.tints.push_back(*layer);
    return out;
}
}

bool GeneticsEngine::CaptureAppearance(RE::Actor* heir, RE::Actor* parentA, RE::Actor* parentB) {
    std::lock_guard lock(mutex_);
    if (!heir || !parentA || !parentB || !heir->GetActorBase() ||
        !parentA->GetActorBase() || !parentB->GetActorBase()) return false;
    // Existing dynasty parents pass their alleles on; founders use their current face.
    auto read = [&](RE::Actor* a) {
        auto it = faces_.find(a->GetFormID());
        return it == faces_.end() ? ReadFace(a) : it->second;
    };
    const auto a = read(parentA), b = read(parentB);
    std::bernoulli_distribution coin(0.5);
    const bool chooseA = coin(rng_);
    const auto& racialParent = chooseA ? a : b;
    auto* race = RE::TESForm::LookupByID<RE::TESRace>(racialParent.race);
    const auto sex = heir->GetActorBase()->GetSex();
    if (!race || race->IsChildRace() || !race->faceRelatedData[sex]) return false;
    FaceGenome result = racialParent;
    result.headParts.clear();
    result.weight = (a.weight + b.weight) * 0.5F;
    result.bodyColor = Pack(Blend(Unpack(a.bodyColor), Unpack(b.bodyColor)));
    for (unsigned i = 0; i < 19; ++i)
        result.morphs[i] = {NormaliseFaceMorph(ChooseAllele(a.morphs[i])),
                            NormaliseFaceMorph(ChooseAllele(b.morphs[i]))};
    auto* raceFace = race->faceRelatedData[sex];
    // Preset indices and tint indices are race/sex specific. Start with valid defaults.
    if ((chooseA ? parentA : parentB)->GetActorBase()->GetSex() != sex) {
        result.presets.fill(0);
        result.tints.clear();
        if (raceFace->presetNPCs && !raceFace->presetNPCs->empty()) {
            auto* preset = (*raceFace->presetNPCs)[0];
            if (preset && preset->faceData) std::copy_n(preset->faceData->parts, 4, result.presets.begin());
        }
        result.faceTexture = ID(raceFace->defaultFaceDetailsTextureSet);
    }
    const auto& first = coin(rng_) ? a : b;
    const auto& second = &first == &a ? b : a;
    for (unsigned type = 0; type < unsigned(HP::HeadPartType::kTotal); ++type) {
        HP* selected = nullptr;
        // Scars/warpaint are acquired rather than genetic. Facial hair follows sex metadata.
        if (type == unsigned(HP::HeadPartType::kScar)) continue;
        for (const auto* candidate : {&first, &second}) {
            for (auto id : candidate->headParts) {
                auto* part = RE::TESForm::LookupByID<HP>(id);
                if (Compatible(part, race, sex) && part->type == static_cast<HP::HeadPartType>(type)) {
                    selected = part; break;
                }
            }
            if (selected) break;
        }
        if (!selected) selected = race->GetHeadPartByType(static_cast<HP::HeadPartType>(type), sex);
        if (selected && Compatible(selected, race, sex)) result.headParts.push_back(ID(selected));
    }
    if (result.headParts.empty()) return false;
    // Skin tone always exists even when Skyrim discarded a founder's pregenerated tints.
    result.tints.clear();
    if (raceFace->tintMasks) for (auto* asset : *raceFace->tintMasks) {
        if (!asset) continue;
        using Tone = RE::TESRace::FaceRelatedData::TintAsset::TintLayer::SkinTone;
        if (asset->texture.skinTone == Tone::kPaint || asset->texture.skinTone == Tone::kDirt) continue;
        RE::TESNPC::Layer layer{};
        layer.tintIndex = asset->texture.index;
        if (asset->texture.skinTone == Tone::kSkinTone) {
            layer.tintColor = Unpack(result.bodyColor);
            layer.interpolationValue = 100;
        } else {
            // Only blend matching masks; arbitrary race/sex indices cannot be reused.
            auto find = [&](const FaceGenome& f) -> const RE::TESNPC::Layer* {
                if (f.race != result.race ||
                    (&f == &a ? parentA : parentB)->GetActorBase()->GetSex() != sex) return nullptr;
                for (const auto& t : f.tints) if (t.tintIndex == layer.tintIndex) return &t;
                return nullptr;
            };
            const auto* ta = find(a); const auto* tb = find(b);
            if (!ta && !tb) continue;
            layer = ta ? *ta : *tb;
            if (ta && tb) {
                layer.tintColor = Blend(ta->tintColor, tb->tintColor);
                layer.interpolationValue = (ta->interpolationValue + tb->interpolationValue) / 2;
            }
        }
        result.tints.push_back(layer);
    }
    faces_[heir->GetFormID()] = std::move(result);
    return true;
}

RE::TESRace* GeneticsEngine::InheritedRace(RE::Actor* actor) const {
    std::lock_guard lock(mutex_);
    if (!actor) return nullptr;
    auto it = faces_.find(actor->GetFormID());
    return it == faces_.end() ? nullptr : RE::TESForm::LookupByID<RE::TESRace>(it->second.race);
}

bool GeneticsEngine::ApplyAppearance(RE::Actor* actor) {
    std::lock_guard lock(mutex_);
    if (!actor) return false;
    auto it = faces_.find(actor->GetFormID());
    auto* base = actor->GetActorBase();
    if (it == faces_.end() || !base || (!Owned(base) && actor != RE::PlayerCharacter::GetSingleton())) return false;
    const auto& face = it->second;
    auto* race = RE::TESForm::LookupByID<RE::TESRace>(face.race);
    if (!race) return false;
    std::vector<HP*> parts;
    for (auto id : face.headParts) {
        auto* part = RE::TESForm::LookupByID<HP>(id);
        if (part) {
            parts.push_back(part);
            for (auto* extra : part->extraParts)
                if (extra && std::find(parts.begin(), parts.end(), extra) == parts.end()) parts.push_back(extra);
        }
    }
    if (parts.empty() || parts.size() > 127) return false;
    auto** allocated = RE::calloc<HP*>(parts.size());
    if (!allocated) return false;
    std::copy(parts.begin(), parts.end(), allocated);
    RE::free(base->headParts);
    base->headParts = allocated;
    base->numHeadParts = static_cast<std::int8_t>(parts.size());
    base->faceNPC = nullptr;
    if (auto genome = GetGenome(actor)) {
        if (genome->sex == Sex::Female) base->actorData.actorBaseFlags.set(RE::ACTOR_BASE_DATA::Flag::kFemale);
        else base->actorData.actorBaseFlags.reset(RE::ACTOR_BASE_DATA::Flag::kFemale);
    }
    base->race = race;
    if (!base->faceData) base->faceData = RE::calloc<RE::TESNPC::FaceData>(1);
    if (!base->faceData) return false;
    for (unsigned i = 0; i < 19; ++i)
        base->faceData->morphs[i] = ExpressFaceMorph(face.morphs[i].a, face.morphs[i].b);
    std::copy(face.presets.begin(), face.presets.end(), base->faceData->parts);
    base->weight = face.weight;
    base->bodyTintColor = Unpack(face.bodyColor);
    if (auto* skin = RE::TESForm::LookupByID<RE::TESObjectARMO>(face.skin)) base->skin = skin;
    base->farSkin = RE::TESForm::LookupByID<RE::TESObjectARMO>(face.farSkin);
    base->SetHairColor(RE::TESForm::LookupByID<RE::BGSColorForm>(face.hairColor));
    base->SetFaceTexture(RE::TESForm::LookupByID<RE::BGSTextureSet>(face.faceTexture));
    if (!base->tintLayers) {
        // This object becomes owned by TESNPC; use Skyrim's allocator.
        auto* layers = RE::calloc<RE::BSTArray<RE::TESNPC::Layer*>>(1);
        if (!layers) return false;
        base->tintLayers = std::construct_at(layers);
    }
    for (auto* layer : *base->tintLayers) RE::free(layer);
    base->tintLayers->clear();
    for (const auto& saved : face.tints) {
        auto* layer = RE::calloc<RE::TESNPC::Layer>(1);
        if (layer) { *layer = saved; base->tintLayers->push_back(layer); }
    }
    if (actor != RE::PlayerCharacter::GetSingleton()) {
        // Levelled/non-unique NPCs use live FaceGen, not a stale exported head NIF.
        base->actorData.actorBaseFlags.reset(RE::ACTOR_BASE_DATA::Flag::kUnique);
        base->actorData.actorBaseFlags.set(RE::ACTOR_BASE_DATA::Flag::kIsChargenFacePreset);
    }
    if (actor == RE::PlayerCharacter::GetSingleton()) {
        // Player rendering reads a separate per-player tint list, not NPC tintLayers.
        auto* player = RE::PlayerCharacter::GetSingleton();
        auto* masks = player->GetTintList();
        auto* racialFace = race->faceRelatedData[base->GetSex()];
        if (masks) for (auto* mask : *masks) {
            if (!mask) continue;
            mask->alpha = 0.0F; // Do not retain the predecessor's cosmetics.
            if (mask->type == RE::TintMask::Type::kSkinTone) {
                mask->color = Unpack(face.bodyColor);
                mask->alpha = 1.0F;
                continue;
            }
            if (!racialFace || !racialFace->tintMasks) continue;
            for (const auto& layer : face.tints) {
                for (auto* asset : *racialFace->tintMasks) {
                    if (asset && asset->texture.index == layer.tintIndex &&
                        asset->texture.skinTone.underlying() == mask->type.underlying()) {
                        mask->color = layer.tintColor;
                        mask->alpha = layer.interpolationValue / 100.0F;
                    }
                }
            }
        }
    }
    base->AddChange(RE::TESNPC::ChangeFlags::kFace | RE::TESNPC::ChangeFlags::kRace);
    SKSE::log::info("Applied parental face: actor {:08X}, race {:08X}, {} head parts, {} tint layers",
        actor->GetFormID(), face.race, parts.size(), face.tints.size());
    return true; // Papyrus queues the 3D update after this function returns.
}

void GeneticsEngine::SaveAppearance(SKSE::SerializationInterface* stream) const {
    if (!stream->OpenRecord('DYFA', 1)) return;
    auto count = static_cast<std::uint32_t>(faces_.size());
    stream->WriteRecordData(count);
    for (const auto& [id, f] : faces_) {
        stream->WriteRecordData(id); stream->WriteRecordData(f.morphs); stream->WriteRecordData(f.presets);
        for (auto form : {f.race, f.hairColor, f.faceTexture, f.skin, f.farSkin}) stream->WriteRecordData(form);
        stream->WriteRecordData(f.bodyColor); stream->WriteRecordData(f.weight);
        auto parts = static_cast<std::uint32_t>(f.headParts.size()); stream->WriteRecordData(parts);
        for (auto form : f.headParts) stream->WriteRecordData(form);
        auto tints = static_cast<std::uint32_t>(f.tints.size()); stream->WriteRecordData(tints);
        for (const auto& t : f.tints) {
            stream->WriteRecordData(Pack(t.tintColor)); stream->WriteRecordData(t.tintIndex);
            stream->WriteRecordData(t.preset); stream->WriteRecordData(t.interpolationValue);
        }
    }
}
void GeneticsEngine::LoadAppearance(SKSE::SerializationInterface* stream, std::uint32_t version) {
    if (version != 1) return;
    auto read = [&](auto& value) { return stream->ReadRecordData(value) == sizeof(value); };
    auto resolve = [&](RE::FormID& id) {
        if (!id) return;
        RE::FormID result{};
        id = stream->ResolveFormID(id, result) ? result : 0;
    };
    std::uint32_t count{};
    if (!read(count) || count > 128) return;
    for (unsigned n = 0; n < count; ++n) {
        RE::FormID id{}; FaceGenome f;
        if (!read(id) || !read(f.morphs) || !read(f.presets)) return;
        for (auto* form : {&f.race, &f.hairColor, &f.faceTexture, &f.skin, &f.farSkin})
            if (!read(*form)) return;
        if (!read(f.bodyColor) || !read(f.weight)) return;
        std::uint32_t size{};
        if (!read(size) || size > 64) return;
        for (unsigned i = 0; i < size; ++i) {
            RE::FormID form{}; if (!read(form)) return; resolve(form);
            if (form) f.headParts.push_back(form);
        }
        if (!read(size) || size > 128) return;
        for (unsigned i = 0; i < size; ++i) {
            RE::TESNPC::Layer t{}; std::uint32_t color{};
            if (!read(color) || !read(t.tintIndex) || !read(t.preset) || !read(t.interpolationValue)) return;
            t.tintColor = Unpack(color); t.interpolationValue = std::min<std::uint16_t>(100, t.interpolationValue);
            f.tints.push_back(t);
        }
        resolve(id);
        for (auto* form : {&f.race, &f.hairColor, &f.faceTexture, &f.skin, &f.farSkin}) resolve(*form);
        bool valid = std::isfinite(f.weight) && f.weight >= 0.0F && f.weight <= 100.0F;
        for (auto& locus : f.morphs) {
            valid &= std::isfinite(locus.a) && std::isfinite(locus.b) &&
                std::abs(locus.a) <= 1.0F && std::abs(locus.b) <= 1.0F;
        }
        if (valid && id && f.race && !f.headParts.empty()) faces_[id] = std::move(f);
    }
}
}
