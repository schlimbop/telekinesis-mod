# Known limitations — 0.6.0

- Skyrim runtime verification remains pending, including the reported slot failure on Skyrim 1.7.104 and live FaceGen rendering, save/reload, succession and custom race compatibility.
- Native NPC face records are inherited; RaceMenu-only custom sliders, overlays and sculpted/exported NPC face geometry outside those records are not reconstructed. Incompatible race/sex head parts use compatible racial defaults. Racial choice is discrete; it is not a new hybrid race.
- Skyrim can discard tint layers for pre-generated parent faces. Body skin tone is sampled directly and reapplied; unavailable cosmetic layers cannot be sampled. Scars, dirt and warpaint are deliberately excluded.
- The 32 living-heir cap is shared with any old juvenile heirs awaiting migration. There is no lifetime birth counter. Normal corpses use engine cleanup.
- Following uses teammate and KeepOffsetFromActor. Residence sends an heir to its persistent marker to wait, rather than a full daily schedule.
- Succession uses essential-player bleedout interception. Forced script deaths and other death-alternative mods may require compatibility work. Quest progress, spells and predecessor inventory carry forward.
- Custom child races must have correct child metadata. The interaction cannot infer age from appearance when a mod incorrectly marks a child as adult.
