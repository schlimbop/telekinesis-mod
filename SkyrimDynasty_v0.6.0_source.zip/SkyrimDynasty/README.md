# Skyrim Dynasty 0.6.0

Selecting **Breeding** now summons a full-grown adult heir beside the player immediately, with the conjuration portal, body effect and sound. New births never create juvenile NPCs or wait ten game days. Existing juvenile heirs are promoted when the manager next restores or polls them. No Creation Kit assembly is needed.

The eligibility policy remains female, adult, alive, non-hostile and outside combat. The actual speaker and player are the parents. Heirs receive a random Skyrim-style name, inherited 18 skills/perks, a random equipment set and the existing approach, follower, wait, home, dismissal and succession choices.

There are 32 living slots and no lifetime birth cap. Death or succession frees a stable slot. Slot allocation now uses the actual arrays, repairs uninitialised arrays and clears interrupted empty-slot reservations. Failures give distinct notifications instead of silently deleting a failed spawn.

## Parental appearance

The previous appearance placeholder is replaced by a native FaceGen implementation. It samples the actual parent face records, inherits all 19 Skyrim face morph alleles, compatible head/eye/hair/brow parts, racial face presets, skin colour, hair colour, body weight and height. Each continuous facial trait receives an allele from each parent. One parent's race defines the compatible mesh/preset family; cross-race shapes are blended without combining incompatible mesh topologies. Opposite-sex parts use the chosen race's compatible defaults. Scars, dirt and warpaint are not hereditary.

Facial alleles, categorical parts, colours and tints are stored in the SKSE co-save with remapped FormIDs. Loading reapplies the same face without rerolling. Unique NPC bases are reserved per living slot, but the engine Unique flag is deliberately cleared to use runtime FaceGen rather than old exported template heads. Parents and ordinary NPCs are never edited.

This implements Skyrim's native facial system. RaceMenu-exclusive sliders, external overlays and sculpted/exported replacement geometry not represented in NPC face records cannot be reconstructed from these records. Such custom changes require a compatible extension; this build must not be described as reproducing every custom face overhaul.

## Install / upgrade

Use Vortex **Install From File**, enable/deploy the mod and enable `DynastyHeirs.esp`. Launch with SKSE64 and the matching Address Library. Fuz Ro D-oh is recommended for the unvoiced topics; enable subtitles.

Replace version 0.5.0 in Vortex, disabling/removing that mod's deployed files before deploying 0.6.0. Do not keep the old face geometry/tint files winning conflicts: this build generates heir faces at runtime. Plugin and existing FormIDs are preserved; ordinary existing saves are supported. SKSE `.skse` co-saves must stay with their `.ess` saves. Keep a backup before testing the update.

Compilation/offline validation and Skyrim gameplay testing are separate. See VALIDATION.txt and KNOWN_LIMITATIONS.md for actual test status.
