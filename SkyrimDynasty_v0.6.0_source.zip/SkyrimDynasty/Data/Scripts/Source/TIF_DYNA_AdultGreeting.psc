Scriptname TIF_DYNA_AdultGreeting extends TopicInfo Hidden
Function Fragment_0(ObjectReference akSpeakerRef)
    (GetOwningQuest() as DynastyAdultGreetingQuest).CompleteGreeting()
EndFunction
