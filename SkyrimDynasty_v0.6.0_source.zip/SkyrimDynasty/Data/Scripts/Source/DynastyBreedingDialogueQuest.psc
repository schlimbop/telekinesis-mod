Scriptname DynastyBreedingDialogueQuest extends Quest

Quest Property ManagerQuest Auto

Function SelectBreeding(Actor akSpeaker)
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if manager == None
        Debug.Trace("[Dynasty] Breeding dialogue has no lifecycle manager.")
        return
    endif
    manager.TryCreateHeirFromDialogue(akSpeaker)
EndFunction
