Scriptname TIF_DYNA_Breeding extends TopicInfo Hidden
Function Fragment_0(ObjectReference akSpeakerRef)
    Actor akSpeaker = akSpeakerRef as Actor
    (GetOwningQuest() as DynastyBreedingDialogueQuest).SelectBreeding(akSpeaker)
EndFunction
