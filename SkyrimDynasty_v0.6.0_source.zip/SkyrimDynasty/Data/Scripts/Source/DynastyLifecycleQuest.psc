Scriptname DynastyLifecycleQuest extends Quest

Actor Property PlayerRef Auto

ActorBase Property AdultHeirBaseMale Auto
ActorBase Property AdultHeirBaseFemale Auto
FormList Property AdultHeirBasesMale Auto
FormList Property AdultHeirBasesFemale Auto
FormList Property AdultLoadouts Auto

ActorBase Property ChildHeirBaseMale Auto
ActorBase Property ChildHeirBaseFemale Auto

Quest Property GreetingQuest Auto
Message Property HeirCommandMessage Auto
Form Property HomeMarkerBase Auto
Form Property ArrivalPortalBase Auto
EffectShader Property ArrivalShader Auto
Sound Property ArrivalSound Auto
Message Property SuccessionMessage Auto
ReferenceAlias Property Successor Auto

Float Property ChildStageDay = 2.0 AutoReadOnly
Float Property AdolescentStageDay = 5.0 AutoReadOnly
Float Property AdultStageDay = 10.0 AutoReadOnly
Float Property PollHours = 1.0 AutoReadOnly

Int Property MaxHeirs = 32 AutoReadOnly

; Behaviour states:
; 0 independent
; 1 following
; 2 waiting here
; 3 living/waiting at assigned home
Actor[] HeirRefs
Float[] BirthDays
Int[] Stages
Int[] BehaviourStates
Bool[] GreetingPending
Bool[] GreetingCompleted
Actor[] ParentA
Actor[] ParentB
Bool[] SlotBusy
ObjectReference[] HomeMarkers

Int heirCount = 0
Bool greetingBusy = False
Bool birthBusy = False
Bool successionBusy = False
Bool successionGuard = False
Bool originalEssential = False
Bool originalGhost = False

Event OnInit()
    InitialiseArrays()
    ConfigureMortality()
    RegisterForSingleUpdateGameTime(PollHours)
EndEvent

Function InitialiseArrays()
    if HeirRefs.Length != 32
        HeirRefs = new Actor[32]
    endif
    if BirthDays.Length != 32
        BirthDays = new Float[32]
    endif
    if Stages.Length != 32
        Stages = new Int[32]
    endif
    if BehaviourStates.Length != 32
        BehaviourStates = new Int[32]
    endif
    if GreetingPending.Length != 32
        GreetingPending = new Bool[32]
    endif
    if GreetingCompleted.Length != 32
        GreetingCompleted = new Bool[32]
    endif
    if ParentA.Length != 32
        ParentA = new Actor[32]
    endif
    if ParentB.Length != 32
        ParentB = new Actor[32]
    endif
    if SlotBusy.Length != 32
        SlotBusy = new Bool[32]
    endif
    if HomeMarkers.Length != 32
        HomeMarkers = new ObjectReference[32]
    endif
EndFunction

Function ConfigureMortality()
    if AdultHeirBaseMale != None
        AdultHeirBaseMale.SetEssential(False)
        AdultHeirBaseMale.SetProtected(False)
    endif

    if AdultHeirBaseFemale != None
        AdultHeirBaseFemale.SetEssential(False)
        AdultHeirBaseFemale.SetProtected(False)
    endif

    if ChildHeirBaseMale != None
        ChildHeirBaseMale.SetEssential(False)
        ChildHeirBaseMale.SetProtected(False)
    endif

    if ChildHeirBaseFemale != None
        ChildHeirBaseFemale.SetEssential(False)
        ChildHeirBaseFemale.SetProtected(False)
    endif
EndFunction

; Shared eligibility policy; do not cache a speaker between conversations.
Bool Function IsEligiblePartner(Actor akPartner)
    if akPartner == None || PlayerRef == None || akPartner == PlayerRef
        return False
    endif
    if akPartner.IsDead() || akPartner.IsChild()
        return False
    endif
    ActorBase partnerBase = akPartner.GetActorBase()
    if partnerBase == None
        return False
    endif
    if partnerBase == ChildHeirBaseMale || partnerBase == ChildHeirBaseFemale
        return False
    endif
    if partnerBase.GetSex() != 1
        return False
    endif
    if akPartner.IsHostileToActor(PlayerRef) || akPartner.IsInCombat()
        return False
    endif
    return True
EndFunction

; The INFO Begin fragment passes its actual speaking actor here.
Actor Function TryCreateHeirFromDialogue(Actor akSpeaker)
    Bool femaleChild = Utility.RandomInt(0, 1) == 1
    return CreateHeir(akSpeaker, femaleChild)
EndFunction

Actor Function CreateHeir(Actor akPartner, Bool abFemale = False)
    ; State may change after the dialogue option was displayed.
    if !IsEligiblePartner(akPartner)
        Debug.Notification("That character is no longer an eligible partner.")
        return None
    endif

    if birthBusy || successionBusy
        return None
    endif
    birthBusy = True
    InitialiseArrays()
    ReclaimDeadSlots()
    ; Only one birth can run. Old interrupted reservations must not consume capacity.
    Int resetSlot = 0
    while resetSlot < SlotBusy.Length
        if !HeirRefs[resetSlot]
            SlotBusy[resetSlot] = False
        endif
        resetSlot += 1
    endwhile
    Int i = FindFreeHeirSlot()
    if i < 0
        Debug.Notification("Dynasty: all 32 living-heir slots are occupied. Death or succession frees a slot.")
        birthBusy = False
        return None
    endif

    SlotBusy[i] = True
    ActorBase adultBase
    if abFemale && AdultHeirBasesFemale != None
        adultBase = AdultHeirBasesFemale.GetAt(i) as ActorBase
    elseif !abFemale && AdultHeirBasesMale != None
        adultBase = AdultHeirBasesMale.GetAt(i) as ActorBase
    endif
    if adultBase == None
        Debug.Notification("Dynasty: adult templates are missing. Check the enabled plugin.")
        SlotBusy[i] = False
        birthBusy = False
        return None
    endif
    if !DynastyNative.IsReady()
        Debug.Notification("Dynasty: native plugin unavailable. Check SKSE/SkyrimDynasty.log.")
        SlotBusy[i] = False
        birthBusy = False
        return None
    endif
    Actor heir = PlayerRef.PlaceAtMe(adultBase, 1, False, True) as Actor
    if heir == None
        Debug.Notification("Dynasty: Skyrim could not create the adult actor.")
        SlotBusy[i] = False
        birthBusy = False
        return None
    endif

    heir.GetActorBase().SetEssential(False)
    heir.GetActorBase().SetProtected(False)
    heir.SetRelationshipRank(PlayerRef, 4)

    Bool genomeCreated = DynastyNative.CreateGenome(heir, PlayerRef, akPartner)
    if !genomeCreated
        DynastyNative.ForgetActor(heir)
        heir.Disable()
        heir.Delete()
        Debug.Trace("[Dynasty] Birth cancelled: genome creation failed.")
        Debug.Notification("Dynasty: inheritance failed. See SkyrimDynasty.log.")
        SlotBusy[i] = False
        birthBusy = False
        return None
    endif

    String generatedName = DynastyNative.GenerateName(heir, abFemale)
    if generatedName == ""
        generatedName = GetFallbackName(abFemale)
    endif
    heir.SetDisplayName(generatedName, True)

    HeirRefs[i] = heir
    BirthDays[i] = Utility.GetCurrentGameTime()
    Stages[i] = 3
    BehaviourStates[i] = 0
    GreetingPending[i] = True
    GreetingCompleted[i] = False
    ParentA[i] = PlayerRef
    ParentB[i] = akPartner
    if i >= heirCount
        heirCount = i + 1
    endif
    if !DynastyNative.PrepareAdult(heir, adultBase)
        Debug.Trace("[Dynasty] Failed to initialise adult perks.")
    endif
    Race inheritedRace = DynastyNative.GetInheritedRace(heir)
    if inheritedRace != None
        heir.SetRace(inheritedRace)
    endif
    if !DynastyNative.ApplyInheritedAppearance(heir, i)
        Debug.Trace("[Dynasty] Failed to apply inherited face.")
    endif
    DynastyNative.ApplyInheritedSkills(heir)
    heir.SetScale(DynastyNative.GetInheritedHeightScale(heir))
    EquipRandomAdultLoadout(heir)
    heir.BlockActivation(True)
    SummonBesidePlayer(heir)
    SlotBusy[i] = False
    if heir.IsDead()
        ReleaseHeirSlot(i)
    endif
    birthBusy = False

    RefreshSuccessionGuard()
    ProcessGreetingQueue()
    Debug.Notification(generatedName + " has arrived as an adult heir.")
    Debug.Trace("[Dynasty] Created heir " + generatedName + "; genome=" + genomeCreated)

    return heir
EndFunction

String Function GetFallbackName(Bool abFemale)
    Int roll = Utility.RandomInt(0, 11)

    if abFemale
        if roll == 0
            return "Alva"
        elseif roll == 1
            return "Brynja"
        elseif roll == 2
            return "Dagny"
        elseif roll == 3
            return "Eirla"
        elseif roll == 4
            return "Freydis"
        elseif roll == 5
            return "Gunnhild"
        elseif roll == 6
            return "Hjorda"
        elseif roll == 7
            return "Ingrid"
        elseif roll == 8
            return "Runa"
        elseif roll == 9
            return "Sigrid"
        elseif roll == 10
            return "Torhild"
        else
            return "Yrsa"
        endif
    else
        if roll == 0
            return "Alrik"
        elseif roll == 1
            return "Bjornar"
        elseif roll == 2
            return "Dagvar"
        elseif roll == 3
            return "Eirik"
        elseif roll == 4
            return "Gunnar"
        elseif roll == 5
            return "Hjalmar"
        elseif roll == 6
            return "Ingvar"
        elseif roll == 7
            return "Ragnar"
        elseif roll == 8
            return "Sigvar"
        elseif roll == 9
            return "Torsten"
        elseif roll == 10
            return "Valdim"
        else
            return "Yngvar"
        endif
    endif
EndFunction


Event OnUpdateGameTime()
    if !birthBusy && !successionBusy
        ReclaimDeadSlots()
        ProcessAges()
        ProcessGreetingQueue()
    endif
    RefreshSuccessionGuard()
    RegisterForSingleUpdateGameTime(PollHours)
EndEvent

Function ProcessAges()
    Int i = 0
    while i < heirCount
        if HeirRefs[i] != None && !HeirRefs[i].IsDead() && Stages[i] < 3
            PromoteToAdult(i)
        endif
        i += 1
    endwhile
EndFunction

Function PromoteToAdult(Int aiIndex)
    Actor oldHeir = HeirRefs[aiIndex]
    if SlotBusy[aiIndex]
        return
    endif
    SlotBusy[aiIndex] = True

    if oldHeir == None || oldHeir.IsDead()
        SlotBusy[aiIndex] = False
        return
    endif

    Bool female = oldHeir.GetActorBase().GetSex() == 1
    ActorBase adultBase

    if female
        adultBase = AdultHeirBaseFemale
    else
        adultBase = AdultHeirBaseMale
    endif

    if adultBase == None
        Debug.Trace("[Dynasty] Missing adult ActorBase.")
        SlotBusy[aiIndex] = False
        return
    endif

    ; Each slot has its own base, so inherited NPC perks never bleed into siblings.
    if female && AdultHeirBasesFemale != None
        adultBase = AdultHeirBasesFemale.GetAt(aiIndex) as ActorBase
    elseif !female && AdultHeirBasesMale != None
        adultBase = AdultHeirBasesMale.GetAt(aiIndex) as ActorBase
    endif
    if adultBase == None || !DynastyNative.PrepareAdult(oldHeir, adultBase)
        Debug.Trace("[Dynasty] Adult talents/base unavailable; promotion deferred.")
        SlotBusy[aiIndex] = False
        return
    endif

    String heirName = oldHeir.GetDisplayName()
    Actor adultHeir = PlayerRef.PlaceAtMe(adultBase, 1, False, True) as Actor

    if adultHeir == None
        Debug.Trace("[Dynasty] Failed to create adult heir.")
        SlotBusy[aiIndex] = False
        return
    endif

    adultHeir.GetActorBase().SetEssential(False)
    adultHeir.GetActorBase().SetProtected(False)
    adultHeir.SetRelationshipRank(PlayerRef, 4)
    adultHeir.SetDisplayName(heirName, True)

    if oldHeir.IsDead() || HeirRefs[aiIndex] != oldHeir
        adultHeir.Delete()
        SlotBusy[aiIndex] = False
        return
    endif
    Bool transferred = DynastyNative.TransferGenome(oldHeir, adultHeir)
    if !transferred
        adultHeir.Delete()
        Debug.Trace("[Dynasty] Genome transfer failed; promotion deferred.")
        SlotBusy[aiIndex] = False
        return
    endif

    Float inheritedScale = DynastyNative.GetInheritedHeightScale(adultHeir)
    if inheritedScale >= 0.85 && inheritedScale <= 1.15
        adultHeir.SetScale(inheritedScale)
    endif

    Race inheritedRace = DynastyNative.GetInheritedRace(adultHeir)
    if inheritedRace != None
        adultHeir.SetRace(inheritedRace)
    endif
    DynastyNative.ApplyInheritedAppearance(adultHeir, aiIndex)
    DynastyNative.ApplyInheritedSkills(adultHeir)
    EquipRandomAdultLoadout(adultHeir)

    oldHeir.Disable()
    oldHeir.Delete()

    HeirRefs[aiIndex] = adultHeir
    Stages[aiIndex] = 3
    BehaviourStates[aiIndex] = 0
    GreetingPending[aiIndex] = True

    adultHeir.BlockActivation(True)
    SummonBesidePlayer(adultHeir)
    SlotBusy[aiIndex] = False
    if adultHeir.IsDead()
        ReleaseHeirSlot(aiIndex)
    endif
    RefreshSuccessionGuard()

    Debug.Notification(heirName + " has come of age.")
    Debug.Trace("[Dynasty] " + heirName + " became adult at game day " + Utility.GetCurrentGameTime())
EndFunction

; Roll exactly once at promotion; normal inventory save data preserves the result.
Function EquipRandomAdultLoadout(Actor akAdult)
    if AdultLoadouts == None || AdultLoadouts.GetSize() == 0
        return
    endif
    Int choice = Utility.RandomInt(0, AdultLoadouts.GetSize() - 1)
    FormList items = AdultLoadouts.GetAt(choice) as FormList
    if items == None
        return
    endif
    Int i = 0
    while i < items.GetSize()
        Form item = items.GetAt(i)
        if item != None
            Int count = 1
            if item as Ammo
                count = 40
            endif
            akAdult.AddItem(item, count, True)
            akAdult.EquipItem(item, False, True)
        endif
        i += 1
    endwhile
EndFunction

Function ProcessGreetingQueue()
    if greetingBusy
        return
    endif

    Int i = 0

    while i < heirCount
        if GreetingPending[i] && !GreetingCompleted[i] && HeirRefs[i] != None && !HeirRefs[i].IsDead()
            StartAdultGreeting(i)
            return
        endif
        i += 1
    endwhile
EndFunction

Function StartAdultGreeting(Int aiIndex)
    DynastyAdultGreetingQuest greeting = GreetingQuest as DynastyAdultGreetingQuest

    if greeting == None
        Debug.Trace("[Dynasty] Greeting quest is not configured.")
        return
    endif

    greetingBusy = True
    GreetingPending[aiIndex] = False
    greeting.BeginGreeting(HeirRefs[aiIndex], aiIndex, self)
EndFunction

Function NotifyGreetingComplete(Int aiIndex)
    if aiIndex >= 0 && aiIndex < heirCount
        GreetingCompleted[aiIndex] = True
    endif

    greetingBusy = False
    RegisterForSingleUpdateGameTime(0.10)
EndFunction

Bool Function IsAdultHeir(Actor akActor)
    Int i = FindHeirIndex(akActor)
    return i >= 0 && Stages[i] >= 3
EndFunction

Int Function FindHeirIndex(Actor akActor)
    if akActor == None
        return -1
    endif

    Int i = 0

    while i < heirCount
        if HeirRefs[i] == akActor
            return i
        endif
        i += 1
    endwhile

    return -1
EndFunction

Function ShowHeirInteraction(Actor akHeir)
    if HeirCommandMessage == None || akHeir == None
        return
    endif

    Int index = FindHeirIndex(akHeir)

    if index < 0 || Stages[index] < 3 || akHeir.IsDead()
        return
    endif

    Int choice = HeirCommandMessage.Show()

    if choice == 0
        RecruitHeir(index)
    elseif choice == 1
        WaitHere(index)
    elseif choice == 2
        AssignHomeHere(index)
    elseif choice == 3
        SendHome(index)
    elseif choice == 4
        DismissHeir(index)
    elseif choice == 5
        akHeir.Activate(PlayerRef, True)
    endif
EndFunction

Function RecruitHeir(Int aiIndex)
    Actor heir = HeirRefs[aiIndex]

    if heir == None || heir.IsDead()
        return
    endif

    heir.ClearKeepOffsetFromActor()
    heir.SetRestrained(False)
    heir.SetRelationshipRank(PlayerRef, 4)
    heir.SetPlayerTeammate(True, True)

    heir.KeepOffsetFromActor(PlayerRef, 0.0, -140.0, 0.0, 0.0, 0.0, 0.0, 768.0, 128.0)

    BehaviourStates[aiIndex] = 1
    Debug.Notification(heir.GetDisplayName() + " is now following you.")
EndFunction

Function WaitHere(Int aiIndex)
    Actor heir = HeirRefs[aiIndex]

    if heir == None || heir.IsDead()
        return
    endif

    heir.ClearKeepOffsetFromActor()
    heir.SetPlayerTeammate(False, False)
    heir.SetRestrained(True)
    BehaviourStates[aiIndex] = 2

    Debug.Notification(heir.GetDisplayName() + " will wait here.")
EndFunction

Function AssignHomeHere(Int aiIndex)
    Actor heir = HeirRefs[aiIndex]

    if heir == None || heir.IsDead() || HomeMarkerBase == None
        return
    endif

    ObjectReference marker = HomeMarkers[aiIndex]

    if marker == None
        marker = heir.PlaceAtMe(HomeMarkerBase, 1, True, False)
        HomeMarkers[aiIndex] = marker
    else
        marker.MoveTo(heir)
    endif

    heir.ClearKeepOffsetFromActor()
    heir.SetPlayerTeammate(False, False)
    heir.SetRestrained(True)
    BehaviourStates[aiIndex] = 3

    Debug.Notification(heir.GetDisplayName() + " will treat this place as home.")
EndFunction

Function SendHome(Int aiIndex)
    Actor heir = HeirRefs[aiIndex]
    ObjectReference marker = HomeMarkers[aiIndex]

    if heir == None || heir.IsDead()
        return
    endif

    if marker == None
        Debug.Notification(heir.GetDisplayName() + " does not have a home assigned yet.")
        return
    endif

    heir.ClearKeepOffsetFromActor()
    heir.SetPlayerTeammate(False, False)
    heir.SetRestrained(False)
    heir.MoveTo(marker)
    heir.SetRestrained(True)

    BehaviourStates[aiIndex] = 3
    Debug.Notification(heir.GetDisplayName() + " has gone home.")
EndFunction

Function DismissHeir(Int aiIndex)
    Actor heir = HeirRefs[aiIndex]

    if heir == None || heir.IsDead()
        return
    endif

    heir.ClearKeepOffsetFromActor()
    heir.SetPlayerTeammate(False, False)
    heir.SetRestrained(False)
    BehaviourStates[aiIndex] = 0

    Debug.Notification(heir.GetDisplayName() + " has been dismissed.")
EndFunction

Function RestoreBehaviour(Actor akHeir)
    Int i = FindHeirIndex(akHeir)

    if i < 0 || akHeir.IsDead()
        return
    endif

    Int savedBehaviour = BehaviourStates[i]

    if savedBehaviour == 1
        akHeir.SetRestrained(False)
        akHeir.SetPlayerTeammate(True, True)
        akHeir.KeepOffsetFromActor(PlayerRef, 0.0, -140.0, 0.0, 0.0, 0.0, 0.0, 768.0, 128.0)
    elseif savedBehaviour == 2
        akHeir.ClearKeepOffsetFromActor()
        akHeir.SetPlayerTeammate(False, False)
        akHeir.SetRestrained(True)
    elseif savedBehaviour == 3
        akHeir.ClearKeepOffsetFromActor()
        akHeir.SetPlayerTeammate(False, False)
        akHeir.SetRestrained(True)
    else
        akHeir.ClearKeepOffsetFromActor()
        akHeir.SetPlayerTeammate(False, False)
        akHeir.SetRestrained(False)
    endif
EndFunction

Function RestoreAllBehaviours()
    InitialiseArrays()
    if DynastyNative.GetInheritedRace(PlayerRef) != None
        DynastyNative.ApplyInheritedAppearance(PlayerRef, -1)
        PlayerRef.QueueNiNodeUpdate()
    endif
    ReclaimDeadSlots()
    ProcessAges()
    RefreshSuccessionGuard()
    Int i = 0

    while i < heirCount
        Actor heir = HeirRefs[i]

        if heir != None && !heir.IsDead() && Stages[i] >= 3
            DynastyNative.RestoreInheritedPerks(heir)
            Race inheritedRace = DynastyNative.GetInheritedRace(heir)
            if inheritedRace != None
                heir.SetRace(inheritedRace)
                DynastyNative.ApplyInheritedAppearance(heir, i)
                heir.QueueNiNodeUpdate()
                heir.RegenerateHead()
            endif
            RestoreBehaviour(heir)
        endif

        i += 1
    endwhile
EndFunction

Int Function GetHeirCount()
    Int living = 0
    Int i = 0
    while i < heirCount
        if HeirRefs[i] != None && !HeirRefs[i].IsDead()
            living += 1
        endif
        i += 1
    endwhile
    return living
EndFunction

Actor Function GetHeir(Int aiIndex)
    if aiIndex < 0 || aiIndex >= heirCount
        return None
    endif

    return HeirRefs[aiIndex]
EndFunction

Float Function GetHeirAgeDays(Int aiIndex)
    if aiIndex < 0 || aiIndex >= heirCount
        return 0.0
    endif

    return Utility.GetCurrentGameTime() - BirthDays[aiIndex]
EndFunction

; Slots are stable indexes, not a lifetime birth counter. No array compaction.
Int Function FindFreeHeirSlot()
    Int i = 0
    while i < HeirRefs.Length
        if !HeirRefs[i] && !SlotBusy[i]
            return i
        endif
        i += 1
    endwhile
    return -1
EndFunction

Function ReclaimDeadSlots()
    Int i = 0
    while i < heirCount
        if HeirRefs[i] != None && HeirRefs[i].IsDead()
            ReleaseHeirSlot(i)
        endif
        i += 1
    endwhile
EndFunction

Function NotifyHeirDeath(Actor akHeir)
    Int i = FindHeirIndex(akHeir)
    if i >= 0
        ReleaseHeirSlot(i)
        RefreshSuccessionGuard()
    endif
EndFunction

Function ReleaseHeirSlot(Int aiIndex)
    Actor heir = HeirRefs[aiIndex]
    if heir == None || SlotBusy[aiIndex]
        return
    endif
    SlotBusy[aiIndex] = True
    ; Unbind a dead/consumed greeting actor before this index can be reused.
    DynastyAdultGreetingQuest greeting = GreetingQuest as DynastyAdultGreetingQuest
    if greeting != None
        greeting.CancelForHeir(heir)
    endif
    heir.ClearKeepOffsetFromActor()
    heir.SetPlayerTeammate(False, False)
    DynastyNative.ForgetActor(heir)
    if HomeMarkers[aiIndex] != None
        HomeMarkers[aiIndex].Disable()
        HomeMarkers[aiIndex].Delete()
    endif
    HomeMarkers[aiIndex] = None
    ParentA[aiIndex] = None
    ParentB[aiIndex] = None
    BirthDays[aiIndex] = 0.0
    Stages[aiIndex] = 0
    BehaviourStates[aiIndex] = 0
    GreetingPending[aiIndex] = False
    GreetingCompleted[aiIndex] = False
    HeirRefs[aiIndex] = None
    SlotBusy[aiIndex] = False
    ; Corpses stay lootable; no forced persistence keeps every corpse forever.
EndFunction

Function SummonBesidePlayer(Actor akHeir)
    ; Initialise actors while disabled, then reveal inside the portal/shader.
    akHeir.MoveTo(PlayerRef, 120.0, 0.0, 0.0, True)
    ObjectReference portal
    Int soundInstance = -1
    if ArrivalPortalBase != None
        portal = akHeir.PlaceAtMe(ArrivalPortalBase, 1, False, False)
    endif
    if ArrivalSound != None
        soundInstance = ArrivalSound.Play(akHeir)
    endif
    Utility.Wait(0.15)
    akHeir.Enable(False)
    akHeir.QueueNiNodeUpdate()
    Utility.Wait(0.10)
    akHeir.RegenerateHead()
    if ArrivalShader != None
        ArrivalShader.Play(akHeir, 2.0)
    endif
    Utility.Wait(3.0)
    if soundInstance >= 0
        Sound.StopInstance(soundInstance)
    endif
    if portal != None
        portal.Disable()
        portal.Delete()
    endif
EndFunction

Int Function NextAdultHeir(Int aiAfter, Int aiDirection = 1)
    Int checked = 0
    Int i = aiAfter
    while checked < HeirRefs.Length
        i += aiDirection
        if i >= HeirRefs.Length
            i = 0
        elseif i < 0
            i = HeirRefs.Length - 1
        endif
        if HeirRefs[i] != None && !HeirRefs[i].IsDead() && Stages[i] >= 3
            return i
        endif
        checked += 1
    endwhile
    return -1
EndFunction

Function RefreshSuccessionGuard()
    InitialiseArrays()
    if successionBusy || PlayerRef == None || PlayerRef.IsDead()
        return
    endif
    Bool available = NextAdultHeir(-1) >= 0
    if available
        if !successionGuard
            originalEssential = PlayerRef.GetActorBase().IsEssential()
            successionGuard = True
        endif
        PlayerRef.GetActorBase().SetEssential(True)
    elseif !available && successionGuard
        PlayerRef.GetActorBase().SetEssential(originalEssential)
        successionGuard = False
    endif
EndFunction

Function BeginSuccession()
    if successionBusy || !successionGuard || PlayerRef.IsDead()
        return
    endif
    if Successor == None || SuccessionMessage == None
        PlayerRef.GetActorBase().SetEssential(False)
        successionGuard = False
        PlayerRef.Kill()
        return
    endif
    successionBusy = True
    originalGhost = PlayerRef.IsGhost()
    PlayerRef.SetGhost(True)
    PlayerRef.SetNoBleedoutRecovery(True)
    Int candidate = NextAdultHeir(-1)
    while candidate >= 0
        Actor heir = HeirRefs[candidate]
        Successor.ForceRefTo(heir)
        Int choice = SuccessionMessage.Show()
        if choice == 0
            ; Recheck after the menu: an NPC may have died in another event.
            if heir != None && !heir.IsDead() && HeirRefs[candidate] == heir
                if ContinueAsHeir(candidate)
                    FinishSuccession()
                    return
                endif
                Debug.Notification("Succession could not be completed. Choose another heir or normal death.")
            endif
            candidate = NextAdultHeir(candidate)
        elseif choice == 1
            candidate = NextAdultHeir(candidate)
        elseif choice == 2
            candidate = NextAdultHeir(candidate, -1)
        else
            candidate = -1
        endif
    endwhile
    ; No living adult, menu cancelled, or normal-death choice: vanilla death.
    FinishSuccession()
    PlayerRef.GetActorBase().SetEssential(False)
    successionGuard = False
    PlayerRef.Kill()
EndFunction

Bool Function ContinueAsHeir(Int aiIndex)
    Actor heir = HeirRefs[aiIndex]
    if heir == None || heir.IsDead() || Stages[aiIndex] < 3
        return False
    endif
    ; Native validates the genome/base first; no NPC is consumed on failure.
    if !DynastyNative.AdoptHeir(heir)
        return False
    endif
    String heirName = heir.GetDisplayName()
    PlayerRef.StopCombat()
    PlayerRef.MoveTo(heir)
    PlayerRef.SetDisplayName(heirName, True)
    PlayerRef.SetRace(heir.GetRace())
    DynastyNative.CopyHeirAppearance(heir)
    PlayerRef.SetScale(DynastyNative.GetInheritedHeightScale(PlayerRef))
    ; Preserve the actual equipment instances (enchantments, tempering, etc.).
    Form[] worn = new Form[34]
    Int[] wornIDs = new Int[34]
    Int slot = 30
    while slot <= 61
        worn[slot - 30] = heir.GetEquippedArmorInSlot(slot)
        wornIDs[slot - 30] = heir.GetWornItemId(Armor.GetMaskForSlot(slot))
        slot += 1
    endwhile
    worn[32] = heir.GetEquippedObject(0)
    worn[33] = heir.GetEquippedObject(1)
    wornIDs[32] = heir.GetEquippedItemId(0)
    wornIDs[33] = heir.GetEquippedItemId(1)
    PlayerRef.UnequipAll()
    heir.RemoveAllItems(PlayerRef, True, False)
    slot = 0
    while slot < 32
        if worn[slot] != None
            PlayerRef.EquipItemById(worn[slot], wornIDs[slot], 0, False, False)
        endif
        slot += 1
    endwhile
    if worn[32] != None
        PlayerRef.EquipItemById(worn[32], wornIDs[32], 2, False, False)
    endif
    if worn[33] != None
        PlayerRef.EquipItemById(worn[33], wornIDs[33], 1, False, False)
    endif
    ResetPlayerSkillProgress()
    Game.SetPlayerLevel(heir.GetLevel())
    Game.SetPlayerExperience(0.0)
    Game.SetPerkPoints(0)
    PlayerRef.RestoreActorValue("Health", 100000.0)
    PlayerRef.RestoreActorValue("Magicka", 100000.0)
    PlayerRef.RestoreActorValue("Stamina", 100000.0)
    heir.ClearKeepOffsetFromActor()
    heir.SetPlayerTeammate(False, False)
    heir.Disable()
    ReleaseHeirSlot(aiIndex)
    heir.Delete()
    PlayerRef.QueueNiNodeUpdate()
    PlayerRef.RegenerateHead()
    Debug.Notification("You now continue the dynasty as " + heirName + ".")
    return True
EndFunction

Function FinishSuccession()
    Successor.Clear()
    PlayerRef.SetNoBleedoutRecovery(False)
    PlayerRef.SetGhost(originalGhost)
    successionBusy = False
    Debug.SendAnimationEvent(PlayerRef, "BleedOutStop")
    RefreshSuccessionGuard()
EndFunction

Function RecoverSuccessionOnLoad()
    ; Never leave a save made during a transition stuck ghosted or invulnerable.
    birthBusy = False
    InitialiseArrays()
    Int i = 0
    while i < SlotBusy.Length
        SlotBusy[i] = False
        i += 1
    endwhile
    if successionBusy
        FinishSuccession()
        if PlayerRef.GetActorValue("Health") <= 0.0
            BeginSuccession()
        endif
    endif
EndFunction

Function ResetPlayerSkillProgress()
    String[] skills = new String[18]
    skills[0] = "OneHanded"
    skills[1] = "TwoHanded"
    skills[2] = "Marksman"
    skills[3] = "Block"
    skills[4] = "Smithing"
    skills[5] = "HeavyArmor"
    skills[6] = "LightArmor"
    skills[7] = "Pickpocket"
    skills[8] = "Lockpicking"
    skills[9] = "Sneak"
    skills[10] = "Alchemy"
    skills[11] = "Speechcraft"
    skills[12] = "Alteration"
    skills[13] = "Conjuration"
    skills[14] = "Destruction"
    skills[15] = "Illusion"
    skills[16] = "Restoration"
    skills[17] = "Enchanting"
    Int i = 0
    while i < skills.Length
        ActorValueInfo info = ActorValueInfo.GetActorValueInfoByName(skills[i])
        if info != None
            info.SetSkillExperience(0.0)
            info.SetSkillLegendaryLevel(0)
        endif
        i += 1
    endwhile
EndFunction
