Scriptname DynastyAdultGreetingQuest extends Quest

ReferenceAlias Property AdultHeir Auto
Actor Property PlayerRef Auto

DynastyLifecycleQuest lifecycle
Int heirIndex = -1

Function BeginGreeting(Actor akHeir, Int aiHeirIndex, DynastyLifecycleQuest akLifecycle)
    if akHeir == None
        return
    endif

    lifecycle = akLifecycle
    heirIndex = aiHeirIndex

    if IsRunning()
        Stop()
        Utility.Wait(0.25)
    endif

    Start()
    AdultHeir.ForceRefTo(akHeir)

    if akHeir.GetParentCell() != PlayerRef.GetParentCell()
        akHeir.MoveTo(PlayerRef, 1800.0, 0.0, 0.0, True)
    elseif akHeir.GetDistance(PlayerRef) > 6000.0
        akHeir.MoveTo(PlayerRef, 1800.0, 0.0, 0.0, True)
    endif

    akHeir.EvaluatePackage()
EndFunction

Function CompleteGreeting()
    Actor heir = AdultHeir.GetActorReference()

    if heir != None
        heir.EvaluatePackage()
    endif

    AdultHeir.Clear()

    if lifecycle != None
        lifecycle.NotifyGreetingComplete(heirIndex)
    endif

    heirIndex = -1
    lifecycle = None
    Stop()
EndFunction

Function CancelForHeir(Actor akHeir)
    if AdultHeir.GetActorReference() == akHeir
        CompleteGreeting()
    endif
EndFunction
