import sys,struct as s,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from esp import records,U32

class CompanionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.all=list(records(ROOT/'Data/DynastyHeirs.esp'))
        cls.forms={fid:(tag,flags,f) for tag,fid,flags,f in cls.all}
    def fields(self,local):return self.forms[0x01000000|local][2]
    def test_new_forms_and_script_outputs(self):
        self.assertEqual(len(self.all),89)
        header=self.forms[0][2]
        self.assertEqual(s.unpack_from('<I',header[b'HEDR'],4)[0],88)
        self.assertEqual(header[b'MAST'],b'Skyrim.esm\0')
        self.assertTrue(self.forms[0][1]&0x200)
        self.assertTrue(all(fid>>24==1 for fid in self.forms if fid))
        for p in (ROOT/'Data/Scripts/Source').glob('*.psc'):
            data=(ROOT/'Data/Scripts'/p.with_suffix('.pex').name).read_bytes()
            self.assertEqual(data[:4],bytes.fromhex('fa57c0de'),p.name)
    def test_mortal_isolated_adult_bases(self):
        for first,listid,sex in [(0x900,0x820,0),(0x940,0x821,1)]:
            bases=[U32.unpack(v)[0] for k,v in self.fields(listid)[b'_entries'] if k==b'LNAM']
            self.assertEqual(bases,[0x01000000|first+i for i in range(32)])
            for local in range(first,first+32):
                fields=self.fields(local);flags=U32.unpack_from(fields[b'ACBS'])[0]
                self.assertEqual(flags&1,sex)
                self.assertFalse(flags&(2|0x800|0x80000000|8))
                self.assertFalse(flags&0x20)
                self.assertTrue(flags&4)
                self.assertNotIn(b'PRKR',fields)
                self.assertIn(b'DynastyHeirActor',fields[b'VMAD'])
    def test_dialogue_policy_matrix(self):
        fields=self.fields(0x80a)
        conditions=[v for k,v in fields[b'_entries'] if k==b'CTDA']
        decoded=[s.unpack('<B3xfH2xIIIIi',x) for x in conditions]
        self.assertEqual([x[2] for x in decoded],[70,46,365,289,719,136,72,72])
        self.assertEqual(decoded[4][3],0x14)
        self.assertTrue(all(x[0]==0 and x[5]==0 for x in decoded))
        def allows(female=True,dead=False,child=False,combat=False,hostile=False,player=False,dynasty_juvenile=False):
            values={70:int(female),46:int(dead),365:int(child),289:int(combat),719:int(hostile),136:int(player),72:int(dynasty_juvenile)}
            return all(values[x[2]]==x[1] for x in decoded)
        self.assertTrue(allows())
        for key in ['dead','child','combat','hostile','player','dynasty_juvenile']:
            self.assertFalse(allows(**{key:True}),key)
        self.assertFalse(allows(female=False))
        self.assertFalse(allows(hostile=True,combat=False))
        self.assertEqual(U32.unpack(self.fields(0x807)[b'DNAM'])[0],1)
        self.assertIn(b'TIF_DYNA_Breeding',fields[b'VMAD'])
        self.assertEqual(self.fields(0x809)[b'SNAM'],b'PFGT')
    def test_summon_succession_and_private_juvenile_records(self):
        manager=self.fields(0x800)[b'VMAD']
        for prop in [b'ArrivalPortalBase',b'ArrivalShader',b'ArrivalSound',b'SuccessionMessage',b'Successor']:
            self.assertIn(prop,manager)
        for child,race in [(0x810,0x850),(0x811,0x851)]:
            fields=self.fields(child)
            self.assertEqual(U32.unpack(fields[b'RNAM'])[0],0x01000000|race)
            self.assertIn(b'DynastyHeirActor',fields[b'VMAD'])
            self.assertFalse(U32.unpack_from(fields[b'ACBS'])[0]&(2|0x800|0x80000000|8))
            self.assertFalse(U32.unpack_from(self.fields(race)[b'DATA'],32)[0]&4)
        menu=self.fields(0x823)
        self.assertIn(b'<Alias=Successor>',menu[b'DESC'])
        buttons=[v.rstrip(b'\0').decode() for k,v in menu[b'_entries'] if k==b'ITXT']
        self.assertEqual(buttons,['Continue as this heir','Next heir','Previous heir','Normal death'])
    def test_package_order_and_equipment(self):
        entries=self.fields(0x804)[b'_entries'];tags=[k for k,v in entries]
        self.assertLess(tags.index(b'PSDT'),tags.index(b'CTDA'))
        for local in range(0x830,0x834):
            equipment=[U32.unpack(v)[0] for k,v in self.fields(local)[b'_entries'] if k==b'LNAM']
            self.assertGreaterEqual(len(equipment),3)
            self.assertEqual(len(equipment),len(set(equipment)))
        self.assertEqual((ROOT/'Data/SEQ/DynastyHeirs.seq').read_bytes(),s.pack('<II',0x01000800,0x01000802))

if __name__=='__main__':unittest.main()
