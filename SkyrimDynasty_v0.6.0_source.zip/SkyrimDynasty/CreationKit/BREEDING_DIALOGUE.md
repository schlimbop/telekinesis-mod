# Global Breeding dialogue — implemented companion



The shared records are already in Data/DynastyHeirs.esp and the compiled fragment

is Data/Scripts/TIF_DYNA_Breeding.pex. The generator is tools/build_companion.py.

No individual NPC edits, per-partner aliases or nearby-actor scanning are used.



DYNA_BreedingDialogueQuest owns a top-level, non-blocking, non-exclusive branch.

Its topic text is exactly Breeding. All INFO conditions use Subject and AND:



| Function | Parameter | Comparison |

|---|---|---|

| GetIsSex | Female | == 1 |

| GetDead | none | == 0 |

| IsChild | none | == 0 |

| IsInCombat | 0 | == 0 |

| IsHostileToActor | PlayerRef | == 0 |

| GetIsReference | PlayerRef | == 0 |
| GetIsID | DYNA_ChildHeirMale | == 0 |
| GetIsID | DYNA_ChildHeirFemale | == 0 |



The Begin fragment passes akSpeakerRef as Actor to SelectBreeding. Its quest

property points to the existing lifecycle manager. CreateHeir rechecks eligibility

before spawning and uses PlayerRef and that exact speaker for CreateGenome.

The End fragment is empty. No voice-type, NPC ID or race allowlist is imposed.



The second INFO belongs to the adult greeting quest, is delivered through its

ForceGreet topic, and calls CompleteGreeting in its End fragment. Both fragment

bindings are present in INFO VMAD and compiled PEX files.



SEQ includes both start-enabled quests. Existing adult command-menu activation

is retained; choose Talk normally to enter an adult heir's ordinary dialogue.


The two private juvenile bases are explicitly denied because their private races
remove engine child immunity for mortality. Their visual age/stages remain
juvenile. This exclusion does not restrict unrelated adult NPCs or require patches.
