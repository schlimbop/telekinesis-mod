# Generated companion records



These records are already assembled in Data/DynastyHeirs.esp. No manual CK work

is needed. tools/build_companion.py regenerates them from an owned Skyrim.esm.

The generator creates 88 new records and no master overrides, plus SEQ data.



- Lifecycle, breeding dialogue and adult greeting quests, with filled properties.

- Player alias with save/load/bleedout handling and an optional Successor alias.

- The global top-level Breeding branch, topic, INFO and compiled Begin fragment.

- An adult ForceGreet topic and compiled End fragment.

- Travel, ForceGreet and current-location sandbox packages.

- Two child NPC bases and 64 adult bases (32 unique slots per sex).

- Two adult-base FormLists and four coherent equipment-set FormLists.

- An equipment-set pool, adult command Message and four-button succession Message.
- Two private mortal juvenile races. Summon properties reference vanilla assets.



See build_records.json for canonical IDs. Adult base ranges 0x900-0x91F and

0x940-0x95F are also validated by the native perk-application code; preserve them

when rebuilding. The plugin is ESL flagged and uses old-runtime-safe local IDs.

