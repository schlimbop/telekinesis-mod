"""Exercise the actual equipment routine with a loaded/unloaded actor and saved choice."""
from pathlib import Path
from types import SimpleNamespace as NS
import re, unittest
S=(Path(__file__).resolve().parents[1]/'Data/Scripts/Source/DynastyLifecycleQuest.psc').read_text()
def routine(env, name="EquipRandomAdultLoadout"):
    text=re.search(r'Function '+name+r'\([^\n]*\)\n(.*?)\nEndFunction',S,re.S)[1]
    lines=['def '+('equip(akAdult, replaceInventory=False)' if name=='EquipRandomAdultLoadout' else 'repair(akHeir)')+':','    global AdultLoadouts, LoadoutChoices'];depth=1
    for raw in text.splitlines():
        line=raw.split(';',1)[0].strip()
        if not line or line.startswith('Debug.Trace('):continue
        if line in ['endif','endwhile']:depth-=1;continue
        line=line.replace('items.Length','len(items)').replace('removed.Length','len(removed)')
        line=line.replace('LoadoutChoices.Length', 'len(LoadoutChoices)').replace('new Int[32]', '[0]*32')
        line=line.replace('(item as Armor)','isinstance(item, Armor)').replace('item as Ammo','isinstance(item, Ammo)')
        line=re.sub(r'\s+as (?:FormList|Outfit)\b','',line)
        line=re.sub(r'^(?:Int|Outfit|FormList|Form\[\]|Form)\s+','',line)
        line=line.replace('&&',' and ').replace('||',' or ')
        line=re.sub(r'!(?!=)','not ',line)
        block=line.startswith(('if ','while '))
        lines.append('    '*depth+line+(':' if block else ''))
        if block:depth+=1
    exec('\n'.join(lines),env)
class Armor:pass
class Ammo:pass
class Actor:
    def __init__(self,loaded=True):self.loaded=loaded;self.inventory={};self.equipped=[];self.outfits=[];self.timeline=[];self.rebuilds=0
    def Is3DLoaded(self):return self.loaded
    def SetOutfit(self,items,_):
        self.outfits.append(items)
        for item in items:self.inventory[item]=1
    def RemoveAllItems(self,*args):self.inventory.clear();self.equipped.clear()
    def GetItemCount(self,item):return self.inventory.get(item,0)
    def AddItem(self,item,count,_):self.inventory[item]=self.GetItemCount(item)+count
    def EquipItem(self,item,*_):
        assert self.GetItemCount(item)>0
        self.equipped.append(item)
    def UnequipItem(self,item,*args):
        if item in self.equipped:self.equipped.remove(item)
    def RemoveItem(self,item,count,*args):
        self.timeline.append('remove');self.inventory.pop(item,None)
    def IsOnMount(self):return False
    def QueueNiNodeUpdate(self):self.rebuilds+=1
    def GetDisplayName(self):return 'Heir'
class EquipmentTests(unittest.TestCase):
    def setUp(self):
        self.armor=[Armor(),Armor(),Armor()];self.weapon=object();self.ammo=Ammo();self.rolls=[]
        items=self.armor+[self.weapon,self.ammo]
        def generate(*args):self.rolls.append(args);return items
        self.env=dict(Armor=Armor,Ammo=Ammo,LoadoutChoices=[0]*32,
            FindHeirIndex=lambda a:0,AdultLoadouts=None,
            DynastyNative=NS(GenerateLoadout=generate,PrepareOutfit=lambda actor:self.armor),
            GiveCombatSpells=lambda actor:None,Debug=NS(Trace=lambda s:None))
        routine(self.env)
    def test_equipment_requires_loaded_actor(self):
        actor=Actor(False);self.env['equip'](actor)
        self.assertEqual(actor.inventory,{})
        self.assertEqual(self.rolls,[])
    def test_complete_set_and_persistent_choice_without_duplicate_items(self):
        actor=Actor();self.env['equip'](actor)
        self.assertEqual(self.env['LoadoutChoices'][0],-1)
        self.assertEqual(actor.GetItemCount(self.ammo),40)
        self.assertEqual(actor.GetItemCount(self.weapon),1)
        self.assertTrue(all(actor.GetItemCount(x)==1 for x in self.armor))
        snapshot=actor.inventory.copy();self.env['equip'](actor)
        self.assertEqual(actor.inventory,snapshot)
        self.assertEqual(len(self.rolls),1)
        self.assertEqual(len(actor.outfits),1)
    def test_legacy_inventory_is_not_replaced(self):
        actor=Actor();actor.inventory[self.weapon]=7;self.env['LoadoutChoices'][0]=3
        self.env['equip'](actor)
        self.assertEqual(actor.inventory,{self.weapon:7});self.assertEqual(self.rolls,[])
    def test_failed_native_generation_retries_on_next_load(self):
        self.env['DynastyNative'].GenerateLoadout=lambda *args:[]
        actor=Actor();self.env['equip'](actor)
        self.assertEqual(self.env['LoadoutChoices'][0],0)
        self.assertEqual(actor.inventory,{})
    def test_fresh_set_clears_old_traded_items_and_replaces_ammo_without_duplicates(self):
        actor=Actor();old=object();actor.inventory[old]=9
        self.env['LoadoutChoices'][0]=-1
        actor.inventory[self.ammo]=500;actor.inventory[self.weapon]=7
        self.env['equip'](actor,True)
        self.assertNotIn(old,actor.inventory)
        self.assertEqual(actor.GetItemCount(self.ammo),40)
        self.assertEqual(actor.GetItemCount(self.weapon),1)
        self.assertTrue(all(actor.GetItemCount(x)==1 for x in self.armor))
        self.assertTrue(self.rolls[0][2])
    def test_failed_fresh_set_keeps_inventory_and_previous_saved_choice(self):
        actor=Actor();old=object();actor.inventory[old]=9
        self.env['LoadoutChoices'][0]=3
        self.env['DynastyNative'].GenerateLoadout=lambda *args:[]
        self.env['equip'](actor,True)
        self.assertEqual(actor.inventory,{old:9})
        self.assertEqual(self.env['LoadoutChoices'][0],3)
    def test_unloaded_fresh_set_keeps_inventory(self):
        actor=Actor(False);old=object();actor.inventory[old]=9
        self.env['equip'](actor,True)
        self.assertEqual(actor.inventory,{old:9});self.assertEqual(self.rolls,[])

    def test_missing_replacement_outfit_does_not_wipe_inventory(self):
        actor=Actor();old=object();actor.inventory[old]=9
        self.env['DynastyNative'].PrepareOutfit=lambda actor:None
        self.env['LoadoutChoices'][0]=-1
        self.env['equip'](actor,True)
        self.assertEqual(actor.inventory,{old:9});self.assertEqual(actor.outfits,[])
        self.assertEqual(self.env['LoadoutChoices'][0],-1)
    def test_upgrade_removes_invalid_generated_gear_only_and_rebuilds_once(self):
        bad=Armor();actor=Actor();actor.inventory={bad:1,self.weapon:3,self.ammo:500};actor.equipped=[bad]
        self.env['DynastyNative'].RemoveInvalidLoadoutItems=lambda actor:[bad]
        self.env['DynastyNative'].PrepareOutfit=lambda actor:actor.timeline.append('outfit')
        routine(self.env,'RepairHeirEquipment');self.env['repair'](actor)
        self.assertEqual(actor.timeline,['outfit','remove'])
        self.assertEqual(actor.inventory,{self.weapon:3,self.ammo:500})
        self.assertEqual(actor.equipped,[]);self.assertEqual(actor.rebuilds,1)
        self.env['DynastyNative'].RemoveInvalidLoadoutItems=lambda actor:[]
        self.env['repair'](actor)
        self.assertEqual(actor.rebuilds,1);self.assertEqual(actor.timeline,['outfit','remove'])

if __name__=='__main__'  :unittest.main()
