#include "LoadoutRules.h"
#include <cassert>
#include <set>
#include <map>
using namespace Dynasty::Equipment;
int main() {
    // Real regression: Cheat Room's "Ring Equip Slot 30 - Head" uses the silver-ring
    // addon (slot 36). It passed the old "any model exists" check and hid the head.
    assert(!ArmorModelCovers(1,64));
    assert(!ArmorModelCovers(4,64));
    assert(!ArmorModelCovers(1U<<21,64));
    assert(!ArmorModelCovers(1,0)); // No addon model for this race/sex.
    assert(!ArmorModelCovers(1|4,4)); // Body addon cannot replace a suppressed head.
    assert(ArmorModelCovers(0x3003,1)); // Vanilla full Imperial/Daedric helmet.
    assert(ArmorModelCovers(0x1002,0x2002)); // Iron helmet may intentionally hide hair/ears.
    assert(ArmorModelCovers(4|8|128,4|8|128)); // Multiple valid addons cover an outfit.
    assert(ArmorModelCovers(1U<<25,1U<<25)); // Custom accessory slots still work.
    std::vector<Item> pool;
    for(std::uint32_t mod:{0U,0x02000000U,0xFE001000U}) {
        for(auto [id,mask]:std::vector<std::pair<std::uint32_t,std::uint32_t>>{{1,4},{2,4|8|128},{3,8},{4,128},{5,1|2},{6,512},{7,64},{8,1U<<25}})
            pool.push_back({mod+id,mask,Kind::Armor,int(id%3),float(id)/8,false});
        for(int type=1;type<=9;++type)pool.push_back({mod+100+std::uint32_t(type),0,Kind::Weapon,type,float(type)/10,false});
        pool.push_back({mod+200,0,Kind::Ammo,0,0.2F,false});pool.push_back({mod+201,0,Kind::Ammo,0,0.9F,true});
    }
    std::map<std::uint32_t,Item> lookup;for(auto i:pool)lookup[i.id]=i;
    std::set<std::vector<std::uint32_t>> kits;std::set<std::uint32_t> selected;
    std::mt19937_64 rng(1234);
    for(int n=0;n<10000;++n) {
        auto kit=Select(pool,1+n%5,float(n%101)/100,rng);kits.insert(kit);std::uint32_t slots=0;int weapon=0,ammo=0;
        for(auto id:kit){selected.insert(id);const auto& i=lookup.at(id);
            if(i.kind==Kind::Weapon)weapon=i.type;
            if(i.kind==Kind::Armor){assert(!(slots&i.mask));slots|=i.mask;}
            if(i.kind==Kind::Ammo){ammo++;assert(i.bolt==(weapon==9));assert(weapon==7||weapon==9);}
        }
        assert(slots&4);if(TwoHanded(weapon)||weapon==8)assert(!(slots&512));
        assert(ammo==int(weapon==7||weapon==9));assert(kit.size()<=13);
    }
    assert(kits.size()>1000);assert(selected.size()==pool.size());
    assert(Select({},1,0.5F,rng).empty());
    // The identical seed reconstructs an identical selection; save restoration does not call Select.
    std::mt19937_64 a(9),b(9);assert(Select(pool,3,.7F,a)==Select(pool,3,.7F,b));
}
