"""Package only after a built x64 DLL is supplied; source archives exclude owned face assets."""
from pathlib import Path
import argparse,hashlib,json,struct,zipfile
ROOT=Path(__file__).resolve().parents[1]

def package(destination,dll=None,source=False):
    items={}
    if source:
        for p in ROOT.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and not any(part in ['build','.git'] for part in p.parts):
                rel=p.relative_to(ROOT).as_posix()
                if rel.startswith(('Data/meshes/','Data/textures/')) or p.suffix in ['.zip','.dll','.pdb','.pyc']:continue
                items['SkyrimDynasty/'+rel]=p.read_bytes()
    else:
        if not dll:raise ValueError('A compiled DLL is required; no source-only installer')
        data=Path(dll).read_bytes();assert data[:2]==b'MZ'
        pe=struct.unpack_from('<I',data,0x3c)[0]
        assert data[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',data,pe+4)[0]==0x8664
        assert b'SKSEPlugin_Load\0' in data and b'SKSEPlugin_Version\0' in data
        for p in (ROOT/'Data').rglob('*'):
            if p.is_file() and 'Source' not in p.parts:items[p.relative_to(ROOT/'Data').as_posix()]=p.read_bytes()
        assert len([n for n in items if n.endswith('.nif')])==66
        assert len([n for n in items if n.endswith('.dds')])==66
        assert len([n for n in items if n.endswith('.pex')])==8
        items['SKSE/Plugins/SkyrimDynasty.dll']=data
        pdb=Path(dll).with_suffix('.pdb')
        if pdb.exists():items['SKSE/Plugins/SkyrimDynasty.pdb']=pdb.read_bytes()
        items['README.md']=(ROOT/'README.md').read_bytes()
    hashes={n:hashlib.sha256(b).hexdigest() for n,b in items.items()}
    items['SHA256SUMS.json']=(json.dumps(hashes,indent=2)+'\n').encode()
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in items.items():z.writestr(n,b)
    with zipfile.ZipFile(destination) as z:
        for n,digest in hashes.items():assert hashlib.sha256(z.read(n)).hexdigest()==digest,n
    print(f'Packaged {destination}: {len(hashes)} verified file hashes')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--dll');p.add_argument('--source',action='store_true');p.add_argument('--output',required=True);a=p.parse_args();package(a.output,a.dll,a.source)
