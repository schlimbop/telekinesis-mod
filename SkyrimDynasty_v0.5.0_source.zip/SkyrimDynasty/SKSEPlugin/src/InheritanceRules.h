#pragma once
#include <algorithm>
namespace Dynasty {
constexpr float InheritedSkill(float player, float mother, float variation) {
    return std::clamp((player + mother) * 0.5F + variation, 0.0F, 100.0F);
}
constexpr bool InheritPerk(bool player, bool mother, bool coin) {
    return (player && mother) || ((player || mother) && coin);
}
}
