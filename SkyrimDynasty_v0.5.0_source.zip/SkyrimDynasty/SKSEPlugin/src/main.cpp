#include "Genetics.h"

#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <algorithm>

namespace
{
    constexpr std::uint32_t kSerializationID = 'DYNA';

    bool CreateGenome(
        RE::StaticFunctionTag*,
        RE::Actor* child,
        RE::Actor* parentA,
        RE::Actor* parentB)
    {
        if (!child || !parentA || !parentB) {
            return false;
        }

        auto& engine = Dynasty::GeneticsEngine::GetSingleton();

        auto ga = engine.GetGenome(parentA);
        if (!ga) {
            ga = engine.MakeFounderGenome(parentA);
            engine.AttachGenome(parentA, *ga);
        }

        auto gb = engine.GetGenome(parentB);
        if (!gb) {
            gb = engine.MakeFounderGenome(parentB);
            engine.AttachGenome(parentB, *gb);
        }

        auto childGenome = engine.Breed(*ga, *gb);
        childGenome.sex = child->GetActorBase()->GetSex() == RE::SEX::kFemale ?
            Dynasty::Sex::Female : Dynasty::Sex::Male;
        childGenome.parentAFormID = parentA->GetFormID();
        childGenome.parentBFormID = parentB->GetFormID();

        if (!engine.CaptureTalents(child, parentA, parentB)) return false;
        return engine.AttachGenome(child, std::move(childGenome));
    }

    bool TransferGenome(
        RE::StaticFunctionTag*,
        RE::Actor* oldActor,
        RE::Actor* newActor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().TransferGenome(oldActor, newActor);
    }

    bool ApplyInheritedAppearance(
        RE::StaticFunctionTag*,
        RE::Actor* actor,
        std::int32_t)
    {
        if (!actor) {
            return false;
        }

        // Height is applied from Papyrus through GetInheritedHeightScale().
        //
        // Full facial implementation point:
        // - retrieve genome
        // - derive expressed phenotype
        // - map phenotype values into RaceMenu/NiOverride morph keys
        // - apply morphs to this reference without altering the shared ActorBase
        // - refresh FaceGen/tints safely
        return Dynasty::GeneticsEngine::GetSingleton().GetGenome(actor).has_value();
    }

    std::string GetGenomeDebugString(
        RE::StaticFunctionTag*,
        RE::Actor* actor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().Describe(actor);
    }

    std::string GenerateName(
        RE::StaticFunctionTag*,
        RE::Actor*,
        bool female)
    {
        return Dynasty::GeneticsEngine::GetSingleton().GenerateName(female);
    }

    float GetInheritedHeightScale(
        RE::StaticFunctionTag*,
        RE::Actor* actor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().HeightScale(actor);
    }

    bool PrepareAdult(RE::StaticFunctionTag*, RE::Actor* child, RE::TESNPC* base) {
        return Dynasty::GeneticsEngine::GetSingleton().PrepareAdult(child, base);
    }
    bool ApplyInheritedSkills(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().ApplyInheritedSkills(actor);
    }
    bool RestoreInheritedPerks(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().RestoreInheritedPerks(actor);
    }

    void ForgetActor(RE::StaticFunctionTag*, RE::Actor* actor) {
        Dynasty::GeneticsEngine::GetSingleton().ForgetActor(actor);
    }
    bool AdoptHeir(RE::StaticFunctionTag*, RE::Actor* heir) {
        return Dynasty::GeneticsEngine::GetSingleton().AdoptHeir(heir);
    }
    bool CopyHeirAppearance(RE::StaticFunctionTag*, RE::Actor* heir) {
        auto* player = RE::PlayerCharacter::GetSingleton();
        if (!player || !heir || heir->IsDead() ||
            !Dynasty::GeneticsEngine::GetSingleton().GetGenome(heir)) return false;
        auto* src = heir->GetActorBase();
        auto* dst = player->GetActorBase();
        if (!src || !dst || !src->headParts || src->numHeadParts <= 0) return false;
        const auto count = static_cast<std::size_t>(src->numHeadParts);
        auto** parts = RE::calloc<RE::BGSHeadPart*>(count);
        if (!parts) return false;
        std::copy_n(src->headParts, count, parts);
        RE::free(dst->headParts);
        dst->headParts = parts;
        dst->numHeadParts = src->numHeadParts;
        dst->faceNPC = nullptr;
        using Flag = RE::ACTOR_BASE_DATA::Flag;
        if (src->GetSex() == RE::SEX::kFemale) dst->actorData.actorBaseFlags.set(Flag::kFemale);
        else dst->actorData.actorBaseFlags.reset(Flag::kFemale);
        if (src->faceData) {
            if (!dst->faceData) dst->faceData = RE::calloc<RE::TESNPC::FaceData>(1);
            if (dst->faceData) *dst->faceData = *src->faceData;
        }
        dst->weight = src->weight;
        dst->height = src->height;
        dst->bodyTintColor = src->bodyTintColor;
        dst->skin = src->skin;
        dst->farSkin = src->farSkin;
        if (src->headRelatedData) {
            dst->SetHairColor(src->headRelatedData->hairColor);
            dst->SetFaceTexture(src->headRelatedData->faceDetails);
        }
        dst->AddChange(RE::TESNPC::ChangeFlags::kFace | RE::TESNPC::ChangeFlags::kGender);
        player->DoReset3D(true);
        return true;
    }

    bool RegisterPapyrus(RE::BSScript::IVirtualMachine* vm)
    {
        vm->RegisterFunction("ForgetActor", "DynastyNative", ForgetActor);
        vm->RegisterFunction("AdoptHeir", "DynastyNative", AdoptHeir);
        vm->RegisterFunction("CopyHeirAppearance", "DynastyNative", CopyHeirAppearance);
        vm->RegisterFunction("PrepareAdult", "DynastyNative", PrepareAdult);
        vm->RegisterFunction("ApplyInheritedSkills", "DynastyNative", ApplyInheritedSkills);
        vm->RegisterFunction("RestoreInheritedPerks", "DynastyNative", RestoreInheritedPerks);
        vm->RegisterFunction("CreateGenome", "DynastyNative", CreateGenome);
        vm->RegisterFunction("TransferGenome", "DynastyNative", TransferGenome);
        vm->RegisterFunction("ApplyInheritedAppearance", "DynastyNative", ApplyInheritedAppearance);
        vm->RegisterFunction("GetGenomeDebugString", "DynastyNative", GetGenomeDebugString);
        vm->RegisterFunction("GenerateName", "DynastyNative", GenerateName);
        vm->RegisterFunction("GetInheritedHeightScale", "DynastyNative", GetInheritedHeightScale);
        return true;
    }

    void SaveCallback(SKSE::SerializationInterface* intfc)
    {
        Dynasty::GeneticsEngine::GetSingleton().Save(intfc);
    }

    void LoadCallback(SKSE::SerializationInterface* intfc)
    {
        Dynasty::GeneticsEngine::GetSingleton().Load(intfc);
    }

    void RevertCallback(SKSE::SerializationInterface*)
    {
        Dynasty::GeneticsEngine::GetSingleton().Revert();
    }
}

SKSEPluginLoad(const SKSE::LoadInterface* skse)
{
    SKSE::Init(skse);

    auto* papyrus = SKSE::GetPapyrusInterface();
    if (!papyrus || !papyrus->Register(RegisterPapyrus)) {
        return false;
    }

    auto* serialization = SKSE::GetSerializationInterface();
    if (!serialization) {
        return false;
    }

    serialization->SetUniqueID(kSerializationID);
    serialization->SetSaveCallback(SaveCallback);
    serialization->SetLoadCallback(LoadCallback);
    serialization->SetRevertCallback(RevertCallback);

    return true;
}
