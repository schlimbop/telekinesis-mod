#pragma once

#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>

#include <cstdint>
#include <array>
#include <mutex>
#include <vector>
#include <optional>
#include <random>
#include <string>
#include <unordered_map>

namespace Dynasty
{
    enum class Sex : std::uint8_t
    {
        Male = 0,
        Female = 1
    };

    struct DiploidFloat
    {
        float a{ 0.5F };
        float b{ 0.5F };
    };

    struct Genome
    {
        std::uint64_t logicalID{ 0 };

        DiploidFloat jawWidth;
        DiploidFloat chinHeight;
        DiploidFloat noseLength;
        DiploidFloat noseWidth;
        DiploidFloat eyeSpacing;
        DiploidFloat eyeSize;
        DiploidFloat cheekHeight;
        DiploidFloat browHeight;
        DiploidFloat height;

        DiploidFloat intelligence;
        DiploidFloat physique;
        DiploidFloat magicalAffinity;

        RE::FormID parentAFormID{ 0 };
        RE::FormID parentBFormID{ 0 };

        Sex sex{ Sex::Male };
    };

    struct TalentGenome
    {
        std::array<float, 18> skills{};
        std::vector<RE::FormID> perks;
    };

    class GeneticsEngine
    {
    public:
        static GeneticsEngine& GetSingleton();

        Genome MakeFounderGenome(RE::Actor* actor);
        Genome Breed(const Genome& parentA, const Genome& parentB);

        bool AttachGenome(RE::Actor* actor, Genome genome);
        bool TransferGenome(RE::Actor* oldActor, RE::Actor* newActor);
        std::optional<Genome> GetGenome(RE::Actor* actor) const;

        std::string Describe(RE::Actor* actor) const;
        std::string GenerateName(bool female);
        float HeightScale(RE::Actor* actor) const;

        bool CaptureTalents(RE::Actor* child, RE::Actor* player, RE::Actor* mother);
        bool PrepareAdult(RE::Actor* child, RE::TESNPC* base);
        bool ApplyInheritedSkills(RE::Actor* actor);
        bool RestoreInheritedPerks(RE::Actor* actor);

        void ForgetActor(RE::Actor* actor);
        bool AdoptHeir(RE::Actor* heir);
        void ResetBasePerks(RE::TESNPC* base);

        void Save(SKSE::SerializationInterface* intfc) const;
        void Load(SKSE::SerializationInterface* intfc);
        void Revert();

    private:
        GeneticsEngine();
        bool ApplyPerks(RE::TESNPC* base, const TalentGenome& talent);
        void SaveTalents(SKSE::SerializationInterface* stream) const;
        void LoadTalentsRecord(SKSE::SerializationInterface* stream, std::uint32_t version);
        void ClearTalents();
        std::unordered_map<RE::FormID, TalentGenome> talents_;
        std::unordered_map<RE::FormID, std::vector<RE::FormID>> appliedBasePerks_;

        float ChooseAllele(const DiploidFloat& locus);
        DiploidFloat BreedLocus(const DiploidFloat& a, const DiploidFloat& b);
        float Mutate(float value);
        float Phenotype(const DiploidFloat& locus) const;
        std::uint64_t NextID();

        mutable std::recursive_mutex mutex_;
        mutable std::mt19937_64 rng_;
        std::unordered_map<RE::FormID, Genome> genomes_;
        std::uint64_t nextID_{ 1 };
    };
}
