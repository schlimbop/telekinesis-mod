"""Execute the manager's non-latent slot/selection code with mocked Skyrim objects.
This translates only the small Papyrus subset used below; it is not a game VM.
"""
from pathlib import Path
from types import SimpleNamespace
import re, unittest
SOURCE=(Path(__file__).resolve().parents[1]/'Data/Scripts/Source/DynastyLifecycleQuest.psc').read_text()

def load_function(name,env):
    match=re.search(r'(?m)^(?:Int )?Function '+name+r'\((.*?)\)\s*\n(.*?)^EndFunction',SOURCE,re.S|re.M)
    if not match:raise AssertionError(name)
    args=re.sub(r'\b(?:Int|Actor)\s+','',match[1])
    lines=['def '+name+'('+args+'):'];depth=1
    for raw in match[2].splitlines():
        line=raw.split(';',1)[0].strip()
        if not line:continue
        if line.lower() in ['endif','endwhile']:
            depth-=1;continue
        if line.lower().startswith(('elseif ','else')):depth-=1
        line=re.sub(r'^(?:Int|Bool|Actor|DynastyAdultGreetingQuest)\s+','',line)
        line=re.sub(r'\s+as DynastyAdultGreetingQuest\b','',line)
        line=line.replace('&&',' and ').replace('||',' or ')
        line=re.sub(r'!(?!=)','not ',line)
        line=re.sub(r'^elseif ','elif ',line)
        block=line.startswith(('if ','elif ','while ')) or line=='else'
        lines.append('    '*depth+line+(':' if block else ''))
        if block:depth+=1
    exec('\n'.join(lines),env)

class Actor:
    def __init__(self,dead=False):self.dead=dead;self.teammate=True
    def IsDead(self):return self.dead
    def ClearKeepOffsetFromActor(self):pass
    def SetPlayerTeammate(self,*args):self.teammate=False
class Marker:
    def __init__(self):self.disabled=False;self.deleted=False
    def Disable(self):self.disabled=True
    def Delete(self):self.deleted=True

class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.forgot=[];self.cancelled=[]
        self.env=dict(MaxHeirs=32,heirCount=32,HeirRefs=[None]*32,SlotBusy=[False]*32,
            BirthDays=[0.0]*32,Stages=[0]*32,BehaviourStates=[0]*32,
            GreetingPending=[False]*32,GreetingCompleted=[False]*32,
            ParentA=[None]*32,ParentB=[None]*32,HomeMarkers=[None]*32,
            GreetingQuest=SimpleNamespace(CancelForHeir=self.cancelled.append),
            DynastyNative=SimpleNamespace(ForgetActor=self.forgot.append))
        for name in ['FindFreeHeirSlot','ReleaseHeirSlot','ReclaimDeadSlots','NextAdultHeir','GetHeirCount']:
            load_function(name,self.env)
    def test_thousands_of_births_reuse_dead_slots(self):
        e=self.env
        for i in range(32):e['HeirRefs'][i]=Actor()
        self.assertEqual(e['FindFreeHeirSlot'](),-1)
        for birth in range(4096):
            retired=birth%32;old=e['HeirRefs'][retired];old.dead=True
            marker=Marker();e['HomeMarkers'][retired]=marker
            e['ParentB'][retired]=object();e['GreetingPending'][retired]=True
            e['ReclaimDeadSlots']()
            self.assertIsNone(e['ParentB'][retired]);self.assertFalse(e['GreetingPending'][retired])
            self.assertTrue(marker.disabled and marker.deleted)
            slot=e['FindFreeHeirSlot']();self.assertEqual(slot,retired)
            e['HeirRefs'][slot]=Actor()
            self.assertEqual(e['GetHeirCount'](),32)
        self.assertEqual(len(self.forgot),4096)
    def test_busy_slot_and_repeated_death_notification(self):
        e=self.env;e['HeirRefs'][0]=Actor(True);e['SlotBusy'][0]=True
        e['ReclaimDeadSlots']();self.assertIsNotNone(e['HeirRefs'][0])
        self.assertEqual(e['FindFreeHeirSlot'](),1)
        e['SlotBusy'][0]=False;e['ReclaimDeadSlots']();e['ReleaseHeirSlot'](0)
        self.assertEqual(len(self.forgot),1);self.assertEqual(e['FindFreeHeirSlot'](),0)
    def test_succession_skips_juveniles_dead_and_empty_slots(self):
        e=self.env
        e['HeirRefs'][0]=Actor();e['Stages'][0]=2
        e['HeirRefs'][3]=Actor(True);e['Stages'][3]=3
        for i in [10,31]:e['HeirRefs'][i]=Actor();e['Stages'][i]=3
        self.assertEqual(e['NextAdultHeir'](-1),10)
        self.assertEqual(e['NextAdultHeir'](10),31)
        self.assertEqual(e['NextAdultHeir'](31),10)
        self.assertEqual(e['NextAdultHeir'](10,-1),31)
        for i in [10,31]:e['HeirRefs'][i].dead=True
        self.assertEqual(e['NextAdultHeir'](-1),-1)
        self.assertEqual(e['GetHeirCount'](),1)
    def test_consuming_successor_frees_slot_without_death(self):
        e=self.env;e['HeirRefs'][17]=Actor();e['Stages'][17]=3
        self.assertEqual(e['NextAdultHeir'](-1),17)
        e['ReleaseHeirSlot'](17)
        self.assertEqual(e['NextAdultHeir'](-1),-1)
        self.assertEqual(e['GetHeirCount'](),0)

if __name__=='__main__':unittest.main()
