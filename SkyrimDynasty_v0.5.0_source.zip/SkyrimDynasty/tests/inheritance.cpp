#include "InheritanceRules.h"
#include <cstdlib>
#include <iostream>
#define CHECK(expr) do { if (!(expr)) { std::cerr << #expr << " failed\n"; return EXIT_FAILURE; } } while (false)
int main() {
    using namespace Dynasty;
    CHECK(InheritedSkill(100, 20, 0) == 60);
    CHECK(InheritedSkill(20, 100, 0) == 60);
    CHECK(InheritedSkill(100, 100, 5) == 100);
    CHECK(InheritedSkill(0, 0, -5) == 0);
    CHECK(InheritedSkill(20, 100, -5) == 55);
    for (bool coin : {false, true}) {
        CHECK(!InheritPerk(false, false, coin));
        CHECK(InheritPerk(true, true, coin));
        CHECK(InheritPerk(true, false, coin) == coin);
        CHECK(InheritPerk(false, true, coin) == coin);
    }
    std::cout << "Inheritance boundary and parent symmetry checks passed\n";
}
