# Known limitations — 0.5.0



- Native DLL compilation and Skyrim gameplay verification are pending. The ESP,

  SEQ, scripts and local template face assets are built; this is not yet a

  verified install-and-play release.

- Founder facial genomes are seeded randomly; actual player/NPC face extraction

  and the full runtime inherited face bridge remain unfinished. Inherited height

  is applied. Template FaceGen assets prevent missing-template assets; they do

  not constitute an inherited face renderer.

- Ageing is due at 10 days and processed at the next existing hourly game-time

  poll. Home sends an heir to its persistent marker to wait, not a full schedule.

- Following uses teammate + KeepOffsetFromActor instead of the vanilla follower

  slot. Adult management remains a Message menu; Talk normally opens dialogue.

- Top-level dialogue requires ordinary conversation. Blocking quest scenes may

  temporarily hide topics. Custom child races must have correct child metadata;

  Skyrim cannot infer age from appearance if a mod flags a child as an adult.

- Inherited perks retain their original conditions and engine limitations.

  Player-only perk effects will still be player-only. No inherited spells or

  arbitrary scripted quest stages are added.

- The generated companion establishes canonical FormIDs for the first time.

  A previously hand-built v0.2/0.3 ESP may use different IDs; no automatic migration

  of arbitrary hand-authored plugins is provided. Normal saves of this generated

  version retain their data and must keep the same plugin/FormIDs.

- There are 32 living slots, shared by juveniles and adults, and no lifetime birth
  limit. Dead/consumed slots are reused. This does not remove Skyrim's own engine,
  save-size or numeric limits, and normal corpses can remain until engine cleanup.
- Succession uses essential-player bleedout interception. It must be tested with
  damage, killmoves, falls, drowning, script kills and normal-death selection.
  Commands/scripts that force death can bypass bleedout. Other death-alternative
  mods that also manage player essential/ghost state need compatibility work.
- The existing inherited facial bridge remains unfinished. Succession copies
  current template head/body fields; RaceMenu overlays and full custom tint-mask
  transfer are not implemented. Save/reload of sex/race/face needs runtime testing.
- Succession carries quest progress, spells and predecessor inventory forward;
  it replaces skills/perks and equips the heir's items. This is character succession
  within one save, not a fresh campaign or reset of every quest-specific state.
