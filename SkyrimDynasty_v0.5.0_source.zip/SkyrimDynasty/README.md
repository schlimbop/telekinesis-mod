# Skyrim Dynasty 0.5.0



A CK3-inspired dynasty framework for Skyrim SE/AE with global Breeding dialogue.



**No Creation Kit assembly is required.** The generated `Data/DynastyHeirs.esp`,

SEQ, eight compiled Papyrus scripts, unique adult templates, AI packages and

random equipment pools are included. The native DLL still needs its Windows

build before an installable release can be packaged. No in-game tests have run.



## Breeding and heirs



Speak to a living adult female NPC outside combat who is not hostile to you.

Select **Breeding**. The player and that actual speaker are the genetic parents;

player sex is unrestricted. Conditions hide the option for children, dead,

hostile or fighting speakers, and creation rechecks the same policy.



Each child keeps its genome and random Skyrim-style individual name. At the

existing 10-game-day threshold, the hourly lifecycle poll promotes it to an adult,

which approaches via Travel and ForceGreet. Heirs are non-essential/non-protected.

Activate an adult heir for Follow, Wait here, Make this your home, Go home,

Dismiss or Talk normally. Normal Skyrim saves plus SKSE co-saves retain identity,

genetics, inherited talents, inventory and follower/residence state.



## Summon arrivals, mortality and living capacity

New children appear about 120 game units beside the player, inside Skyrim's
conjuration portal with its sound and a two-second body shader. Adult promotion
also uses this arrival. These are Skyrim's own Oblivion-style conjuration assets,
not assets copied from the separate Oblivion game. Temporary portals are removed.

There are **32 living children at once**, counting juveniles and adults together.
There is **no lifetime birth cap**. Death and succession free a slot immediately;
birth also sweeps deceased slots as a fallback. The slot number stays stable so
other siblings keep their homes, greetings and genetics. Retired actor genomes,
talent snapshots and home markers are released; recycled bases have their old
inherited perks removed before receiving another heir's perks. Corpses stay
lootable under normal engine cleanup rather than being forced persistent forever.

Both juveniles and adults are mortal and non-protected. Dynasty juveniles use
private copies of child races with engine child immunity removed, retaining the
child models. They remain explicitly excluded from Breeding in both the INFO
conditions and the manager. Vanilla child races and NPCs are never overridden.

## Continue as a living adult heir

While an adult heir is alive, the player becomes essential for defeat interception.
On bleedout, choose **Continue as this heir**, **Next heir**, **Previous heir** or
**Normal death**. The message displays the candidate's name through the Successor
alias. Dead heirs and juveniles cannot be selected. With no adult heir, normal
player death applies. The guard is refreshed at promotion, death, loading and a
five-second fallback check. This is a death alternative, not a resurrection after
Skyrim has already reloaded a save.

Succession moves the player to the selected heir and copies their genome, name,
sex/race, template head data, inherited scale, current 18 base skill levels,
current owned perks, health/magicka/stamina and character level. Their inventory
is transferred and their equipped instances are equipped on the player. The
predecessor's inventory and quest items remain available but are unequipped;
quest progress/spells remain on the player reference. Skill XP, legendary counts,
level XP and unspent perk points restart. The selected NPC is removed and its
living slot becomes available; the player and NPC cannot coexist as duplicates.

The original player reference remains 0x14 so quests can continue. Succession
copies the current template appearance, not an unfinished parental face renderer.
Exact face/tint persistence and equipment behavior still need Skyrim verification.

## Adult skills, perks and equipment



At birth, all 18 parental **base** skills are captured. The adult receives the

50/50 average for each skill, with a one-time random variation of -5 to +5 and

bounds of 0 to 100. Equipment, temporary buffs and damage do not affect the sample.



For every loaded perk form owned by the parents, the child inherits it with a

50% chance if one parent has it and certainty if both do. This includes mod-added

perks. The selection is captured at birth, stored in the SKSE co-save and carried

to the adult; later changes to either parent's perks do not reroll it. Perk effects

retain their original conditions; effects written only for the player do not

become NPC-compatible automatically. Spells are not copied.



Each of 32 heir slots has separate male/female adult bases, allowing its own NPC

perk array without modifying other heirs or vanilla NPCs. Perks are installed

before adult spawn and restored on load. Skill initialization only runs at

adulthood, so loading a save does not overwrite subsequent skill changes.



At adulthood, roll one coherent set: leather sword/shield, iron two-handed,

leather archer (40 arrows plus dagger), or novice mage robes/dagger. Items are

ordinary individual inventory, can be looted, and are not rerolled on reload.



## Build and installation status



Required for the finished installer: SKSE64 and the matching Address Library.

Fuz Ro D-oh is recommended for readable timing of the unvoiced dialogue,

particularly custom voice types. Enable dialogue subtitles.



The Windows GitHub Actions workflow in `.github/workflows/build.yml` builds the

CommonLibSSE-NG DLL and runs executable inheritance checks. Then use:



```

python tools/package.py --dll build/Release/SkyrimDynasty.dll --output SkyrimDynasty-0.5.0-install.zip

```



The package command refuses to make an installer without a real x64 SKSE DLL,

all eight PEX scripts and matching face assets. Once built, install that ZIP

with Vortex and enable DynastyHeirs.esp. Do not install the source ZIP as a mod.



The current local face assets come from four owned vanilla templates. They are

excluded from the portable source ZIP; `tools/prepare_faces.py` recreates them

from an owned installation (requires Python lz4). The appearance bridge remains

unfinished: faces are template faces, not fully inherited parental likenesses.



## Development verification



```

python -m unittest discover -s tests -v

```



Caprica 0.3.0 compiled all eight scripts. xEdit 4.1.5f Check for Errors passed.

Nine binary/lifecycle checks passed. Native compilation/CTest and Skyrim gameplay tests

remain pending; see VALIDATION.txt, KNOWN_LIMITATIONS.md and TESTING.md.

