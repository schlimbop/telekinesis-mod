# Skyrim Dynasty 0.9.6

Choose **Breeding** in ordinary dialogue with a living adult female NPC, including guards and hostile factions. Neither the player nor the NPC may be in combat. A named adult heir is summoned beside the player with a conjuration portal and sound. Player and speaker are the genetic parents. No Creation Kit assembly is needed.

## 0.9.6 armour model variants

Outfits now weight distinct worn appearances across the full compatible item pool, without an equal-per-plugin quota. Large variant collections such as Book of UUNP can contribute their many separate designs instead of sharing the same slice of picks as a one-item plugin. Copies of one vanilla mesh across many plugins or enchantments still share one appearance group. Same-name items with different worn-sex models remain separate candidates; names are never used to merge designs.

The selector uses the heir's actual male/female armour-addon meshes and texture swaps. Female bikini pieces can be drawn from installed playable armour, including modular pieces in custom slots; a mod's male fallback mesh remains its supplied male appearance. A display-name match does not imply a model match. Recent/current-kit avoidance, one headwear piece, four modular extras, ten total armour pieces, compatibility checks and configured exclusions/value limits remain in force. Existing kits are retained until you request a fresh set. The log now records the selected worn-sex model paths and distinct torso-design count so identically named variants can be checked directly.

## 0.9.6 equipment, cosmetics and summoning spell

New and explicitly replaced kits use at most ten armour/accessory pieces, including at most four modular extras and one headwear piece. These are limits, not fixed presets: the full compatible installed pool remains available. A single visible mesh cannot be selected repeatedly through slot-remapped forms. Open-face headwear takes priority over named masks/face coverings; full-head replacement helmets remain excluded by the existing headless-NPC guard. Unknown mod mesh geometry cannot be inspected universally from equipment records.

A fresh kit prioritises a different torso and weapon appearance from that heir's current kit when alternatives exist. Unused compatible appearances take priority globally, with each distinct appearance competing directly. Duplicate enchantments and texture-set records with the same actual model/texture paths share a design. Optional jewellery and bounded modular pieces prevent every free slot being filled. The old default outfit is detached before old inventory is cleared, then the replacement outfit is applied. Existing saved kits stay intact until you request a fresh set; retrieve anything you want to keep first.

Hairstyle changes now replace the loaded hair mesh as well as the saved head-part list. Hair-covering headwear is unequipped and retained in inventory so the change is visible. Explicit facepaint changes always choose a supported racial paint, avoiding the current mask when alternatives exist. The birth paint chance remains unchanged. Mesh/material updates run on the game thread; missing meshes, textures and unsupported racial masks still require compatible assets.

**Dynasty: Summon Heir** is added automatically to the player's spellbook on new and existing saves. Equip it from the Conjuration spells and cast it at an adult female NPC. Unlike dialogue, this spell accepts dead, hostile and fighting targets, including when the player is fighting. It creates a named adult heir with the player and target as genetic parents, beside the target, with portal, shader and sound. It does not resurrect or alter the mother. Children, the player and male targets are rejected. The normal living-heir capacity, mortality, genetics, skills/perks, follower orders and save persistence still apply. Rapid repeated hits while a birth is being staged are ignored. This spell has no magicka cost and always uses the summoning effects; dialogue/recall still respect the effects setting.

## Partners outside combat

Hostility and faction membership no longer restrict partner eligibility. The NPC must still be a living adult female, and neither actor may be in combat. The dialogue conditions check the NPC and player separately; the spawning function checks both again when selected. Children and the mod's private juvenile templates remain excluded.

For guards or enemies that only deliver a short line instead of opening full dialogue, aim at the nearby NPC and press **B**. A **Breeding / Cancel** prompt opens for a valid target within 250 game units. It uses the same genetics and birth function as speech. The original target is captured and rechecked after confirmation, so combat starting, moving out of range or changing the crosshair cannot create an heir with an unintended partner. Menus, disabled activation controls, unloaded/disabled targets and repeated key events are ignored.

Remap or disable the key in **SkyUI MCM > Skyrim Dynasty > Settings > Breeding: nearby targeted NPC**. Keyboard B works without SkyUI. A hostile NPC that detects and attacks the player must be out of combat again before either entry point can work. The shortcut does not pacify the actor or alter factions.

Version 0.9.6 includes a new matching native DLL and retains the succession inventory/spellbook fix.

## Succession inventory and spellbook fix

After choosing a living adult heir at death, the player keeps only that heir's carried items and known spells. The predecessor's inventory is cleared first, including gold, keys and quest-marked items, then the heir's actual item instances are transferred and worn equipment restored. Tempering, enchantments and stack extras use the existing engine transfer. An empty heir inventory produces an empty player inventory.

After race, perks and level are applied, the live successor spellbook replaces the predecessor's known spells, powers and abilities. This uses actual actor spells, including base and added spells, rather than only the generated mage kit. Shared spells remain; predecessor-only spells are unequipped, unfavourited and removed. The heir NPC is consumed only after transfer. Shouts/word unlocks and quest progress remain on the persistent player reference; other mods can still grant spells later through their own scripts. This applies to future succession, not retroactively to previous transitions.

## Family identity update

New births express facial features in coherent groups: nose, jaw, cheeks, eyes, brows, mouth and chin. Each group favours either parent's stored allele while retaining both parents' genetic contribution. The group's nose/eye/mouth preset and compatible eye part follow that same preference, with the existing chance of a new valid preset. Mutations remain stored, inheritable alleles. Face/body RGB and the selected racial skin family remain consistent. Existing saved faces are not rerolled.

SkyUI MCM now has **Appearance DNA** and **Appearance tools** pages. The DNA page selects a living heir and shows all 19 stored allele pairs and expressed values, with an asterisk on new mutations. Its report records parent names at birth, group dominance, race/eye/hair-colour origins and skin blending. Older heirs keep their saved alleles but report unknown parent-of-origin history instead of inventing it. A compact resemblance summary also appears in ordinary family/ability dialogue.

A following heir earns one perk point per new companion level, after the existing skill growth. It spends points on suitable perks from the installed skill trees, checking level, skill and prerequisite perks. Only playable, visible, non-trait perks with numeric combat/crafting entry points are learned automatically; quest, ability, activation and spell/script entries are excluded. Unsafe or unsupported mod perks are skipped. Unspent points are banked and retried on a later level gain or combat-role change. Inherited and earned perks are counted separately in reports, both survive saves and succession, and earned perks can be inherited by future children. Old heirs get no retroactive perk points merely for upgrading.

Heirs also inherit a saved temperament from their parents: assertiveness, bravery and preference for distance. These influence real NPC aggression/confidence and combat-style attack, retreat and range preferences. Aggression is bounded to unaggressive/aggressive; it never creates frenzy or very-aggressive village attackers. Heirs remain mortal and non-essential. Existing heirs acquire their temperament once on upgrade. These are AI preferences, not new voiced personality quests.

Three new speech commands restore the saved inherited appearance, randomise hairstyle only, or reroll facial paint only. The same actions are available in Appearance tools. Use them on a nearby loaded heir outside combat. Core genes, race, skin tone, skills, inventory and follow/home orders are preserved. Hair colour stays inherited during hairstyle rerolls; manual paint rerolls force a compatible paint when one exists. Missing/deleted required head parts fall back to parts from the saved race. There must still be a compatible racial head; repair cannot reconstruct missing third-party assets or arbitrary baked sculpts.

## Modular equipment update (0.9.6)

Fresh kits support modular pieces in compatible biped slots, within the piece limits above. This includes installed bikini tops, thongs, tassets, shoulder pads, bracers and other modular pieces. No named armour presets or plugin patches are required. Each distinct compatible appearance gets a chance; the torso source has a gentle preference for accessory pieces when matching is enabled. Armour classes, slot conflicts, race/sex meshes and the headless-helmet guard remain enforced. Packs with only female meshes cannot supply male outfits.

Existing outfits stay saved. Ask an heir to choose a new equipment set to use the new assembly; this replaces their old carried items. The generated-item log now lists names, plugin sources and slot masks for diagnosis. Visually overlapping meshes that use separate slots can still clip; the game records do not describe their geometry. The selector cannot reconstruct missing meshes or body conversions.

## Equipment variety and exclusions

New births and explicit fresh-kit requests draw from the full compatible installed weapon and armour pool. Every role can receive any weapon type and any torso armour class. Role and price preferences are gentle weights; they no longer exclude other weapon groups or torso classes. The existing compatibility checks still require usable models, matching race/sex, non-overlapping equipment slots and correct bow/crossbow ammunition. Generated full-head replacement helmets remain excluded because of the reported headless-actor problem.

The selector first prefers globally least-used compatible appearances and avoids the current kit where alternatives exist. The weights operate across distinct designs without a per-plugin quota, considering other heirs' generated kits and a rolling history of the last 512 generated item selections. That history survives saves, deaths, slot reuse and succession. It is bounded and does not add a lifetime child limit. An old save starts without historical entries but still considers existing saved kits. If the compatible pool is small, the least-used available item is reused rather than failing solely because it appeared before.

Enchanted duplicates with the same model/texture-swap signature share an appearance group. A hundred variants of one ordinary sword no longer get a hundred times the chance of a distinct mod-added design. Their individual records remain available within the group. Armour signatures use the current heir's valid race/sex addon models. The signature cannot inspect arbitrary NIF geometry, runtime visual overrides or textures replaced externally without record changes.

**Match armour class / prefer materials** in MCM keeps physical pieces in the randomly selected torso class, using clothing when matching pieces are unavailable, with a small matching-material preference. Turn it off to allow mixed physical armour classes. All roles can choose any torso class in either mode. A configured item-value ceiling and manual exclusions remain strict; remove restrictive limits to use the largest compatible pool.

Existing heirs keep their equipment on upgrade and reload. Use **Replace everything you carry with a fresh equipment set** to apply the new selection to an existing heir. Retrieve belongings you want to keep first: a successful fresh-kit command discards their old inventory. A failed roll with no usable torso preserves the old kit and inventory. The native log reports scanned and compatible armour/weapon/ammunition counts for diagnosis.

For manual exclusions, copy `Data/SKSE/Plugins/SkyrimDynastyEquipment.example.json` to `Data/SKSE/Plugins/SkyrimDynastyEquipment.json` in the installed game data tree, edit it, and restart Skyrim. The example is inactive and does not overwrite a custom active configuration. Exclude all forms originating in a named plugin or individual stable plugin/local-form pairs (including ESLs):

```json
{
  "maxGoldValue": 0,
  "excludedPlugins": ["ProblemGear.esp"],
  "excludedForms": [{"plugin": "OtherGear.esl", "localFormID": "0x800"}]
}
```

Use the actual plugin name and local form ID from your load order; the names above are examples. File and MCM value ceilings both apply. Invalid configuration is logged and ignored. Exclusions apply to future/fresh kits, not items the player deliberately trades. Model/slot compatibility and open-face headgear restrictions remain enabled.

## Inherited levels and companion growth

New adult heirs start at the rounded average of both parents' current levels, with a random variation of up to 10% (at least one level), bounded to the engine's 1–65535 range. The template's bootstrap level no longer determines a visible heir's level.

An heir earns one level for every player level gained while following. Recruitment starts tracking at the current player level; time spent waiting, at home or dismissed gives no retroactive levels. Polling uses the existing five-second follower update. Leaving the party credits any final pending gains. Succession resets every heir's tracking baseline so changing the player level cannot grant free levels.

Health, magicka and stamina each start at a base of 100. Each level above one supplies ten total base-stat points, split according to the inherited physical and magical skills. This stat allocation stays individual and stable. Each earned companion level trains the six strongest skills that are still below 100 by one point each, preserving existing live training before adding the gains. Parentally inherited perks remain; earned companion levels now additionally supply safe skill-tree perk points. Mortal/non-essential status is unchanged.

Level, birth level, stats, allocation and tracking baseline persist in the SKSE co-save. Existing heirs upgrade once using the average of their available parents' current levels, without sibling variation; historical birth levels cannot be recovered from old saves. With one available parent its level is used; with neither, the heir retains its current level. Existing base resources are never reduced by this migration, so an injured heir is not killed by a smaller health budget. Faces and inventory are preserved. Succession transfers the selected heir's actual level, current skills and base stats after the race/level change.

## Face DNA and arrival update

Each new heir has a 50/50 chance of receiving either parent's race (same-race parents retain that race). The selected race supplies a compatible skeleton, skin and head family, while skin tone and compatible eye features still inherit independently.

The 19 facial DNA loci each sample one allele from each parent. Each inherited allele has a 10% chance of a small bounded mutation, stored in the genome so it can pass to later generations. Nose, eye and mouth presets normally inherit from a parent, with a 15% chance to select another valid preset for the chosen race. An incompatible parental preset now selects randomly among valid presets instead of collapsing to the first default. Parent capture reads the player's actual actor-base sliders.

Hair is randomised among playable installed head parts compatible with the heir's race and sex. Hair colour normally comes from either parent, with a 5% chance of a different colour from the selected race's palette. There is a 25% chance of facial paint/tattoo tint from that race's registered masks, including mod masks registered on the race. Paint colours can come from parental paint or the asset palette. Birth rolls persist across saves; existing heirs are not automatically rerolled. Explicit cosmetic tools can change hair style or paint while preserving genes.

Painted faces receive a runtime DDS tint texture built from the same inherited RGB used for the body, with paint blended only where its mask applies. This preserves face/body tone outside the painted region and avoids the old RGB-only material discarding paint. Masks can be loaded from loose files or BSAs. Generated textures are local cache data, not bundled game assets; reloads reconstruct them and retired heirs' cache files are cleaned up.

Summon arrival resolves its vanilla portal, shader and sound on every call, repairing stale saved quest properties. The adult is equipped before being revealed inside the portal, with the effect and sound at its arrival position beside the player. The existing MCM effect toggle remains respected.

## Head visibility and equipment replacement fix

The random equipment generator now checks that armor addons for the heir's race/sex actually cover the head, body, hands and feet slots hidden by the item. An item cannot claim the head slot while using only a ring model. This fixes a concrete incompatibility found with Cheat Room's slot-remapping rings. Generated kits also exclude full-head replacement helmets (slot 30): removing armour restored the user's missing heads, and ordinary full-face helmets were present in the saved kits. Open-face helmets, circlets and compatible mod accessories remain eligible. This is a deliberate visibility restriction on random kits; manually traded equipment is not globally altered. Purely malformed meshes cannot be fully validated from plugin records.

Existing heirs automatically lose invalid items from their generated kit on load; their remaining inventory is retained and their meshes refresh. The inherited face/genome is preserved. This repair targets previously generated equipment, not arbitrary items manually equipped later.

The speech command **Replace everything you carry with a fresh equipment set** now discards the heir's entire current inventory, including traded items, after generating a valid replacement. It updates the outfit, clears old items, then adds exactly the new kit and ammunition. A failed generation or missing outfit leaves the current inventory in place. Ordinary loading never performs this full reset.

## Follower fix retained

Follow me now assigns Skyrim's real Follow procedure targeting the player. Each active follower occupies one of 32 optional persistent quest aliases; neither those aliases nor the actor bases grant essential/protected status. Heirs remain mortal and multiple heirs can accompany the player without taking the vanilla single-follower quest slot.

Following actors path normally nearby. A lightweight player check every five seconds recovers followers separated by an interior door, worldspace transition, or more than 8192 game units. Location changes request an earlier check. Catch-up places followers near the player without replaying birth effects or regenerating inventory. Wait, residence, dismissal, death and succession clear the follow alias. Loading a save upgrades already-following heirs automatically.

This release requires the matching newly compiled 0.9.6 DLL and scripts included in the installer.

## Features

- New heirs receive individual equipment drawn from playable weapons, armour and ammunition in the entire installed load order, including DLC, ESP and ESL mods. There are no preset-kit restrictions. Armour must have a model for the heir's sex/race; pieces cannot overlap occupied slots; ranged weapons receive matching arrows or bolts and two-handed weapons cannot be combined with shields. Quality biases value without excluding tiers; coherent selection restricts each kit to suitable groups/classes when available, and explicit value/plugin/form filters can exclude items.
- Warrior, archer, mage, rogue and craftsman roles are weighted by inherited skills. Each heir receives an individually varied ground combat style. Dialogue can change the role. Mages can receive suitable installed Destruction combat spells; scripted and high-skill effects are excluded. Craftsman is a cautious combat role, not an autonomous crafting/economy simulator.
- Ordinary heir activation opens speech dialogue for following, waiting, trading equipment, assigning residence, going home, dismissal, ancestry, abilities and combat roles. The old activation command popup is no longer used. Enable subtitles; Fuz Ro D-oh is recommended for silent responses.
- Residents can wander locally and use available beds and eating furniture on daily schedules. Assigned locations must have usable navigation and furniture. Dismissed heirs return to their assigned home. Recall is available in the MCM and orders the heir to wait beside you.
- The optional SkyUI MCM configures living capacity (1â€“32), inherited skill/external morph strength, gear quality bias, female probability, summon effects, story-perk filtering and combat variation. Settings are stored in the SKSE co-save. Lowering capacity does not remove living heirs.
- The MCM includes a paged genealogy journal with parentage, generation, skills, residence and alive/dead/successor status. Historical entries are compact records; deaths do not retain every actor reference. There is no fixed lifetime entry/birth cap.
- The succession choice previews ancestry, role, strongest skills, inherited perk count and actual equipped items. The MCM's recall action lets you inspect a living heir's appearance before defeat. On defeat, choose a living adult; identity, inherited appearance, skills/perks and actual equipment transfer and their NPC slot is freed.

## Appearance inheritance

Native inheritance retains 19 diploid facial traits with heritable mutations, parental/valid mutated nose-eye-mouth presets, eye parts, random compatible hair, mostly inherited hair RGB, skin RGB, weight and height. The saved phenotype is stable across loads. The loaded face receives the same RGB skin colour as the body, and texture families follow the inherited race. Human/elf pairings can combine an elf-shaped head with a lighter skin tone and compatible red eyes. A parental race still supplies the skeleton/head family; this does not create a new hybrid mesh.

The optional RaceMenu bridge adds live BodyMorph slider inheritance when a compatible SKEE BodyMorph v4/v5 interface is available. Morph-enabled BodySlide meshes are required. It only writes its own `SkyrimDynasty` morph key. A compatible provider exposing the public Preset v1 interface can additionally supply custom face sliders and matched-topology sculpts. Stock upstream RaceMenu does not expose that Preset interface in its interface map, so custom sculpt transfer is **not guaranteed by installing RaceMenu**. The log reports both detected interfaces. Baked replacement faces, arbitrary overlays and body presets without live morph data cannot be reconstructed universally.

The v0.7.1 player-tint layout crash fix remains, including regression checks for Skyrim 1.7.104. The build uses CommonLib runtime accessors rather than the stale GetTintList offset.

## Installation and upgrading

Fully replace the previous Dynasty version in Vortex with `SkyrimDynasty_v0.9.6_Vortex.zip`, enable/deploy and leave `DynastyHeirs.esp` enabled. Restart through matching SKSE64 with Address Library. SkyUI is needed for the MCM; core birth and heir dialogue do not require it. RaceMenu is optional and must support your exact Skyrim runtime. Back up the ESS/SKSE save pair and keep the files together.

Existing v0.6/v0.7 heirs keep their current equipment and inventory changes. New heirs use the installed-item generator. Existing heirs can change combat role or explicitly choose a fresh installed-item kit through dialogue; historical events before this version cannot be reconstructed if the old actor/genome has already been removed. Existing v0.6 native appearance data retains its migration path. Old deployed template FaceGen overrides from v0.5 must be removed if still present.

There are 32 reusable living slots and no lifetime birth cap. Heirs remain mortal and non-essential/non-protected. Summon arrival, courier-style greeting, follower commands, residence, save persistence and succession remain supported.

## Verification

See `VALIDATION.txt` for performed checks and `TESTING.md` for the in-game acceptance checks still needed. No gameplay or visual correctness is claimed from compilation. Corresponding source/build scripts are included under `Source`; see `LICENSE` and `THIRD_PARTY_NOTICES.txt`.
