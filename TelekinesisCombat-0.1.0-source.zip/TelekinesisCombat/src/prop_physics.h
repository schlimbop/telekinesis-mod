#pragma once
#include <RE/Skyrim.h>
#include <cmath>

namespace tkc {
inline bool carryableType(RE::FormType type,bool carryableLight=false) {
    switch(type) {
    case RE::FormType::Weapon: case RE::FormType::Misc: case RE::FormType::Armor:
    case RE::FormType::Ingredient: case RE::FormType::AlchemyItem: case RE::FormType::Book:
    case RE::FormType::Scroll: case RE::FormType::Ammo: case RE::FormType::SoulGem:
    case RE::FormType::KeyMaster: return true;
    case RE::FormType::Light: return carryableLight;
    default: return false;
    }
}
inline bool aimableMeleeType(RE::WEAPON_TYPE type) {
    switch(type) {
    case RE::WEAPON_TYPE::kOneHandSword: case RE::WEAPON_TYPE::kOneHandDagger:
    case RE::WEAPON_TYPE::kOneHandAxe: case RE::WEAPON_TYPE::kOneHandMace:
    case RE::WEAPON_TYPE::kTwoHandSword: case RE::WEAPON_TYPE::kTwoHandAxe: return true;
    default: return false;
    }
}
enum class PropMotion { unavailable, dynamic, dormant };
inline PropMotion propMotion(const RE::hkpMotion& motion) {
    using Type=RE::hkpMotion::MotionType;
    const float mass=motion.GetMass();
    const bool hasMass=std::isfinite(mass) && mass>0;
    switch(motion.type.get()) {
    case Type::kDynamic: case Type::kSphereInertia: case Type::kBoxInertia: case Type::kThinBoxInertia:
        return hasMass ? PropMotion::dynamic : PropMotion::unavailable;
    case Type::kFixed: case Type::kKeyframed:
        // Skyrim restores the saved dynamic motion; never invent mass/inertia for a static mesh.
        return hasMass || motion.savedMotion ? PropMotion::dormant : PropMotion::unavailable;
    default: return PropMotion::unavailable;
    }
}
inline constexpr RE::FormID previewShader(bool object,bool rejected) {
    // Enchantment membrane shaders also cover objects/weapons; Detect Life is particle-only.
    return object ? (rejected ? 0xd7661 : 0x5d608) : (rejected ? 0xdc209 : 0x146);
}
}
