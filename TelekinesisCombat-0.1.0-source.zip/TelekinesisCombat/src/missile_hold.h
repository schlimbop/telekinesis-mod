#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <atomic>

namespace missile_hold {
// SE/AE slots from CommonLib's MissileProjectile declarations; VR is rejected at load.
inline std::atomic<RE::FormID> suspended{};
inline bool matches(const RE::MissileProjectile* missile) {
    auto id=suspended.load(std::memory_order_acquire);
    return id!=0 && missile && missile->GetFormID()==id;
}
inline void suspend(RE::MissileProjectile* missile) { suspended.store(missile->GetFormID(),std::memory_order_release); }
inline void clear() { suspended.store(0,std::memory_order_release); }
inline REL::Relocation<void(*)(RE::MissileProjectile*,float)> update;
inline REL::Relocation<bool(*)(RE::MissileProjectile*)> impacts;
using AddImpact=void(*)(RE::MissileProjectile*,RE::TESObjectREFR*,const RE::NiPoint3&,const RE::NiPoint3&,
    RE::hkpCollidable*,std::int32_t,std::uint32_t);
inline REL::Relocation<AddImpact> addImpact;
inline void updateHook(RE::MissileProjectile* missile,float dt) {
    if(matches(missile)) {
        // Projectile::Update advances livingTime AFTER UpdateImpl; reset here to prevent expiry.
        missile->GetProjectileRuntimeData().livingTime=0.f;
        return;
    }
    update(missile,dt);
}
inline bool impactsHook(RE::MissileProjectile* missile) { return matches(missile) ? false : impacts(missile); }
inline void addImpactHook(RE::MissileProjectile* missile,RE::TESObjectREFR* ref,const RE::NiPoint3& point,
    const RE::NiPoint3& velocity,RE::hkpCollidable* collidable,std::int32_t arg6,std::uint32_t arg7) {
    if(!matches(missile)) addImpact(missile,ref,point,velocity,collidable,arg6,arg7);
}
inline bool installed=false;
inline void install() {
    if(installed) return;
    installed=true;
    REL::Relocation<std::uintptr_t> vtable{RE::VTABLE_MissileProjectile[0]};
    update=vtable.write_vfunc(0xAB,updateHook);
    impacts=vtable.write_vfunc(0xAC,impactsHook);
    addImpact=vtable.write_vfunc(0xBD,addImpactHook);
    SKSE::log::info("Missile hold hooks installed (SE/AE UpdateImpl/ProcessImpacts/AddImpact)");
}
}
