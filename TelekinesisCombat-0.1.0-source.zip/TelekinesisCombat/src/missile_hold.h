#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <atomic>
#include <array>
#include <algorithm>

namespace missile_hold {
// SE/AE slots from CommonLib's MissileProjectile declarations; VR is rejected at load.
inline constexpr std::size_t capacity=6;
inline std::array<std::atomic<RE::FormID>,capacity> suspended{};
inline bool matches(const RE::MissileProjectile* missile) {
    if(!missile) return false;
    auto id=missile->GetFormID();
    return id && std::any_of(suspended.begin(),suspended.end(),[&](auto& slot){return slot.load(std::memory_order_acquire)==id;});
}
// Controller mutations run on the game thread; hooks only read these atomic IDs.
inline bool suspend(RE::MissileProjectile* missile) {
    if(!missile || !missile->GetFormID()) return false;
    if(matches(missile)) return true;
    for(auto& slot:suspended) if(!slot.load(std::memory_order_acquire)) {
        slot.store(missile->GetFormID(),std::memory_order_release); return true;
    }
    return false;
}
inline void resume(RE::FormID id) {
    for(auto& slot:suspended) if(slot.load(std::memory_order_acquire)==id) slot.store(0,std::memory_order_release);
}
inline bool any() { return std::any_of(suspended.begin(),suspended.end(),[](auto& slot){return slot.load(std::memory_order_acquire)!=0;}); }
inline void clear() { for(auto& slot:suspended) slot.store(0,std::memory_order_release); }

template<class T> struct Hooks {
inline static REL::Relocation<void(*)(T*,float)> update;
inline static REL::Relocation<bool(*)(T*)> impacts;
using AddImpact=void(*)(T*,RE::TESObjectREFR*,const RE::NiPoint3&,const RE::NiPoint3&,
    RE::hkpCollidable*,std::int32_t,std::uint32_t);
inline static REL::Relocation<AddImpact> addImpact;
static void updateHook(T* missile,float dt) {
    if(matches(missile)) {
        // Projectile::Update advances livingTime AFTER UpdateImpl; reset here to prevent expiry.
        missile->GetProjectileRuntimeData().livingTime=0.f;
        return;
    }
    update(missile,dt);
}
static bool impactsHook(T* missile) { return matches(missile) ? false : impacts(missile); }
static void addImpactHook(T* missile,RE::TESObjectREFR* ref,const RE::NiPoint3& point,
    const RE::NiPoint3& velocity,RE::hkpCollidable* collidable,std::int32_t arg6,std::uint32_t arg7) {
    if(!matches(missile)) addImpact(missile,ref,point,velocity,collidable,arg6,arg7);
}
static void install() {
    REL::Relocation<std::uintptr_t> vtable{T::VTABLE[0]};
    update=vtable.write_vfunc(0xAB,updateHook);
    impacts=vtable.write_vfunc(0xAC,impactsHook);
    addImpact=vtable.write_vfunc(0xBD,addImpactHook);
}
};
inline bool installed=false;
inline void install() {
    if(installed) return;
    installed=true;
    Hooks<RE::MissileProjectile>::install();
    Hooks<RE::ArrowProjectile>::install();
    SKSE::log::info("Missile and arrow hold hooks installed (SE/AE UpdateImpl/ProcessImpacts/AddImpact)");
}
}
