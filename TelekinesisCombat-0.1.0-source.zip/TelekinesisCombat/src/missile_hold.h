#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <atomic>

namespace missile_hold {
// SE/AE slots from CommonLib's MissileProjectile declarations; VR is rejected at load.
inline std::atomic<RE::FormID> suspended{};
inline bool matches(const RE::MissileProjectile* missile) {
    auto id=suspended.load(std::memory_order_acquire);
    return id!=0 && missile && missile->GetFormID()==id;
}
inline void suspend(RE::MissileProjectile* missile) { suspended.store(missile->GetFormID(),std::memory_order_release); }
inline void clear() { suspended.store(0,std::memory_order_release); }
template<class T> struct Hooks {
inline static REL::Relocation<void(*)(T*,float)> update;
inline static REL::Relocation<bool(*)(T*)> impacts;
using AddImpact=void(*)(T*,RE::TESObjectREFR*,const RE::NiPoint3&,const RE::NiPoint3&,
    RE::hkpCollidable*,std::int32_t,std::uint32_t);
inline static REL::Relocation<AddImpact> addImpact;
static void updateHook(T* missile,float dt) {
    if(matches(missile)) {
        // Projectile::Update advances livingTime AFTER UpdateImpl; reset here to prevent expiry.
        missile->GetProjectileRuntimeData().livingTime=0.f;
        return;
    }
    update(missile,dt);
}
static bool impactsHook(T* missile) { return matches(missile) ? false : impacts(missile); }
static void addImpactHook(T* missile,RE::TESObjectREFR* ref,const RE::NiPoint3& point,
    const RE::NiPoint3& velocity,RE::hkpCollidable* collidable,std::int32_t arg6,std::uint32_t arg7) {
    if(!matches(missile)) addImpact(missile,ref,point,velocity,collidable,arg6,arg7);
}
static void install() {
    REL::Relocation<std::uintptr_t> vtable{T::VTABLE[0]};
    update=vtable.write_vfunc(0xAB,updateHook);
    impacts=vtable.write_vfunc(0xAC,impactsHook);
    addImpact=vtable.write_vfunc(0xBD,addImpactHook);
}
};
inline bool installed=false;
inline void install() {
    if(installed) return;
    installed=true;
    Hooks<RE::MissileProjectile>::install();
    Hooks<RE::ArrowProjectile>::install();
    SKSE::log::info("Missile and arrow hold hooks installed (SE/AE UpdateImpl/ProcessImpacts/AddImpact)");
}
}
