#pragma once
#include <RE/Skyrim.h>

namespace feedback {
inline RE::BSSoundHandle sound(RE::FormID id,tkc::Vec point,float volume=1.f) {
    RE::BSSoundHandle handle;
    if(!cfg.feedback) return handle;
    auto* form=RE::TESForm::LookupByID<RE::BGSSoundDescriptorForm>(id);
    auto* audio=RE::BSAudioManager::GetSingleton();
    if(form && audio && audio->GetSoundHandle(handle,form)) {
        handle.SetPosition({point.x,point.y,point.z}); handle.SetVolume(volume); handle.Play();
    }
    return handle;
}
inline void shader(RE::TESObjectREFR* ref,RE::FormID id,float seconds,RE::NiAVObject* node=nullptr) {
    if(ref && ref->Get3D()) if(auto* effect=RE::TESForm::LookupByID<RE::TESEffectShader>(id))
        ref->ApplyEffectShader(effect,seconds,nullptr,false,false,node,true);
}
// Material and position are copied while the ray's world lock is held; no Havok pointer escapes.
inline void impact(RE::TESObjectCELL* cell,RE::TESObjectWEAP* weapon,RE::MATERIAL_ID material,tkc::Vec point,tkc::Vec direction) {
    if(!cfg.feedback || !cell) return;
    auto* set=weapon ? weapon->impactDataSet : nullptr;
    if(!set) set=RE::TESForm::LookupByID<RE::BGSImpactDataSet>(0x193b7); // Stock blunt impacts.
    auto* type=RE::BGSMaterialType::GetMaterialType(material);
    RE::BGSImpactData* data=nullptr;
    for(int depth=0;set && type && depth<8;++depth,type=type->parentType) {
        auto found=set->impactMap.find(type);
        if(found!=set->impactMap.end() && found->second) { data=found->second; break; }
    }
    if(!data) { sound(material==RE::MATERIAL_ID::kSkin ? 0xe4f24 : 0x53a5e,point,.8f); return; }
    auto position=RE::NiPoint3{point.x,point.y,point.z};
    RE::BSSoundHandle first,second;
    RE::BGSImpactManager::ImpactSoundData sounds{};
    sounds.impactData=data; sounds.position=&position; sounds.sound1=&first; sounds.sound2=&second;
    sounds.playSound1=true; sounds.playSound2=true;
    if(auto* manager=RE::BGSImpactManager::GetSingleton()) manager->PlayImpactDataSounds(sounds);
    auto* model=data->GetModel();
    if(model && *model) {
        auto angles=tkc::missileAngles(direction); RE::NiMatrix3 rotation;
        rotation.SetEulerAnglesXYZ(angles.x,0.f,angles.z);
        (void)cell->PlaceParticleEffect(std::clamp(data->data.effectDuration,.2f,3.f),model,rotation,position,1.f,0,nullptr);
    }
}
}
