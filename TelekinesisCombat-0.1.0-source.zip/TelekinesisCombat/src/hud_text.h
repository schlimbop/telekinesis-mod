#pragma once
#include <algorithm>
#include <cmath>
#include <string>
#include <string_view>

namespace tkc {
struct HudLayout { float x,y,width,height,font; };
inline HudLayout hudLayout(float left,float top,float width,float height) {
    float font=std::clamp(height/45.f,12.f,24.f);
    return {left+width*.25f,top+height*.61f,width*.5f,font*7.f,font};
}
inline std::string hudName(const char* name) {
    std::string_view value=name && *name ? name : "target";
    std::size_t end=std::min<std::size_t>(value.size(),64);
    if(end<value.size()) while(end>0 && (static_cast<unsigned char>(value[end])&0xc0)==0x80) --end;
    std::string text(value.substr(0,end));
    std::replace_if(text.begin(),text.end(),[](unsigned char c){ return c<32; },' ');
    if(end<value.size()) text+="...";
    return text;
}
inline std::string chargeText(float progress) {
    progress=std::isfinite(progress) ? std::clamp(progress,0.f,1.f) : 0.f;
    int blocks=static_cast<int>(progress*12);
    return "Crush ["+std::string(blocks,'|')+std::string(12-blocks,'.')+"] "+
        std::to_string(static_cast<int>(progress*100))+"% - keep holding";
}
}
