#pragma once
#include <algorithm>
#include <cmath>

namespace tkc {
struct HudLayout { float x,y,width,height,font; };
inline HudLayout hudLayout(float left,float top,float width,float height) {
    float font=std::clamp(height/72.f,10.f,16.f);
    float margin=height*.025f, textWidth=std::min(width*.4f,font*25.f);
    return {left+width-margin-textWidth,top+margin,textWidth,font*1.8f,font};
}
struct EquipHint {
    bool equipped=false;
    float remaining=0;
    bool update(bool hasSpell,bool visible,float dt) {
        if(hasSpell && !equipped) remaining=2.f;
        equipped=hasSpell;
        if(!hasSpell) remaining=0;
        if(visible && std::isfinite(dt)) remaining=std::max(0.f,remaining-std::max(0.f,dt));
        return visible && remaining>0;
    }
};
}
