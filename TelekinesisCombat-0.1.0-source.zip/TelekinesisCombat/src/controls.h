#pragma once
namespace tkc {
enum class CastAction { none, grab, release, charge, cancelCharge };
// Releases still clean up a grip after unequipping; new presses require the spell's hand.
constexpr CastAction castAction(bool down, bool up, bool held, bool primary, bool controlHand) {
    if(up) return held && primary ? CastAction::release : CastAction::cancelCharge;
    if(!down || !controlHand) return CastAction::none;
    if(!held) return CastAction::grab;
    return primary ? CastAction::none : CastAction::charge;
}
}
