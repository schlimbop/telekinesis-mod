#pragma once
namespace tkc {
// Shift used to acquire a prop must not also slam it on the initial release.
constexpr bool shiftSlam(bool held,bool left,bool right,bool initialShift) { return held && (left || right) && !initialShift; }
enum class CastAction { none, grab, release, charge, cancelCharge };
// Releases still clean up a grip after unequipping; new presses require the spell's hand.
constexpr CastAction castAction(bool down, bool up, bool held, bool primary, bool controlHand) {
    if(up) return held && primary ? CastAction::release : CastAction::cancelCharge;
    if(!down || !controlHand) return CastAction::none;
    if(!held) return CastAction::grab;
    return primary ? CastAction::none : CastAction::charge;
}
}
