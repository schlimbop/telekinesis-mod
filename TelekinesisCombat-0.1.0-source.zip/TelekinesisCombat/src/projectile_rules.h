#pragma once
#include <RE/Skyrim.h>
#include "combat_math.h"

namespace tkc {
inline bool catchableProjectile(RE::MissileProjectile* missile,RE::BGSProjectile* base) {
    if(!missile) return false;
    auto& data=missile->GetProjectileRuntimeData();
    using Flags=RE::Projectile::Flags;
    using BaseFlags=RE::BGSProjectileData::BGSProjectileFlags;
    if(!base || data.flags.any(Flags::kDestroyed,Flags::kFading,Flags::kProcessedImpacts,Flags::kHitScan) ||
       base->data.flags.any(BaseFlags::kHitScan,BaseFlags::kExplosionAltTrigger,BaseFlags::kContinuousUpdate) ||
       missile->GetMissileRuntimeData().waitingToInitialize3D ||
       missile->GetMissileRuntimeData().impactResult!=RE::ImpactResult::kNone ||
       !finite({data.linearVelocity.x,data.linearVelocity.y,data.linearVelocity.z}) ||
       !std::isfinite(data.power) || data.power<=0 || !std::isfinite(data.scale) || data.scale<=0) return false;
    Vec speed{data.linearVelocity.x,data.linearVelocity.y,data.linearVelocity.z};
    if(!std::isfinite(length(speed)) || length(speed)<=1.f) return false;
    { RE::BSSpinLockGuard lock(data.unk0E8); if(!data.impacts.empty()) return false; }
    if(missile->As<RE::ArrowProjectile>()) {
        auto* weapon=data.weaponSource;
        // shortcut: exploding/continuous ammunition needs a separate detonation controller.
        return base->data.types.any(RE::BGSProjectileData::Type::kArrow) && !data.spell &&
            !base->data.flags.any(BaseFlags::kExplosion) && data.ammoSource && weapon &&
            (weapon->GetWeaponType()==RE::WEAPON_TYPE::kBow || weapon->GetWeaponType()==RE::WEAPON_TYPE::kCrossbow) &&
            data.ammoSource->GetRuntimeData().data.projectile==base &&
            std::isfinite(data.weaponDamage) && data.weaponDamage>0;
    }
    auto* spell=data.spell ? data.spell->As<RE::SpellItem>() : nullptr;
    return base->IsMissile() && spell && spell->IsHostile() &&
        spell->GetCastingType()==RE::MagicSystem::CastingType::kFireAndForget &&
        spell->GetDelivery()==RE::MagicSystem::Delivery::kAimed && spell->GetAVEffect() &&
        spell->GetAVEffect()==data.avEffect && data.avEffect->data.projectileBase==base &&
        !data.weaponSource && !data.ammoSource;
}
}
