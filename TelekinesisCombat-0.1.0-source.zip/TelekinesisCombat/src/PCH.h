#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <RE/S/SendHUDMessage.h>
#include <string_view>
using namespace std::literals;
