#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <mutex>
#include <string>
#include "hud_text.h"

namespace grip_hud {
inline std::mutex mutex;
inline std::string latest;
inline bool queued=false;
inline void render(const std::string& text) {
    auto* ui=RE::UI::GetSingleton();
    auto menu=ui ? ui->GetMenu(RE::HUDMenu::MENU_NAME) : nullptr;
    auto* movie=menu ? menu->uiMovie.get() : nullptr;
    if(!movie) return;
    RE::GFxValue field;
    if(!movie->GetVariable(&field,"_root.TKCGripStatus") || !field.IsObject()) {
        if(text.empty()) return;
        RE::GFxValue depth;
        if(!movie->Invoke("_root.getNextHighestDepth",&depth,nullptr,0) || !depth.IsNumber()) return;
        RE::GFxValue args[]{RE::GFxValue("TKCGripStatus"),depth,RE::GFxValue(0),RE::GFxValue(0),RE::GFxValue(1),RE::GFxValue(1)};
        if(!movie->Invoke("_root.createTextField",nullptr,args,6) ||
           !movie->GetVariable(&field,"_root.TKCGripStatus") || !field.IsObject()) {
            static bool warned=false;
            if(!warned) { SKSE::log::warn("HUD replacement does not support the TKC text field"); warned=true; }
            return;
        }
        field.SetMember("selectable",RE::GFxValue(false));
        field.SetMember("_alpha",RE::GFxValue(92));
        field.SetMember("embedFonts",RE::GFxValue(true));
    }
    field.SetMember("background",RE::GFxValue(false));
    field.SetMember("multiline",RE::GFxValue(false));
    field.SetMember("wordWrap",RE::GFxValue(false));
    field.SetMember("_visible",RE::GFxValue(!text.empty() && !ui->GameIsPaused()));
    if(text.empty()) return;
    auto rect=movie->GetVisibleFrameRect();
    if(!std::isfinite(rect.right-rect.left) || !std::isfinite(rect.bottom-rect.top) ||
       rect.right<=rect.left || rect.bottom<=rect.top) return;
    auto layout=tkc::hudLayout(rect.left,rect.top,rect.right-rect.left,rect.bottom-rect.top);
    field.SetMember("_x",RE::GFxValue(layout.x)); field.SetMember("_y",RE::GFxValue(layout.y));
    field.SetMember("_width",RE::GFxValue(layout.width)); field.SetMember("_height",RE::GFxValue(layout.height));
    field.SetText(text.c_str()); // Plain text prevents object names becoming markup.
    RE::GFxValue format;
    movie->CreateObject(&format,"TextFormat");
    if(format.IsObject()) {
        format.SetMember("font",RE::GFxValue("$EverywhereFont"));
        format.SetMember("size",RE::GFxValue(layout.font));
        format.SetMember("align",RE::GFxValue("right"));
        format.SetMember("color",RE::GFxValue(0xd8eaff));
        field.Invoke("setTextFormat",nullptr,&format,1);
    }
    RE::GFxValue textHeight;
    if(field.GetMember("textHeight",&textHeight) && textHeight.IsNumber() && std::isfinite(textHeight.GetNumber()))
        field.SetMember("_height",RE::GFxValue(std::clamp(textHeight.GetNumber()+8.,static_cast<double>(layout.font*1.5f),static_cast<double>(layout.height))));
}
inline void publish(std::string text) {
    auto* tasks=SKSE::GetTaskInterface(); if(!tasks) return;
    {
        std::lock_guard lock(mutex); latest=std::move(text);
        if(queued) return;
        queued=true;
    }
    // Coalesce updates; resolve the current movie only on the UI thread, never retain GFx values.
    tasks->AddUITask([] {
        std::string text;
        { std::lock_guard lock(mutex); text=latest; queued=false; }
        render(text);
    });
}
}
