#pragma once
#include <algorithm>
#include <cmath>

namespace tkc {
struct Vec {
    float x{}, y{}, z{};
    Vec operator+(Vec b) const { return {x+b.x,y+b.y,z+b.z}; }
    Vec operator-(Vec b) const { return {x-b.x,y-b.y,z-b.z}; }
    Vec operator*(float s) const { return {x*s,y*s,z*s}; }
};
inline float dot(Vec a, Vec b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline float length(Vec a) { return std::sqrt(dot(a,a)); }
inline Vec unit(Vec a) { float n=length(a); return n>0.001f ? a*(1/n) : Vec{}; }
inline Vec limit(Vec a, float cap) { float n=length(a); return n>cap ? a*(cap/n) : a; }
inline bool finite(Vec a) { return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z); }
inline float aimScore(Vec origin, Vec direction, Vec point, float radius, float range, float degrees=3.f) {
    Vec offset=point-origin; float ahead=dot(offset,direction);
    if(ahead<=0 || length(offset)>range) return -1;
    float width=std::clamp(radius,24.f,80.f)+ahead*std::tan(degrees*.01745329252f);
    float score=length(offset-direction*ahead)/width;
    return score<=1.f ? score : -1.f;
}
inline Vec advanceAnchor(Vec anchor, Vec goal, float speed, float dt) {
    return anchor+limit(goal-anchor,speed*std::max(0.f,dt));
}
inline Vec holdVelocity(Vec previous, Vec anchor, Vec body, float dt, float gain, float speed) {
    Vec feed=dt>.0001f ? (anchor-previous)*(1.f/dt) : Vec{};
    return limit(feed+(anchor-body)*gain,speed);
}
inline float segmentDistance(Vec a, Vec b, Vec p) {
    Vec ab=b-a; float d=dot(ab,ab);
    float t=d>0.001f ? std::clamp(dot(p-a,ab)/d,0.f,1.f) : 0.f;
    return length(p-(a+ab*t));
}
// Fraction along a swept segment entering expanded actor bounds; -1 means no hit.
inline float boxHit(Vec from, Vec to, Vec low, Vec high, float padding) {
    if(!finite(from) || !finite(to) || !finite(low) || !finite(high)) return -1;
    float first=0, last=1;
    const float a[]{from.x,from.y,from.z}, d[]{to.x-from.x,to.y-from.y,to.z-from.z};
    const float lo[]{low.x-padding,low.y-padding,low.z-padding};
    const float hi[]{high.x+padding,high.y+padding,high.z+padding};
    for(int i=0;i<3;++i) {
        if(lo[i]>hi[i]) return -1;
        if(std::abs(d[i])<.0001f) { if(a[i]<lo[i] || a[i]>hi[i]) return -1; }
        else {
            float x=(lo[i]-a[i])/d[i], y=(hi[i]-a[i])/d[i];
            if(x>y) std::swap(x,y);
            first=std::max(first,x); last=std::min(last,y);
            if(first>last) return -1;
        }
    }
    return first;
}
inline bool weakened(float current,float maximum,float fraction) {
    return std::isfinite(current) && std::isfinite(maximum) && current>0 && maximum>0 && current<=maximum*fraction;
}
inline float resistance(float scale, int targetLevel, int playerLevel, float levelFactor) {
    return std::clamp(scale*scale*scale*(1.f+std::max(0,targetLevel-playerLevel)*levelFactor),1.f,8.f);
}
inline float damage(float speed, float mass, float multiplier, float minimum, float cap) {
    if (speed<minimum) return 0.f;
    // Gameplay units, deliberately not a claim of real-world joules.
    return std::clamp(mass*speed*speed*multiplier/1000000.f,0.f,cap);
}
inline bool lethalFall(float peak,float height,float verticalSpeed,float drop,float minimum) {
    return std::isfinite(peak) && std::isfinite(height) && std::isfinite(verticalSpeed) &&
        peak-height>=drop && verticalSpeed<=-minimum;
}
inline float actorImpactDamage(float health,float maximum,int playerLevel,int targetLevel,
    float speed,float referenceSpeed,float fraction,float capFraction,int killAdvantage,bool fall,bool slam=false) {
    if(!std::isfinite(health) || !std::isfinite(maximum) || health<=0 || maximum<=0 ||
       !std::isfinite(speed) || speed<=0 || referenceSpeed<=0) return 0;
    int difference=playerLevel-targetLevel;
    if((fall && !slam) || difference>=killAdvantage) return health+1000.f;
    float scale=std::clamp(1.f+difference*.03f,.5f,1.5f);
    float ratio=speed/referenceSpeed;
    float amount=maximum*std::min(capFraction,fraction*scale*ratio*ratio);
    return slam ? std::min(amount,std::max(0.f,health-1.f)) : amount;
}

}
