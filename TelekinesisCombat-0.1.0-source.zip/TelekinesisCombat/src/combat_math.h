#pragma once
#include <algorithm>
#include <cmath>

namespace tkc {
struct Vec {
    float x{}, y{}, z{};
    Vec operator+(Vec b) const { return {x+b.x,y+b.y,z+b.z}; }
    Vec operator-(Vec b) const { return {x-b.x,y-b.y,z-b.z}; }
    Vec operator*(float s) const { return {x*s,y*s,z*s}; }
};
inline float dot(Vec a, Vec b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline float length(Vec a) { return std::sqrt(dot(a,a)); }
inline Vec unit(Vec a) { float n=length(a); return n>0.001f ? a*(1/n) : Vec{}; }
inline Vec limit(Vec a, float cap) { float n=length(a); return n>cap ? a*(cap/n) : a; }
inline bool finite(Vec a) { return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z); }
inline float aimScore(Vec origin, Vec direction, Vec point, float radius, float range) {
    Vec offset=point-origin; float ahead=dot(offset,direction);
    if(ahead<=0 || length(offset)>range) return -1;
    float width=std::clamp(radius,16.f,45.f)+ahead*.02f;
    float score=length(offset-direction*ahead)/width;
    return score<=1.f ? score : -1.f;
}
inline Vec advanceAnchor(Vec anchor, Vec goal, float speed, float dt) {
    return anchor+limit(goal-anchor,speed*std::max(0.f,dt));
}
inline Vec holdVelocity(Vec previous, Vec anchor, Vec body, float dt, float gain, float speed) {
    Vec feed=dt>.0001f ? (anchor-previous)*(1.f/dt) : Vec{};
    return limit(feed+(anchor-body)*gain,speed);
}
inline float segmentDistance(Vec a, Vec b, Vec p) {
    Vec ab=b-a; float d=dot(ab,ab);
    float t=d>0.001f ? std::clamp(dot(p-a,ab)/d,0.f,1.f) : 0.f;
    return length(p-(a+ab*t));
}
inline float resistance(float scale, int targetLevel, int playerLevel, float levelFactor) {
    return std::clamp(scale*scale*scale*(1.f+std::max(0,targetLevel-playerLevel)*levelFactor),1.f,8.f);
}
inline float damage(float speed, float mass, float multiplier, float minimum, float cap) {
    if (speed<minimum) return 0.f;
    // Gameplay units, deliberately not a claim of real-world joules.
    return std::clamp(mass*speed*speed*multiplier/1000000.f,0.f,cap);
}
}
