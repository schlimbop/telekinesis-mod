#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace tkc {
struct Vec {
    float x{}, y{}, z{};
    Vec operator+(Vec b) const { return {x+b.x,y+b.y,z+b.z}; }
    Vec operator-(Vec b) const { return {x-b.x,y-b.y,z-b.z}; }
    Vec operator*(float s) const { return {x*s,y*s,z*s}; }
};
inline float dot(Vec a, Vec b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline Vec cross(Vec a,Vec b) { return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x}; }
inline float length(Vec a) { return std::sqrt(dot(a,a)); }
inline Vec unit(Vec a) { float n=length(a); return n>0.001f ? a*(1/n) : Vec{}; }
inline Vec limit(Vec a, float cap) { float n=length(a); return n>cap ? a*(cap/n) : a; }
inline bool finite(Vec a) { return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z); }
// Arrival is measured against the final hold goal, never the retrieval anchor.
struct GraspState {
    bool ready=false, haveGoal=false;
    float settled=0;
    Vec previousGoal{};
    void update(Vec body,Vec velocity,Vec goal,float dt) {
        if(!finite(body) || !finite(velocity) || !finite(goal) || !std::isfinite(dt)) { *this={}; return; }
        if(dt<=0 || ready) return;
        Vec goalVelocity=haveGoal ? (goal-previousGoal)*(1.f/dt) : Vec{};
        previousGoal=goal; haveGoal=true;
        if(length(body-goal)<=30.f && length(velocity-goalVelocity)<=400.f)
            settled+=std::min(dt,.05f);
        else settled=0;
        // Once acquired, normal camera movement must not revoke the grip.
        ready=settled>=.08f;
    }
};
inline bool lethalItemHit(float before,float after,float dealt) {
    return std::isfinite(before) && std::isfinite(after) && std::isfinite(dealt) && before>0 && after<=0 && dealt>0;
}
struct WeaponRotation { float x{},y{},z{},w=1; };
inline WeaponRotation weaponRotation(Vec direction) {
    if(!finite(direction) || length(direction)<.001f) return {};
    // Stock melee geometry points along local +Y, not the object's vertical +Z axis.
    auto d=unit(direction); float w=1+d.y;
    Vec axis{d.z,0,-d.x}; float norm=std::sqrt(dot(axis,axis)+w*w);
    return norm>.001f ? WeaponRotation{axis.x/norm,0,axis.z/norm,w/norm} : WeaponRotation{1,0,0,0};
}
inline Vec weaponForward(WeaponRotation q) {
    float norm=q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w;
    if(!std::isfinite(norm) || norm<.000001f) return {};
    return {2*(q.x*q.y-q.w*q.z)/norm,1-2*(q.x*q.x+q.z*q.z)/norm,2*(q.y*q.z+q.w*q.x)/norm};
}
inline Vec weaponTurnVelocity(Vec forward,Vec target,float dt) {
    if(!finite(forward) || !finite(target) || !std::isfinite(dt) || dt<=0) return {};
    forward=unit(forward); target=unit(target);
    if(length(forward)<.5f || length(target)<.5f) return {};
    Vec axis=cross(forward,target); float sine=length(axis),cosine=std::clamp(dot(forward,target),-1.f,1.f);
    if(sine<.0001f) {
        if(cosine>0) return {};
        axis=cross(forward,std::abs(forward.x)<.8f ? Vec{1,0,0} : Vec{0,1,0});
    }
    float angle=std::atan2(sine,cosine);
    return unit(axis)*std::min(8.f,angle*std::min(12.f,1.f/dt));
}
inline bool rayHasRemaining(Vec cursor,Vec end,Vec direction) { return dot(end-cursor,direction)>.001f; }
inline float nearbyScore(Vec origin,Vec point,float radius) {
    float d=length(point-origin);
    return finite(point) && std::isfinite(radius) && d<=radius ? d : -1.f;
}
// Time to closest approach must lie ahead, inside both the capture sphere and threat corridor.
// The one-tick lead admits a missile that would cross the capture sphere before the next poll.
inline float predictedMissileScore(Vec player,Vec point,Vec velocity,float radius,float lookAhead,float threat,float poll=.016f) {
    if(!finite(player) || !finite(point) || !finite(velocity) || !std::isfinite(radius) || radius<=0) return -1;
    float v2=dot(velocity,velocity); if(v2<=1) return -1;
    float t=dot(player-point,velocity)/v2;
    if(t<=0 || t>lookAhead || length(point+velocity*t-player)>threat) return -1;
    float step=std::clamp(t,0.f,std::max(0.f,poll));
    if(length(point+velocity*step-player)>radius) return -1;
    return t; // Earliest actual threat wins, rather than nearest passing particle.
}
struct MissileAngles { float x,z; };
inline MissileAngles missileAngles(Vec direction) {
    direction=unit(direction);
    return {-std::asin(std::clamp(direction.z,-1.f,1.f)),std::atan2(direction.x,direction.y)};
}
inline float aimScore(Vec origin, Vec direction, Vec point, float radius, float range, float degrees=3.f) {
    Vec offset=point-origin; float ahead=dot(offset,direction);
    if(ahead<=0 || length(offset)>range) return -1;
    float width=std::clamp(radius,40.f,80.f)+std::min(180.f,ahead*std::tan(degrees*.01745329252f));
    float score=length(offset-direction*ahead)/width;
    return score<=1.f ? score : -1.f;
}
inline bool keepAimTarget(float strictScore,float graceScore,float bestScore,float age) {
    return graceScore>=0 && ((strictScore>=0 && bestScore>=strictScore-.15f) || (bestScore==INFINITY && age<=.24f));
}
// Keep the item on the camera's crosshair ray; third-person adds the depth to the player.
inline float itemRayDistance(Vec camera,Vec direction,Vec player,float ahead,bool thirdPerson) {
    return ahead+(thirdPerson ? std::max(0.f,dot(player-camera,direction)) : 0.f);
}
inline Vec advanceAnchor(Vec anchor, Vec goal, float speed, float dt) {
    return anchor+limit(goal-anchor,speed*std::max(0.f,dt));
}
// Smooth close camera motion, but keep distant retrieval at full configured speed.
inline Vec gripAnchor(Vec anchor,Vec goal,float speed,float dt,bool retrieving) {
    if(dt<=0 || !finite(anchor) || !finite(goal)) return anchor;
    Vec step=(goal-anchor)*(retrieving ? 1.f : -std::expm1(-18.f*dt));
    return anchor+limit(step,speed*dt);
}
inline Vec holdVelocity(Vec previous, Vec anchor, Vec body, float dt, float gain, float speed) {
    Vec feed=dt>.0001f ? (anchor-previous)*(1.f/dt) : Vec{};
    float response=dt>.0001f ? -std::expm1(-gain*dt)/dt : gain;
    return limit(feed+(anchor-body)*response,speed);
}
inline constexpr int orbitLimit=3;
// Keep the formation near the player even when normal pull/push permits a distant grip.
inline float orbitHoldDistance(float ahead) { return std::clamp(ahead,140.f,220.f); }
inline Vec orbitOffset(Vec forward,float phase,int slot,float radius,float depth) {
    radius=std::min(radius,std::max(0.f,depth)*.28f);
    forward=unit(forward);
    Vec right=unit({forward.y,-forward.x,0});
    if(length(right)<.5f) right={1,0,0};
    Vec up=unit({right.y*forward.z-right.z*forward.y,
                 right.z*forward.x-right.x*forward.z,right.x*forward.y-right.y*forward.x});
    float angle=phase+static_cast<float>(slot)*2.09439510239f;
    // Center on the crosshair; the previous upward bias pushed the top arc out of view.
    return right*(std::cos(angle)*radius)+up*(std::sin(angle)*radius);
}
// Three equally spaced slots must clear the widest two transverse footprints.
inline float orbitSpacing(float first,float second,float requested,float depth) {
    float cap=std::min(60.f,std::max(0.f,depth)*.28f);
    float radius=std::max(std::min(requested,cap),(first+second+8.f)/1.73205080757f);
    return std::isfinite(radius) && radius<=cap ? radius : -1.f;
}
inline float finisherProgress(float charged,float duration) {
    return std::isfinite(charged) && std::isfinite(duration) && duration>0 ? std::clamp(charged/duration,0.f,1.f) : 0.f;
}
inline Vec crosshairLaunchDirection(Vec body,Vec camera,Vec direction,float distance) {
    if(!finite(body) || !finite(camera) || !finite(direction) || !std::isfinite(distance) || distance<=0) return {};
    return unit(camera+unit(direction)*distance-body);
}
inline float impactFeedbackStrength(float speed,float mass) {
    if(!std::isfinite(speed) || !std::isfinite(mass)) return 0;
    return std::clamp(speed/3600.f,0.f,1.f)*std::clamp(std::sqrt(std::max(0.f,mass)/10.f),.35f,1.5f);
}
inline float survivorReaction(float dealt,float maximum,float speed,float mass,bool blunt) {
    if(!std::isfinite(dealt) || !std::isfinite(maximum) || !std::isfinite(speed) || !std::isfinite(mass) || dealt<=0 || maximum<=0) return 0;
    float force=impactFeedbackStrength(speed,mass);
    return std::clamp(dealt/maximum*1.5f+force*.35f+(blunt ? .12f : 0.f),.15f,1.f);
}
inline float impactCameraStrength(float strength,float distance) {
    if(!std::isfinite(strength) || !std::isfinite(distance)) return 0;
    return std::clamp(strength*.10f,0.f,.14f)*std::clamp(1.f-distance/1000.f,0.f,1.f);
}
inline float segmentDistance(Vec a, Vec b, Vec p) {
    Vec ab=b-a; float d=dot(ab,ab);
    float t=d>0.001f ? std::clamp(dot(p-a,ab)/d,0.f,1.f) : 0.f;
    return length(p-(a+ab*t));
}
// Fraction along a swept segment entering expanded actor bounds; -1 means no hit.
inline float boxHit(Vec from, Vec to, Vec low, Vec high, float padding) {
    if(!finite(from) || !finite(to) || !finite(low) || !finite(high)) return -1;
    float first=0, last=1;
    const float a[]{from.x,from.y,from.z}, d[]{to.x-from.x,to.y-from.y,to.z-from.z};
    const float lo[]{low.x-padding,low.y-padding,low.z-padding};
    const float hi[]{high.x+padding,high.y+padding,high.z+padding};
    for(int i=0;i<3;++i) {
        if(lo[i]>hi[i]) return -1;
        if(std::abs(d[i])<.0001f) { if(a[i]<lo[i] || a[i]>hi[i]) return -1; }
        else {
            float x=(lo[i]-a[i])/d[i], y=(hi[i]-a[i])/d[i];
            if(x>y) std::swap(x,y);
            first=std::max(first,x); last=std::min(last,y);
            if(first>last) return -1;
        }
    }
    return first;
}
// Relative motion catches an actor crossing a blade's path between updates.
inline float movingBoxHit(Vec from,Vec to,Vec low,Vec high,Vec halfExtent,float padding,Vec movement) {
    return boxHit(from+movement,to,low-halfExtent,high+halfExtent,padding);
}
// A prop slowdown alone is not proof of a hit; keep its tracker alive until a real contact.
inline bool confirmedImpact(bool actorHit,bool geometryHit,bool thrownActor,bool velocityLoss) {
    return actorHit || geometryHit || (thrownActor && velocityLoss);
}
inline bool weakened(float current,float maximum,float fraction) {
    return std::isfinite(current) && std::isfinite(maximum) && current>0 && maximum>0 && current<=maximum*fraction;
}
inline float resistance(float scale, int targetLevel, int playerLevel, float levelFactor) {
    return std::clamp(scale*scale*scale*(1.f+std::max(0,targetLevel-playerLevel)*levelFactor),1.f,8.f);
}
enum class WeaponStyle { clutter, dagger, blade, blunt, ranged };
inline std::uint32_t fallbackImpactSet(WeaponStyle style,bool twoHanded) {
    if(style==WeaponStyle::blade || style==WeaponStyle::dagger) return twoHanded ? 0x949d5 : 0x13cac;
    return twoHanded ? 0xe4cb0 : 0x193b7;
}
inline Vec glanceVelocity(Vec incoming,Vec normal) {
    if(!finite(incoming) || !finite(normal) || length(normal)<.5f || length(incoming)<1) return {};
    normal=unit(normal);
    float incidence=-dot(unit(incoming),normal);
    if(incidence<.02f || incidence>.35f) return {};
    return (incoming-normal*(2.f*dot(incoming,normal)))*.55f;
}
inline float contactProbeReach(Vec halfExtent,Vec direction) {
    if(!finite(halfExtent) || !finite(direction) || length(direction)<.5f) return 0;
    direction=unit(direction);
    return std::clamp(std::abs(direction.x)*std::max(0.f,halfExtent.x)+
        std::abs(direction.y)*std::max(0.f,halfExtent.y)+std::abs(direction.z)*std::max(0.f,halfExtent.z)+6.f,6.f,160.f);
}
inline bool contactVelocityChanged(Vec before,Vec after) {
    if(!finite(before) || !finite(after)) return false;
    float change=length(before-after);
    return std::isfinite(change) && change>std::max(150.f,length(before)*.1f);
}
inline bool recallReach(Vec origin,Vec target) {
    return finite(origin) && finite(target);
}
inline bool gripTooFar(Vec origin,Vec target,float range,float maxDistance,bool recalledWeapon) {
    return !recalledWeapon && length(target-origin)>range*2.f+maxDistance;
}
inline float projectileSpeedRatio(float nativeSpeed,float capturedSpeed) {
    if(!std::isfinite(nativeSpeed) || !std::isfinite(capturedSpeed) || nativeSpeed<=0 || capturedSpeed<=0) return 0;
    float ratio=capturedSpeed/nativeSpeed;
    return std::isfinite(ratio) && ratio>0 ? ratio : 0;
}
inline float penetration(WeaponStyle style) {
    return style==WeaponStyle::blunt ? .25f : style==WeaponStyle::dagger ? .15f : 0.f;
}
inline float combatObjectDamage(float speed,float mass,float baseDamage,WeaponStyle style,float kineticScale,
    float baseScale,float overall,float minimum,float cap,float floor) {
    if(!std::isfinite(speed) || !std::isfinite(mass) || !std::isfinite(baseDamage) || speed<minimum) return 0;
    float ratio=std::clamp(speed/3600.f,0.f,1.25f);
    float type=style==WeaponStyle::dagger ? .9f : style==WeaponStyle::blunt ? 1.1f : 1.f;
    float kinetic=std::clamp(mass,1.f,100.f)*speed*speed*kineticScale/1000000.f;
    float weapon=std::max(0.f,baseDamage)*baseScale*ratio*type;
    return std::clamp(std::max(floor*ratio,kinetic+weapon)*overall,0.f,cap);
}
inline float mitigateObjectDamage(float amount,float armorRating,float armorFactor,float armorCap,float pierce,float difficulty,float armorBase=0.f) {
    if(!std::isfinite(amount) || !std::isfinite(armorRating) || !std::isfinite(difficulty)) return 0;
    float reduction=std::clamp(std::max(0.f,armorRating)*armorFactor+std::max(0.f,armorBase),0.f,armorCap);
    return std::max(0.f,amount*(1.f-reduction*(1.f-std::clamp(pierce,0.f,1.f)))*std::clamp(difficulty,0.f,10.f));
}
inline float enchantmentCost(float amount,float reduction) {
    return std::max(0.f,amount)*std::clamp(1.f-reduction*.01f,0.f,1.f);
}
// Combat XP uses a replenishing game-time budget. No idle holding or prop pickup awards experience.
inline float budgetedXP(float requested,float& budget) {
    float granted=std::clamp(requested,0.f,std::max(0.f,budget)); budget-=granted; return granted;
}
inline bool lethalFall(float peak,float height,float verticalSpeed,float drop,float minimum) {
    return std::isfinite(peak) && std::isfinite(height) && std::isfinite(verticalSpeed) &&
        peak-height>=drop && verticalSpeed<=-minimum;
}
inline float actorImpactDamage(float health,float maximum,int playerLevel,int targetLevel,
    float speed,float referenceSpeed,float fraction,float capFraction,int killAdvantage,bool fall,bool slam=false) {
    if(!std::isfinite(health) || !std::isfinite(maximum) || health<=0 || maximum<=0 ||
       !std::isfinite(speed) || speed<=0 || referenceSpeed<=0) return 0;
    int difference=playerLevel-targetLevel;
    if((fall && !slam) || difference>=killAdvantage) return health+1000.f;
    float scale=std::clamp(1.f+difference*.03f,.5f,1.5f);
    float ratio=speed/referenceSpeed;
    float amount=maximum*std::min(capFraction,fraction*scale*ratio*ratio);
    return slam ? std::min(amount,std::max(0.f,health-1.f)) : amount;
}

}
