#pragma once
#include <algorithm>
#include <cmath>

namespace tkc {
struct Vec {
    float x{}, y{}, z{};
    Vec operator+(Vec b) const { return {x+b.x,y+b.y,z+b.z}; }
    Vec operator-(Vec b) const { return {x-b.x,y-b.y,z-b.z}; }
    Vec operator*(float s) const { return {x*s,y*s,z*s}; }
};
inline float dot(Vec a, Vec b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline float length(Vec a) { return std::sqrt(dot(a,a)); }
inline Vec unit(Vec a) { float n=length(a); return n>0.001f ? a*(1/n) : Vec{}; }
inline Vec limit(Vec a, float cap) { float n=length(a); return n>cap ? a*(cap/n) : a; }
inline bool finite(Vec a) { return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z); }
inline bool rayHasRemaining(Vec cursor,Vec end,Vec direction) { return dot(end-cursor,direction)>.001f; }
inline float nearbyScore(Vec origin,Vec point,float radius) {
    float d=length(point-origin);
    return finite(point) && std::isfinite(radius) && d<=radius ? d : -1.f;
}
// Time to closest approach must lie ahead, inside both the capture sphere and threat corridor.
// The one-tick lead admits a missile that would cross the capture sphere before the next poll.
inline float predictedMissileScore(Vec player,Vec point,Vec velocity,float radius,float lookAhead,float threat,float poll=.016f) {
    if(!finite(player) || !finite(point) || !finite(velocity) || !std::isfinite(radius) || radius<=0) return -1;
    float v2=dot(velocity,velocity); if(v2<=1) return -1;
    float t=dot(player-point,velocity)/v2;
    if(t<=0 || t>lookAhead || length(point+velocity*t-player)>threat) return -1;
    float step=std::clamp(t,0.f,std::max(0.f,poll));
    if(length(point+velocity*step-player)>radius) return -1;
    return t; // Earliest actual threat wins, rather than nearest passing particle.
}
struct MissileAngles { float x,z; };
inline MissileAngles missileAngles(Vec direction) {
    direction=unit(direction);
    return {-std::asin(std::clamp(direction.z,-1.f,1.f)),std::atan2(direction.x,direction.y)};
}
inline float aimScore(Vec origin, Vec direction, Vec point, float radius, float range, float degrees=3.f) {
    Vec offset=point-origin; float ahead=dot(offset,direction);
    if(ahead<=0 || length(offset)>range) return -1;
    float width=std::clamp(radius,24.f,80.f)+ahead*std::tan(degrees*.01745329252f);
    float score=length(offset-direction*ahead)/width;
    return score<=1.f ? score : -1.f;
}
// Keep the item on the camera's crosshair ray; third-person adds the depth to the player.
inline float itemRayDistance(Vec camera,Vec direction,Vec player,float ahead,bool thirdPerson) {
    return ahead+(thirdPerson ? std::max(0.f,dot(player-camera,direction)) : 0.f);
}
inline Vec advanceAnchor(Vec anchor, Vec goal, float speed, float dt) {
    return anchor+limit(goal-anchor,speed*std::max(0.f,dt));
}
inline Vec holdVelocity(Vec previous, Vec anchor, Vec body, float dt, float gain, float speed) {
    Vec feed=dt>.0001f ? (anchor-previous)*(1.f/dt) : Vec{};
    return limit(feed+(anchor-body)*gain,speed);
}
inline float segmentDistance(Vec a, Vec b, Vec p) {
    Vec ab=b-a; float d=dot(ab,ab);
    float t=d>0.001f ? std::clamp(dot(p-a,ab)/d,0.f,1.f) : 0.f;
    return length(p-(a+ab*t));
}
// Fraction along a swept segment entering expanded actor bounds; -1 means no hit.
inline float boxHit(Vec from, Vec to, Vec low, Vec high, float padding) {
    if(!finite(from) || !finite(to) || !finite(low) || !finite(high)) return -1;
    float first=0, last=1;
    const float a[]{from.x,from.y,from.z}, d[]{to.x-from.x,to.y-from.y,to.z-from.z};
    const float lo[]{low.x-padding,low.y-padding,low.z-padding};
    const float hi[]{high.x+padding,high.y+padding,high.z+padding};
    for(int i=0;i<3;++i) {
        if(lo[i]>hi[i]) return -1;
        if(std::abs(d[i])<.0001f) { if(a[i]<lo[i] || a[i]>hi[i]) return -1; }
        else {
            float x=(lo[i]-a[i])/d[i], y=(hi[i]-a[i])/d[i];
            if(x>y) std::swap(x,y);
            first=std::max(first,x); last=std::min(last,y);
            if(first>last) return -1;
        }
    }
    return first;
}
// Relative motion catches an actor crossing a blade's path between updates.
inline float movingBoxHit(Vec from,Vec to,Vec low,Vec high,Vec halfExtent,float padding,Vec movement) {
    return boxHit(from+movement,to,low-halfExtent,high+halfExtent,padding);
}
// A prop slowdown alone is not proof of a hit; keep its tracker alive until a real contact.
inline bool confirmedImpact(bool actorHit,bool geometryHit,bool thrownActor,bool velocityLoss) {
    return actorHit || geometryHit || (thrownActor && velocityLoss);
}
inline bool weakened(float current,float maximum,float fraction) {
    return std::isfinite(current) && std::isfinite(maximum) && current>0 && maximum>0 && current<=maximum*fraction;
}
inline float resistance(float scale, int targetLevel, int playerLevel, float levelFactor) {
    return std::clamp(scale*scale*scale*(1.f+std::max(0,targetLevel-playerLevel)*levelFactor),1.f,8.f);
}
enum class WeaponStyle { clutter, dagger, blade, blunt, ranged };
inline float penetration(WeaponStyle style) {
    return style==WeaponStyle::blunt ? .25f : style==WeaponStyle::dagger ? .15f : 0.f;
}
inline float combatObjectDamage(float speed,float mass,float baseDamage,WeaponStyle style,float kineticScale,
    float baseScale,float overall,float minimum,float cap,float floor) {
    if(!std::isfinite(speed) || !std::isfinite(mass) || !std::isfinite(baseDamage) || speed<minimum) return 0;
    float ratio=std::clamp(speed/3600.f,0.f,1.25f);
    float type=style==WeaponStyle::dagger ? .9f : style==WeaponStyle::blunt ? 1.1f : 1.f;
    float kinetic=std::clamp(mass,1.f,100.f)*speed*speed*kineticScale/1000000.f;
    float weapon=std::max(0.f,baseDamage)*baseScale*ratio*type;
    return std::clamp(std::max(floor*ratio,kinetic+weapon)*overall,0.f,cap);
}
inline float mitigateObjectDamage(float amount,float armorRating,float armorFactor,float armorCap,float pierce,float difficulty,float armorBase=0.f) {
    if(!std::isfinite(amount) || !std::isfinite(armorRating) || !std::isfinite(difficulty)) return 0;
    float reduction=std::clamp(std::max(0.f,armorRating)*armorFactor+std::max(0.f,armorBase),0.f,armorCap);
    return std::max(0.f,amount*(1.f-reduction*(1.f-std::clamp(pierce,0.f,1.f)))*std::clamp(difficulty,0.f,10.f));
}
inline float enchantmentCost(float amount,float reduction) {
    return std::max(0.f,amount)*std::clamp(1.f-reduction*.01f,0.f,1.f);
}
// Combat XP uses a replenishing game-time budget. No idle holding or prop pickup awards experience.
inline float budgetedXP(float requested,float& budget) {
    float granted=std::clamp(requested,0.f,std::max(0.f,budget)); budget-=granted; return granted;
}
inline bool lethalFall(float peak,float height,float verticalSpeed,float drop,float minimum) {
    return std::isfinite(peak) && std::isfinite(height) && std::isfinite(verticalSpeed) &&
        peak-height>=drop && verticalSpeed<=-minimum;
}
inline float actorImpactDamage(float health,float maximum,int playerLevel,int targetLevel,
    float speed,float referenceSpeed,float fraction,float capFraction,int killAdvantage,bool fall,bool slam=false) {
    if(!std::isfinite(health) || !std::isfinite(maximum) || health<=0 || maximum<=0 ||
       !std::isfinite(speed) || speed<=0 || referenceSpeed<=0) return 0;
    int difference=playerLevel-targetLevel;
    if((fall && !slam) || difference>=killAdvantage) return health+1000.f;
    float scale=std::clamp(1.f+difference*.03f,.5f,1.5f);
    float ratio=speed/referenceSpeed;
    float amount=maximum*std::min(capFraction,fraction*scale*ratio*ratio);
    return slam ? std::min(amount,std::max(0.f,health-1.f)) : amount;
}

}
