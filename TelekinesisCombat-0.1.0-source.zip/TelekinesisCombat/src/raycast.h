#pragma once
#include <RE/B/bhkPickData.h>
#include <RE/B/bhkShape.h>
#include "combat_math.h"

namespace tkc {
inline RE::MATERIAL_ID rayMaterial(const RE::hkpShape* shape) {
    if(!shape) return RE::MATERIAL_ID::kStone;
    switch(shape->type) {
    case RE::hkpShapeType::kSphere:
    case RE::hkpShapeType::kCylinder:
    case RE::hkpShapeType::kTriangle:
    case RE::hkpShapeType::kBox:
    case RE::hkpShapeType::kCapsule:
    case RE::hkpShapeType::kConvexVertices:
        if(shape->userData && shape->userData->materialID!=RE::MATERIAL_ID::kNone)
            return shape->userData->materialID;
        break;
    default: break;
    }
    // shortcut: compound/terrain impacts use stone; add exact materials only after safe child-key traversal is verified.
    // Native GetMaterialID can dereference a missing compressed-mesh material table even on a valid ray hit.
    return RE::MATERIAL_ID::kStone;
}

inline void preparePickRay(RE::bhkPickData& pick, Vec from, Vec to, float scale) {
    // bhkWorld::PickObject consumes an origin and displacement, not two endpoints.
    Vec start=from*scale, delta=(to-from)*scale;
    pick.rayInput.from=RE::hkVector4(start.x,start.y,start.z,1.f);
    pick.rayInput.to=RE::hkVector4(0.f,0.f,0.f,0.f);
    pick.ray=RE::hkVector4(delta.x,delta.y,delta.z,1.f);
}
}
