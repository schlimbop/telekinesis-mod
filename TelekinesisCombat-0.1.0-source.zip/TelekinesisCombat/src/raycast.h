#pragma once
#include <RE/B/bhkPickData.h>
#include "combat_math.h"

namespace tkc {
inline void preparePickRay(RE::bhkPickData& pick, Vec from, Vec to, float scale) {
    // bhkWorld::PickObject consumes an origin and displacement, not two endpoints.
    Vec start=from*scale, delta=(to-from)*scale;
    pick.rayInput.from=RE::hkVector4(start.x,start.y,start.z,1.f);
    pick.rayInput.to=RE::hkVector4(0.f,0.f,0.f,0.f);
    pick.ray=RE::hkVector4(delta.x,delta.y,delta.z,1.f);
}
}
