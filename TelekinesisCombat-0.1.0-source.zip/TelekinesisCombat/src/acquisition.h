#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <cmath>

namespace acquisition {
inline bool learned=false, tomePlaced=false;
inline float retry=0;
inline void save(SKSE::SerializationInterface* file) {
    std::uint8_t placed=tomePlaced ? 1 : 0;
    if(!file->WriteRecord(0x544F4D45,1,placed)) SKSE::log::error("Could not save spell-tome placement state");
}
inline void revert(SKSE::SerializationInterface*) { learned=false; tomePlaced=false; retry=0; }
inline void load(SKSE::SerializationInterface* file) {
    revert(file);
    std::uint32_t type,version,length;
    while(file->GetNextRecordInfo(type,version,length)) {
        if(type!=0x544F4D45 || version!=1 || length!=1) continue;
        std::uint8_t placed=0;
        if(file->ReadRecordData(placed)==1 && placed<=1) tomePlaced=placed!=0;
    }
}
inline void install() {
    auto* file=SKSE::GetSerializationInterface();
    file->SetUniqueID(0x544B434D);
    file->SetSaveCallback(save); file->SetLoadCallback(load); file->SetRevertCallback(revert);
}
inline void tick(RE::SpellItem* spell,const std::string& plugin,float dt) {
    if(!spell || (retry-=dt)>0) return;
    retry=.5f;
    auto* player=RE::PlayerCharacter::GetSingleton();
    if(!player || !player->Get3D() || !player->GetParentCell()) return;
    if(!learned) {
        learned=player->HasSpell(spell) || player->AddSpell(spell);
        if(learned) SKSE::log::info("Combat Telekinesis available to player");
    }
    if(tomePlaced) return;
    // Vanilla Dragonsreach enchanting table, verified from the owned Skyrim.esm.
    auto* table=RE::TESForm::LookupByID<RE::TESObjectREFR>(0xc6e44);
    if(!table || table->IsDisabled() || !table->Get3D() || table->GetParentCell()!=player->GetParentCell()) return;
    auto* book=RE::TESDataHandler::GetSingleton()->LookupForm<RE::TESObjectBOOK>(0x806,plugin);
    if(!book) return;
    auto placed=table->PlaceObjectAtMe(book,true);
    if(!placed) return;
    auto position=table->GetPosition(); float angle=table->GetAngleZ();
    // Place on the side of the work surface, clear of the central enchanting apparatus.
    position.x+=std::cos(angle)*45.f; position.y+=std::sin(angle)*45.f; position.z+=80.f;
    placed->SetPosition(position); placed->SetAngle({0,0,angle});
    tomePlaced=true;
    SKSE::log::info("Placed spell tome {:08X} on Farengar's enchanting table",placed->GetFormID());
}
}
