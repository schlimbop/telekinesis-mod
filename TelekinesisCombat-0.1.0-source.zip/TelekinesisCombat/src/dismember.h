#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <RE/H/hkpShapeRayCastInput.h>
#include <RE/H/hkpShapeRayCastOutput.h>
#include "combat_math.h"
#include "limb_contact.h"
#include <cstddef>
#include <string>
#include <vector>

namespace tkc::dismember {
// Independently declared ABI for Seb263's DF APIs 1.0.1/1.0.2. No framework implementation/assets are bundled.
// Reference: https://github.com/powerof3/PapyrusExtenderSSE/blob/master/include/API/DismemberingFrameworkAPI.h
struct Params {
    bool forceExecution=false;
    std::string specificNode;
    bool ignoreArmorClass=false, noLimbImpulse=false, noSoundEffect=false, noPlayerEffect=false;
    RE::HitData* hitData=nullptr;
};
static_assert(sizeof(Params)==0x38 && offsetof(Params,specificNode)==0x08 && offsetof(Params,hitData)==0x30);
class API {
public:
    virtual std::size_t GetVersion() const=0;
    virtual void Dismember(RE::Actor*,const RE::BSFixedString&,RE::Actor*,RE::TESObjectWEAP*,const Params*) const=0;
    virtual bool IsDismembered(RE::Actor*) const=0;
    virtual bool IsDismemberedNode(RE::Actor*,const RE::BSFixedString&) const=0;
    virtual void RefreshActorDismemberedState(RE::Actor*) const=0;
};
inline constexpr std::uint32_t messageKey=0x46440000, apiVersion=0x010001;
inline std::size_t detectedVersion=0;
inline API* api=nullptr;
inline bool bind(API* candidate) {
    detectedVersion=candidate ? candidate->GetVersion() : 0;
    api=candidate && supportedDismemberAPI(detectedVersion) ? candidate : nullptr;
    return api!=nullptr;
}
inline void load() {
    API* candidate=nullptr;
    // Message-only discovery after game load: no DLL import, LoadLibrary, ESP master or Papyrus dependency.
    SKSE::GetMessagingInterface()->Dispatch(messageKey,&candidate,sizeof(candidate),nullptr);
    bool accepted=bind(candidate);
    if(accepted) SKSE::log::info("Optional DF integration: API 1.0.{} available (0x{:06X})",detectedVersion&0xff,detectedVersion);
    else if(candidate) SKSE::log::warn("Optional DF integration: unsupported API 0x{:06X}; ordinary deaths retained",detectedVersion);
    else SKSE::log::info("Optional DF integration: API not provided; ordinary deaths retained");
}
inline Vec point(const RE::hkVector4& v) {
    return {v.quad.m128_f32[0],v.quad.m128_f32[1],v.quad.m128_f32[2]};
}
inline Vec localPoint(Vec world,const RE::hkTransform& transform) {
    Vec delta=world-point(transform.translation);
    return {dot(delta,point(transform.rotation.col0)),dot(delta,point(transform.rotation.col1)),dot(delta,point(transform.rotation.col2))};
}
struct Contact { std::string node,region; float fraction=1; const char* method="none"; int shapes=0, joints=0; };
inline bool limbShape(RE::hkpShapeType type) {
    return type==RE::hkpShapeType::kSphere || type==RE::hkpShapeType::kCapsule ||
        type==RE::hkpShapeType::kBox || type==RE::hkpShapeType::kConvexVertices;
}
inline float shapeContact(const RE::hkpShape* shape,const RE::hkTransform& transform,Vec from,Vec to) {
    if(!shape || !limbShape(shape->type)) return -1;
    Vec a=localPoint(from,transform),b=localPoint(to,transform);
    if(!finite(a) || !finite(b) || length(b-a)<=.00001f) return -1;
    RE::hkpShapeRayCastInput input{};
    input.from={a.x,a.y,a.z,0}; input.to={b.x,b.y,b.z,0};
    RE::hkpShapeRayCastOutput output{};
    return shape->CastRayImpl(input,output) && std::isfinite(output.hitFraction) &&
        output.hitFraction>=0 && output.hitFraction<1 ? output.hitFraction : -1;
}
inline void findContact(RE::NiAVObject* object,Vec from,Vec to,Contact& result,int& visited,int depth=0) {
    if(!object || depth>64 || ++visited>1024) return;
    auto* collision=object->collisionObject ? object->collisionObject->AsBhkNiCollisionObject() : nullptr;
    auto* wrapper=collision && collision->body ? collision->body->AsBhkRigidBody() : nullptr;
    auto* body=wrapper ? wrapper->GetRigidBody() : nullptr;
    auto* shape=body ? body->GetShape() : nullptr;
    if(shape && !object->name.empty()) {
        ++result.shapes;
        float fraction=shapeContact(shape,body->motion.motionState.transform,from,to);
        if(fraction>=0 && fraction<result.fraction) {
            result.node=object->name.c_str(); result.region=result.node; result.fraction=fraction; result.method="body ray";
        }
    }
    if(auto* node=object->AsNode()) for(auto& child:node->children) findContact(child.get(),from,to,result,visited,depth+1);
}
inline void collectPose(RE::NiAVObject* object,LimbPose& pose,std::array<std::string,limbJointNames.size()>& names,int& visited,int depth=0) {
    if(!object || depth>64 || ++visited>1024) return;
    int joint=object->name.empty() ? -1 : limbJointIndex(object->name.c_str());
    Vec position{object->world.translate.x,object->world.translate.y,object->world.translate.z};
    if(joint>=0 && finite(position) && !pose[joint].present) {
        pose[joint]={position,true}; names[joint]=object->name.c_str();
    }
    if(auto* node=object->AsNode()) for(auto& child:node->children) collectPose(child.get(),pose,names,visited,depth+1);
}
inline Contact hitContact(RE::Actor* victim,Vec from,Vec to,Vec extent) {
    Contact contact;
    if(!api || !victim || !finite(from) || !finite(to) || !finite(extent)) return contact;
    auto* root=victim->Get3D(); auto* cell=victim->GetParentCell(); auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!root || !world) return contact;
    LimbPose pose{}; std::array<std::string,limbJointNames.size()> names;
    {
        RE::BSReadLockGuard lock(world->worldLock);
        float scale=RE::bhkWorld::GetWorldScale(); int visited=0;
        findContact(root,from*scale,to*scale,contact,visited);
        visited=0; collectPose(root,pose,names,visited);
    }
    contact.joints=static_cast<int>(std::count_if(pose.begin(),pose.end(),[](auto& joint){return joint.present;}));
    // Living actors need not expose active ragdoll bodies. Current Ni pose and full weapon bounds still exist.
    auto posed=posedLimbContact(pose,from,to,extent,victim->GetScale());
    if(posed.joint>=0 && (contact.node.empty() || posed.fraction<=contact.fraction)) {
        contact.node=names[posed.joint]; contact.region=contact.node; contact.fraction=posed.fraction; contact.method="posed weapon volume";
    }
    int joint=limbJointIndex(contact.region),cut=dismemberCutJoint(joint);
    if(cut>=0 && cut<static_cast<int>(pose.size()) && pose[cut].present) contact.node=names[cut];
    return contact;
}
struct Pending { RE::ActorHandle actor; std::string node; RE::FormID weapon{}; float remaining=.5f; };
inline std::vector<Pending> pending;
inline void queue(RE::Actor* victim,std::string node,RE::TESObjectWEAP* weapon,float before,float after,float dealt) {
    if(!api || !victim || node.empty() || !lethalItemHit(before,after,dealt)) return;
    if(pending.size()>=32) return;
    auto handle=victim->GetHandle();
    if(std::any_of(pending.begin(),pending.end(),[&](auto& item){return item.actor==handle;})) return;
    pending.push_back({RE::ActorHandle{victim},std::move(node),weapon ? weapon->GetFormID() : 0});
}
inline void tick(float dt,bool enabled) {
    if(!enabled || !api) { pending.clear(); return; }
    auto* player=RE::PlayerCharacter::GetSingleton();
    for(auto it=pending.begin();it!=pending.end();) {
        auto victim=it->actor.get(); it->remaining-=dt;
        if(!victim || !player || victim->IsDeleted() || victim->IsDisabled() || !victim->Get3D() ||
           !victim->GetParentCell() || !player->GetParentCell() ||
           !victim->GetParentCell()->GetbhkWorld() ||
           victim->GetParentCell()->GetbhkWorld()!=player->GetParentCell()->GetbhkWorld() || it->remaining<=0) {
            SKSE::log::info("DF pending request discarded: unavailable target/world or death-confirmation timeout");
            it=pending.erase(it); continue;
        }
        if(victim->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)>0) { it=pending.erase(it); continue; }
        if(!victim->IsDead() || victim->IsInKillMove()) { ++it; continue; }
        RE::BSFixedString node(it->node);
        if(!api->IsDismemberedNode(victim.get(),node)) {
            Params params; params.forceExecution=true; params.specificNode=it->node;
            auto* weapon=it->weapon ? RE::TESForm::LookupByID<RE::TESObjectWEAP>(it->weapon) : nullptr;
            // Cosmetic request only after confirmed death. DF retains responsibility for supported assets/armor.
            api->Dismember(victim.get(),node,player,weapon,&params);
            SKSE::log::info("DF dismemberment requested for {:08X}: node {}",victim->GetFormID(),it->node);
        }
        it=pending.erase(it);
    }
}
}
