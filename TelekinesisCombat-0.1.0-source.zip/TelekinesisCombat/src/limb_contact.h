#pragma once
#include "combat_math.h"
#include <array>
#include <string_view>

namespace tkc {
// Exact distance from a joint segment to an axis-aligned box centered at zero.
inline float segmentBoxDistance2(Vec a,Vec b,Vec extent) {
    if(!finite(a) || !finite(b) || !finite(extent) || extent.x<0 || extent.y<0 || extent.z<0) return INFINITY;
    std::array<float,8> cuts{0,1}; int count=2;
    Vec delta=b-a;
    const std::array origin{a.x,a.y,a.z},direction{delta.x,delta.y,delta.z},half{extent.x,extent.y,extent.z};
    for(int axis=0;axis<3;++axis) if(std::abs(direction[axis])>1e-6f)
        for(float face:{-half[axis],half[axis]}) {
            float t=(face-origin[axis])/direction[axis];
            if(t>0 && t<1) cuts[count++]=t;
        }
    std::sort(cuts.begin(),cuts.begin()+count);
    auto distance=[&](float t) {
        float result=0;
        for(int axis=0;axis<3;++axis) {
            float gap=std::max(0.f,std::abs(origin[axis]+direction[axis]*t)-half[axis]); result+=gap*gap;
        }
        return result;
    };
    float best=INFINITY;
    for(int i=1;i<count;++i) {
        float low=cuts[i-1],high=cuts[i],middle=(low+high)*.5f,numerator=0,denominator=0;
        for(int axis=0;axis<3;++axis) {
            float point=origin[axis]+direction[axis]*middle;
            if(point < -half[axis] || point > half[axis]) {
                float face=point<0 ? -half[axis] : half[axis];
                numerator+=direction[axis]*(origin[axis]-face); denominator+=direction[axis]*direction[axis];
            }
        }
        float t=denominator>1e-8f ? std::clamp(-numerator/denominator,low,high) : low;
        best=std::min({best,distance(low),distance(high),distance(t)});
    }
    return best;
}
// A moving weapon box against a posed anatomical capsule; no targeting/aim-assist padding.
inline float sweptBoxCapsule(Vec from,Vec to,Vec extent,Vec a,Vec b,float radius) {
    if(!finite(from) || !finite(to) || !finite(a) || !finite(b) || !finite(extent) ||
       extent.x<0 || extent.y<0 || extent.z<0 || !std::isfinite(radius) || radius<=0 || radius>256) return -1;
    Vec lowBound{std::min(a.x,b.x)-radius,std::min(a.y,b.y)-radius,std::min(a.z,b.z)-radius};
    Vec highBound{std::max(a.x,b.x)+radius,std::max(a.y,b.y)+radius,std::max(a.z,b.z)+radius};
    if(boxHit(from,to,lowBound-extent,highBound+extent,0)<0) return -1;
    Vec movement=to-from; float threshold=radius*radius+.001f;
    auto distance=[&](float t) { Vec center=from+movement*t; return segmentBoxDistance2(a-center,b-center,extent); };
    if(distance(0)<=threshold) return 0;
    if(length(movement)<.0001f) return -1;
    // Distance between convex sets along a line is convex, so bracket its minimum before finding entry.
    float low=0,high=1;
    for(int i=0;i<36;++i) {
        float first=(2*low+high)/3,second=(low+2*high)/3;
        if(distance(first)<distance(second)) high=second; else low=first;
    }
    float nearest=(low+high)*.5f;
    if(distance(1)<distance(nearest)) nearest=1;
    if(distance(nearest)>threshold) return -1;
    low=0; high=nearest;
    for(int i=0;i<24;++i) { float middle=(low+high)*.5f; if(distance(middle)<=threshold) high=middle; else low=middle; }
    return high;
}
inline constexpr std::array<std::string_view,17> limbJointNames{
    "NPC Head","NPC Neck","NPC Pelvis","NPC Spine1","NPC Spine2",
    "NPC L UpperArm","NPC L Forearm","NPC L Hand","NPC L Thigh","NPC L Calf","NPC L Foot",
    "NPC R UpperArm","NPC R Forearm","NPC R Hand","NPC R Thigh","NPC R Calf","NPC R Foot"};
inline int limbJointIndex(std::string_view name) {
    for(int i=0;i<static_cast<int>(limbJointNames.size());++i) {
        auto key=limbJointNames[i];
        if(name==key || (name.starts_with(key) && name.substr(key.size()).starts_with(" ["))) return i;
    }
    return -1;
}
// Official humanoid/Draugr/Falmer packs register head removal at Neck (Head is the detached RefNode).
inline int dismemberCutJoint(int contact) {
    switch(contact) {
    case 0: return 1;
    case 7: return 6;
    case 10: return 9;
    case 13: return 12;
    case 16: return 15;
    default: return contact;
    }
}
struct LimbJoint { Vec point{}; bool present=false; };
using LimbPose=std::array<LimbJoint,limbJointNames.size()>;
struct PosedLimbHit { int joint=-1; float fraction=1, distance=INFINITY; };
// shortcut: named-joint capsules and weapon AABBs approximate meshes; calibrate custom rigs or add shape sweeps after game tests.
inline PosedLimbHit posedLimbContact(const LimbPose& pose,Vec from,Vec to,Vec extent,float scale) {
    PosedLimbHit best;
    if(!std::isfinite(scale) || scale<=0) return best;
    scale=std::clamp(scale,.25f,3.f);
    auto consider=[&](int joint,Vec a,Vec b,float radius) {
        float fraction=sweptBoxCapsule(from,to,extent,a,b,radius*scale);
        if(fraction<0) return;
        float distance=segmentDistance(a,b,from+(to-from)*fraction);
        if(best.joint<0 || fraction<best.fraction-.001f ||
           (std::abs(fraction-best.fraction)<=.001f && distance<best.distance)) best={joint,fraction,distance};
    };
    auto region=[&](int start,int end,float radius) {
        if(pose[start].present && pose[end].present) consider(start,pose[start].point,pose[end].point,radius);
    };
    if(pose[0].present && pose[1].present) {
        Vec head=pose[0].point,neck=pose[1].point;
        consider(0,neck,head+(head-neck)*.6f,10.5f);
    }
    // Torso zones participate even if DF has no torso asset: a chest hit must not choose a nearby arm/head.
    region(2,3,16); region(3,4,15);
    for(int side:{5,11}) {
        region(side,side+1,7); region(side+1,side+2,6.5f);
        region(side+2,side+2,5); region(side+3,side+4,10);
        region(side+4,side+5,7); region(side+5,side+5,6);
    }
    return best;
}
}
