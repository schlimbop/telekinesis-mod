#pragma once
#include <algorithm>
#include <array>
#include <cstddef>
#include <span>
#include <string_view>

namespace settings {
inline constexpr const char* homeLabels[]{"Balanced", "Powerful", "Objects", "Costs / XP", "Projectiles", "Resistance", "Controls", "Feedback", "Reload INI", "Close"};
inline constexpr const char* objectLabels[]{"Damage -", "Damage +", "Damage cap", "Weapon base -", "Weapon base +", "Armor", "Difficulty", "Back"};
inline constexpr const char* costLabels[]{"Costs -20%", "Costs +20%", "Cost reductions", "XP scale", "XP budget", "Back"};
inline constexpr const char* projectileLabels[]{"Capture", "Radius -", "Radius +", "Prediction -", "Prediction +", "Return aim", "Hold limit", "Threat radius", "Back"};
inline constexpr const char* resistanceLabels[]{"Resistance -", "Resistance +", "Size limit -", "Size limit +", "Execute health", "Lethal gap", "Protect NPCs", "Creatures", "Back"};
inline constexpr const char* controlLabels[]{"Settings key", "Modifier key", "Legacy on/off", "Legacy keys", "Reset keys", "Back"};
inline constexpr const char* legacyLabels[]{"Grab key", "Launch key", "Pull key", "Push key", "Slam key", "Execute key", "Back"};
inline constexpr const char* feedbackLabels[]{"Preview", "Sounds / VFX", "Decapitation", "Profile log", "Cache interval", "Search interval", "Back"};
struct MenuPage {
    std::string_view title;
    std::span<const char* const> labels;
};
inline constexpr std::array<MenuPage,8> menuPages{{
    {"Settings", homeLabels}, {"Object damage", objectLabels}, {"Costs / Alteration XP", costLabels},
    {"Projectiles", projectileLabels}, {"Resistance", resistanceLabels}, {"Controls", controlLabels},
    {"Legacy controls", legacyLabels}, {"Feedback / performance", feedbackLabels}
}};

// Skyrim puts native message-box buttons in one row; always reserve space for navigation.
struct MenuLayout {
    static constexpr int cancelled=-1, more=-2;
    std::size_t labelCount, sections, section, first, actions, buttonCount;
    constexpr MenuLayout(std::size_t count, std::size_t requested=0) : labelCount(count),
        sections(count>1 ? count/2 : 1), section(std::min(requested,sections-1)),
        first(section*2), actions(count>1 ? std::min(std::size_t{2},count-1-first) : 0),
        buttonCount(count ? actions+(sections>1 ? 1 : 0)+1 : 0) {}
    constexpr int action(std::size_t button) const {
        if(button>=buttonCount) return cancelled;
        if(button<actions) return static_cast<int>(first+button);
        if(sections>1 && button==actions) return more;
        return static_cast<int>(labelCount-1);
    }
    constexpr std::size_t next() const { return (section+1)%sections; }
};
}
