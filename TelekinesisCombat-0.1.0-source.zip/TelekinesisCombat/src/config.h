#pragma once
#include <Windows.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <spdlog/spdlog.h>
#include <filesystem>
#include <string>
#include <vector>

struct Config {
    std::string plugin="TelekinesisCombat.esp";
    std::uint32_t control=0x800, hold=0x801, execution=0;
    std::uint32_t grab=34, launch=35, pull=36, push=37, slam=38, execute=45;
    bool legacyHotkeys=false;
    float grabCost=15, holdCost=12, launchCost=10, executionCost=40, disarmCost=25;
    float nearbyRadius=300, disarmRange=1800;
    bool catchProjectiles=true;
    float projectileRadius=400, projectileCost=15, projectileHoldSeconds=8;
    float levelFactor=.04f, maxScale=1.5f, maxHeight=260, maxExtent=360, executionHealth=.35f, charge=1.f;
    bool undead=true, creatures=true, corpses=true, protect=true, orient=true, decapitate=true;
    float range=6000, aimAssist=3, pickupSpeed=10000, distance=300, minDistance=140, maxDistance=650, adjustSpeed=240;
    float gain=10, holdSpeed=4500, launchSpeed=3600, slamSpeed=3000;
    float minimum=450, multiplier=1.2f, damageCap=1200, objectMassFloor=5, massCap=40;
    float objectHitMinimum=25, weaponHitMinimum=80;
    float actorLaunchSpeed=1600, actorSlamSpeed=1400, throwFraction=.20f, slamFraction=.30f, actorDamageCap=.45f;
    float cliffDrop=800, actorFlightSeconds=15, itemDistance=160, pickupReach=260;
    int lethalLevelAdvantage=10;
    float radius=26, flightSeconds=4;
    int maxFlights=8;
    bool preview=true, feedback=true, settingsEnabled=true, costPerks=true, armor=true, difficulty=true, profile=false;
    std::uint32_t settingsKey=68, modifierKey=42, modifierKey2=54;
    float damageScale=1, weaponBaseScale=12, xpScale=1, xpPerMinute=60;
    float predictionSeconds=.25f, threatRadius=110, searchInterval=.12f, cacheInterval=.25f;
    int returnMode=0; // 0 original caster (visible/alive), 1 crosshair
    void preset(bool powerful) {
        multiplier=1.2f; damageCap=powerful ? 2000.f : 1200.f; damageScale=powerful ? 1.8f : 1.f;
        weaponBaseScale=12; objectHitMinimum=25; weaponHitMinimum=80;
        grabCost=powerful ? 10.f : 15.f; holdCost=powerful ? 7.f : 12.f; launchCost=powerful ? 6.f : 10.f;
        executionCost=powerful ? 30.f : 40.f; disarmCost=powerful ? 18.f : 25.f; projectileCost=powerful ? 10.f : 15.f;
        levelFactor=powerful ? .02f : .04f; executionHealth=powerful ? .4f : .35f;
        projectileRadius=powerful ? 550.f : 400.f; predictionSeconds=powerful ? .35f : .25f;
        // Presets deliberately retain NPC throw/slam lethality, controls and immunity choices.
    }
    bool save() const {
        auto path=std::filesystem::absolute("Data/SKSE/Plugins/TelekinesisCombat.ini").string();
        bool ok=true;
        auto write=[&](const char* section,const char* key,auto value) {
            auto text=std::to_string(value);
            if(!WritePrivateProfileStringA(section,key,text.c_str(),path.c_str())) ok=false;
        };
        write("Controls","Grab",grab);
        write("Controls","Launch",launch);
        write("Controls","Pull",pull);
        write("Controls","Push",push);
        write("Controls","Slam",slam);
        write("Controls","Execute",execute);
        write("Gameplay","GrabCost",grabCost);
        write("Gameplay","HoldCostPerSecond",holdCost);
        write("Gameplay","LaunchCost",launchCost);
        write("Gameplay","ExecutionCost",executionCost);
        write("Gameplay","ProjectileCaptureRadius",projectileRadius);
        write("Gameplay","ProjectileGrabCost",projectileCost);
        write("Gameplay","MaxProjectileHoldSeconds",projectileHoldSeconds);
        write("Gameplay","DisarmCost",disarmCost);
        write("Gameplay","NearbyPickupRadius",nearbyRadius);
        write("Gameplay","DisarmRange",disarmRange);
        write("Gameplay","LevelResistance",levelFactor);
        write("Gameplay","MaxActorScale",maxScale);
        write("Gameplay","MaxActorHeight",maxHeight);
        write("Gameplay","MaxActorExtent",maxExtent);
        write("Gameplay","ExecutionHealthFraction",executionHealth);
        write("Gameplay","ExecutionChargeSeconds",charge);
        write("Physics","Range",range);
        write("Physics","AimAssistDegrees",aimAssist);
        write("Physics","PickupSpeed",pickupSpeed);
        write("Physics","MinHoldDistance",minDistance);
        write("Physics","MaxHoldDistance",maxDistance);
        write("Physics","HoldDistance",distance);
        write("Physics","ItemHoldDistance",itemDistance);
        write("Physics","PickupReach",pickupReach);
        write("Physics","PullPushSpeed",adjustSpeed);
        write("Physics","SpringGain",gain);
        write("Physics","MaxHoldSpeed",holdSpeed);
        write("Physics","LaunchSpeed",launchSpeed);
        write("Physics","SlamSpeed",slamSpeed);
        write("Physics","ImpactMinSpeed",minimum);
        write("Physics","ImpactDamageMultiplier",multiplier);
        write("Physics","MaxImpactDamage",damageCap);
        write("Physics","ObjectMassCap",massCap);
        write("Physics","ObjectMassFloor",objectMassFloor);
        write("Physics","ObjectMinHitDamage",objectHitMinimum);
        write("Physics","WeaponMinHitDamage",weaponHitMinimum);
        write("Physics","ActorLaunchSpeed",actorLaunchSpeed);
        write("Physics","ActorSlamSpeed",actorSlamSpeed);
        write("Physics","ActorThrowDamageFraction",throwFraction);
        write("Physics","ActorSlamDamageFraction",slamFraction);
        write("Physics","ActorDamageCapFraction",actorDamageCap);
        write("Physics","CliffLethalDrop",cliffDrop);
        write("Physics","ActorFlightSeconds",actorFlightSeconds);
        write("Physics","HitRadius",radius);
        write("Physics","FlightSeconds",flightSeconds);
        write("Controls","SettingsMenu",settingsEnabled);
        write("Controls","SettingsKey",settingsKey);
        write("Controls","ModifierKey",modifierKey);
        write("Controls","SecondaryModifierKey",modifierKey2);
        write("Feedback","TargetPreview",preview);
        write("Feedback","EffectsAndSounds",feedback);
        write("Gameplay","CostReductionPerks",costPerks);
        write("Gameplay","AlterationXPScale",xpScale);
        write("Gameplay","MaxAlterationXPPerMinute",xpPerMinute);
        write("Gameplay","ProjectileLookAheadSeconds",predictionSeconds);
        write("Gameplay","ProjectileThreatRadius",threatRadius);
        write("Gameplay","ProjectileReturnMode",returnMode);
        write("Physics","ObjectDamageScale",damageScale);
        write("Physics","WeaponBaseDamageScale",weaponBaseScale);
        write("Physics","RespectArmor",armor);
        write("Physics","RespectDifficulty",difficulty);
        write("Performance","SearchInterval",searchInterval);
        write("Performance","CandidateCacheSeconds",cacheInterval);
        write("Performance","Profile",profile);
        write("Controls","LegacyHotkeys",legacyHotkeys);
        write("Gameplay","LethalLevelAdvantage",lethalLevelAdvantage);
        write("Gameplay","CatchProjectiles",catchProjectiles);
        write("Gameplay","AllowUndead",undead);
        write("Gameplay","AllowCreatures",creatures);
        write("Gameplay","AllowCorpses",corpses);
        write("Gameplay","ProtectProtectedActors",protect);
        write("Physics","OrientSwords",orient);
        write("Gameplay","ExecutionDecapitation",decapitate);
        write("Physics","MaxFlights",maxFlights);
        if(!ok) spdlog::error("Cannot save settings to {} (Windows error {})",path,GetLastError());
        return ok;
    }
    void load() {
        auto path=std::filesystem::absolute("Data/SKSE/Plugins/TelekinesisCombat.ini").string();
        auto read=[&](const char* section,const char* key,const std::string& fallback) {
            char buffer[512]{};
            GetPrivateProfileStringA(section,key,fallback.c_str(),buffer,sizeof(buffer),path.c_str());
            return std::string(buffer);
        };
        auto number=[&](const char* section,const char* key,float fallback,float lo,float hi) {
            try {
                auto s=read(section,key,std::to_string(fallback)); size_t used=0;
                float n=std::stof(s,&used);
                if(used!=s.size() || !std::isfinite(n)) throw std::invalid_argument(key);
                return std::clamp(n,lo,hi);
            } catch(...) { spdlog::warn("Invalid INI {}.{}; using default",section,key); return fallback; }
        };
        auto form=[&](const char* key,std::uint32_t fallback) {
            try {
                auto s=read("Forms",key,std::to_string(fallback)); size_t used=0;
                auto n=std::stoul(s,&used,0);
                if(used!=s.size() || n>0xFFFFFF) throw std::invalid_argument(key);
                return static_cast<std::uint32_t>(n);
            } catch(...) { spdlog::warn("Invalid form {}",key); return fallback; }
        };
        plugin=read("Forms","Plugin",plugin);
        legacyHotkeys=number("Controls","LegacyHotkeys",0,0,1)!=0;
        control=form("ControlSpell",control); hold=form("HoldSpell",hold); execution=form("ExecutionSpell",execution);
#define KEY(member,name) member=static_cast<std::uint32_t>(number("Controls",name,static_cast<float>(member),1,255))
        KEY(grab,"Grab"); KEY(launch,"Launch"); KEY(pull,"Pull"); KEY(push,"Push"); KEY(slam,"Slam"); KEY(execute,"Execute");
#undef KEY
#define G(member,name,lo,hi) member=number("Gameplay",name,member,lo,hi)
        G(grabCost,"GrabCost",0,500); G(holdCost,"HoldCostPerSecond",0,500);
        G(launchCost,"LaunchCost",0,500); G(executionCost,"ExecutionCost",0,1000);
        G(projectileRadius,"ProjectileCaptureRadius",100,1000); G(projectileCost,"ProjectileGrabCost",0,500);
        G(projectileHoldSeconds,"MaxProjectileHoldSeconds",1,30);
        G(disarmCost,"DisarmCost",0,500); G(nearbyRadius,"NearbyPickupRadius",100,800); G(disarmRange,"DisarmRange",200,6000);
        G(levelFactor,"LevelResistance",0,.2f); G(maxScale,"MaxActorScale",.5f,2);
        G(maxHeight,"MaxActorHeight",50,500); G(maxExtent,"MaxActorExtent",100,800); G(executionHealth,"ExecutionHealthFraction",.01f,.5f);
        G(charge,"ExecutionChargeSeconds",.25f,5);
        lethalLevelAdvantage=static_cast<int>(number("Gameplay","LethalLevelAdvantage",10,1,100));
#undef G
        catchProjectiles=number("Gameplay","CatchProjectiles",1,0,1)!=0;
        undead=number("Gameplay","AllowUndead",1,0,1)!=0;
        creatures=number("Gameplay","AllowCreatures",1,0,1)!=0;
        corpses=number("Gameplay","AllowCorpses",1,0,1)!=0;
        protect=number("Gameplay","ProtectProtectedActors",1,0,1)!=0;
        orient=number("Physics","OrientSwords",1,0,1)!=0;
        decapitate=number("Gameplay","ExecutionDecapitation",1,0,1)!=0;
#define P(member,name,lo,hi) member=number("Physics",name,member,lo,hi)
        P(range,"Range",200,8000); P(aimAssist,"AimAssistDegrees",.25f,5);
        P(pickupSpeed,"PickupSpeed",1000,20000); P(minDistance,"MinHoldDistance",80,500);
        P(maxDistance,"MaxHoldDistance",minDistance,1000); P(distance,"HoldDistance",minDistance,maxDistance);
        P(itemDistance,"ItemHoldDistance",minDistance,maxDistance); P(pickupReach,"PickupReach",100,300);
        P(adjustSpeed,"PullPushSpeed",20,600); P(gain,"SpringGain",1,12); P(holdSpeed,"MaxHoldSpeed",100,8000);
        P(launchSpeed,"LaunchSpeed",500,4500); P(slamSpeed,"SlamSpeed",500,4500);
        P(minimum,"ImpactMinSpeed",100,2000); P(multiplier,"ImpactDamageMultiplier",0,10);
        P(damageCap,"MaxImpactDamage",0,10000); P(massCap,"ObjectMassCap",1,100);
        P(objectMassFloor,"ObjectMassFloor",1,massCap);
        P(objectHitMinimum,"ObjectMinHitDamage",0,damageCap); P(weaponHitMinimum,"WeaponMinHitDamage",0,damageCap);
        P(actorLaunchSpeed,"ActorLaunchSpeed",500,3000); P(actorSlamSpeed,"ActorSlamSpeed",500,3000);
        P(throwFraction,"ActorThrowDamageFraction",.01f,.5f); P(slamFraction,"ActorSlamDamageFraction",.01f,.5f);
        P(actorDamageCap,"ActorDamageCapFraction",.05f,.8f);
        P(cliffDrop,"CliffLethalDrop",400,4000); P(actorFlightSeconds,"ActorFlightSeconds",4,30);
        P(radius,"HitRadius",10,80); P(flightSeconds,"FlightSeconds",.5f,8);
#undef P
        maxFlights=static_cast<int>(number("Physics","MaxFlights",8,1,16));
#define N(section,member,name,lo,hi) member=static_cast<decltype(member)>(number(section,name,static_cast<float>(member),lo,hi))
        N("Controls",settingsEnabled,"SettingsMenu",0,1); N("Controls",settingsKey,"SettingsKey",2,255);
        N("Controls",modifierKey,"ModifierKey",2,255); N("Controls",modifierKey2,"SecondaryModifierKey",0,255);
        N("Feedback",preview,"TargetPreview",0,1); N("Feedback",feedback,"EffectsAndSounds",0,1);
        N("Gameplay",costPerks,"CostReductionPerks",0,1); N("Gameplay",xpScale,"AlterationXPScale",0,5);
        N("Gameplay",xpPerMinute,"MaxAlterationXPPerMinute",0,300);
        N("Gameplay",predictionSeconds,"ProjectileLookAheadSeconds",.02f,.75f);
        N("Gameplay",threatRadius,"ProjectileThreatRadius",30,200);
        N("Gameplay",returnMode,"ProjectileReturnMode",0,1);
        N("Physics",damageScale,"ObjectDamageScale",0,5); N("Physics",weaponBaseScale,"WeaponBaseDamageScale",0,30);
        N("Physics",armor,"RespectArmor",0,1); N("Physics",difficulty,"RespectDifficulty",0,1);
        N("Performance",searchInterval,"SearchInterval",.05f,.5f); N("Performance",cacheInterval,"CandidateCacheSeconds",.1f,1);
        N("Performance",profile,"Profile",0,1);
#undef N
        if(settingsKey==modifierKey || (modifierKey2 && settingsKey==modifierKey2) || modifierKey==modifierKey2) {
            spdlog::warn("Conflicting settings/modifier controls; restoring F10 and both Shift keys");
            settingsKey=68; modifierKey=42; modifierKey2=54;
        }
        std::vector<std::uint32_t> keys{grab,launch,pull,push,slam,execute,settingsKey,modifierKey};
        if(modifierKey2) keys.push_back(modifierKey2);
        std::sort(keys.begin(),keys.end());
        if(std::adjacent_find(keys.begin(),keys.end())!=keys.end()) {
            spdlog::warn("Duplicate controls; restoring defaults");
            grab=34; launch=35; pull=36; push=37; slam=38; execute=45; settingsKey=68; modifierKey=42; modifierKey2=54;
        }
    }
};
inline Config cfg;

