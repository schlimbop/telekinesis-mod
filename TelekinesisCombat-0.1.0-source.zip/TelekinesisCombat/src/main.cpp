#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <Windows.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <atomic>
#include <array>
#include <chrono>
#include <filesystem>
#include <thread>
#include <stdexcept>
#include <vector>
#include "combat_math.h"
#include "controls.h"
#include "raycast.h"
#include "missile_hold.h"
#include "config.h"
#include "feedback.h"
#include "settings_menu.h"
#include <unordered_map>

namespace {
using namespace tkc;
using Clock=std::chrono::steady_clock;
Vec vec(RE::NiPoint3 p) { return {p.x,p.y,p.z}; }
RE::NiPoint3 ni(Vec p) { return {p.x,p.y,p.z}; }
Vec vec(const RE::hkVector4& p) {
    return {p.quad.m128_f32[0],p.quad.m128_f32[1],p.quad.m128_f32[2]};
}
RE::hkVector4 hk(Vec p) { return {p.x,p.y,p.z,0.f}; }

// No body/scene pointers survive a game-thread task or world-lock scope.
void bodies(RE::NiAVObject* object,std::vector<RE::bhkRigidBody*>& out) {
    if(!object || out.size()>=128) return;
    if(auto* collision=object->collisionObject ? object->collisionObject->AsBhkNiCollisionObject() : nullptr) {
        if(auto* body=collision->body ? collision->body->AsBhkRigidBody() : nullptr) {
            if(auto* rigid=body->GetRigidBody(); rigid && rigid->motion.GetMass()>0 &&
                std::find(out.begin(),out.end(),body)==out.end()) out.push_back(body);
        }
    }
    if(auto* node=object->AsNode()) for(auto& child:node->children) bodies(child.get(),out);
}
struct Sample { Vec position{}, velocity{}, halfExtent{}; int count{}; };
Sample sample(RE::TESObjectREFR* ref) {
    Sample s;
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return s;
    RE::BSReadLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float inverse=RE::bhkWorld::GetWorldScaleInverse();
    Vec low{INFINITY,INFINITY,INFINITY},high{-INFINITY,-INFINITY,-INFINITY};
    bool prop=ref->As<RE::Actor>()==nullptr;
    for(auto* body:list) {
        RE::hkVector4 pos; body->GetCenterOfMassWorld(pos);
        s.position=s.position+vec(pos)*inverse;
        s.velocity=s.velocity+vec(body->GetRigidBody()->motion.linearVelocity)*inverse;
        if(prop) {
            RE::hkAabb bounds; body->GetAabbWorldspace(bounds);
            auto a=vec(bounds.min)*inverse,b=vec(bounds.max)*inverse;
            if(finite(a) && finite(b)) {
                low={std::min(low.x,a.x),std::min(low.y,a.y),std::min(low.z,a.z)};
                high={std::max(high.x,b.x),std::max(high.y,b.y),std::max(high.z,b.z)};
            }
        }
        ++s.count;
    }
    if(s.count) { s.position=s.position*(1.f/s.count); s.velocity=s.velocity*(1.f/s.count); }
    if(prop && s.count && finite(low) && finite(high)) {
        // Include blade length and offset centres, without giving malformed meshes an unlimited hit box.
        s.halfExtent={std::clamp(std::max(s.position.x-low.x,high.x-s.position.x),0.f,120.f),
                      std::clamp(std::max(s.position.y-low.y,high.y-s.position.y),0.f,120.f),
                      std::clamp(std::max(s.position.z-low.z,high.z-s.position.z),0.f,120.f)};
    }
    return s;
}
bool velocity(RE::TESObjectREFR* ref,Vec speed,Vec* direction=nullptr,bool stabilize=false) {
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D() || !finite(speed)) return false;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float scale=RE::bhkWorld::GetWorldScale();
    Vec average{};
    bool actor=ref->As<RE::Actor>()!=nullptr;
    if(actor && !list.empty()) {
        for(auto* body:list) average=average+vec(body->GetRigidBody()->motion.linearVelocity);
        average=average*(1.f/list.size());
    }
    for(auto* body:list) {
        auto* rigid=body->GetRigidBody();
        // Activate sleeping bodies, and preserve relative limb motion in a ragdoll.
        Vec relative=actor ? vec(rigid->motion.linearVelocity)-average : Vec{};
        rigid->SetLinearVelocity(hk(speed*scale+relative));
        // Suppress collision-induced spin only while holding props, never on ragdoll limbs.
        if(stabilize && !actor) rigid->SetAngularVelocity(RE::hkVector4{});
    }
    if(direction && cfg.orient && list.size()==1) {
        auto* weapon=ref->GetBaseObject()->As<RE::TESObjectWEAP>();
        if(weapon && (weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kTwoHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandDagger)) {
            // ponytail: vanilla sword meshes use local +Z; custom mesh axes need per-mesh calibration.
            auto d=unit(*direction); float w=1+d.z;
            Vec axis{-d.y,d.x,0}; float norm=std::sqrt(dot(axis,axis)+w*w);
            RE::hkQuaternion rotation;
            rotation.vec=norm>.001f ? RE::hkVector4(axis.x/norm,axis.y/norm,0,w/norm) : RE::hkVector4(1,0,0,0);
            list.front()->SetRotation(rotation);
            list.front()->SetAngularVelocity(RE::hkVector4{});
        }
    }
    return !list.empty();
}

// Resolve a swept prop contact visually as well as applying damage; never reposition an actor.
void stopProp(RE::TESObjectREFR* ref,Vec contact) {
    if(!ref || ref->As<RE::Actor>() || !finite(contact)) return;
    auto state=sample(ref); if(!state.count) return;
    auto* cell=ref->GetParentCell(); auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    Vec offset=(contact-state.position)*RE::bhkWorld::GetWorldScale();
    for(auto* body:list) {
        RE::hkVector4 position; body->GetPosition(position);
        position=hk(vec(position)+offset); body->SetPosition(position);
        body->GetRigidBody()->SetLinearVelocity(RE::hkVector4{});
        body->GetRigidBody()->SetAngularVelocity(RE::hkVector4{});
    }
}

struct RayHit { bool hit{}; float fraction=1; RE::ObjectRefHandle ref; RE::MATERIAL_ID material=RE::MATERIAL_ID::kStone; };
RayHit ray(RE::TESObjectCELL* cell,Vec from,Vec to,RE::TESObjectREFR* ignore) {
    RayHit result;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || length(to-from)<.1f) return result;
    RE::BSReadLockGuard lock(world->worldLock);
    Vec start=from, dir=unit(to-from); float total=length(to-from);
    // Skip source body hits without globally changing any collision filter.
    for(int i=0;i<32;++i) {
        // Reaching the end after skipping only source/player bodies is a clear ray, not a wall.
        if(!rayHasRemaining(start,to,dir)) return result;
        RE::bhkPickData pick{};
        preparePickRay(pick,start,to,RE::bhkWorld::GetWorldScale());
        pick.rayInput.filterInfo.SetCollisionLayer(RE::COL_LAYER::kLOS);
        world->PickObject(pick);
        if(!pick.rayOutput.HasHit()) return result;
        auto* ref=RE::TESHavokUtilities::FindCollidableRef(*pick.rayOutput.rootCollidable);
        Vec point=start+(to-start)*pick.rayOutput.hitFraction;
        if((!ignore || ref!=ignore) && ref!=RE::PlayerCharacter::GetSingleton()) {
            result.hit=true; result.fraction=std::clamp(length(point-from)/total,0.f,1.f);
            if(ref) result.ref=ref->GetHandle();
            result.material=rayMaterial(pick.rayOutput.rootCollidable->GetShape());
            return result;
        }
        start=point+dir*8;
    }
    // Conservative: an unresolved obstruction stops targeting/hold travel.
    result.hit=true; result.fraction=0;
    return result;
}

class Combat final : public RE::BSTEventSink<RE::InputEvent*> {
    struct Flight {
        RE::ObjectRefHandle ref;
        Vec previous{}, velocity{}, halfExtent{};
        float mass{}, remaining{}, elapsed{}, refresh{}, peakZ{};
        bool slam{}, impactApplied{};
        float baseDamage{}; WeaponStyle style=WeaponStyle::clutter;
    };
    enum class Mode { none, grab, disarm, catchSpell };
    struct Selection { Mode mode=Mode::none; RE::ObjectRefHandle ref; RE::FormID weapon{}; bool left{}; };
    Selection slowSelection;
    bool selectionShift=false;
    float searchAge=100, cacheAge=100, previewAge=0, noticeAge=0;
    std::vector<RE::ObjectRefHandle> objectCache;
    std::vector<RE::ActorHandle> actorCache;
    RE::bhkWorld* cacheWorld{}; // Identity only.
    std::string lastPreview;
    RE::BSSoundHandle chargeSound;
    int chargeStep=-1;
    float xpBudget=60;
    double combatTime=0;
    std::unordered_map<RE::FormID,double> xpCooldown;
    double profileTotal=0, profilePeak=0; std::uint64_t profileTicks=0, cacheScans=0;
    float profileAge=0;
    std::uint64_t settingsRevision=0;
    RE::ObjectRefHandle held;
    RE::ObjectRefHandle projectileCaster;
    RE::FormID projectileSpell{};
    float projectilePower=1, projectileScale=1, projectileSpeed{};
    RE::bhkWorld* holdWorld{}; // identity only; never dereferenced after a world change
    Vec anchor{};
    std::vector<Flight> flights;
    struct Decapitation { RE::ActorHandle ref; float remaining=2.f; };
    std::vector<Decapitation> executions;
    RE::SpellItem* controlSpell{};
    RE::SpellItem* holdSpell{};
    RE::SpellItem* executionSpell{};
    bool active=false, execDown=false, pulling=false, pushing=false;
    bool slamDown=false, shiftLeft=false, shiftRight=false, ignoreInitialShift=false;
    RE::ObjectRefHandle pendingWeapon;
    float pendingWeaponTime{};
    bool castingShift=false;
    RE::BSFixedString gripInput;
    RE::BSFixedString castingInput;
    RE::BSFixedString finisherInput;
    bool castingHeld=false;
    float lastPoll=.016f;
    float retry{}, holdAge{}, refresh{}, costFactor=1, charged{}, distance=300;
    Clock::time_point last=Clock::now();
public:
    std::atomic_bool ready=false, queued=false;
    static Combat& get() { static auto* instance=new Combat; return *instance; }
    void resolve() {
        cfg=Config{}; cfg.load(); xpBudget=cfg.xpPerMinute;
        auto* data=RE::TESDataHandler::GetSingleton();
        controlSpell=data->LookupForm<RE::SpellItem>(cfg.control,cfg.plugin);
        holdSpell=data->LookupForm<RE::SpellItem>(cfg.hold,cfg.plugin);
        executionSpell=cfg.execution ? data->LookupForm<RE::SpellItem>(cfg.execution,cfg.plugin) : nullptr;
        // Vanilla rank-cost perks use SpellHasCastingPerk. This private spell is novice Alteration.
        if(controlSpell) controlSpell->data.castingPerk=RE::TESForm::LookupByID<RE::BGSPerk>(0xf2ca6);
        bool ragdollHold=false;
        if(holdSpell) for(auto* effect:holdSpell->effects) {
            if(effect && effect->baseEffect && effect->baseEffect->GetArchetype()==RE::EffectArchetypes::ArchetypeID::kValueModifier &&
               effect->baseEffect->data.primaryAV==RE::ActorValue::kGrabbed &&
               effect->GetDuration()==2 && effect->GetMagnitude()==1.f) ragdollHold=true;
        }
        active=controlSpell && ragdollHold;
        SKSE::log::info("Gameplay layer {} (control {:X}, hold {:X})",active ? "ready" : "MISSING/INVALID",cfg.control,cfg.hold);
        if(!active) RE::SendHUDMessage::ShowHUDMessage("Telekinesis Combat: missing/invalid companion spells. See README.");
        ready=true;
    }
    bool usable() const {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
        return ready && active && p && p->Get3D() && p->GetParentCell() && !p->IsDead() && !p->IsInKillMove() &&
            ui && !ui->GameIsPaused() && !ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) &&
            !ui->IsMenuOpen(RE::MainMenu::MENU_NAME) && !ui->IsMenuOpen(RE::DialogueMenu::MENU_NAME) &&
            (p->GetEquippedObject(false)==controlSpell || p->GetEquippedObject(true)==controlSpell);
    }
    void drop(bool stop=true) {
        chargeSound.Stop(); chargeStep=-1;
        if(auto ref=held.get()) {
            if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) missile->Kill();
            else if(stop) velocity(ref.get(),{});
            if(auto* a=ref->As<RE::Actor>(); a && holdSpell) {
                if(auto* player=RE::PlayerCharacter::GetSingleton()) {
                    RE::ActorHandle actorCaster{player};
                    a->AsMagicTarget()->DispelEffect(holdSpell,actorCaster);
                }
            }
        }
        missile_hold::clear(); projectileCaster={}; projectileSpell=0;
        held={}; pendingWeapon={}; pendingWeaponTime=0; holdWorld=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        ignoreInitialShift=false; castingShift=false;
        gripInput=RE::BSFixedString(); slamDown=false;
        castingInput=RE::BSFixedString(); castingHeld=false; finisherInput=RE::BSFixedString();
    }
    void reset() { drop(); shiftLeft=false; shiftRight=false; flights.clear(); previousTargets.clear(); executions.clear(); objectCache.clear(); actorCache.clear(); cacheWorld=nullptr;
        slowSelection={}; searchAge=cacheAge=100; lastPreview.clear(); xpCooldown.clear();
        settings::cancelRebind(); last=Clock::now(); }
    bool allowed(RE::Actor* a) const {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || (a->IsDead() && !cfg.corpses) || a->IsChild() || a->IsEssential() ||
            (cfg.protect && a->IsProtected()) || a->IsInKillMove() || a->GetScale()>cfg.maxScale ||
            a->HasKeywordString("ActorTypeDragon") || a->HasKeywordString("ActorTypeGiant")) return false;
        auto* race=a->GetRace();
        auto extent=vec(a->GetBoundMax())-vec(a->GetBoundMin());
        if(!race || !finite(extent) || extent.z>cfg.maxHeight ||
           std::max({extent.x,extent.y,extent.z})>cfg.maxExtent) return false;
        if(a->HasKeywordString("ActorTypeUndead")) return cfg.undead;
        return a->HasKeywordString("ActorTypeNPC") || cfg.creatures;
    }
    Vec aim() const {
        auto* camera=RE::PlayerCamera::GetSingleton();
        if(camera && camera->cameraRoot) {
            auto& r=camera->cameraRoot->world.rotate;
            return unit({r.entry[0][1],r.entry[1][1],r.entry[2][1]});
        }
        return {0,1,0};
    }
    float actualCost(float amount) const {
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(cfg.costPerks && controlSpell) {
            amount=enchantmentCost(amount,p->AsActorValueOwner()->GetActorValue(RE::ActorValue::kAlterationModifier));
            // Same argument order as native MagicItem::CalculateCost; do not use the zero-cost spell's calculated cost.
            RE::BGSEntryPoint::HandleEntryPoint(RE::BGSEntryPoint::ENTRY_POINT::kModSpellCost,p,controlSpell,&amount);
        }
        return std::isfinite(amount) ? std::clamp(amount,0.f,10000.f) : 10000.f;
    }
    bool spend(float amount,float* chargedCost=nullptr) {
        amount=actualCost(amount);
        auto* values=RE::PlayerCharacter::GetSingleton()->AsActorValueOwner();
        if(values->GetActorValue(RE::ActorValue::kMagicka)<amount) return false;
        values->DamageActorValue(RE::ActorValue::kMagicka,amount);
        if(chargedCost) *chargedCost=amount;
        return true;
    }
    void experience(RE::Actor* target,float amount,bool allowDead=false) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(!target || (!allowDead && target->IsDead()) || target==p || target->IsChild() || target->IsEssential() || (cfg.protect && target->IsProtected()) ||
           !target->IsHostileToActor(p) || cfg.xpScale<=0) return;
        auto id=target->GetFormID(); auto old=xpCooldown.find(id);
        if(old!=xpCooldown.end() && combatTime-old->second<2) return;
        float award=budgetedXP(amount*cfg.xpScale,xpBudget); if(award<=0) return;
        xpCooldown[id]=combatTime;
        p->AddSkillExperience(RE::ActorValue::kAlteration,award);
    }
    float physicalDamage(RE::Actor* target,float amount,WeaponStyle style) const {
        float rating=0;
        if(cfg.armor) rating=target->AsActorValueOwner()->GetActorValue(RE::ActorValue::kDamageResist);
        float diff=1;
        if(cfg.difficulty) {
            static constexpr const char* names[]{"fDiffMultHPByPCVE","fDiffMultHPByPCE","fDiffMultHPByPCN",
                "fDiffMultHPByPCH","fDiffMultHPByPCVH","fDiffMultHPByPCL"};
            static constexpr float fallback[]{2.f,1.5f,1.f,.75f,.5f,.25f};
            int index=std::clamp(RE::PlayerCharacter::GetSingleton()->GetGameStatsData().difficulty,0,5);
            diff=fallback[index];
            if(auto* setting=RE::GameSettingCollection::GetSingleton()->GetSetting(names[index]); setting && setting->GetType()==RE::Setting::Type::kFloat)
                diff=setting->GetFloat();
        }
        auto gmst=[](const char* name,float fallback) {
            auto* value=RE::GameSettingCollection::GetSingleton()->GetSetting(name);
            return value && value->GetType()==RE::Setting::Type::kFloat ? value->GetFloat() : fallback;
        };
        return mitigateObjectDamage(amount,rating,gmst("fArmorScalingFactor",.12f)*.01f,
            std::clamp(gmst("fMaxArmorRating",80.f)*.01f,0.f,.95f),penetration(style),diff,cfg.armor ? target->GetArmorBaseFactorSum() : 0.f);
    }
    void castHold(RE::Actor* a) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool refreshed=false;
        if(auto* effects=a->AsMagicTarget()->GetActiveEffectList()) for(auto* effect:*effects) {
            if(effect && effect->spell==holdSpell && !effect->flags.any(RE::ActiveEffect::Flag::kDispelled) &&
               effect->GetCasterActor().get()==p) {
                effect->duration=effect->elapsedSeconds+2.f; refreshed=true;
            }
        }
        if(refreshed) return;
        if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(holdSpell,true,a,1.f,false,1.f,p);
    }
    void hurt(RE::Actor* a,float amount) {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || a->IsDead() || a->IsChild() || a->IsEssential() ||
           (cfg.protect && a->IsProtected()) || !std::isfinite(amount) || amount<=0) return;
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool hostile=a->IsHostileToActor(p);
        a->StartCombat(p);
        auto* values=a->AsActorValueOwner();
        float before=values->GetActorValue(RE::ActorValue::kHealth);
        values->DamageActorValue(RE::ActorValue::kHealth,amount);
        if(hostile) experience(a,std::clamp(amount*.03f,1.f,8.f),true);
        // HandleHealthDamage is a post-damage death/attacker notification, not subtraction.
        a->HandleHealthDamage(p,amount);
        SKSE::log::info("Impact/finish {:08X}: {:.1f} damage, health {:.1f} -> {:.1f}",
            a->GetFormID(),amount,before,values->GetActorValue(RE::ActorValue::kHealth));
    }
    bool weak(RE::Actor* a) const {
        if(!a || a->IsDead() || !allowed(a)) return false;
        auto* values=a->AsActorValueOwner();
        float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
            a->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
        return weakened(values->GetActorValue(RE::ActorValue::kHealth),maximum,cfg.executionHealth);
    }
    void beginFinisher(const RE::BSFixedString& input) {
        auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
        if(!weak(actor)) { RE::SendHUDMessage::ShowHUDMessage("Finisher requires a weakened target."); return; }
        if(execDown) return;
        finisherInput=input; execDown=true; charged=0; chargeStep=-1;
        chargeSound=feedback::sound(0x3f20c,pickCenter(actor),.5f);
        SKSE::log::info("Finisher charging on {:08X}",actor->GetFormID());
        RE::SendHUDMessage::ShowHUDMessage("Crushing target... keep the finisher control held.");
    }
    bool sameWorld(RE::TESObjectREFR* ref) const {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* playerCell=p ? p->GetParentCell() : nullptr;
        auto* cell=ref ? ref->GetParentCell() : nullptr;
        auto* world=playerCell ? playerCell->GetbhkWorld() : nullptr;
        return world && cell && cell->GetbhkWorld()==world;
    }
    bool pickable(RE::TESObjectREFR* ref) const {
        if(!ref || ref==RE::PlayerCharacter::GetSingleton() || !ref->Get3D() || ref->IsDisabled() || !sameWorld(ref)) return false;
        if(ref->As<RE::Actor>()) return true; // Immunities are checked before spending or changing actor state.
        auto* base=ref->GetBaseObject(); if(!base) return false;
        auto type=base->GetFormType();
        return type==RE::FormType::Weapon || type==RE::FormType::Misc || type==RE::FormType::Armor ||
            type==RE::FormType::Ingredient || type==RE::FormType::AlchemyItem;
    }
    struct Bounds { Vec low,high; };
    Bounds actorBounds(RE::Actor* actor) const {
        Vec low=vec(actor->GetBoundMin()),high=vec(actor->GetBoundMax());
        Vec center=(low+high)*.5f, position=vec(actor->GetPosition());
        // Native controller bounds are world coordinates; base-form fallback bounds are local.
        if(length(center-position)>length(high-low)+256.f) { low=low+position; high=high+position; }
        if(actor->IsDead() || actor->IsInRagdollState()) {
            auto body=sample(actor);
            if(body.count) { Vec offset=body.position-(low+high)*.5f; low=low+offset; high=high+offset; }
        }
        return {low,high};
    }
    struct Target { RE::ActorHandle ref; Bounds bounds; Vec movement{}; };
    std::vector<Target> previousTargets;
    Vec pickCenter(RE::TESObjectREFR* ref) const {
        if(auto* actor=ref->As<RE::Actor>()) { auto b=actorBounds(actor); return (b.low+b.high)*.5f; }
        auto body=sample(ref);
        return body.count ? body.position : vec(ref->Get3D()->worldBound.center);
    }
    void cacheCandidates() {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto* world=p->GetParentCell()->GetbhkWorld();
        if(cacheWorld==world && cacheAge<cfg.cacheInterval) return;
        objectCache.clear(); actorCache.clear(); cacheWorld=world; cacheAge=0; ++cacheScans;
        RE::TES::GetSingleton()->ForEachCell([&](RE::TESObjectCELL* cell) {
            if(cell && cell->GetbhkWorld()==world) cell->ForEachReference([&](RE::TESObjectREFR* ref) {
                if(ref && ref!=p && ref->Get3D() && !ref->IsDisabled()) {
                    if(auto* a=ref->As<RE::Actor>()) actorCache.emplace_back(a);
                    else if(pickable(ref)) objectCache.push_back(ref->GetHandle());
                }
                return RE::BSContainer::ForEachResult::kContinue;
            });
        });
    }
    RE::NiPointer<RE::TESObjectREFR> pick(Vec origin,Vec direction) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto visible=[&](RE::TESObjectREFR* ref,Vec center) {
            // Small floor-level props may have a hollow/offset mesh centre. Try visible upper points too.
            float lift=std::clamp(ref->Get3D()->worldBound.radius*.3f,4.f,24.f);
            for(Vec point:{center,center+Vec{0,0,lift},center+Vec{0,0,lift*.5f}}) {
                auto obstruction=ray(p->GetParentCell(),origin,point,nullptr);
                if(!obstruction.hit || obstruction.ref.get().get()==ref) return true;
            }
            return false;
        };
        if(auto* picker=RE::CrosshairPickData::GetSingleton()) {
            for(auto handle:{picker->grabPickRef,picker->GetActiveTarget()}) {
                auto ref=handle.get();
                if(pickable(ref.get())) {
                    Vec center=pickCenter(ref.get());
                    if(aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,cfg.range,cfg.aimAssist)>=0 && visible(ref.get(),center)) return ref;
                }
            }
        }
        auto hit=ray(p->GetParentCell(),origin,origin+direction*cfg.range,nullptr);
        auto direct=hit.ref.get();
        if(pickable(direct.get())) return direct;
        // A small aim cone catches distant clutter that a single pixel-width ray misses.
        // Keep only eight candidates, then verify visibility; walls remain blockers.
        struct Candidate { RE::ObjectRefHandle ref; Vec center; float score; };
        std::vector<Candidate> candidates;
        cacheCandidates();
        auto consider=[&](RE::TESObjectREFR* ref) {
            if(!pickable(ref)) return;
            auto* scene=ref->Get3D();
            if(length(vec(scene->worldBound.center)-origin)>cfg.range+scene->worldBound.radius+500.f) return;
            Vec center=pickCenter(ref);
            float score=aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,cfg.range,cfg.aimAssist);
            if(score<0) return;
            candidates.push_back({ref->GetHandle(),center,score});
            std::sort(candidates.begin(),candidates.end(),[](auto& a,auto& b){ return a.score<b.score; });
            if(candidates.size()>8) candidates.pop_back();
            return;
        };
        for(auto handle:objectCache) if(auto ref=handle.get()) consider(ref.get());
        for(auto handle:actorCache) if(auto ref=handle.get()) consider(ref.get());
        for(auto& candidate:candidates) {
            auto ref=candidate.ref.get();
            if(ref && visible(ref.get(),candidate.center)) return ref;
        }
        return {};
    }
    bool grip(RE::NiPointer<RE::TESObjectREFR> ref,bool quiet=false,bool paid=false) {
        if(!ref || !ref->Get3D() || ref->IsDisabled() || !sameWorld(ref.get())) return false;
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool tracked=std::any_of(flights.begin(),flights.end(),[&](auto& f){return f.ref==ref->GetHandle();});
        costFactor=1;
        if(auto* a=ref->As<RE::Actor>()) {
            auto* process=a->GetActorRuntimeData().currentProcess;
            bool dead=a->IsDead();
            if(!allowed(a) || (dead && !sample(a).count) || (!dead && (!process ||
               a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kParalysis)>0 ||
               (a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kGrabbed)>0 && !tracked)))) {
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Target resists telekinesis."); return false;
            }
            costFactor=resistance(a->GetScale(),dead ? p->GetLevel() : a->GetLevel(),p->GetLevel(),cfg.levelFactor);
            if(!spend(cfg.grabCost*costFactor)) return false;
            if(!dead) {
                // Existing live ragdolls need suspension, not another knockdown. Corpses need neither.
                if(!a->IsInRagdollState()) process->KnockExplosion(a,a->GetPosition(),0.f);
                castHold(a); a->StartCombat(p);
            }
        } else {
            auto* base=ref->GetBaseObject();
            if(!base) return false;
            // Loose carryable objects only. Never change static/animated/door physics.
            auto type=base->GetFormType();
            if(type!=RE::FormType::Weapon && type!=RE::FormType::Misc && type!=RE::FormType::Armor &&
               type!=RE::FormType::Ingredient && type!=RE::FormType::AlchemyItem) return false;
            if(!sample(ref.get()).count) {
                SKSE::log::warn("Target {:08X} has no movable rigid bodies",ref->GetFormID());
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Telekinesis: this object has no movable physics body."); return false;
            }
            if(!paid && !spend(cfg.grabCost)) return false;
        }
        std::erase_if(flights,[&](auto& f){return f.ref==ref->GetHandle();});
        held=ref->GetHandle(); holdWorld=p->GetParentCell()->GetbhkWorld(); holdAge=0; refresh=0; charged=0;
        distance=ref->As<RE::Actor>() ? cfg.distance : cfg.itemDistance;
        auto initial=sample(ref.get()); anchor=initial.count ? initial.position : pickCenter(ref.get());
        SKSE::log::info("Grip established on {:08X}",ref->GetFormID());
        return true;
    }

    Vec weaponPoint(RE::Actor* actor,RE::TESObjectWEAP* weapon,bool left) const {
        auto bounds=actorBounds(actor); Vec point=(bounds.low+bounds.high)*.5f;
        if(auto* hand=actor->Get3D()->GetObjectByName(RE::BSFixedString(left ? "NPC L Hand [LHnd]" : "NPC R Hand [RHnd]")))
            point=vec(hand->world.translate);
        // Choose the equipped mesh closest to that hand, including identical dual-wielded base forms.
        if(auto& biped=actor->GetBiped(); biped) {
            float closest=300.f; const Vec handPoint=point;
            for(auto& part:biped->objects) if(part.item==weapon && part.partClone) {
                auto center=vec(part.partClone->worldBound.center); float d=length(center-handPoint);
                if(finite(center) && d<closest) { closest=d; point=center; }
            }
        }
        return point;
    }
    Selection findWeapon(Vec origin,Vec direction) {
        struct Choice { RE::ActorHandle actor; RE::FormID weapon{}; bool left{}; Vec point{}; float score{}; };
        cacheCandidates();
        auto* p=RE::PlayerCharacter::GetSingleton();
        std::vector<Choice> choices;
        for(auto handle:actorCache) if(auto actor=handle.get(); actor && actor->Get3D() && sameWorld(actor.get()) && !actor->IsDisabled()) {
            if(actor->IsDead() || !allowed(actor.get()) || !actor->IsHostileToActor(p) ||
               !actor->AsActorState()->IsWeaponDrawn()) continue;
            auto bounds=actorBounds(actor.get());
            float bodyScore=aimScore(origin,direction,(bounds.low+bounds.high)*.5f,32,cfg.disarmRange,cfg.aimAssist);
            for(bool left:{false,true}) {
                auto* entry=actor->GetEquippedEntryData(left);
                auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
                if(!weapon || weapon->IsBound() || weapon->IsHandToHandMelee() || entry->IsQuestObject()) continue;
                Vec point=weaponPoint(actor.get(),weapon,left);
                float score=aimScore(origin,direction,point,32,cfg.disarmRange,cfg.aimAssist);
                // Direct weapon aim wins; aiming at its wielder is a fallback, with right-hand priority.
                if(score<0 && bodyScore>=0 && length(point-origin)<=cfg.disarmRange) score=2.f+bodyScore+(left ? .1f : 0.f);
                if(score>=0) choices.push_back({handle,weapon->GetFormID(),left,point,score});
            }
        }
        std::sort(choices.begin(),choices.end(),[](auto& a,auto& b){return a.score<b.score;});
        for(auto& choice:choices) {
            auto actor=choice.actor.get(); if(!actor) continue;
            auto obstruction=ray(p->GetParentCell(),origin,choice.point,nullptr);
            if(obstruction.hit && obstruction.ref.get().get()!=actor.get()) continue;
            auto* entry=actor->GetEquippedEntryData(choice.left);
            auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
            if(!weapon || weapon->GetFormID()!=choice.weapon || entry->IsQuestObject() || weapon->IsBound()) continue;
            RE::ExtraDataList* extra=nullptr;
            if(entry->extraLists) for(auto* list:*entry->extraLists) if(list &&
                (choice.left ? list->HasType<RE::ExtraWornLeft>() : list->HasType<RE::ExtraWorn>())) { extra=list; break; }
            // Never substitute a different enchanted/tempered copy if the worn instance is ambiguous.
            if(!extra) continue;
            return {Mode::disarm,actor->GetHandle(),choice.weapon,choice.left};
        }
        return {};
    }
    bool disarm(const Selection& selection,bool quiet) {
        auto actorRef=selection.ref.get(); auto* a=actorRef ? actorRef->As<RE::Actor>() : nullptr;
        if(!a || !a->Get3D() || !sameWorld(a) || !allowed(a) || a->IsDead() || a->IsDisabled()) return false;
        RE::NiPointer<RE::Actor> actor{a}; auto* p=RE::PlayerCharacter::GetSingleton();
        if(!a->IsHostileToActor(p) || !a->AsActorState()->IsWeaponDrawn()) return false;
        auto* entry=a->GetEquippedEntryData(selection.left);
        auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
        if(!weapon || weapon->GetFormID()!=selection.weapon || entry->IsQuestObject() || weapon->IsBound()) return false;
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()),point=weaponPoint(a,weapon,selection.left);
        if(length(point-origin)>cfg.disarmRange) return false;
        auto wall=ray(p->GetParentCell(),origin,point,nullptr); if(wall.hit && wall.ref.get().get()!=a) return false;
        RE::ExtraDataList* extra=nullptr;
        if(entry->extraLists) for(auto* list:*entry->extraLists) if(list &&
            (selection.left ? list->HasType<RE::ExtraWornLeft>() : list->HasType<RE::ExtraWorn>())) { extra=list; break; }
        if(!extra) return false;
        float paidCost=0;
        float cost=cfg.disarmCost*resistance(actor->GetScale(),actor->GetLevel(),p->GetLevel(),cfg.levelFactor);
        if(!spend(cost,&paidCost)) {
            if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Not enough Magicka to disarm this enemy.");
            return true;
        }
        auto location=ni(point+unit(origin-point)*20.f+Vec{0,0,8});
        // Drop exactly the worn instance; native DropObject handles unequipping and inventory removal.
        auto dropped=actor->DropObject(weapon,extra,1,&location,nullptr);
        if(!dropped) {
            p->AsActorValueOwner()->RestoreActorValue(RE::ActorValue::kMagicka,paidCost);
            if(!quiet) RE::SendHUDMessage::ShowHUDMessage("That weapon could not be disarmed.");
            return true;
        }
        experience(actor.get(),6.f); feedback::sound(0x53a5d,point);
        cacheAge=100; searchAge=100;
        pendingWeapon=dropped; pendingWeaponTime=1.5f;
        SKSE::log::info("Disarm {:08X}: worn weapon {:08X} -> loose ref; waiting for physics",actor->GetFormID(),selection.weapon);
        return true;
    }
    RE::NiPointer<RE::TESObjectREFR> nearestObject() {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto b=actorBounds(p); Vec origin=(b.low+b.high)*.5f;
        cacheCandidates();
        RE::NiPointer<RE::TESObjectREFR> closest; float bestDistance=cfg.nearbyRadius;
        for(auto handle:objectCache) if(auto ref=handle.get(); ref && pickable(ref.get())) {
            if(length(vec(ref->Get3D()->worldBound.center)-origin)>cfg.nearbyRadius+ref->Get3D()->worldBound.radius+100.f) continue;
            auto body=sample(ref.get()); if(!body.count) continue;
            float score=nearbyScore(origin,body.position,cfg.nearbyRadius);
            if(score<0 || score>bestDistance) continue;
            auto obstruction=ray(p->GetParentCell(),origin,body.position,ref.get());
            if(!obstruction.hit) { closest=ref; bestDistance=score; }
        }
        return closest;
    }
    RE::ObjectRefHandle findMissile(RE::ObjectRefHandle only={}) {
        if(!cfg.catchProjectiles) return {};
        auto* manager=RE::Projectile::Manager::GetSingleton();
        auto* player=RE::PlayerCharacter::GetSingleton();
        if(!manager) return {};
        std::vector<RE::ProjectileHandle> candidates;
        {
            RE::BSSpinLockGuard lock(manager->projectileLock);
            for(auto& list:{&manager->limited,&manager->unlimited})
                for(auto handle:*list) candidates.push_back(handle);
        }
        auto bounds=actorBounds(player); Vec center=(bounds.low+bounds.high)*.5f;
        RE::NiPointer<RE::Projectile> closest; float best=INFINITY;
        for(auto handle:candidates) if(auto projectile=handle.get()) {
            if(only && projectile->GetHandle()!=only) continue;
            auto* missile=projectile->As<RE::MissileProjectile>();
            if(!missile || !missile->Get3D() || missile->IsDisabled() || !sameWorld(missile)) continue;
            auto& data=missile->GetProjectileRuntimeData();
            auto* base=missile->GetProjectileBase();
            auto* spell=data.spell ? data.spell->As<RE::SpellItem>() : nullptr;
            auto shooter=data.shooter.get(); auto* caster=shooter ? shooter->As<RE::Actor>() : nullptr;
            using Flags=RE::Projectile::Flags;
            using BaseFlags=RE::BGSProjectileData::BGSProjectileFlags;
            if(!base || !base->IsMissile() || !spell || !caster || caster==player || !caster->IsHostileToActor(player) ||
               !spell->IsHostile() || spell->GetCastingType()!=RE::MagicSystem::CastingType::kFireAndForget ||
               spell->GetDelivery()!=RE::MagicSystem::Delivery::kAimed || !spell->GetAVEffect() ||
               spell->GetAVEffect()!=data.avEffect || data.avEffect->data.projectileBase!=base ||
               data.weaponSource || data.ammoSource || data.flags.any(Flags::kDestroyed,Flags::kFading,Flags::kProcessedImpacts,Flags::kHitScan) ||
               base->data.flags.any(BaseFlags::kHitScan,BaseFlags::kExplosionAltTrigger,BaseFlags::kContinuousUpdate) ||
               missile->GetMissileRuntimeData().waitingToInitialize3D ||
               missile->GetMissileRuntimeData().impactResult!=RE::ImpactResult::kNone ||
               !std::isfinite(data.power) || data.power<=0 || !std::isfinite(data.scale) || data.scale<=0) continue;
            Vec position=vec(missile->GetPosition()), speed=vec(data.linearVelocity);
            float score=predictedMissileScore(center,position,speed,cfg.projectileRadius,cfg.predictionSeconds,cfg.threatRadius,lastPoll);
            if(score<0 || score>=best) continue;
            Vec eye=vec(RE::PlayerCamera::GetActiveCameraPosition());
            auto obstruction=ray(player->GetParentCell(),eye,position,missile);
            if(obstruction.hit) continue;
            best=score; closest=projectile;
        }
        return closest ? closest->GetHandle() : RE::ObjectRefHandle{};
    }
    bool catchMissile(RE::ObjectRefHandle selected,bool quiet) {
        if(findMissile(selected)!=selected || !selected) return false;
        auto ref=selected.get(); auto* missile=ref ? ref->As<RE::MissileProjectile>() : nullptr;
        if(!missile) return false;
        auto* player=RE::PlayerCharacter::GetSingleton(); auto& data=missile->GetProjectileRuntimeData();
        if(!spend(cfg.projectileCost)) {
            if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Not enough Magicka to catch this projectile.");
            return true;
        }
        if(auto shooter=data.shooter.get()) experience(shooter->As<RE::Actor>(),5.f);
        feedback::sound(0x53a5d,vec(missile->GetPosition()));
        projectileCaster=data.shooter; projectileSpell=data.spell->GetFormID();
        projectilePower=data.power; projectileScale=data.scale; projectileSpeed=length(vec(data.linearVelocity));
        held=missile->GetHandle(); holdWorld=player->GetParentCell()->GetbhkWorld();
        holdAge=0; refresh=0; charged=0; costFactor=1; distance=cfg.itemDistance; anchor=vec(missile->GetPosition());
        // Suppression starts before moving the reference. The hook touches no controller pointers.
        missile_hold::suspend(missile); data.linearVelocity={}; data.velocity={}; data.desiredTarget={};
        SKSE::log::info("Caught missile {:08X}, source spell {:08X}; release to return",missile->GetFormID(),projectileSpell);
        RE::SendHUDMessage::ShowHUDMessage("Projectile held. Release to return; Activate to dissipate.");
        return true;
    }
    void holdMissile(RE::MissileProjectile* missile,float dt) {
        auto* player=RE::PlayerCharacter::GetSingleton();
        if(!missile_hold::matches(missile) || missile->IsDisabled() || !missile->Get3D() || !sameWorld(missile) ||
           missile->GetProjectileRuntimeData().flags.any(RE::Projectile::Flags::kDestroyed) ||
           holdAge>=cfg.projectileHoldSeconds || !spend(cfg.holdCost*dt)) { drop(); return; }
        distance=std::clamp(distance+((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt,cfg.minDistance,cfg.maxDistance);
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
        auto* camera=RE::PlayerCamera::GetSingleton();
        float reach=itemRayDistance(origin,direction,vec(player->GetPosition()),distance,camera && camera->IsInThirdPerson());
        auto wall=ray(player->GetParentCell(),origin,origin+direction*reach,missile);
        Vec goal=origin+direction*(wall.hit ? std::max(0.f,reach*wall.fraction-50.f) : reach);
        auto next=advanceAnchor(anchor,goal,cfg.pickupSpeed,dt);
        auto obstacle=ray(player->GetParentCell(),anchor,next,missile);
        if(obstacle.hit) next=anchor+(next-anchor)*std::max(0.f,obstacle.fraction-.05f);
        anchor=next;
        missile->SetPosition(ni(anchor));
        // Native missile movement writes the root's local translation from reference position.
        // Update3D then publishes world transforms. No Havok prop controller is used here.
        missile->Get3D()->local.translate=ni(anchor); missile->Update3D();
    }
    void returnMissile(RE::MissileProjectile* missile) {
        auto* player=RE::PlayerCharacter::GetSingleton();
        auto* spell=RE::TESForm::LookupByID<RE::SpellItem>(projectileSpell);
        if(!spell || !spell->GetAVEffect() || spell->GetAVEffect()->data.projectileBase!=missile->GetProjectileBase() ||
           !spend(cfg.launchCost)) { drop(); return; }
        Vec origin=vec(missile->GetPosition()), direction=aim();
        if(cfg.returnMode==0) if(auto ref=projectileCaster.get()) if(auto* caster=ref->As<RE::Actor>(); caster && !caster->IsDead() &&
            !caster->IsDisabled() && caster->Get3D() && sameWorld(caster)) {
            auto bounds=actorBounds(caster); Vec target=(bounds.low+bounds.high)*.5f;
            auto obstruction=ray(player->GetParentCell(),origin,target,missile);
            if(!obstruction.hit || obstruction.ref.get().get()==caster) direction=unit(target-origin);
        }
        if(!finite(direction) || length(direction)<.5f) { drop(); return; }
        auto angles=missileAngles(direction);
        RE::Projectile::LaunchData launch(player,ni(origin),{angles.x,angles.z},spell);
        launch.power=projectilePower; launch.scale=projectileScale;
        RE::ProjectileHandle result; RE::Projectile::Launch(&result,launch);
        if(auto returned=result.get()) {
            auto& data=returned->GetProjectileRuntimeData();
            auto* base=returned->GetProjectileBase(); float baseSpeed=base ? base->data.speed : 0.f;
            // Native launch gives the return missile the player's collision group and damage attribution.
            if(baseSpeed>0 && std::isfinite(projectileSpeed)) data.speedMult=projectileSpeed/baseSpeed;
            data.linearVelocity=ni(direction*projectileSpeed); data.desiredTarget={};
            SKSE::log::info("Returned source spell {:08X} as missile {:08X}",projectileSpell,returned->GetFormID());
        } else RE::SendHUDMessage::ShowHUDMessage("Projectile return failed; dissipating safely.");
        // Kill has native cleanup without impact/explosion. Never resume the hostile collision group.
        drop();
    }
    Selection selectTarget(bool shift) {
        if(searchAge>=cfg.searchInterval || shift!=selectionShift) {
            searchAge=0; selectionShift=shift;
            Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition());
            slowSelection=shift ? findWeapon(origin,aim()) : Selection{};
            if(slowSelection.mode==Mode::none) {
                auto ref=shift ? nearestObject() : pick(origin,aim());
                slowSelection=ref ? Selection{Mode::grab,ref->GetHandle()} : Selection{};
            }
        }
        if(shift && slowSelection.mode!=Mode::disarm) if(auto missile=findMissile()) return {Mode::catchSpell,missile};
        return slowSelection;
    }
    float selectionCost(const Selection& selection) const {
        auto ref=selection.ref.get(); float amount=cfg.grabCost;
        if(selection.mode==Mode::catchSpell) amount=cfg.projectileCost;
        if(selection.mode==Mode::disarm) amount=cfg.disarmCost;
        if(auto* a=ref ? ref->As<RE::Actor>() : nullptr; a && !a->IsDead())
            amount*=resistance(a->GetScale(),a->GetLevel(),RE::PlayerCharacter::GetSingleton()->GetLevel(),cfg.levelFactor);
        return actualCost(amount);
    }
    void targetPreview() {
        if(!cfg.preview || !usable() || pendingWeapon) return;
        auto selected=held ? Selection{Mode::grab,held} : selectTarget(shiftLeft || shiftRight);
        auto ref=selected.ref.get(); std::string text;
        bool rejected=false; RE::NiAVObject* node=nullptr;
        if(ref && ref->Get3D() && !ref->IsDisabled() && sameWorld(ref.get())) {
            auto* actor=ref->As<RE::Actor>();
            auto* weapon=selected.weapon ? RE::TESForm::LookupByID<RE::TESObjectWEAP>(selected.weapon) : nullptr;
            const char* name=weapon ? weapon->GetName() : ref->GetName();
            if(selected.mode==Mode::disarm && actor && weapon) {
                // Attach only to the selected worn mesh, rather than lighting the whole wielder.
                if(auto& biped=actor->GetBiped(); biped) {
                    float best=INFINITY; Vec point=weaponPoint(actor,weapon,selected.left);
                    for(auto& part:biped->objects) if(part.item==weapon && part.partClone) {
                        float d=length(vec(part.partClone->worldBound.center)-point);
                        if(d<best) { best=d; node=part.partClone.get(); }
                    }
                }
                text="Disarm: ";
            } else if(selected.mode==Mode::catchSpell) text="Catch: ";
            else if(held && weak(actor)) text=execDown ? "Crush charging: " : "Execute ready (hold Activate): ";
            else text=held ? "Holding: " : "Grab: ";
            text+=name && *name ? name : "target";
            if(actor && !allowed(actor)) { text+=" - immune/too large"; rejected=true; }
            else if(!held && selectionCost(selected)>RE::PlayerCharacter::GetSingleton()->AsActorValueOwner()->GetActorValue(RE::ActorValue::kMagicka)) {
                text+=" - insufficient Magicka"; rejected=true;
            } else if(actor && !actor->IsDead() && selected.mode==Mode::grab && !held &&
                (actor->AsActorValueOwner()->GetActorValue(RE::ActorValue::kParalysis)>0 || actor->AsActorValueOwner()->GetActorValue(RE::ActorValue::kGrabbed)>0)) {
                text+=" - controlled by another effect"; rejected=true;
            } else if(!actor && selected.mode==Mode::grab && !sample(ref.get()).count) { text+=" - no movable physics"; rejected=true; }
            // Do not stack continuously while held or shade the entire actor for an unavailable weapon mesh.
            if(!held && (selected.mode!=Mode::disarm || node))
                feedback::shader(ref.get(),rejected ? 0xdc209 : 0x146,.18f,node);
        } else text=(shiftLeft || shiftRight) ? "Shift: aim at a weapon / catch incoming spell / nearby item" : "Telekinesis: aim at an actor or loose item";
        if(text!=lastPreview && noticeAge>=.75f && !execDown) {
            RE::SendHUDMessage::ShowHUDMessage(text.c_str()); lastPreview=text; noticeAge=0;
        }
    }
    void grab(bool quiet=false,bool shift=false) {
        if(held || pendingWeapon) { drop(); return; }
        auto selected=selectTarget(shift);
        if(selected.mode==Mode::disarm) { disarm(selected,quiet); return; }
        if(selected.mode==Mode::catchSpell) { catchMissile(selected.ref,quiet); return; }
        auto ref=selected.ref.get();
        if(!ref || !pickable(ref.get())) {
            if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Telekinesis: no eligible target in view.");
            return;
        }
        auto* player=RE::PlayerCharacter::GetSingleton(); auto playerBounds=actorBounds(player);
        Vec origin=shift ? (playerBounds.low+playerBounds.high)*.5f : vec(RE::PlayerCamera::GetActiveCameraPosition());
        Vec point=pickCenter(ref.get());
        if(length(point-origin)>(shift ? cfg.nearbyRadius : cfg.range)) return;
        bool visible=false;
        float lift=std::clamp(ref->Get3D()->worldBound.radius*.3f,4.f,24.f);
        for(Vec test:{point,point+Vec{0,0,lift},point+Vec{0,0,lift*.5f}}) {
            auto wall=ray(RE::PlayerCharacter::GetSingleton()->GetParentCell(),origin,test,nullptr);
            if(!wall.hit || wall.ref.get().get()==ref.get()) { visible=true; break; }
        }
        if(!visible) return;
        if(grip(ref,quiet)) feedback::sound(0x53a5d,point,.6f);
    }
    void launch(bool slam) {
        auto ref=held.get(); if(!ref) return;
        if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) { returnMissile(missile); return; }
        if(!sample(ref.get()).count) return;
        if(auto* a=ref->As<RE::Actor>(); a && !a->IsDead() && !a->IsInRagdollState()) return;
        if(static_cast<int>(flights.size())>=cfg.maxFlights) { RE::SendHUDMessage::ShowHUDMessage("Too many objects in flight."); return; }
        if(!spend(cfg.launchCost*costFactor)) return;
        bool actor=ref->As<RE::Actor>()!=nullptr;
        float launchSpeed=actor ? cfg.actorLaunchSpeed : cfg.launchSpeed;
        float slamSpeed=actor ? cfg.actorSlamSpeed : cfg.slamSpeed;
        Vec speed=slam ? Vec{0,0,-slamSpeed} : aim()*launchSpeed;
        Vec launchDirection=unit(speed);
        if(!velocity(ref.get(),speed,actor ? nullptr : &launchDirection)) { drop(); return; }
        auto s=sample(ref.get());
        float mass=actor ? 0.f : std::clamp(ref->GetWeight(),cfg.objectMassFloor,cfg.massCap);
        flights.push_back({held,s.position,speed,s.halfExtent,mass,actor ? cfg.actorFlightSeconds : cfg.flightSeconds,0,0,s.position.z,slam,false});
        if(auto* weapon=ref->GetBaseObject()->As<RE::TESObjectWEAP>()) {
            flights.back().baseDamage=static_cast<float>(weapon->GetAttackDamage());
            flights.back().style=weapon->IsOneHandedDagger() ? WeaponStyle::dagger :
                (weapon->IsOneHandedMace() || weapon->HasKeywordString("WeapTypeWarhammer")) ? WeaponStyle::blunt :
                weapon->IsRanged() ? WeaponStyle::ranged : WeaponStyle::blade;
        }
        chargeSound.Stop(); chargeStep=-1; searchAge=100;
        feedback::sound(0x53a5e,s.position,.8f);
        if(!actor) SKSE::log::info("Prop launch {:08X}: speed {:.1f}, half extents {:.1f}/{:.1f}/{:.1f}",
            ref->GetFormID(),length(speed),s.halfExtent.x,s.halfExtent.y,s.halfExtent.z);
        // Keep the brief grabbed-state effect for the flight; it expires on its own.
        held={}; holdWorld=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        gripInput=RE::BSFixedString(); slamDown=false;
    }
    void execute(RE::Actor* a) {
        if(!weak(a)) { charged=0; execDown=false; return; }
        if(!spend(cfg.executionCost*costFactor)) {
            RE::SendHUDMessage::ShowHUDMessage("Not enough Magicka for the finisher.");
            charged=0; execDown=false; return;
        }
        hurt(a,a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)+1000.f);
        if(a->IsDead() || a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)<=0) {
            // Wait for engine death state instead of beheading a living actor during notification.
            if(executions.size()<8) executions.push_back({RE::ActorHandle{a}});
            RE::SendHUDMessage::ShowHUDMessage("Telekinetic crush!");
        } else { RE::SendHUDMessage::ShowHUDMessage("Target resisted the finisher."); }
        drop(false);
    }
    void tick() {
        auto now=Clock::now(); float dt=std::chrono::duration<float>(now-last).count(); last=now;
        if(!ready) return;
        struct Timer {
            Combat& owner; Clock::time_point start=Clock::now();
            ~Timer() { if(cfg.profile) { double ms=std::chrono::duration<double,std::milli>(Clock::now()-start).count();
                owner.profileTotal+=ms; owner.profilePeak=std::max(owner.profilePeak,ms); ++owner.profileTicks; } }
        } timer{*this};
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* ui=RE::UI::GetSingleton();
        if(!p || !p->Get3D() || !p->GetParentCell() || !ui ||
           ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) || ui->IsMenuOpen(RE::MainMenu::MENU_NAME)) { reset(); return; }
        if(ui->GameIsPaused()) return; // Preserve the grip and freeze costs/flight timers while paused.
        dt=std::clamp(dt,0.f,.05f); lastPoll=std::max(.016f,dt);
        combatTime+=dt; searchAge+=dt; cacheAge+=dt; previewAge+=dt; noticeAge+=dt;
        xpBudget=std::min(cfg.xpPerMinute,xpBudget+cfg.xpPerMinute*dt/60.f);
        std::erase_if(xpCooldown,[&](auto& value){return combatTime-value.second>60;});
        settings::tick(dt);
        if(settingsRevision!=settings::revision) {
            settingsRevision=settings::revision; cacheAge=searchAge=100; slowSelection={}; lastPreview.clear();
            shiftLeft=shiftRight=false; xpBudget=std::min(xpBudget,cfg.xpPerMinute);
        }
        if(usable() && !held && !pendingWeapon) cacheCandidates();
        if(cfg.preview && previewAge>=.16f) { previewAge=0; targetPreview(); }
        profileAge+=dt;
        if(cfg.profile && profileAge>=5.f && profileTicks) {
            SKSE::log::info("Controller profile: mean {:.3f} ms, peak {:.3f} ms, {} ticks, {} cache scans, {} actors/{} props",
                profileTotal/profileTicks,profilePeak,profileTicks,cacheScans,actorCache.size(),objectCache.size());
            profileAge=0; profileTotal=profilePeak=0; profileTicks=cacheScans=0;
        }
        for(auto it=executions.begin();it!=executions.end();) {
            auto actor=it->ref.get(); it->remaining-=dt;
            if(!actor || !actor->Get3D() || actor->IsDisabled() || !sameWorld(actor.get()) || it->remaining<=0) {
                it=executions.erase(it); continue;
            }
            if(actor->IsDead() && !actor->IsInKillMove()) {
                SKSE::ModCallbackEvent event{RE::BSFixedString("TKC_Execution"),RE::BSFixedString("crush"),0.f,actor.get()};
                SKSE::GetModCallbackEventSource()->SendEvent(&event);
                auto* race=actor->GetRace();
                bool success=cfg.decapitate && actor->HasKeywordString("ActorTypeNPC") && race &&
                    (race->decapitateArmors[0] || race->decapitateArmors[1]) && actor->Decapitate();
                if(cfg.feedback) {
                    if(executionSpell) if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
                        caster->CastSpellImmediate(executionSpell,false,actor.get(),1.f,false,0.f,p);
                    feedback::sound(0xe4f24,pickCenter(actor.get()));
                    feedback::shader(actor.get(),0x57c67,.3f);
                }
                SKSE::log::info("Execution death confirmed {:08X}; decapitation {}",actor->GetFormID(),success);
                it=executions.erase(it); continue;
            }
            ++it;
        }
        if(castingHeld && !usable()) drop();
        if(pendingWeapon) {
            pendingWeaponTime-=dt; auto ref=pendingWeapon.get();
            if(!usable() || !ref || ref->IsDisabled() || !sameWorld(ref.get())) drop();
            else if(ref->Get3D() && sample(ref.get()).count) {
                pendingWeapon={}; pendingWeaponTime=0;
                if(!grip(ref,true,true)) drop();
            } else if(pendingWeaponTime<=0) {
                RE::SendHUDMessage::ShowHUDMessage("Disarmed weapon dropped; its physics could not be loaded."); drop();
            }
        }
        if(!held && !pendingWeapon && castingHeld) {
            retry+=dt;
            if(retry>=(castingShift ? .016f : .08f)) { retry=0; grab(true,castingShift); if(held || pendingWeapon) gripInput=castingInput; }
        }
        if(held && (!usable() || p->GetParentCell()->GetbhkWorld()!=holdWorld)) drop();
        if(auto ref=held.get()) {
            holdAge+=dt; refresh+=dt;
            auto* actor=ref->As<RE::Actor>();
            if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) holdMissile(missile,dt);
            else if(ref->IsDisabled() || !ref->Get3D() || !sameWorld(ref.get()) || (actor && !allowed(actor)) || !spend(cfg.holdCost*costFactor*dt)) { drop(); }
            else {
                if(actor && !actor->IsDead() && refresh>=1.f) { castHold(actor); refresh=0; }
                auto s=sample(ref.get());
                if(!finite(s.position) || !finite(s.velocity)) { drop(); }
                else if(!s.count || (actor && !actor->IsDead() && !actor->IsInRagdollState())) {
                    if(holdAge>1.5f) { RE::SendHUDMessage::ShowHUDMessage("Cannot establish a ragdoll grip."); drop(); }
                } else {
                    distance=std::clamp(distance+((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt,cfg.minDistance,cfg.maxDistance);
                    Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
                    auto* camera=RE::PlayerCamera::GetSingleton();
                    float rayDistance=actor ? distance : itemRayDistance(origin,direction,vec(p->GetPosition()),
                        distance,camera && camera->IsInThirdPerson());
                    auto wall=ray(p->GetParentCell(),origin,origin+direction*rayDistance,ref.get());
                    float safeDistance=wall.hit ? std::max(80.f,rayDistance*wall.fraction-60.f) : rayDistance;
                    if(length(s.position-origin)>cfg.range*2.f+cfg.maxDistance) { drop(); }
                    else {
                        Vec previous=anchor;
                        float speedLimit=!actor && length(s.position-origin)>rayDistance+200.f ? cfg.pickupSpeed : cfg.holdSpeed;
                        auto next=advanceAnchor(anchor,origin+direction*safeDistance,speedLimit,dt);
                        // Sweep the body's path too: turning toward a wall clamps the grip instead of dropping it.
                        auto blocked=ray(ref->GetParentCell(),s.position,next,ref.get());
                        if(blocked.hit) {
                            Vec delta=next-s.position; float travel=length(delta);
                            next=s.position+unit(delta)*std::max(0.f,travel*blocked.fraction-30.f);
                        }
                        anchor=next;
                        // Do not rotate a held mesh every tick: its COM offset would move underneath this controller.
                        velocity(ref.get(),holdVelocity(previous,anchor,s.position,dt,cfg.gain,speedLimit),nullptr,!actor);
                        if(execDown && weak(actor)) {
                            charged+=dt;
                            int step=static_cast<int>(std::clamp(charged/cfg.charge,0.f,1.f)*4.f);
                            if(step!=chargeStep) {
                                chargeStep=step;
                                if(cfg.feedback) { feedback::shader(actor,0x57c67,.25f); chargeSound.SetFrequency(.8f+.4f*step/4.f); }
                                std::string text="Crush "+std::to_string(step*25)+"%";
                                RE::SendHUDMessage::ShowHUDMessage(text.c_str());
                            }
                            if(charged>=cfg.charge) execute(actor);
                        } else { charged=0; chargeSound.Stop(); chargeStep=-1; }
                    }
                }
            }
        } else { held={}; missile_hold::clear(); projectileCaster={}; projectileSpell=0; }
        // Refresh cached handles slowly, but update physical bounds and motion every flight tick.
        std::vector<Target> targets;
        if(!flights.empty()) {
            cacheCandidates();
            for(auto handle:actorCache) if(auto actor=handle.get(); actor && actor->Get3D() && !actor->IsDead() &&
                !actor->IsDisabled() && sameWorld(actor.get())) targets.push_back({handle,{}});
        }
        // Query physics after releasing cell reference locks.
        for(auto& target:targets) {
            auto actor=target.ref.get(); if(!actor) continue;
            target.bounds=actorBounds(actor.get());
            auto old=std::find_if(previousTargets.begin(),previousTargets.end(),[&](auto& t){return t.ref==target.ref;});
            if(old!=previousTargets.end()) {
                target.movement=(target.bounds.low+target.bounds.high-old->bounds.low-old->bounds.high)*.5f;
                if(length(target.movement)>512.f) target.movement={}; // Teleporting actors have no swept combat path.
            }
        }
        for(auto it=flights.begin();it!=flights.end();) {
            auto ref=it->ref.get(); it->remaining-=dt; it->elapsed+=dt; it->refresh+=dt;
            auto s=ref ? sample(ref.get()) : Sample{};
            if(!ref || !s.count || ref->IsDisabled() || !sameWorld(ref.get()) || it->remaining<=0 ||
                !finite(s.position) || !finite(s.velocity) || length(s.position-it->previous)>cfg.range) {
                if(ref && !ref->As<RE::Actor>()) SKSE::log::info("Prop flight ended {:08X}: {}",ref->GetFormID(),
                    it->remaining<=0 ? "expired without confirmed contact" : "physics/scene unavailable");
                it=flights.erase(it); continue;
            }
            auto* thrown=ref->As<RE::Actor>();
            if(thrown && !thrown->IsDead() && !it->impactApplied && allowed(thrown) && it->refresh>=1.f) { castHold(thrown); it->refresh=0; }
            it->peakZ=std::max(it->peakZ,s.position.z);
            float speed=length(it->velocity);
            // A ray covers static geometry; swept actor bounds cover high-speed tunnelling.
            auto wall=ray(ref->GetParentCell(),it->previous,s.position,ref.get());
            auto wallRef=wall.ref.get();
            RE::Actor* victim=wallRef ? wallRef->As<RE::Actor>() : nullptr;
            float closest=wall.hit ? wall.fraction : 1.f;
            Vec step=s.position-it->previous;
            for(auto& target:targets) {
                auto a=target.ref.get(); if(!a || a.get()==ref.get()) continue;
                auto bounds=target.bounds;
                Vec extent=thrown ? Vec{} : Vec{std::max(it->halfExtent.x,s.halfExtent.x),
                    std::max(it->halfExtent.y,s.halfExtent.y),std::max(it->halfExtent.z,s.halfExtent.z)};
                // ponytail: swept AABBs approximate blade/limb contact; exact mesh contacts need Havok callbacks.
                float t=movingBoxHit(it->previous,s.position,bounds.low,bounds.high,extent,cfg.radius,target.movement);
                if(t>=0 && t<=closest) {
                    // Test to the body itself, not only its padded entry, so long blades cannot reach through walls.
                    auto obstruction=ray(ref->GetParentCell(),it->previous,(bounds.low+bounds.high)*.5f,ref.get());
                    auto obstructionRef=obstruction.ref.get();
                    if(!obstruction.hit || obstructionRef.get()==a.get()) { victim=a.get(); closest=t; }
                }
            }
            // Ignore the initial settling tick. Directional velocity loss catches wall/floor impacts.
            float loss=dot(it->velocity-s.velocity,unit(it->velocity));
            bool collision=confirmedImpact(victim!=nullptr,wall.hit,thrown!=nullptr,
                it->elapsed>.06f && loss>std::max(cfg.minimum,speed*.4f));
            if(!thrown) speed=std::min(4500.f,std::max({speed,length(s.velocity),length(step)/std::max(dt,.001f)}));
            bool fall=thrown && !it->slam && lethalFall(it->peakZ,s.position.z,it->velocity.z,cfg.cliffDrop,cfg.minimum);
            if(collision && speed>=cfg.minimum && (!it->impactApplied || fall)) {
                if(!thrown) {
                    Vec contact=it->previous+step*closest;
                    stopProp(ref.get(),contact-unit(it->velocity)*2.f);
                    if(victim) {
                        float raw=combatObjectDamage(speed,it->mass,it->baseDamage,it->style,cfg.multiplier,
                            cfg.weaponBaseScale,cfg.damageScale,cfg.minimum,cfg.damageCap,
                            it->style==WeaponStyle::clutter ? cfg.objectHitMinimum : cfg.weaponHitMinimum);
                        float amount=physicalDamage(victim,raw,it->style);
                        SKSE::log::info("Prop hit {:08X} -> {:08X}: speed {:.1f}, weight {:.1f}, damage {:.1f}",
                            ref->GetFormID(),victim->GetFormID(),speed,it->mass,amount);
                        hurt(victim,amount);
                        if(!victim->IsDead() && !victim->IsInRagdollState() && !victim->IsInKillMove() &&
                           !victim->IsChild() && !victim->IsEssential() && !(cfg.protect && victim->IsProtected())) {
                            victim->SetGraphVariableFloat(RE::BSFixedString("staggerMagnitude"),
                                std::clamp(amount/250.f+(it->style==WeaponStyle::blunt ? .2f : 0.f),.2f,.9f));
                            victim->NotifyAnimationGraph(RE::BSFixedString("staggerStart"));
                        }
                    }
                    else SKSE::log::info("Prop contact {:08X}: geometry/non-actor obstruction",ref->GetFormID());
                    feedback::impact(ref->GetParentCell(),ref->GetBaseObject()->As<RE::TESObjectWEAP>(),
                        victim ? RE::MATERIAL_ID::kSkin : wall.material,contact,unit(it->velocity));
                    it=flights.erase(it); continue;
                }
                feedback::impact(ref->GetParentCell(),nullptr,victim ? RE::MATERIAL_ID::kSkin : wall.material,s.position,unit(it->velocity));
                auto actorDamage=[&](RE::Actor* target,bool slammed,bool falling) {
                    auto* values=target->AsActorValueOwner();
                    float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
                        target->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
                    return actorImpactDamage(values->GetActorValue(RE::ActorValue::kHealth),maximum,p->GetLevel(),target->GetLevel(),
                        speed,slammed ? cfg.actorSlamSpeed : cfg.actorLaunchSpeed,
                        slammed ? cfg.slamFraction : cfg.throwFraction,cfg.actorDamageCap,cfg.lethalLevelAdvantage,falling,slammed);
                };
                if(!it->impactApplied && victim) hurt(victim,actorDamage(victim,false,false));
                if(!thrown->IsDead()) {
                    hurt(thrown,actorDamage(thrown,it->slam,fall));
                    if(it->slam && !thrown->IsDead() && allowed(thrown)) {
                        if(auto* queue=RE::TaskQueueInterface::GetSingleton()) {
                            RE::ActorHandle target{thrown},caster{p}; queue->QueueActorDisarm(target,caster);
                            SKSE::log::info("Nonlethal slam: disarm queued for {:08X}",thrown->GetFormID());
                        }
                    }
                }
                it->impactApplied=true;
                // One ordinary hit; continue tracking a surviving throw for a later cliff landing.
                if(it->slam || thrown->IsDead()) { it=flights.erase(it); continue; }
            }
            it->previous=s.position; it->velocity=s.velocity; ++it;
        }
        previousTargets=std::move(targets);
    }
    struct Button {
        std::uint32_t key; RE::INPUT_DEVICE device; RE::BSFixedString action;
        bool down,up,pressed;
    };
    void input(const std::vector<Button>& buttons) {
        for(const auto& button:buttons) {
            if(settings::capture(button.key,button.device,button.down)) return;
            if(cfg.settingsEnabled && button.device==RE::INPUT_DEVICE::kKeyboard && button.key==cfg.settingsKey && button.down) {
                auto* p=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
                if(ready && active && p && p->Get3D() && !p->IsDead() && ui && !ui->GameIsPaused()) {
                    drop(); settings::open(); searchAge=cacheAge=100;
                }
                return;
            }
        }
        // Snapshot both modifier keys before casting actions, including presses in the same input batch.
        for(const auto& button:buttons) if(button.device==RE::INPUT_DEVICE::kKeyboard && (button.key==cfg.modifierKey || (cfg.modifierKey2 && button.key==cfg.modifierKey2))) {
            auto& key=button.key==cfg.modifierKey ? shiftLeft : shiftRight;
            if(button.down) key=true;
            if(button.up) key=false;
        }
        if(!shiftLeft && !shiftRight) ignoreInitialShift=false;
        slamDown=shiftSlam(static_cast<bool>(held),shiftLeft,shiftRight,ignoreInitialShift);
        for(const auto& button:buttons) {
            auto key=button.key; auto device=button.device; auto userEvent=button.action;
            auto* user=RE::UserEvents::GetSingleton();
            if(!user) continue;
            // Use Skyrim's mapped casting actions, including remapped mouse/gamepad buttons.
            bool castInput=userEvent==user->leftAttack || userEvent==user->rightAttack;
            if(castInput) {
                auto* player=RE::PlayerCharacter::GetSingleton();
                bool controlHand=player && player->GetEquippedObject(userEvent==user->leftAttack)==controlSpell;
                auto action=castAction(button.down,button.up,static_cast<bool>(held) || static_cast<bool>(pendingWeapon),userEvent==gripInput,controlHand);
                if(button.up) {
                    if(userEvent==castingInput) { castingHeld=false; castingInput=RE::BSFixedString(); }
                    if(action==CastAction::release) {
                        if(usable()) launch(slamDown);
                        // Failed launch (Magicka, ragdoll or flight limit) must release the grip.
                        if(held || pendingWeapon) drop();
                    } else if(userEvent==finisherInput) { execDown=false; charged=0; chargeSound.Stop(); chargeStep=-1; finisherInput=RE::BSFixedString(); }
                    continue;
                }
                if(!usable()) continue;
                if(action==CastAction::grab) {
                    castingHeld=true; castingInput=userEvent; retry=0;
                    castingShift=shiftLeft || shiftRight; ignoreInitialShift=castingShift; slamDown=false;
                    grab(false,castingShift); if(held || pendingWeapon) gripInput=userEvent;
                } else if(action==CastAction::charge) {
                    beginFinisher(userEvent);
                }
                continue;
            }
            if(device==RE::INPUT_DEVICE::kKeyboard && (key==cfg.modifierKey || (cfg.modifierKey2 && key==cfg.modifierKey2))) continue;
            if(!usable()) continue;
            if((held || pendingWeapon) && userEvent==user->activate) {
                if(button.down) {
                    auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
                    if(pendingWeapon || (ref && ref->As<RE::MissileProjectile>())) drop();
                    else if(weak(actor)) beginFinisher(userEvent);
                    else if(ref && !actor) {
                        auto body=sample(ref.get());
                        auto* player=RE::PlayerCharacter::GetSingleton();
                        auto bounds=actorBounds(player); Vec origin=(bounds.low+bounds.high)*.5f;
                        auto obstacle=ray(ref->GetParentCell(),origin,body.position,ref.get());
                        bool close=body.count && length(body.position-origin)<=cfg.pickupReach;
                        drop();
                        if(close && !obstacle.hit) {
                            bool activated=ref->ActivateRef(RE::PlayerCharacter::GetSingleton(),0,nullptr,std::max(1,static_cast<int>(ref->extraList.GetCount())),false);
                            SKSE::log::info("Held item {:08X}: native activation {}",ref->GetFormID(),activated);
                        }
                    } else drop();
                } else if(button.up && finisherInput==userEvent) { drop(); }
                continue;
            }
            if(held && device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9) && button.pressed) {
                distance=std::clamp(distance+(key==8 ? -50.f : 50.f),cfg.minDistance,cfg.maxDistance);
                continue;
            }
            if(!cfg.legacyHotkeys || device!=RE::INPUT_DEVICE::kKeyboard) continue;
            if(button.up) {
                if(key==cfg.execute) { execDown=false; charged=0; chargeSound.Stop(); chargeStep=-1; }
                if(key==cfg.pull) pulling=false;
                if(key==cfg.push) pushing=false;
            }
            if(!usable() || !button.down) continue;
            if(key==cfg.grab) { ignoreInitialShift=shiftLeft || shiftRight; slamDown=false; grab(false,ignoreInitialShift); }
            else if(key==cfg.launch) launch(false);
            else if(key==cfg.slam) launch(true);
            else if(key==cfg.pull) pulling=true;
            else if(key==cfg.push) pushing=true;
            else if(key==cfg.execute && held) beginFinisher(userEvent);
        }
    }
    RE::BSEventNotifyControl ProcessEvent(RE::InputEvent* const* events,RE::BSTEventSource<RE::InputEvent*>*) override {
        if(!events || !ready) return RE::BSEventNotifyControl::kContinue;
        std::vector<Button> buttons;
        for(auto* event=*events;event;event=event->next) {
            auto* button=event->AsButtonEvent();
            if(!button) continue;
            auto key=button->GetIDCode(); auto device=button->GetDevice();
            if(button->IsDown() || button->IsUp() || (device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9)))
                buttons.push_back({key,device,button->QUserEvent(),button->IsDown(),button->IsUp(),button->IsPressed()});
        }
        // Input can arrive on worker threads. Own a snapshot and mutate game state on the game thread.
        if(!buttons.empty()) SKSE::GetTaskInterface()->AddTask([buttons=std::move(buttons)] {
            auto& state=Combat::get(); if(state.ready) state.input(buttons);
        });
        return RE::BSEventNotifyControl::kContinue;
    }
};

std::jthread ticker;
void message(SKSE::MessagingInterface::Message* msg) {
    auto& combat=Combat::get();
    switch(msg->type) {
    case SKSE::MessagingInterface::kDataLoaded:
        combat.resolve();
        missile_hold::install(); // Acquisition toggle is live; every unheld missile forwards unchanged.
        RE::BSInputDeviceManager::GetSingleton()->AddEventSink(&combat);
        ticker=std::jthread([](std::stop_token stop) {
            while(!stop.stop_requested()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(16));
                auto& c=Combat::get();
                if(!c.ready || c.queued.exchange(true)) continue;
                SKSE::GetTaskInterface()->AddTask([] {
                    auto& state=Combat::get();
                    try { state.tick(); } catch(const std::exception& e) { SKSE::log::error("Tick: {}",e.what()); }
                    state.queued=false;
                });
            }
        });
        break;
    case SKSE::MessagingInterface::kSaveGame:
        // SKSE dispatches before serialization: do not save a frozen hostile missile with zero velocity.
        if(missile_hold::suspended.load(std::memory_order_acquire)!=0) combat.drop();
        break;
    case SKSE::MessagingInterface::kPreLoadGame:
        combat.ready=false; combat.reset(); break;
    case SKSE::MessagingInterface::kPostLoadGame:
    case SKSE::MessagingInterface::kNewGame:
        combat.reset(); combat.ready=true; break;
    default: break;
    }
}
}

SKSEPluginLoad(const SKSE::LoadInterface* skse) {
    auto directory=SKSE::log::log_directory();
    if(!directory) return false;
    auto sink=std::make_shared<spdlog::sinks::basic_file_sink_mt>((*directory/"TelekinesisCombat.log").string(),true);
    auto logger=std::make_shared<spdlog::logger>("TKC",sink);
    spdlog::set_default_logger(logger); spdlog::flush_on(spdlog::level::info);
    SKSE::Init(skse);
    if(REL::Module::IsVR()) { SKSE::log::error("VR is not supported"); return false; }
    const auto runtime=REL::Module::get().version();
    const std::array supported{REL::Version{1,5,97,0},REL::Version{1,6,640,0},REL::Version{1,6,659,0},
        REL::Version{1,6,1170,0},REL::Version{1,6,1179,0},REL::Version{1,7,104,0}};
    if(std::find(supported.begin(),supported.end(),runtime)==supported.end()) {
        SKSE::log::error("Runtime {} is outside the target list",runtime.string()); return false;
    }
    return SKSE::GetMessagingInterface()->RegisterListener(message);
}
