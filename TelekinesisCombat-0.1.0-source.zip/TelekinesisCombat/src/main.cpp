#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <Windows.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <atomic>
#include <array>
#include <chrono>
#include <filesystem>
#include <thread>
#include <stdexcept>
#include <vector>
#include "combat_math.h"
#include "controls.h"
#include "raycast.h"

namespace {
using namespace tkc;
using Clock=std::chrono::steady_clock;
Vec vec(RE::NiPoint3 p) { return {p.x,p.y,p.z}; }
RE::NiPoint3 ni(Vec p) { return {p.x,p.y,p.z}; }
Vec vec(const RE::hkVector4& p) {
    return {p.quad.m128_f32[0],p.quad.m128_f32[1],p.quad.m128_f32[2]};
}
RE::hkVector4 hk(Vec p) { return {p.x,p.y,p.z,0.f}; }

struct Config {
    std::string plugin="TelekinesisCombat.esp";
    std::uint32_t control=0x800, hold=0x801, execution=0;
    std::uint32_t grab=34, launch=35, pull=36, push=37, slam=38, execute=45;
    bool legacyHotkeys=false;
    float grabCost=15, holdCost=12, launchCost=10, executionCost=40;
    float levelFactor=.04f, maxScale=1.3f, maxHeight=180, executionHealth=.25f, charge=1.5f;
    bool undead=true, protect=true, orient=true;
    float range=1800, distance=300, minDistance=140, maxDistance=650, adjustSpeed=240;
    float gain=6, holdSpeed=1000, launchSpeed=2600, slamSpeed=2200;
    float minimum=450, multiplier=1, damageCap=1200, actorMass=70, massCap=40;
    float radius=38, flightSeconds=4;
    int maxFlights=8;
    void load() {
        auto path=std::filesystem::absolute("Data/SKSE/Plugins/TelekinesisCombat.ini").string();
        auto read=[&](const char* section,const char* key,const std::string& fallback) {
            char buffer[512]{};
            GetPrivateProfileStringA(section,key,fallback.c_str(),buffer,sizeof(buffer),path.c_str());
            return std::string(buffer);
        };
        auto number=[&](const char* section,const char* key,float fallback,float lo,float hi) {
            try {
                auto s=read(section,key,std::to_string(fallback)); size_t used=0;
                float n=std::stof(s,&used);
                if(used!=s.size() || !std::isfinite(n)) throw std::invalid_argument(key);
                return std::clamp(n,lo,hi);
            } catch(...) { SKSE::log::warn("Invalid INI {}.{}; using default",section,key); return fallback; }
        };
        auto form=[&](const char* key,std::uint32_t fallback) {
            try {
                auto s=read("Forms",key,std::to_string(fallback)); size_t used=0;
                auto n=std::stoul(s,&used,0);
                if(used!=s.size() || n>0xFFFFFF) throw std::invalid_argument(key);
                return static_cast<std::uint32_t>(n);
            } catch(...) { SKSE::log::warn("Invalid form {}",key); return fallback; }
        };
        plugin=read("Forms","Plugin",plugin);
        legacyHotkeys=number("Controls","LegacyHotkeys",0,0,1)!=0;
        control=form("ControlSpell",control); hold=form("HoldSpell",hold); execution=form("ExecutionSpell",execution);
#define KEY(member,name) member=static_cast<std::uint32_t>(number("Controls",name,static_cast<float>(member),1,255))
        KEY(grab,"Grab"); KEY(launch,"Launch"); KEY(pull,"Pull"); KEY(push,"Push"); KEY(slam,"Slam"); KEY(execute,"Execute");
#undef KEY
#define G(member,name,lo,hi) member=number("Gameplay",name,member,lo,hi)
        G(grabCost,"GrabCost",0,500); G(holdCost,"HoldCostPerSecond",0,500);
        G(launchCost,"LaunchCost",0,500); G(executionCost,"ExecutionCost",0,1000);
        G(levelFactor,"LevelResistance",0,.2f); G(maxScale,"MaxActorScale",.5f,2);
        G(maxHeight,"MaxActorHeight",50,300); G(executionHealth,"ExecutionHealthFraction",.01f,.5f);
        G(charge,"ExecutionChargeSeconds",.25f,5);
#undef G
        undead=number("Gameplay","AllowUndead",1,0,1)!=0;
        protect=number("Gameplay","ProtectProtectedActors",1,0,1)!=0;
        orient=number("Physics","OrientSwords",1,0,1)!=0;
#define P(member,name,lo,hi) member=number("Physics",name,member,lo,hi)
        P(range,"Range",200,4000); P(minDistance,"MinHoldDistance",100,500);
        P(maxDistance,"MaxHoldDistance",minDistance,1000); P(distance,"HoldDistance",minDistance,maxDistance);
        P(adjustSpeed,"PullPushSpeed",20,600); P(gain,"SpringGain",1,12); P(holdSpeed,"MaxHoldSpeed",100,1600);
        P(launchSpeed,"LaunchSpeed",500,4500); P(slamSpeed,"SlamSpeed",500,4500);
        P(minimum,"ImpactMinSpeed",100,2000); P(multiplier,"ImpactDamageMultiplier",0,5);
        P(damageCap,"MaxImpactDamage",0,10000); P(actorMass,"ActorMass",10,200); P(massCap,"ObjectMassCap",1,100);
        P(radius,"HitRadius",10,80); P(flightSeconds,"FlightSeconds",.5f,8);
#undef P
        maxFlights=static_cast<int>(number("Physics","MaxFlights",8,1,16));
        std::vector<std::uint32_t> keys{grab,launch,pull,push,slam,execute};
        std::sort(keys.begin(),keys.end());
        if(std::adjacent_find(keys.begin(),keys.end())!=keys.end()) {
            SKSE::log::warn("Duplicate controls; restoring defaults");
            grab=34; launch=35; pull=36; push=37; slam=38; execute=45;
        }
    }
} cfg;

// No body/scene pointers survive a game-thread task or world-lock scope.
void bodies(RE::NiAVObject* object,std::vector<RE::bhkRigidBody*>& out) {
    if(!object || out.size()>=128) return;
    if(auto* collision=object->collisionObject ? object->collisionObject->AsBhkNiCollisionObject() : nullptr) {
        if(auto* body=collision->body ? collision->body->AsBhkRigidBody() : nullptr) {
            if(auto* rigid=body->GetRigidBody(); rigid && rigid->motion.GetMass()>0 &&
                std::find(out.begin(),out.end(),body)==out.end()) out.push_back(body);
        }
    }
    if(auto* node=object->AsNode()) for(auto& child:node->children) bodies(child.get(),out);
}
struct Sample { Vec position{}, velocity{}; int count{}; };
Sample sample(RE::TESObjectREFR* ref) {
    Sample s;
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return s;
    RE::BSReadLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float inverse=RE::bhkWorld::GetWorldScaleInverse();
    for(auto* body:list) {
        RE::hkVector4 pos; body->GetCenterOfMassWorld(pos);
        s.position=s.position+vec(pos)*inverse;
        s.velocity=s.velocity+vec(body->GetRigidBody()->motion.linearVelocity)*inverse;
        ++s.count;
    }
    if(s.count) { s.position=s.position*(1.f/s.count); s.velocity=s.velocity*(1.f/s.count); }
    return s;
}
bool velocity(RE::TESObjectREFR* ref,Vec speed,Vec* direction=nullptr) {
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D() || !finite(speed)) return false;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    auto value=hk(speed*RE::bhkWorld::GetWorldScale());
    for(auto* body:list) body->SetLinearVelocity(value);
    if(direction && cfg.orient && list.size()==1) {
        auto* weapon=ref->GetBaseObject()->As<RE::TESObjectWEAP>();
        if(weapon && (weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kTwoHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandDagger)) {
            // ponytail: vanilla sword meshes use local +Z; custom mesh axes need per-mesh calibration.
            auto d=unit(*direction); float w=1+d.z;
            Vec axis{-d.y,d.x,0}; float norm=std::sqrt(dot(axis,axis)+w*w);
            RE::hkQuaternion rotation;
            rotation.vec=norm>.001f ? RE::hkVector4(axis.x/norm,axis.y/norm,0,w/norm) : RE::hkVector4(1,0,0,0);
            list.front()->SetRotation(rotation);
            list.front()->SetAngularVelocity(RE::hkVector4{});
        }
    }
    return !list.empty();
}

struct RayHit { bool hit{}; float fraction=1; RE::ObjectRefHandle ref; };
RayHit ray(RE::TESObjectCELL* cell,Vec from,Vec to,RE::TESObjectREFR* ignore) {
    RayHit result;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || length(to-from)<.1f) return result;
    RE::BSReadLockGuard lock(world->worldLock);
    Vec start=from, dir=unit(to-from); float total=length(to-from);
    // Skip source body hits without globally changing any collision filter.
    for(int i=0;i<32 && length(start-from)<total;++i) {
        RE::bhkPickData pick{};
        preparePickRay(pick,start,to,RE::bhkWorld::GetWorldScale());
        pick.rayInput.filterInfo.SetCollisionLayer(RE::COL_LAYER::kLOS);
        world->PickObject(pick);
        if(!pick.rayOutput.HasHit()) return result;
        auto* ref=RE::TESHavokUtilities::FindCollidableRef(*pick.rayOutput.rootCollidable);
        Vec point=start+(to-start)*pick.rayOutput.hitFraction;
        if((!ignore || ref!=ignore) && ref!=RE::PlayerCharacter::GetSingleton()) {
            result.hit=true; result.fraction=std::clamp(length(point-from)/total,0.f,1.f);
            if(ref) result.ref=ref->GetHandle();
            return result;
        }
        start=point+dir*8;
    }
    // Conservative: an unresolved obstruction stops targeting/hold travel.
    result.hit=true; result.fraction=0;
    return result;
}

class Combat final : public RE::BSTEventSink<RE::InputEvent*> {
    struct Flight {
        RE::ObjectRefHandle ref;
        Vec previous{}, velocity{};
        float mass{}, multiplier=1, remaining{}, elapsed{}, refresh{};
    };
    RE::ObjectRefHandle held;
    RE::TESObjectCELL* holdCell{}; // compared only; never dereferenced after a cell change
    std::vector<Flight> flights;
    RE::SpellItem* controlSpell{};
    RE::SpellItem* holdSpell{};
    RE::SpellItem* executionSpell{};
    bool active=false, execDown=false, pulling=false, pushing=false;
    bool slamDown=false;
    RE::BSFixedString gripInput;
    float holdAge{}, refresh{}, costFactor=1, charged{}, distance=300;
    Clock::time_point last=Clock::now();
public:
    std::atomic_bool ready=false, queued=false;
    static Combat& get() { static auto* instance=new Combat; return *instance; }
    void resolve() {
        cfg.load();
        auto* data=RE::TESDataHandler::GetSingleton();
        controlSpell=data->LookupForm<RE::SpellItem>(cfg.control,cfg.plugin);
        holdSpell=data->LookupForm<RE::SpellItem>(cfg.hold,cfg.plugin);
        executionSpell=cfg.execution ? data->LookupForm<RE::SpellItem>(cfg.execution,cfg.plugin) : nullptr;
        bool paralysis=false;
        if(holdSpell) for(auto* effect:holdSpell->effects) {
            if(effect && effect->baseEffect && effect->baseEffect->GetArchetype()==RE::EffectArchetypes::ArchetypeID::kParalysis &&
               effect->GetDuration()>=2 && effect->GetDuration()<=3) paralysis=true;
        }
        active=controlSpell && paralysis;
        SKSE::log::info("Gameplay layer {} (control {:X}, hold {:X})",active ? "ready" : "MISSING/INVALID",cfg.control,cfg.hold);
        if(!active) RE::SendHUDMessage::ShowHUDMessage("Telekinesis Combat: missing/invalid companion spells. See README.");
        ready=true;
    }
    bool usable() const {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
        return ready && active && p && p->Get3D() && p->GetParentCell() && !p->IsDead() && !p->IsInKillMove() &&
            ui && !ui->GameIsPaused() && !ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) &&
            !ui->IsMenuOpen(RE::MainMenu::MENU_NAME) && !ui->IsMenuOpen(RE::DialogueMenu::MENU_NAME) &&
            (p->GetEquippedObject(false)==controlSpell || p->GetEquippedObject(true)==controlSpell);
    }
    void drop(bool stop=true) {
        if(auto ref=held.get()) {
            if(stop) velocity(ref.get(),{});
            if(auto* a=ref->As<RE::Actor>(); a && holdSpell) {
                if(auto* player=RE::PlayerCharacter::GetSingleton()) {
                    RE::ActorHandle actorCaster{player};
                    a->AsMagicTarget()->DispelEffect(holdSpell,actorCaster);
                }
            }
        }
        held={}; holdCell=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        gripInput=RE::BSFixedString(); slamDown=false;
    }
    void reset() { drop(); flights.clear(); last=Clock::now(); }
    bool allowed(RE::Actor* a) const {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || a->IsDead() || a->IsChild() || a->IsEssential() ||
            (cfg.protect && a->IsProtected()) || a->IsInKillMove() || a->GetScale()>cfg.maxScale ||
            a->HasKeywordString("ActorTypeDragon") || a->HasKeywordString("ActorTypeGiant")) return false;
        auto* race=a->GetRace();
        if(!race || (a->GetBoundMax().z-a->GetBoundMin().z)*a->GetScale()>cfg.maxHeight) return false;
        return a->HasKeywordString("ActorTypeNPC") || (cfg.undead && a->HasKeywordString("ActorTypeUndead"));
    }
    Vec aim() const {
        auto* camera=RE::PlayerCamera::GetSingleton();
        if(camera && camera->cameraRoot) {
            auto& r=camera->cameraRoot->world.rotate;
            return unit({r.entry[0][1],r.entry[1][1],r.entry[2][1]});
        }
        return {0,1,0};
    }
    bool spend(float amount) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* values=p->AsActorValueOwner();
        if(values->GetActorValue(RE::ActorValue::kMagicka)<amount) return false;
        values->DamageActorValue(RE::ActorValue::kMagicka,amount); return true;
    }
    void castHold(RE::Actor* a) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(holdSpell,true,a,1.f,false,1.f,p);
    }
    void hurt(RE::Actor* a,float amount) {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || a->IsDead() || a->IsChild() || a->IsEssential() ||
           (cfg.protect && a->IsProtected()) || amount<=0) return;
        auto* p=RE::PlayerCharacter::GetSingleton();
        a->StartCombat(p);
        a->HandleHealthDamage(p,amount);
    }
    void grab() {
        if(held) { drop(); return; }
        auto* p=RE::PlayerCharacter::GetSingleton(); Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition());
        // Use the same nearby target Skyrim displays under the crosshair.
        // The corrected physics ray extends selection beyond activation distance.
        RE::NiPointer<RE::TESObjectREFR> ref;
        if(auto* picker=RE::CrosshairPickData::GetSingleton()) ref=picker->GetActiveTarget().get();
        bool nativeTarget=ref && ref.get()!=p && ref->GetParentCell()==p->GetParentCell() &&
            ref->Get3D() && !ref->IsDisabled() && length(vec(ref->GetPosition())-origin)<=cfg.range;
        RayHit hit;
        if(!nativeTarget) { hit=ray(p->GetParentCell(),origin,origin+aim()*cfg.range,nullptr); ref=hit.ref.get(); }
        SKSE::log::info("Grab: {} target {:08X}, ray hit {}, fraction {}",nativeTarget ? "crosshair" : "physics",
            ref ? ref->GetFormID() : 0,hit.hit,hit.fraction);
        if(!ref || !ref->Get3D() || ref->IsDisabled()) {
            RE::SendHUDMessage::ShowHUDMessage("Telekinesis: aim at a loose object or humanoid."); return;
        }
        if(std::any_of(flights.begin(),flights.end(),[&](auto& f){return f.ref==ref->GetHandle();})) return;
        costFactor=1;
        if(auto* a=ref->As<RE::Actor>()) {
            if(!allowed(a) || a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kParalysis)>0) {
                RE::SendHUDMessage::ShowHUDMessage("Target resists telekinesis."); return;
            }
            costFactor=resistance(a->GetScale(),a->GetLevel(),p->GetLevel(),cfg.levelFactor);
            if(!spend(cfg.grabCost*costFactor)) return;
            castHold(a); a->StartCombat(p);
        } else {
            auto* base=ref->GetBaseObject();
            if(!base) return;
            // Loose carryable objects only. Never change static/animated/door physics.
            auto type=base->GetFormType();
            if(type!=RE::FormType::Weapon && type!=RE::FormType::Misc && type!=RE::FormType::Armor &&
               type!=RE::FormType::Ingredient && type!=RE::FormType::AlchemyItem) return;
            if(!sample(ref.get()).count) {
                SKSE::log::warn("Target {:08X} has no movable rigid bodies",ref->GetFormID());
                RE::SendHUDMessage::ShowHUDMessage("Telekinesis: this object has no movable physics body."); return;
            }
            if(!spend(cfg.grabCost)) return;
        }
        held=ref->GetHandle(); holdCell=p->GetParentCell(); holdAge=0; refresh=0; charged=0; distance=cfg.distance;
        SKSE::log::info("Grip established on {:08X}",ref->GetFormID());
    }
    void launch(bool slam) {
        auto ref=held.get(); if(!ref || !sample(ref.get()).count) return;
        if(auto* a=ref->As<RE::Actor>(); a && !a->IsInRagdollState()) return;
        if(static_cast<int>(flights.size())>=cfg.maxFlights) { RE::SendHUDMessage::ShowHUDMessage("Too many objects in flight."); return; }
        if(!spend(cfg.launchCost*costFactor)) return;
        Vec speed=slam ? Vec{0,0,-cfg.slamSpeed} : aim()*cfg.launchSpeed;
        if(!velocity(ref.get(),speed)) { drop(); return; }
        auto s=sample(ref.get());
        float mass=ref->As<RE::Actor>() ? cfg.actorMass : std::clamp(ref->GetWeight(),1.f,cfg.massCap);
        float mult=ref->GetBaseObject()->As<RE::TESObjectWEAP>() ? 2.f : 1.f;
        flights.push_back({held,s.position,speed,mass,mult,cfg.flightSeconds,0,0});
        // Keep the brief paralysis effect for the flight; it expires without saved native state.
        held={}; holdCell=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        gripInput=RE::BSFixedString(); slamDown=false;
    }
    void execute(RE::Actor* a) {
        if(!allowed(a) || !spend(cfg.executionCost*costFactor)) { charged=0; execDown=false; return; }
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(executionSpell) if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(executionSpell,false,a,1.f,false,0.f,p);
        SKSE::ModCallbackEvent event{RE::BSFixedString("TKC_Execution"),RE::BSFixedString("crush"),0.f,a};
        SKSE::GetModCallbackEventSource()->SendEvent(&event);
        hurt(a,a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)+10000.f);
        RE::SendHUDMessage::ShowHUDMessage("Telekinetic crush!");
        drop(false);
    }
    void tick() {
        auto now=Clock::now(); float dt=std::chrono::duration<float>(now-last).count(); last=now;
        if(!ready) return;
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* ui=RE::UI::GetSingleton();
        if(!p || !p->Get3D() || !p->GetParentCell() || !ui || ui->GameIsPaused() ||
           ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) || ui->IsMenuOpen(RE::MainMenu::MENU_NAME) || dt>.25f) { reset(); return; }
        dt=std::clamp(dt,0.f,.05f);
        if(held && (!usable() || p->GetParentCell()!=holdCell)) drop();
        if(auto ref=held.get()) {
            holdAge+=dt; refresh+=dt;
            auto* actor=ref->As<RE::Actor>();
            if(ref->IsDisabled() || !ref->Get3D() || (actor && !allowed(actor)) || !spend(cfg.holdCost*costFactor*dt)) { drop(); }
            else {
                if(actor && refresh>=1.f) { castHold(actor); refresh=0; }
                auto s=sample(ref.get());
                if(!finite(s.position) || !finite(s.velocity)) { drop(); }
                else if(!s.count || (actor && !actor->IsInRagdollState())) {
                    if(holdAge>.75f) { RE::SendHUDMessage::ShowHUDMessage("Cannot establish a ragdoll grip."); drop(); }
                } else {
                    distance=std::clamp(distance+((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt,cfg.minDistance,cfg.maxDistance);
                    Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
                    auto wall=ray(p->GetParentCell(),origin,origin+direction*distance,ref.get());
                    float safeDistance=wall.hit ? std::max(0.f,distance*wall.fraction-60.f) : distance;
                    if(safeDistance<80.f || length(s.position-origin)>cfg.range) { drop(); }
                    else {
                        Vec target=origin+direction*safeDistance;
                        velocity(ref.get(),limit((target-s.position)*cfg.gain,cfg.holdSpeed),&direction);
                        float maximum=actor ? actor->AsActorValueOwner()->GetPermanentActorValue(RE::ActorValue::kHealth) : 0;
                        if(execDown && actor && maximum>0 && actor->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)/maximum<=cfg.executionHealth) {
                            if(charged==0) RE::SendHUDMessage::ShowHUDMessage("Crushing target... keep the finisher control held.");
                            charged+=dt; if(charged>=cfg.charge) execute(actor);
                        } else charged=0;
                    }
                }
            }
        } else held={};
        for(auto it=flights.begin();it!=flights.end();) {
            auto ref=it->ref.get(); it->remaining-=dt; it->elapsed+=dt; it->refresh+=dt;
            auto s=ref ? sample(ref.get()) : Sample{};
            if(!ref || !s.count || ref->IsDisabled() || ref->GetParentCell()!=p->GetParentCell() || it->remaining<=0 ||
                !finite(s.position) || !finite(s.velocity) || length(s.position-it->previous)>cfg.range) { it=flights.erase(it); continue; }
            if(auto* a=ref->As<RE::Actor>(); a && allowed(a) && it->refresh>=1.f) { castHold(a); it->refresh=0; }
            float speed=length(it->velocity);
            // A ray covers static geometry; swept humanoid bounds cover high-speed actor tunnelling.
            auto wall=ray(ref->GetParentCell(),it->previous,s.position,ref.get());
            auto wallRef=wall.ref.get();
            RE::Actor* victim=wallRef ? wallRef->As<RE::Actor>() : nullptr;
            float closest=wall.hit ? wall.fraction : 1.f;
            Vec step=s.position-it->previous; float distance2=dot(step,step);
            // Havok can move the body without updating the reference's logical origin.
            ref->GetParentCell()->ForEachReferenceInRange(ni((it->previous+s.position)*.5f),300.f+length(step)*.5f,[&](RE::TESObjectREFR* candidate) {
                auto* a=candidate->As<RE::Actor>();
                if(!a || a==ref.get() || a==p || !a->Get3D() || a->IsDead() || a->GetParentCell()!=ref->GetParentCell()) return RE::BSContainer::ForEachResult::kContinue;
                Vec center=vec(a->GetPosition())+Vec{0,0,65.f*a->GetScale()};
                // ponytail: a swept sphere approximates a humanoid torso; exact limb hits require Havok contact integration.
                float t=distance2>.01f ? std::clamp(dot(center-it->previous,step)/distance2,0.f,1.f) : 1.f;
                if(t<=closest && segmentDistance(it->previous,s.position,center)<=cfg.radius*a->GetScale()) {
                    auto obstruction=ray(ref->GetParentCell(),it->previous,center,ref.get());
                    auto obstructionRef=obstruction.ref.get();
                    if(!obstruction.hit || obstructionRef.get()==a) { victim=a; closest=t; }
                }
                return RE::BSContainer::ForEachResult::kContinue;
            });
            // Ignore the initial settling tick. Directional velocity loss catches wall/floor impacts.
            float loss=dot(it->velocity-s.velocity,unit(it->velocity));
            bool collision=victim || wall.hit || (it->elapsed>.06f && loss>std::max(cfg.minimum,speed*.4f));
            if(collision && speed>=cfg.minimum) {
                float amount=damage(speed,it->mass,cfg.multiplier*it->multiplier,cfg.minimum,cfg.damageCap);
                if(victim) hurt(victim,amount);
                if(auto* thrown=ref->As<RE::Actor>()) hurt(thrown,amount);
                it=flights.erase(it); // one damaging impact per launch
            } else { it->previous=s.position; it->velocity=s.velocity; ++it; }
        }
    }
    RE::BSEventNotifyControl ProcessEvent(RE::InputEvent* const* events,RE::BSTEventSource<RE::InputEvent*>*) override {
        if(!events) return RE::BSEventNotifyControl::kContinue;
        for(auto* event=*events;event;event=event->next) {
            auto* button=event->AsButtonEvent();
            if(!button) continue;
            auto key=button->GetIDCode();
            auto device=button->GetDevice();
            auto userEvent=button->QUserEvent();
            auto* user=RE::UserEvents::GetSingleton();
            if(!user) continue;
            // Use Skyrim's mapped casting actions, including remapped mouse/gamepad buttons.
            bool castInput=userEvent==user->leftAttack || userEvent==user->rightAttack;
            if(castInput) {
                auto* player=RE::PlayerCharacter::GetSingleton();
                bool controlHand=player && player->GetEquippedObject(userEvent==user->leftAttack)==controlSpell;
                auto action=castAction(button->IsDown(),button->IsUp(),static_cast<bool>(held),userEvent==gripInput,controlHand);
                if(button->IsUp()) {
                    if(action==CastAction::release) {
                        if(usable()) launch(slamDown);
                        // Failed launch (Magicka, ragdoll or flight limit) must release the grip.
                        if(held) drop();
                    } else { execDown=false; charged=0; }
                    continue;
                }
                if(!usable()) continue;
                if(action==CastAction::grab) {
                    grab(); if(held) gripInput=userEvent;
                } else if(action==CastAction::charge) {
                    auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
                    float maximum=actor ? actor->AsActorValueOwner()->GetPermanentActorValue(RE::ActorValue::kHealth) : 0;
                    if(actor && maximum>0 && actor->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)/maximum<=cfg.executionHealth) {
                        execDown=true; charged=0;
                    } else RE::SendHUDMessage::ShowHUDMessage("Finisher requires a weakened humanoid.");
                }
                continue;
            }
            if(device==RE::INPUT_DEVICE::kKeyboard && (key==42 || key==54)) {
                if(button->IsUp()) slamDown=false;
                else if(button->IsDown() && usable()) slamDown=true;
            }
            if(!usable()) continue;
            if(held && userEvent==user->activate && button->IsDown()) { drop(); continue; }
            if(held && device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9) && button->IsPressed()) {
                distance=std::clamp(distance+(key==8 ? -50.f : 50.f),cfg.minDistance,cfg.maxDistance);
                continue;
            }
            if(!cfg.legacyHotkeys || device!=RE::INPUT_DEVICE::kKeyboard) continue;
            if(button->IsUp()) {
                if(key==cfg.execute) { execDown=false; charged=0; }
                if(key==cfg.pull) pulling=false;
                if(key==cfg.push) pushing=false;
            }
            if(!usable() || !button->IsDown()) continue;
            if(key==cfg.grab) grab();
            else if(key==cfg.launch) launch(false);
            else if(key==cfg.slam) launch(true);
            else if(key==cfg.pull) pulling=true;
            else if(key==cfg.push) pushing=true;
            else if(key==cfg.execute && held) { execDown=true; charged=0; }
        }
        return RE::BSEventNotifyControl::kContinue;
    }
};

std::jthread ticker;
void message(SKSE::MessagingInterface::Message* msg) {
    auto& combat=Combat::get();
    switch(msg->type) {
    case SKSE::MessagingInterface::kDataLoaded:
        combat.resolve();
        RE::BSInputDeviceManager::GetSingleton()->AddEventSink(&combat);
        ticker=std::jthread([](std::stop_token stop) {
            while(!stop.stop_requested()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(16));
                auto& c=Combat::get();
                if(!c.ready || c.queued.exchange(true)) continue;
                SKSE::GetTaskInterface()->AddTask([] {
                    auto& state=Combat::get();
                    try { state.tick(); } catch(const std::exception& e) { SKSE::log::error("Tick: {}",e.what()); }
                    state.queued=false;
                });
            }
        });
        break;
    case SKSE::MessagingInterface::kPreLoadGame:
        combat.ready=false; combat.reset(); break;
    case SKSE::MessagingInterface::kPostLoadGame:
    case SKSE::MessagingInterface::kNewGame:
        combat.reset(); combat.ready=true; break;
    default: break;
    }
}
}

SKSEPluginLoad(const SKSE::LoadInterface* skse) {
    auto directory=SKSE::log::log_directory();
    if(!directory) return false;
    auto sink=std::make_shared<spdlog::sinks::basic_file_sink_mt>((*directory/"TelekinesisCombat.log").string(),true);
    auto logger=std::make_shared<spdlog::logger>("TKC",sink);
    spdlog::set_default_logger(logger); spdlog::flush_on(spdlog::level::info);
    SKSE::Init(skse);
    if(REL::Module::IsVR()) { SKSE::log::error("VR is not supported"); return false; }
    const auto runtime=REL::Module::get().version();
    const std::array supported{REL::Version{1,5,97,0},REL::Version{1,6,640,0},REL::Version{1,6,659,0},
        REL::Version{1,6,1170,0},REL::Version{1,6,1179,0},REL::Version{1,7,104,0}};
    if(std::find(supported.begin(),supported.end(),runtime)==supported.end()) {
        SKSE::log::error("Runtime {} is outside the target list",runtime.string()); return false;
    }
    return SKSE::GetMessagingInterface()->RegisterListener(message);
}
