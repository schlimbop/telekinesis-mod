#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <Windows.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <atomic>
#include <array>
#include <chrono>
#include <filesystem>
#include <thread>
#include <stdexcept>
#include <vector>
#include <span>
#include "combat_math.h"
#include "controls.h"
#include "raycast.h"
#include "missile_hold.h"
#include "projectile_rules.h"
#include "config.h"
#include "feedback.h"
#include "prop_physics.h"
#include "settings_menu.h"
#include "hud.h"
#include "dismember.h"
#include <unordered_map>

namespace {
using namespace tkc;
using Clock=std::chrono::steady_clock;
Vec vec(RE::NiPoint3 p) { return {p.x,p.y,p.z}; }
RE::NiPoint3 ni(Vec p) { return {p.x,p.y,p.z}; }
Vec vec(const RE::hkVector4& p) {
    return {p.quad.m128_f32[0],p.quad.m128_f32[1],p.quad.m128_f32[2]};
}
RE::hkVector4 hk(Vec p) { return {p.x,p.y,p.z,0.f}; }

// No body/scene pointers survive a game-thread task or world-lock scope.
void bodies(RE::NiAVObject* object,std::vector<RE::bhkRigidBody*>& out,bool includeDormant=false) {
    if(!object || out.size()>=128) return;
    if(auto* collision=object->collisionObject ? object->collisionObject->AsBhkNiCollisionObject() : nullptr) {
        if(auto* body=collision->body ? collision->body->AsBhkRigidBody() : nullptr) {
            if(auto* rigid=body->GetRigidBody()) {
                auto state=propMotion(rigid->motion);
                if((state==PropMotion::dynamic || (includeDormant && state==PropMotion::dormant)) &&
                   std::find(out.begin(),out.end(),body)==out.end()) out.push_back(body);
            }
        }
    }
    if(auto* node=object->AsNode()) for(auto& child:node->children) bodies(child.get(),out,includeDormant);
}
struct Sample { Vec position{}, velocity{}, halfExtent{}; int count{}; bool dormant{}; };
Sample sample(RE::TESObjectREFR* ref,bool includeDormant=false) {
    Sample s;
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return s;
    RE::BSReadLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list,includeDormant);
    float inverse=RE::bhkWorld::GetWorldScaleInverse();
    Vec low{INFINITY,INFINITY,INFINITY},high{-INFINITY,-INFINITY,-INFINITY};
    bool prop=ref->As<RE::Actor>()==nullptr;
    for(auto* body:list) {
        s.dormant|=propMotion(body->GetRigidBody()->motion)==PropMotion::dormant;
        RE::hkVector4 pos; body->GetCenterOfMassWorld(pos);
        s.position=s.position+vec(pos)*inverse;
        s.velocity=s.velocity+vec(body->GetRigidBody()->motion.linearVelocity)*inverse;
        if(prop) {
            RE::hkAabb bounds; body->GetAabbWorldspace(bounds);
            auto a=vec(bounds.min)*inverse,b=vec(bounds.max)*inverse;
            if(finite(a) && finite(b)) {
                low={std::min(low.x,a.x),std::min(low.y,a.y),std::min(low.z,a.z)};
                high={std::max(high.x,b.x),std::max(high.y,b.y),std::max(high.z,b.z)};
            }
        }
        ++s.count;
    }
    if(s.count) { s.position=s.position*(1.f/s.count); s.velocity=s.velocity*(1.f/s.count); }
    if(prop && s.count && finite(low) && finite(high)) {
        // Include blade length and offset centres, without giving malformed meshes an unlimited hit box.
        s.halfExtent={std::clamp(std::max(s.position.x-low.x,high.x-s.position.x),0.f,120.f),
                      std::clamp(std::max(s.position.y-low.y,high.y-s.position.y),0.f,120.f),
                      std::clamp(std::max(s.position.z-low.z,high.z-s.position.z),0.f,120.f)};
    }
    return s;
}
bool velocity(RE::TESObjectREFR* ref,Vec speed,Vec* direction=nullptr,bool stabilize=false,float turnDt=0) {
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D() || !finite(speed)) return false;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float scale=RE::bhkWorld::GetWorldScale();
    Vec average{};
    bool actor=ref->As<RE::Actor>()!=nullptr;
    if(actor && !list.empty()) {
        for(auto* body:list) average=average+vec(body->GetRigidBody()->motion.linearVelocity);
        average=average*(1.f/list.size());
    }
    for(auto* body:list) {
        auto* rigid=body->GetRigidBody();
        // Activate sleeping bodies, and preserve relative limb motion in a ragdoll.
        Vec relative=actor ? vec(rigid->motion.linearVelocity)-average : Vec{};
        rigid->SetLinearVelocity(hk(speed*scale+relative));
        // Suppress collision-induced spin only while holding props, never on ragdoll limbs.
        if(stabilize && !actor) rigid->SetAngularVelocity(RE::hkVector4{});
    }
    if(direction && cfg.orient && !actor && list.size()==1) {
        auto* base=ref->GetBaseObject();
        auto* weapon=base ? base->As<RE::TESObjectWEAP>() : nullptr;
        if(weapon && aimableMeleeType(weapon->GetWeaponType()) && finite(*direction) && length(*direction)>.5f) {
            auto* body=list.front();
            if(stabilize) {
                RE::hkQuaternion current; body->GetRotation(current);
                auto& q=current.vec.quad;
                Vec forward=weaponForward({q.m128_f32[0],q.m128_f32[1],q.m128_f32[2],q.m128_f32[3]});
                body->GetRigidBody()->SetAngularVelocity(hk(weaponTurnVelocity(forward,*direction,turnDt)));
            } else {
                // shortcut: measured stock melee meshes use local +Y; custom axes need per-mesh calibration.
                auto q=weaponRotation(*direction); RE::hkQuaternion rotation;
                rotation.vec=RE::hkVector4(q.x,q.y,q.z,q.w);
                RE::hkVector4 center,position; RE::hkQuaternion previous;
                body->GetCenterOfMassWorld(center); body->GetPosition(position); body->GetRotation(previous);
                if(finite(vec(center)) && finite(vec(position))) {
                    body->SetRotation(rotation);
                    RE::hkVector4 moved; body->GetCenterOfMassWorld(moved);
                    // Launch rotation must preserve the COM tracked by the hold/flight controllers.
                    if(finite(vec(moved))) {
                        position=hk(vec(position)+vec(center)-vec(moved)); body->SetPosition(position);
                    } else body->SetRotation(previous);
                }
                body->GetRigidBody()->SetAngularVelocity(RE::hkVector4{});
            }
        }
    }
    return !list.empty();
}

// Resolve a swept prop contact visually as well as applying damage; never reposition an actor.
void stopProp(RE::TESObjectREFR* ref,Vec contact) {
    if(!ref || ref->As<RE::Actor>() || !finite(contact)) return;
    auto state=sample(ref); if(!state.count) return;
    auto* cell=ref->GetParentCell(); auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    Vec offset=(contact-state.position)*RE::bhkWorld::GetWorldScale();
    for(auto* body:list) {
        RE::hkVector4 position; body->GetPosition(position);
        position=hk(vec(position)+offset); body->SetPosition(position);
        body->GetRigidBody()->SetLinearVelocity(RE::hkVector4{});
        body->GetRigidBody()->SetAngularVelocity(RE::hkVector4{});
    }
}

struct RayHit { bool hit{}; float fraction=1; RE::ObjectRefHandle ref; RE::MATERIAL_ID material=RE::MATERIAL_ID::kStone; Vec normal{}, point{}; };
RayHit ray(RE::TESObjectCELL* cell,Vec from,Vec to,RE::TESObjectREFR* ignore,std::span<const RE::ObjectRefHandle> ignored={}) {
    RayHit result;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || length(to-from)<.1f) return result;
    RE::BSReadLockGuard lock(world->worldLock);
    Vec start=from, dir=unit(to-from); float total=length(to-from);
    // Skip source body hits without globally changing any collision filter.
    for(int i=0;i<32;++i) {
        // Reaching the end after skipping only source/player bodies is a clear ray, not a wall.
        if(!rayHasRemaining(start,to,dir)) return result;
        RE::bhkPickData pick{};
        preparePickRay(pick,start,to,RE::bhkWorld::GetWorldScale());
        pick.rayInput.filterInfo.SetCollisionLayer(RE::COL_LAYER::kLOS);
        world->PickObject(pick);
        if(!pick.rayOutput.HasHit()) return result;
        auto* ref=RE::TESHavokUtilities::FindCollidableRef(*pick.rayOutput.rootCollidable);
        Vec point=start+(to-start)*pick.rayOutput.hitFraction;
        bool orbitBody=ref && !ignored.empty() && std::find(ignored.begin(),ignored.end(),ref->GetHandle())!=ignored.end();
        if((!ignore || ref!=ignore) && ref!=RE::PlayerCharacter::GetSingleton() && !orbitBody) {
            result.hit=true; result.fraction=std::clamp(length(point-from)/total,0.f,1.f);
            if(ref) result.ref=ref->GetHandle();
            result.material=rayMaterial(pick.rayOutput.rootCollidable->GetShape());
            result.normal=vec(pick.rayOutput.normal);
            result.point=point;
            return result;
        }
        start=point+dir*8;
    }
    // Conservative: an unresolved obstruction stops targeting/hold travel.
    result.hit=true; result.fraction=0; result.point=from;
    return result;
}

class Combat final : public RE::BSTEventSink<RE::InputEvent*> {
    struct Flight {
        RE::ObjectRefHandle ref;
        Vec previous{}, velocity{}, halfExtent{};
        float mass{}, remaining{}, elapsed{}, refresh{}, peakZ{};
        bool slam{}, impactApplied{};
        float baseDamage{}; WeaponStyle style=WeaponStyle::clutter; int ricochets=0;
    };
    enum class Mode { none, grab, disarm, catchSpell };
    struct Selection { Mode mode=Mode::none; RE::ObjectRefHandle ref; RE::FormID weapon{}; bool left{}; };
    Selection slowSelection;
    bool selectionShift=false;
    float searchAge=100, cacheAge=100, previewAge=0, stickyAge=100;
    RE::ObjectRefHandle stickyTarget;
    std::vector<RE::ObjectRefHandle> objectCache;
    std::vector<RE::ActorHandle> actorCache;
    RE::bhkWorld* cacheWorld{}; // Identity only.
    EquipHint equipHint;
    bool hintVisible=false;
    float orbitSpacingRadius=50;
    std::unordered_map<RE::FormID,double> reactionCooldown;
    RE::BSSoundHandle chargeSound;
    int chargeStep=-1;
    float xpBudget=60;
    double combatTime=0;
    std::unordered_map<RE::FormID,double> xpCooldown;
    double profileTotal=0, profilePeak=0; std::uint64_t profileTicks=0, cacheScans=0;
    float profileAge=0;
    std::uint64_t settingsRevision=0;
    RE::ObjectRefHandle held, lastThrownWeapon;
    bool recalledWeapon=false;
    GraspState grasp;
    struct OrbitItem { RE::ObjectRefHandle ref; Vec anchor{}; int slot{}; GraspState grasp; };
    std::vector<OrbitItem> orbitItems;
    bool orbitSession=false;
    int heldSlot=0;
    float orbitPhase=0, orbitSearchAge=0, shakeAge=1;
    RE::ObjectRefHandle projectileCaster;
    RE::FormID projectileSpell{};
    float projectilePower=1, projectileScale=1, projectileSpeed{};
    RE::bhkWorld* holdWorld{}; // identity only; never dereferenced after a world change
    Vec anchor{};
    std::vector<Flight> flights;
    struct Decapitation { RE::ActorHandle ref; float remaining=2.f; };
    std::vector<Decapitation> executions;
    RE::SpellItem* controlSpell{};
    RE::SpellItem* holdSpell{};
    RE::SpellItem* executionSpell{};
    bool active=false, execDown=false, pulling=false, pushing=false;
    bool slamDown=false, shiftLeft=false, shiftRight=false, ignoreInitialShift=false;
    RE::ObjectRefHandle pendingWeapon;
    float pendingWeaponTime{};
    bool castingShift=false;
    RE::BSFixedString gripInput;
    RE::BSFixedString castingInput;
    RE::BSFixedString finisherInput;
    bool castingHeld=false;
    float lastPoll=.016f;
    float retry{}, holdAge{}, refresh{}, costFactor=1, charged{}, distance=300;
    Clock::time_point last=Clock::now();
public:
    std::atomic_bool ready=false, queued=false;
    static Combat& get() { static auto* instance=new Combat; return *instance; }
    void resolve() {
        cfg=Config{}; cfg.load(); xpBudget=cfg.xpPerMinute;
        auto* data=RE::TESDataHandler::GetSingleton();
        controlSpell=data->LookupForm<RE::SpellItem>(cfg.control,cfg.plugin);
        holdSpell=data->LookupForm<RE::SpellItem>(cfg.hold,cfg.plugin);
        executionSpell=cfg.execution ? data->LookupForm<RE::SpellItem>(cfg.execution,cfg.plugin) : nullptr;
        // Vanilla rank-cost perks use SpellHasCastingPerk. This private spell is novice Alteration.
        if(controlSpell) controlSpell->data.castingPerk=RE::TESForm::LookupByID<RE::BGSPerk>(0xf2ca6);
        bool ragdollHold=false;
        if(holdSpell) for(auto* effect:holdSpell->effects) {
            if(effect && effect->baseEffect && effect->baseEffect->GetArchetype()==RE::EffectArchetypes::ArchetypeID::kValueModifier &&
               effect->baseEffect->data.primaryAV==RE::ActorValue::kGrabbed &&
               effect->GetDuration()==2 && effect->GetMagnitude()==1.f) ragdollHold=true;
        }
        active=controlSpell && ragdollHold;
        SKSE::log::info("Gameplay layer {} (control {:X}, hold {:X})",active ? "ready" : "MISSING/INVALID",cfg.control,cfg.hold);
        if(!active) SKSE::log::warn("{}","Telekinesis Combat: missing/invalid companion spells. See README.");
        ready=true;
    }
    bool usable() const {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
        return ready && active && p && p->Get3D() && p->GetParentCell() && !p->IsDead() && !p->IsInKillMove() &&
            ui && !ui->GameIsPaused() && !ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) &&
            !ui->IsMenuOpen(RE::MainMenu::MENU_NAME) && !ui->IsMenuOpen(RE::DialogueMenu::MENU_NAME) &&
            (p->GetEquippedObject(false)==controlSpell || p->GetEquippedObject(true)==controlSpell);
    }
    void cancelFinisher(bool report=true) {
        bool started=execDown && charged>0;
        execDown=false; charged=0; chargeSound.Stop(); chargeStep=-1; finisherInput=RE::BSFixedString();
        if(report && started) {
            SKSE::log::info("Crush cancelled");
            if(auto ref=held.get(); ref && sameWorld(ref.get())) feedback::sound(0x53a5e,pickCenter(ref.get()),.3f);
        }
    }
    bool finisherReady(RE::Actor* actor) const {
        return weak(actor) && RE::PlayerCharacter::GetSingleton()->AsActorValueOwner()->GetActorValue(RE::ActorValue::kMagicka)>=actualCost(cfg.executionCost*costFactor);
    }
    void updateEquipHint(float dt) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool equipped=active && controlSpell && p &&
            (p->GetEquippedObject(false)==controlSpell || p->GetEquippedObject(true)==controlSpell);
        bool show=equipHint.update(equipped,usable(),dt);
        if(show!=hintVisible) {
            hintVisible=show;
            grip_hud::publish(show ? "Combat Telekinesis equipped" : "");
        }
    }
    void drop(bool stop=true) {
        cancelFinisher();
        for(auto& item:orbitItems) if(auto ref=item.ref.get(); ref && sameWorld(ref.get())) velocity(ref.get(),{},nullptr,true);
        orbitItems.clear(); orbitSession=false; orbitPhase=orbitSearchAge=0; heldSlot=0;
        chargeSound.Stop(); chargeStep=-1;
        if(auto ref=held.get()) {
            if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) missile->Kill();
            else if(stop) velocity(ref.get(),{},nullptr,true);
            if(auto* a=ref->As<RE::Actor>(); a && holdSpell) {
                if(auto* player=RE::PlayerCharacter::GetSingleton()) {
                    RE::ActorHandle actorCaster{player};
                    a->AsMagicTarget()->DispelEffect(holdSpell,actorCaster);
                }
            }
        }
        missile_hold::clear(); projectileCaster={}; projectileSpell=0;
        held={}; pendingWeapon={}; pendingWeaponTime=0; holdWorld=nullptr; charged=0; execDown=false; pulling=false; pushing=false; recalledWeapon=false; grasp={};
        ignoreInitialShift=false; castingShift=false;
        gripInput=RE::BSFixedString(); slamDown=false;
        castingInput=RE::BSFixedString(); castingHeld=false; finisherInput=RE::BSFixedString();
    }
    void reset() { dismember::pending.clear(); drop(); shiftLeft=false; shiftRight=false; flights.clear(); previousTargets.clear(); executions.clear(); objectCache.clear(); actorCache.clear(); cacheWorld=nullptr;
        slowSelection={}; stickyTarget={}; stickyAge=100; searchAge=cacheAge=100; xpCooldown.clear(); reactionCooldown.clear();
        equipHint={}; hintVisible=false; lastThrownWeapon={}; grip_hud::publish({});
        settings::cancelRebind(); last=Clock::now(); }
    bool allowed(RE::Actor* a) const {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || (a->IsDead() && !cfg.corpses) || a->IsChild() || a->IsEssential() ||
            (cfg.protect && a->IsProtected()) || a->IsInKillMove() || a->GetScale()>cfg.maxScale ||
            a->HasKeywordString("ActorTypeDragon") || a->HasKeywordString("ActorTypeGiant")) return false;
        auto* race=a->GetRace();
        auto extent=vec(a->GetBoundMax())-vec(a->GetBoundMin());
        if(!race || !finite(extent) || extent.z>cfg.maxHeight ||
           std::max({extent.x,extent.y,extent.z})>cfg.maxExtent) return false;
        if(a->HasKeywordString("ActorTypeUndead")) return cfg.undead;
        return a->HasKeywordString("ActorTypeNPC") || cfg.creatures;
    }
    Vec aim() const {
        auto* camera=RE::PlayerCamera::GetSingleton();
        if(camera && camera->cameraRoot) {
            auto& r=camera->cameraRoot->world.rotate;
            return unit({r.entry[0][1],r.entry[1][1],r.entry[2][1]});
        }
        return {0,1,0};
    }
    float actualCost(float amount) const {
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(cfg.costPerks && controlSpell) {
            amount=enchantmentCost(amount,p->AsActorValueOwner()->GetActorValue(RE::ActorValue::kAlterationModifier));
            // Same argument order as native MagicItem::CalculateCost; do not use the zero-cost spell's calculated cost.
            RE::BGSEntryPoint::HandleEntryPoint(RE::BGSEntryPoint::ENTRY_POINT::kModSpellCost,p,controlSpell,&amount);
        }
        return std::isfinite(amount) ? std::clamp(amount,0.f,10000.f) : 10000.f;
    }
    bool spend(float amount,float* chargedCost=nullptr) {
        amount=actualCost(amount);
        auto* values=RE::PlayerCharacter::GetSingleton()->AsActorValueOwner();
        if(values->GetActorValue(RE::ActorValue::kMagicka)<amount) return false;
        values->DamageActorValue(RE::ActorValue::kMagicka,amount);
        if(chargedCost) *chargedCost=amount;
        return true;
    }
    void experience(RE::Actor* target,float amount,bool allowDead=false) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(!target || (!allowDead && target->IsDead()) || target==p || target->IsChild() || target->IsEssential() || (cfg.protect && target->IsProtected()) ||
           !target->IsHostileToActor(p) || cfg.xpScale<=0) return;
        auto id=target->GetFormID(); auto old=xpCooldown.find(id);
        if(old!=xpCooldown.end() && combatTime-old->second<2) return;
        float award=budgetedXP(amount*cfg.xpScale,xpBudget); if(award<=0) return;
        xpCooldown[id]=combatTime;
        p->AddSkillExperience(RE::ActorValue::kAlteration,award);
    }
    float physicalDamage(RE::Actor* target,float amount,WeaponStyle style) const {
        float rating=0;
        if(cfg.armor) rating=target->AsActorValueOwner()->GetActorValue(RE::ActorValue::kDamageResist);
        float diff=1;
        if(cfg.difficulty) {
            static constexpr const char* names[]{"fDiffMultHPByPCVE","fDiffMultHPByPCE","fDiffMultHPByPCN",
                "fDiffMultHPByPCH","fDiffMultHPByPCVH","fDiffMultHPByPCL"};
            static constexpr float fallback[]{2.f,1.5f,1.f,.75f,.5f,.25f};
            int index=std::clamp(RE::PlayerCharacter::GetSingleton()->GetGameStatsData().difficulty,0,5);
            diff=fallback[index];
            if(auto* setting=RE::GameSettingCollection::GetSingleton()->GetSetting(names[index]); setting && setting->GetType()==RE::Setting::Type::kFloat)
                diff=setting->GetFloat();
        }
        auto gmst=[](const char* name,float fallback) {
            auto* value=RE::GameSettingCollection::GetSingleton()->GetSetting(name);
            return value && value->GetType()==RE::Setting::Type::kFloat ? value->GetFloat() : fallback;
        };
        return mitigateObjectDamage(amount,rating,gmst("fArmorScalingFactor",.12f)*.01f,
            std::clamp(gmst("fMaxArmorRating",80.f)*.01f,0.f,.95f),penetration(style),diff,cfg.armor ? target->GetArmorBaseFactorSum() : 0.f);
    }
    void castHold(RE::Actor* a) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool refreshed=false;
        if(auto* effects=a->AsMagicTarget()->GetActiveEffectList()) for(auto* effect:*effects) {
            if(effect && effect->spell==holdSpell && !effect->flags.any(RE::ActiveEffect::Flag::kDispelled) &&
               effect->GetCasterActor().get()==p) {
                effect->duration=effect->elapsedSeconds+2.f; refreshed=true;
            }
        }
        if(refreshed) return;
        if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(holdSpell,true,a,1.f,false,1.f,p);
    }
    float hurt(RE::Actor* a,float amount) {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || a->IsDead() || a->IsChild() || a->IsEssential() ||
           (cfg.protect && a->IsProtected()) || !std::isfinite(amount) || amount<=0) return 0;
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool hostile=a->IsHostileToActor(p);
        a->StartCombat(p);
        auto* values=a->AsActorValueOwner();
        float before=values->GetActorValue(RE::ActorValue::kHealth);
        values->DamageActorValue(RE::ActorValue::kHealth,amount);
        if(hostile) experience(a,std::clamp(amount*.03f,1.f,8.f),true);
        // HandleHealthDamage is a post-damage death/attacker notification, not subtraction.
        a->HandleHealthDamage(p,amount);
        SKSE::log::info("Impact/finish {:08X}: {:.1f} damage, health {:.1f} -> {:.1f}",
            a->GetFormID(),amount,before,values->GetActorValue(RE::ActorValue::kHealth));
        return std::clamp(before-values->GetActorValue(RE::ActorValue::kHealth),0.f,amount);
    }
    void react(RE::Actor* actor,float dealt,float speed,float mass,WeaponStyle style) {
        if(!actor || actor->IsDead() || !allowed(actor) || actor->IsInRagdollState() || actor->GetHandle()==held) return;
        auto* values=actor->AsActorValueOwner();
        float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+actor->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
        float strength=survivorReaction(dealt,maximum,speed,mass,style==WeaponStyle::blunt);
        auto id=actor->GetFormID(); auto prior=reactionCooldown.find(id);
        if(strength<=0 || (prior!=reactionCooldown.end() && combatTime-prior->second<1.25)) return;
        reactionCooldown[id]=combatTime;
        auto* process=actor->GetActorRuntimeData().currentProcess;
        // Native zero-force knockdown interrupts without adding launch velocity or scripted damage.
        if(strength>=.85f && speed>=2400.f && mass>=10.f && process) process->KnockExplosion(actor,actor->GetPosition(),0.f);
        else {
            actor->SetGraphVariableFloat(RE::BSFixedString("staggerMagnitude"),strength);
            actor->NotifyAnimationGraph(RE::BSFixedString("staggerStart"));
        }
    }
    bool weak(RE::Actor* a) const {
        if(!a || a->IsDead() || !allowed(a)) return false;
        auto* values=a->AsActorValueOwner();
        float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
            a->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
        return weakened(values->GetActorValue(RE::ActorValue::kHealth),maximum,cfg.executionHealth);
    }
    void beginFinisher(const RE::BSFixedString& input) {
        auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
        if(!finisherReady(actor)) { SKSE::log::info("{}",weak(actor) ? "Crush needs more Magicka" : "Crush requires a weakened target"); return; }
        if(execDown) return;
        finisherInput=input; execDown=true; charged=0; chargeStep=-1;
        chargeSound=feedback::sound(0x3f20c,pickCenter(actor),.5f);
        SKSE::log::info("Finisher charging on {:08X}",actor->GetFormID());
    }
    bool sameWorld(RE::TESObjectREFR* ref) const {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* playerCell=p ? p->GetParentCell() : nullptr;
        auto* cell=ref ? ref->GetParentCell() : nullptr;
        auto* world=playerCell ? playerCell->GetbhkWorld() : nullptr;
        return world && cell && cell->GetbhkWorld()==world;
    }
    bool pickable(RE::TESObjectREFR* ref,bool requirePhysics=false) const {
        if(!ref || ref==RE::PlayerCharacter::GetSingleton() || !ref->Get3D() || ref->IsDisabled() || !sameWorld(ref)) return false;
        if(ref->As<RE::Actor>()) return true; // Immunities are checked before spending or changing actor state.
        auto* base=ref->GetBaseObject(); if(!base) return false;
        auto* light=base->As<RE::TESObjectLIGH>();
        return carryableType(base->GetFormType(),light && light->CanBeCarried()) &&
            (!requirePhysics || sample(ref,true).count>0);
    }
    float acquisitionRange(RE::TESObjectREFR* ref) const {
        return cfg.orbit && ref && !ref->As<RE::Actor>() ? std::min(cfg.range,cfg.orbitRange) : cfg.range;
    }
    struct Bounds { Vec low,high; };
    Bounds actorBounds(RE::Actor* actor) const {
        Vec low=vec(actor->GetBoundMin()),high=vec(actor->GetBoundMax());
        Vec center=(low+high)*.5f, position=vec(actor->GetPosition());
        // Native controller bounds are world coordinates; base-form fallback bounds are local.
        if(length(center-position)>length(high-low)+256.f) { low=low+position; high=high+position; }
        if(actor->IsDead() || actor->IsInRagdollState()) {
            auto body=sample(actor);
            if(body.count) { Vec offset=body.position-(low+high)*.5f; low=low+offset; high=high+offset; }
        }
        return {low,high};
    }
    struct Target { RE::ActorHandle ref; Bounds bounds; Vec movement{}; };
    std::vector<Target> previousTargets;
    Vec pickCenter(RE::TESObjectREFR* ref) const {
        if(auto* actor=ref->As<RE::Actor>()) { auto b=actorBounds(actor); return (b.low+b.high)*.5f; }
        auto body=sample(ref,true);
        return body.count ? body.position : vec(ref->Get3D()->worldBound.center);
    }
    void cacheCandidates() {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto* world=p->GetParentCell()->GetbhkWorld();
        if(cacheWorld==world && cacheAge<cfg.cacheInterval) return;
        objectCache.clear(); actorCache.clear(); cacheWorld=world; cacheAge=0; ++cacheScans;
        RE::TES::GetSingleton()->ForEachCell([&](RE::TESObjectCELL* cell) {
            if(cell && cell->GetbhkWorld()==world) cell->ForEachReference([&](RE::TESObjectREFR* ref) {
                if(ref && ref!=p && ref->Get3D() && !ref->IsDisabled()) {
                    if(auto* a=ref->As<RE::Actor>()) actorCache.emplace_back(a);
                    else if(pickable(ref)) objectCache.push_back(ref->GetHandle());
                }
                return RE::BSContainer::ForEachResult::kContinue;
            });
        });
    }
    bool visible(RE::TESObjectREFR* ref,Vec origin,Vec center) const {
        if(!ref || !ref->Get3D() || !sameWorld(ref)) return false;
        float lift=std::clamp(ref->Get3D()->worldBound.radius*.3f,4.f,24.f);
        for(Vec point:{center,center+Vec{0,0,lift},center+Vec{0,0,lift*.5f}}) {
            auto obstruction=ray(ref->GetParentCell(),origin,point,nullptr);
            if(!obstruction.hit || obstruction.ref.get().get()==ref) return true;
        }
        return false;
    }
    RE::NiPointer<RE::TESObjectREFR> pick(Vec origin,Vec direction) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(auto* picker=RE::CrosshairPickData::GetSingleton()) {
            for(auto handle:{picker->grabPickRef,picker->GetActiveTarget()}) {
                auto ref=handle.get();
                if(pickable(ref.get(),true)) {
                    Vec center=pickCenter(ref.get());
                    if(aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,acquisitionRange(ref.get()),cfg.aimAssist)>=0 && visible(ref.get(),origin,center)) { stickyTarget=ref->GetHandle(); stickyAge=0; return ref; }
                }
            }
        }
        auto hit=ray(p->GetParentCell(),origin,origin+direction*cfg.range,nullptr);
        auto direct=hit.ref.get();
        if(pickable(direct.get(),true) && length(pickCenter(direct.get())-origin)<=acquisitionRange(direct.get())) {
            stickyTarget=direct->GetHandle(); stickyAge=0; return direct;
        }
        // A small aim cone catches distant clutter that a single pixel-width ray misses.
        // Keep only eight candidates, then verify visibility; walls remain blockers.
        struct Candidate { RE::ObjectRefHandle ref; Vec center; float score; };
        std::vector<Candidate> candidates;
        cacheCandidates();
        auto consider=[&](RE::TESObjectREFR* ref) {
            if(!pickable(ref)) return;
            auto* scene=ref->Get3D();
            if(length(vec(scene->worldBound.center)-origin)>cfg.range+scene->worldBound.radius+500.f) return;
            Vec center=pickCenter(ref);
            float score=aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,acquisitionRange(ref),cfg.aimAssist);
            if(score<0 || !pickable(ref,true)) return;
            candidates.push_back({ref->GetHandle(),center,score});
            std::sort(candidates.begin(),candidates.end(),[](auto& a,auto& b){ return a.score<b.score; });
            if(candidates.size()>8) candidates.pop_back();
            return;
        };
        for(auto handle:objectCache) if(auto ref=handle.get()) consider(ref.get());
        for(auto handle:actorCache) if(auto ref=handle.get()) consider(ref.get());
        RE::NiPointer<RE::TESObjectREFR> best; float bestScore=INFINITY;
        for(auto& candidate:candidates) {
            auto ref=candidate.ref.get();
            if(ref && visible(ref.get(),origin,candidate.center)) { best=ref; bestScore=candidate.score; break; }
        }
        auto old=stickyTarget.get();
        if(pickable(old.get(),true)) {
            Vec center=pickCenter(old.get());
            float score=aimScore(origin,direction,center,old->Get3D()->worldBound.radius,acquisitionRange(old.get()),cfg.aimAssist);
            float graceScore=aimScore(origin,direction,center,old->Get3D()->worldBound.radius+12.f,acquisitionRange(old.get()),cfg.aimAssist+1.f);
            if(keepAimTarget(score,graceScore,bestScore,stickyAge) && visible(old.get(),origin,center)) {
                if(score>=0) stickyAge=0;
                return old;
            }
        }
        stickyTarget=best ? best->GetHandle() : RE::ObjectRefHandle{}; stickyAge=best ? 0.f : 100.f;
        return best;
    }
    bool activateProp(RE::NiPointer<RE::TESObjectREFR> ref,bool quiet=true,bool paid=false) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(!pickable(ref.get(),true)) return false;
        float chargedCost=0;
        if(!paid && !spend(cfg.grabCost,&chargedCost)) return false;
        auto before=sample(ref.get(),true);
        if(before.dormant) {
            // Actual grab only, outside our world lock. Force traversal of initially frozen root nodes.
            ref->Get3D()->SetMotionType(RE::hkpMotion::MotionType::kDynamic,true,true,true);
            ref->AddChange(RE::TESObjectREFR::ChangeFlags::kHavokMoved);
        }
        // The native velocity setter activates sleeping bodies; verify restoration before recording a grip.
        if(!velocity(ref.get(),{},nullptr,true)) {
            if(chargedCost>0) p->AsActorValueOwner()->RestoreActorValue(RE::ActorValue::kMagicka,chargedCost);
            SKSE::log::warn("Target {:08X}: native physics activation failed (dormant {})",ref->GetFormID(),before.dormant);
            if(!quiet) SKSE::log::warn("{}","Telekinesis: this object's physics could not be activated.");
            return false;
        }
        SKSE::log::info("Prop {:08X}: {} physics activated",ref->GetFormID(),before.dormant ? "dormant" : "dynamic");
        return true;
    }
    std::array<RE::ObjectRefHandle,orbitLimit> orbitHandles() const {
        std::array<RE::ObjectRefHandle,orbitLimit> result{held};
        for(std::size_t i=0;i<orbitItems.size();++i) result[i+1]=orbitItems[i].ref;
        return result;
    }
    bool grip(RE::NiPointer<RE::TESObjectREFR> ref,bool quiet=false,bool paid=false) {
        if(!ref || !ref->Get3D() || ref->IsDisabled() || !sameWorld(ref.get())) return false;
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool tracked=std::any_of(flights.begin(),flights.end(),[&](auto& f){return f.ref==ref->GetHandle();});
        costFactor=1;
        if(auto* a=ref->As<RE::Actor>()) {
            auto* process=a->GetActorRuntimeData().currentProcess;
            bool dead=a->IsDead();
            if(!allowed(a) || (dead && !sample(a).count) || (!dead && (!process ||
               a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kParalysis)>0 ||
               (a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kGrabbed)>0 && !tracked)))) {
                if(!quiet) SKSE::log::warn("{}","Target resists telekinesis."); return false;
            }
            costFactor=resistance(a->GetScale(),dead ? p->GetLevel() : a->GetLevel(),p->GetLevel(),cfg.levelFactor);
            if(!spend(cfg.grabCost*costFactor)) return false;
            if(!dead) {
                // Existing live ragdolls need suspension, not another knockdown. Corpses need neither.
                if(!a->IsInRagdollState()) process->KnockExplosion(a,a->GetPosition(),0.f);
                castHold(a); a->StartCombat(p);
            }
        } else {
            if(!activateProp(ref,quiet,paid)) return false;
        }
        std::erase_if(flights,[&](auto& f){return f.ref==ref->GetHandle();});
        held=ref->GetHandle(); holdWorld=p->GetParentCell()->GetbhkWorld(); holdAge=0; refresh=0; charged=0; recalledWeapon=false; grasp={};
        orbitSession=cfg.orbit && !ref->As<RE::Actor>(); heldSlot=0; orbitPhase=orbitSearchAge=0;
        distance=ref->As<RE::Actor>() ? cfg.distance : cfg.itemDistance;
        if(orbitSession) distance=orbitHoldDistance(distance);
        auto initial=sample(ref.get()); anchor=initial.count ? initial.position : pickCenter(ref.get());
        SKSE::log::info("Grip established on {:08X}",ref->GetFormID());
        return true;
    }

    Vec weaponAimPoint() const {
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()),direction=aim();
        auto* player=RE::PlayerCharacter::GetSingleton(); auto ref=held.get(); auto ignored=orbitHandles();
        auto hit=ray(player->GetParentCell(),origin,origin+direction*cfg.range,ref.get(),ignored);
        return origin+direction*(hit.hit ? cfg.range*hit.fraction : cfg.range);
    }
    float footprint(RE::TESObjectREFR* ref) const {
        auto state=sample(ref,true);
        auto* base=ref ? ref->GetBaseObject() : nullptr;
        auto* weapon=base ? base->As<RE::TESObjectWEAP>() : nullptr;
        if(cfg.orient && weapon && aimableMeleeType(weapon->GetWeaponType())) {
            // shortcut: stock record bounds/axes approximate the footprint; custom meshes need calibration.
            auto& b=base->boundData;
            float width=static_cast<float>(b.boundMax.x-b.boundMin.x)*.5f;
            float height=static_cast<float>(b.boundMax.z-b.boundMin.z)*.5f;
            if(width>0 && height>0) return std::sqrt(width*width+height*height)*ref->GetScale();
        }
        return length(state.halfExtent);
    }
    float requiredOrbitRadius(RE::TESObjectREFR* candidate=nullptr) const {
        float first=0,second=0;
        auto include=[&](RE::TESObjectREFR* ref) {
            if(!ref) return;
            float radius=footprint(ref);
            if(radius>first) { second=first; first=radius; } else second=std::max(second,radius);
        };
        if(auto ref=held.get()) include(ref.get());
        for(auto& item:orbitItems) if(auto ref=item.ref.get()) include(ref.get());
        include(candidate);
        return (first+second+8.f)/1.73205080757f;
    }
    float visibleDepth(RE::TESObjectREFR* ref,float requested) const {
        // Keep a long blade's rear end clear of the near camera plane.
        auto* base=ref ? ref->GetBaseObject() : nullptr;
        auto* weapon=base ? base->As<RE::TESObjectWEAP>() : nullptr;
        if(cfg.orient && weapon && aimableMeleeType(weapon->GetWeaponType())) {
            auto& b=base->boundData;
            float half=static_cast<float>(b.boundMax.y-b.boundMin.y)*.5f*ref->GetScale();
            requested=std::max(requested,std::min(220.f,half+85.f));
        }
        return requested;
    }
    void updateOrbit(float dt,Vec weaponTarget) {
        if(!orbitSession) return;
        if(!cfg.orbit || !held || !usable()) { drop(); return; }
        orbitPhase=std::fmod(orbitPhase+cfg.orbitSpeed*dt,6.28318530718f); orbitSearchAge+=dt;
        auto* player=RE::PlayerCharacter::GetSingleton();
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()),direction=aim();
        auto* camera=RE::PlayerCamera::GetSingleton();
        float needed=requiredOrbitRadius();
        distance=orbitHoldDistance(std::max(distance,std::min(60.f,needed)/.28f));
        if(auto ref=held.get()) distance=visibleDepth(ref.get(),distance);
        float radius=orbitSpacing(0,0,cfg.orbitRadius,distance);
        orbitSpacingRadius=std::max(radius,std::min(60.f,needed));
        float depth=itemRayDistance(origin,direction,vec(player->GetPosition()),orbitHoldDistance(distance),camera && camera->IsInThirdPerson());
        auto ignored=orbitHandles();
        for(auto it=orbitItems.begin();it!=orbitItems.end();) {
            auto ref=it->ref.get();
            if(!ref || !pickable(ref.get()) || ref->As<RE::Actor>()) {
                if(ref && sameWorld(ref.get())) velocity(ref.get(),{},nullptr,true);
                it=orbitItems.erase(it); continue;
            }
            auto state=sample(ref.get());
            if(!state.count || !finite(state.position) || !finite(state.velocity) || length(state.position-origin)>cfg.range*2.f+cfg.maxDistance) {
                velocity(ref.get(),{},nullptr,true); it=orbitItems.erase(it); continue;
            }
            if(!spend(cfg.holdCost*dt)) { drop(); return; }
            Vec goal=origin+direction*depth+orbitOffset(direction,orbitPhase,it->slot,orbitSpacingRadius,orbitHoldDistance(distance));
            auto wall=ray(player->GetParentCell(),origin,goal,ref.get(),ignored);
            if(wall.hit) goal=origin+(goal-origin)*std::max(0.f,wall.fraction-30.f/std::max(1.f,length(goal-origin)));
            it->grasp.update(state.position,state.velocity,goal,dt);
            Vec previous=it->anchor;
            float speedLimit=length(state.position-goal)>200.f ? cfg.pickupSpeed : cfg.holdSpeed;
            auto next=gripAnchor(previous,goal,speedLimit,dt,length(state.position-goal)>200.f);
            auto blocked=ray(ref->GetParentCell(),state.position,next,ref.get(),ignored);
            if(blocked.hit) next=state.position+unit(next-state.position)*std::max(0.f,length(next-state.position)*blocked.fraction-30.f);
            it->anchor=next;
            Vec facing=unit(weaponTarget-state.position);
            if(!velocity(ref.get(),holdVelocity(previous,next,state.position,dt,cfg.gain,speedLimit),&facing,true,dt)) { it=orbitItems.erase(it); continue; }
            ++it;
        }
        // Only gather while actively casting. Released shots never refill the orbit on their own.
        if(!castingHeld || orbitItems.size()>=static_cast<std::size_t>(orbitLimit-1) || orbitSearchAge<.4f ||
           player->AsActorValueOwner()->GetActorValue(RE::ActorValue::kMagicka)<actualCost(cfg.grabCost)) return;
        // Settle the existing formation before pulling another body through it.
        auto primary=held.get(); auto primaryState=sample(primary.get());
        if(!grasp.ready || !primaryState.count || length(primaryState.position-anchor)>30.f || length(primaryState.velocity)>400.f) return;
        orbitSearchAge=0; cacheCandidates();
        RE::NiPointer<RE::TESObjectREFR> chosen; float best=INFINITY;
        for(auto handle:objectCache) if(auto ref=handle.get(); ref && ref->Get3D() && pickable(ref.get())) {
            if(handle==held || std::any_of(orbitItems.begin(),orbitItems.end(),[&](auto& item){return item.ref==handle;}) ||
               std::any_of(flights.begin(),flights.end(),[&](auto& flight){return flight.ref==handle;})) continue;
            if(length(vec(ref->Get3D()->worldBound.center)-origin)>cfg.orbitRange+ref->Get3D()->worldBound.radius+100.f) continue;
            auto state=sample(ref.get(),true); if(!state.count) continue;
            float score=aimScore(origin,direction,state.position,ref->Get3D()->worldBound.radius,std::min(cfg.range,cfg.orbitRange),10.f);
            if(score<0 || score>=best || requiredOrbitRadius(ref.get())>60.f) continue;
            auto wall=ray(player->GetParentCell(),origin,state.position,ref.get(),ignored);
            if(wall.hit) continue;
            chosen=ref; best=score;
        }
        if(!chosen || !activateProp(chosen)) return;
        int slot=0;
        while(slot<orbitLimit && (slot==heldSlot || std::any_of(orbitItems.begin(),orbitItems.end(),[&](auto& item){return item.slot==slot;}))) ++slot;
        auto state=sample(chosen.get());
        orbitItems.push_back({chosen->GetHandle(),state.position,slot});
        feedback::sound(0x53a5d,state.position,.6f);
        SKSE::log::info("Orbit acquired {:08X} in slot {}; {} items",chosen->GetFormID(),slot,orbitItems.size()+1);
    }
    Vec weaponPoint(RE::Actor* actor,RE::TESObjectWEAP* weapon,bool left) const {
        auto bounds=actorBounds(actor); Vec point=(bounds.low+bounds.high)*.5f;
        if(auto* hand=actor->Get3D()->GetObjectByName(RE::BSFixedString(left ? "NPC L Hand [LHnd]" : "NPC R Hand [RHnd]")))
            point=vec(hand->world.translate);
        // Choose the equipped mesh closest to that hand, including identical dual-wielded base forms.
        if(auto& biped=actor->GetBiped(); biped) {
            float closest=300.f; const Vec handPoint=point;
            for(auto& part:biped->objects) if(part.item==weapon && part.partClone) {
                auto center=vec(part.partClone->worldBound.center); float d=length(center-handPoint);
                if(finite(center) && d<closest) { closest=d; point=center; }
            }
        }
        return point;
    }
    Selection findWeapon(Vec origin,Vec direction) {
        struct Choice { RE::ActorHandle actor; RE::FormID weapon{}; bool left{}; Vec point{}; float score{}; };
        cacheCandidates();
        auto* p=RE::PlayerCharacter::GetSingleton();
        std::vector<Choice> choices;
        for(auto handle:actorCache) if(auto actor=handle.get(); actor && actor->Get3D() && sameWorld(actor.get()) && !actor->IsDisabled()) {
            if(actor->IsDead() || !allowed(actor.get()) || !actor->IsHostileToActor(p) ||
               !actor->AsActorState()->IsWeaponDrawn()) continue;
            auto bounds=actorBounds(actor.get());
            float bodyScore=aimScore(origin,direction,(bounds.low+bounds.high)*.5f,32,cfg.disarmRange,cfg.aimAssist);
            for(bool left:{false,true}) {
                auto* entry=actor->GetEquippedEntryData(left);
                auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
                if(!weapon || weapon->IsBound() || weapon->IsHandToHandMelee() || entry->IsQuestObject()) continue;
                Vec point=weaponPoint(actor.get(),weapon,left);
                float score=aimScore(origin,direction,point,32,cfg.disarmRange,cfg.aimAssist);
                // Direct weapon aim wins; aiming at its wielder is a fallback, with right-hand priority.
                if(score<0 && bodyScore>=0 && length(point-origin)<=cfg.disarmRange) score=2.f+bodyScore+(left ? .1f : 0.f);
                if(score>=0) choices.push_back({handle,weapon->GetFormID(),left,point,score});
            }
        }
        std::sort(choices.begin(),choices.end(),[](auto& a,auto& b){return a.score<b.score;});
        for(auto& choice:choices) {
            auto actor=choice.actor.get(); if(!actor) continue;
            auto obstruction=ray(p->GetParentCell(),origin,choice.point,nullptr);
            if(obstruction.hit && obstruction.ref.get().get()!=actor.get()) continue;
            auto* entry=actor->GetEquippedEntryData(choice.left);
            auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
            if(!weapon || weapon->GetFormID()!=choice.weapon || entry->IsQuestObject() || weapon->IsBound()) continue;
            RE::ExtraDataList* extra=nullptr;
            if(entry->extraLists) for(auto* list:*entry->extraLists) if(list &&
                (choice.left ? list->HasType<RE::ExtraWornLeft>() : list->HasType<RE::ExtraWorn>())) { extra=list; break; }
            // Never substitute a different enchanted/tempered copy if the worn instance is ambiguous.
            if(!extra) continue;
            return {Mode::disarm,actor->GetHandle(),choice.weapon,choice.left};
        }
        return {};
    }
    bool disarm(const Selection& selection,bool quiet) {
        auto actorRef=selection.ref.get(); auto* a=actorRef ? actorRef->As<RE::Actor>() : nullptr;
        if(!a || !a->Get3D() || !sameWorld(a) || !allowed(a) || a->IsDead() || a->IsDisabled()) return false;
        RE::NiPointer<RE::Actor> actor{a}; auto* p=RE::PlayerCharacter::GetSingleton();
        if(!a->IsHostileToActor(p) || !a->AsActorState()->IsWeaponDrawn()) return false;
        auto* entry=a->GetEquippedEntryData(selection.left);
        auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
        if(!weapon || weapon->GetFormID()!=selection.weapon || entry->IsQuestObject() || weapon->IsBound()) return false;
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()),point=weaponPoint(a,weapon,selection.left);
        if(length(point-origin)>cfg.disarmRange) return false;
        auto wall=ray(p->GetParentCell(),origin,point,nullptr); if(wall.hit && wall.ref.get().get()!=a) return false;
        RE::ExtraDataList* extra=nullptr;
        if(entry->extraLists) for(auto* list:*entry->extraLists) if(list &&
            (selection.left ? list->HasType<RE::ExtraWornLeft>() : list->HasType<RE::ExtraWorn>())) { extra=list; break; }
        if(!extra) return false;
        float paidCost=0;
        float cost=cfg.disarmCost*resistance(actor->GetScale(),actor->GetLevel(),p->GetLevel(),cfg.levelFactor);
        if(!spend(cost,&paidCost)) {
            if(!quiet) SKSE::log::warn("{}","Not enough Magicka to disarm this enemy.");
            return true;
        }
        auto location=ni(point+unit(origin-point)*20.f+Vec{0,0,8});
        // Drop exactly the worn instance; native DropObject handles unequipping and inventory removal.
        auto dropped=actor->DropObject(weapon,extra,1,&location,nullptr);
        if(!dropped) {
            p->AsActorValueOwner()->RestoreActorValue(RE::ActorValue::kMagicka,paidCost);
            if(!quiet) SKSE::log::warn("{}","That weapon could not be disarmed.");
            return true;
        }
        experience(actor.get(),6.f); feedback::sound(0x53a5d,point);
        cacheAge=100; searchAge=100;
        pendingWeapon=dropped; pendingWeaponTime=1.5f;
        SKSE::log::info("Disarm {:08X}: worn weapon {:08X} -> loose ref; waiting for physics",actor->GetFormID(),selection.weapon);
        return true;
    }
    RE::NiPointer<RE::TESObjectREFR> nearestObject() {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto b=actorBounds(p); Vec origin=(b.low+b.high)*.5f;
        cacheCandidates();
        float radius=cfg.orbit ? std::min(cfg.nearbyRadius,cfg.orbitRange) : cfg.nearbyRadius;
        RE::NiPointer<RE::TESObjectREFR> closest; float bestDistance=radius;
        for(auto handle:objectCache) if(auto ref=handle.get(); ref && pickable(ref.get())) {
            if(length(vec(ref->Get3D()->worldBound.center)-origin)>radius+ref->Get3D()->worldBound.radius+100.f) continue;
            auto body=sample(ref.get(),true); if(!body.count) continue;
            float score=nearbyScore(origin,body.position,radius);
            if(score<0 || score>bestDistance) continue;
            auto obstruction=ray(p->GetParentCell(),origin,body.position,ref.get());
            if(!obstruction.hit) { closest=ref; bestDistance=score; }
        }
        return closest;
    }
    RE::ObjectRefHandle findMissile(RE::ObjectRefHandle only={}) {
        if(!cfg.catchProjectiles) return {};
        auto* manager=RE::Projectile::Manager::GetSingleton();
        auto* player=RE::PlayerCharacter::GetSingleton();
        if(!manager) return {};
        std::vector<RE::ProjectileHandle> candidates;
        {
            RE::BSSpinLockGuard lock(manager->projectileLock);
            for(auto& list:{&manager->limited,&manager->unlimited})
                for(auto handle:*list) candidates.push_back(handle);
        }
        auto bounds=actorBounds(player); Vec center=(bounds.low+bounds.high)*.5f;
        RE::NiPointer<RE::Projectile> closest; float best=INFINITY;
        for(auto handle:candidates) if(auto projectile=handle.get()) {
            if(only && projectile->GetHandle()!=only) continue;
            auto* missile=projectile->As<RE::MissileProjectile>();
            if(!missile || !missile->Get3D() || missile->IsDisabled() || !sameWorld(missile)) continue;
            auto& data=missile->GetProjectileRuntimeData();
            auto* base=missile->GetProjectileBase();
            auto shooter=data.shooter.get(); auto* caster=shooter ? shooter->As<RE::Actor>() : nullptr;
            if(!caster || caster==player || !caster->IsHostileToActor(player) || !catchableProjectile(missile,base)) continue;
            Vec position=vec(missile->GetPosition()), speed=vec(data.linearVelocity);
            float score=predictedMissileScore(center,position,speed,cfg.projectileRadius,cfg.predictionSeconds,cfg.threatRadius,lastPoll);
            if(score<0 || score>=best) continue;
            Vec eye=vec(RE::PlayerCamera::GetActiveCameraPosition());
            auto obstruction=ray(player->GetParentCell(),eye,position,missile);
            if(obstruction.hit) continue;
            best=score; closest=projectile;
        }
        return closest ? closest->GetHandle() : RE::ObjectRefHandle{};
    }
    bool catchMissile(RE::ObjectRefHandle selected,bool quiet) {
        if(findMissile(selected)!=selected || !selected) return false;
        auto ref=selected.get(); auto* missile=ref ? ref->As<RE::MissileProjectile>() : nullptr;
        if(!missile) return false;
        auto* player=RE::PlayerCharacter::GetSingleton(); auto& data=missile->GetProjectileRuntimeData();
        float paid=0;
        if(!spend(cfg.projectileCost,&paid)) {
            if(!quiet) SKSE::log::warn("{}","Not enough Magicka to catch this projectile.");
            return true;
        }
        bool captured=false;
        {
            RE::BSSpinLockGuard lock(data.unk0E8);
            captured=catchableProjectile(missile,missile->GetProjectileBase());
            if(captured) {
                projectileCaster=data.shooter; projectileSpell=data.spell ? data.spell->GetFormID() : 0;
                projectilePower=data.power; projectileScale=data.scale; projectileSpeed=length(vec(data.linearVelocity));
                // Suppression starts before moving the reference; callbacks touch no controller pointers.
                missile_hold::suspend(missile); data.linearVelocity={}; data.velocity={}; data.desiredTarget={};
            }
        }
        if(!captured) { player->AsActorValueOwner()->RestoreActorValue(RE::ActorValue::kMagicka,paid); return false; }
        held=missile->GetHandle(); holdWorld=player->GetParentCell()->GetbhkWorld();
        holdAge=0; refresh=0; charged=0; grasp={}; costFactor=1; distance=cfg.itemDistance; anchor=vec(missile->GetPosition());
        if(auto shooter=projectileCaster.get()) experience(shooter->As<RE::Actor>(),5.f);
        feedback::sound(0x53a5d,anchor);
        SKSE::log::info("Caught missile {:08X}, source spell {:08X}; release to return",missile->GetFormID(),projectileSpell);

        return true;
    }
    void holdMissile(RE::MissileProjectile* missile,float dt) {
        auto* player=RE::PlayerCharacter::GetSingleton();
        if(!missile_hold::matches(missile) || missile->IsDisabled() || !missile->Get3D() || !sameWorld(missile) ||
           missile->GetProjectileRuntimeData().flags.any(RE::Projectile::Flags::kDestroyed) ||
           holdAge>=cfg.projectileHoldSeconds || !spend(cfg.holdCost*dt)) { drop(); return; }
        distance=std::clamp(distance+((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt,cfg.minDistance,cfg.maxDistance);
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
        auto* camera=RE::PlayerCamera::GetSingleton();
        float reach=itemRayDistance(origin,direction,vec(player->GetPosition()),distance,camera && camera->IsInThirdPerson());
        auto wall=ray(player->GetParentCell(),origin,origin+direction*reach,missile);
        Vec goal=origin+direction*(wall.hit ? std::max(0.f,reach*wall.fraction-50.f) : reach);
        auto next=advanceAnchor(anchor,goal,cfg.pickupSpeed,dt);
        auto obstacle=ray(player->GetParentCell(),anchor,next,missile);
        if(obstacle.hit) next=anchor+(next-anchor)*std::max(0.f,obstacle.fraction-.05f);
        grasp.update(next,dt>0 ? (next-anchor)*(1.f/dt) : Vec{},goal,dt);
        anchor=next;
        missile->SetPosition(ni(anchor));
        // Native missile movement writes the root's local translation from reference position.
        // Update3D then publishes world transforms. No Havok prop controller is used here.
        missile->Get3D()->local.translate=ni(anchor); missile->Update3D();
    }
    void returnMissile(RE::MissileProjectile* missile) {
        auto* player=RE::PlayerCharacter::GetSingleton();
        auto* arrow=missile->As<RE::ArrowProjectile>();
        auto& original=missile->GetProjectileRuntimeData();
        auto* spell=RE::TESForm::LookupByID<RE::SpellItem>(projectileSpell);
        if(arrow ? (!original.ammoSource || !original.weaponSource || !std::isfinite(original.weaponDamage) || original.weaponDamage<=0 ||
            original.ammoSource->GetRuntimeData().data.projectile!=missile->GetProjectileBase()) :
            (!spell || !spell->GetAVEffect() || spell->GetAVEffect()->data.projectileBase!=missile->GetProjectileBase())) { drop(); return; }
        if(!spend(cfg.launchCost)) { drop(); return; }
        Vec origin=vec(missile->GetPosition()), direction=aim();
        if(cfg.returnMode==0) if(auto ref=projectileCaster.get()) if(auto* caster=ref->As<RE::Actor>(); caster && !caster->IsDead() &&
            !caster->IsDisabled() && caster->Get3D() && sameWorld(caster)) {
            auto bounds=actorBounds(caster); Vec target=(bounds.low+bounds.high)*.5f;
            auto obstruction=ray(player->GetParentCell(),origin,target,missile);
            if(!obstruction.hit || obstruction.ref.get().get()==caster) direction=unit(target-origin);
        }
        if(!finite(direction) || length(direction)<.5f) { drop(); return; }
        auto angles=missileAngles(direction);
        RE::Projectile::LaunchData launch(missile->GetProjectileBase(),player,ni(origin),{angles.x,angles.z});
        launch.useOrigin=true; launch.autoAim=false;
        launch.power=projectilePower; launch.scale=projectileScale;
        if(arrow) {
            launch.ammoSource=original.ammoSource; launch.weaponSource=original.weaponSource;
            launch.enchantItem=arrow->GetArrowRuntimeData().enchantItem;
            launch.poison=arrow->GetArrowRuntimeData().poison;
        } else {
            launch.spell=spell;
            auto* effect=spell->GetCostliestEffectItem(); launch.area=effect ? effect->GetArea() : 0;
        }
        float speed=projectileSpeed, damage=original.weaponDamage;
        // Remove the suspended hostile body before spawning its player-owned replacement.
        drop();
        RE::ProjectileHandle result; RE::Projectile::Launch(&result,launch);
        if(auto returned=result.get()) {
            auto& data=returned->GetProjectileRuntimeData();
            data.speedMult=1.f;
            float multiplier=projectileSpeedRatio(returned->GetSpeed(),speed);
            if(multiplier<=0) { returned->Kill(); SKSE::log::warn("Invalid return speed; replacement dissipated safely."); return; }
            data.speedMult=multiplier;
            data.linearVelocity=ni(direction*speed); data.desiredTarget={};
            if(arrow) data.weaponDamage=damage; // Preserve the incoming shot, not the player's bow perks.
            SKSE::log::info("Returned {} as projectile {:08X}",arrow ? "ammunition" : "spell",returned->GetFormID());
        } else SKSE::log::warn("Projectile return failed; original dissipated safely.");
    }
    void recallWeapon() {
        if(held || pendingWeapon || !usable()) return;
        auto ref=lastThrownWeapon.get();
        auto* base=ref ? ref->GetBaseObject() : nullptr;
        if(!base || !base->As<RE::TESObjectWEAP>() || ref->IsDeleted()) {
            lastThrownWeapon={}; SKSE::log::info("Recall: no valid last thrown weapon"); return;
        }
        if(!pickable(ref.get(),true)) {
            SKSE::log::info("Recall {:08X}: physics unavailable/disabled or another world; history retained",ref->GetFormID()); return;
        }
        Vec eye=vec(RE::PlayerCamera::GetActiveCameraPosition()), point=pickCenter(ref.get());
        if(!recallReach(eye,point) || !visible(ref.get(),eye,point)) {
            SKSE::log::info("Recall {:08X}: invalid position or blocked path",ref->GetFormID()); return;
        }
        if(!grip(ref)) { SKSE::log::info("Recall {:08X}: insufficient Magicka or activation failed",ref->GetFormID()); return; }
        // Recalled grips have no distance cutoff; world/physics checks and swept walls still apply.
        recalledWeapon=true; ignoreInitialShift=true; slamDown=false;
        castingHeld=false; castingInput=RE::BSFixedString();
        auto* user=RE::UserEvents::GetSingleton(); auto* player=RE::PlayerCharacter::GetSingleton();
        gripInput=player->GetEquippedObject(true)==controlSpell ? user->leftAttack : user->rightAttack;
        feedback::sound(0x53a5d,point,.6f);
        SKSE::log::info("Recalled weapon {:08X}",ref->GetFormID());
    }
    Selection selectTarget(bool shift,bool force=false) {
        if(force || searchAge>=cfg.searchInterval || shift!=selectionShift) {
            if(shift!=selectionShift) { stickyTarget={}; stickyAge=100; }
            searchAge=0; selectionShift=shift;
            Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition());
            slowSelection=shift ? findWeapon(origin,aim()) : Selection{};
            if(slowSelection.mode==Mode::none) {
                auto ref=shift ? nearestObject() : pick(origin,aim());
                slowSelection=ref ? Selection{Mode::grab,ref->GetHandle()} : Selection{};
            }
        }
        if(shift && slowSelection.mode!=Mode::disarm) if(auto missile=findMissile()) return {Mode::catchSpell,missile};
        return slowSelection;
    }
    float selectionCost(const Selection& selection) const {
        auto ref=selection.ref.get(); float amount=cfg.grabCost;
        if(selection.mode==Mode::catchSpell) amount=cfg.projectileCost;
        if(selection.mode==Mode::disarm) amount=cfg.disarmCost;
        if(auto* a=ref ? ref->As<RE::Actor>() : nullptr; a && !a->IsDead())
            amount*=resistance(a->GetScale(),a->GetLevel(),RE::PlayerCharacter::GetSingleton()->GetLevel(),cfg.levelFactor);
        return actualCost(amount);
    }
    void targetPreview() {
        if(!cfg.preview || !usable() || pendingWeapon) return;
        auto selected=held ? Selection{Mode::grab,held} : selectTarget(shiftLeft || shiftRight);
        auto ref=selected.ref.get();
        bool rejected=false; RE::NiAVObject* node=nullptr;
        if(ref && ref->Get3D() && !ref->IsDisabled() && sameWorld(ref.get())) {
            auto* actor=ref->As<RE::Actor>();
            auto* weapon=selected.weapon ? RE::TESForm::LookupByID<RE::TESObjectWEAP>(selected.weapon) : nullptr;
            if(selected.mode==Mode::disarm && actor && weapon) {
                // Attach only to the selected worn mesh, rather than lighting the whole wielder.
                if(auto& biped=actor->GetBiped(); biped) {
                    float best=INFINITY; Vec point=weaponPoint(actor,weapon,selected.left);
                    for(auto& part:biped->objects) if(part.item==weapon && part.partClone) {
                        float d=length(vec(part.partClone->worldBound.center)-point);
                        if(d<best) { best=d; node=part.partClone.get(); }
                    }
                }
            }
            if(actor && !allowed(actor)) rejected=true;
            else if(!held && selectionCost(selected)>RE::PlayerCharacter::GetSingleton()->AsActorValueOwner()->GetActorValue(RE::ActorValue::kMagicka)) rejected=true;
            else if(actor && !actor->IsDead() && selected.mode==Mode::grab && !held &&
                (actor->AsActorValueOwner()->GetActorValue(RE::ActorValue::kParalysis)>0 || actor->AsActorValueOwner()->GetActorValue(RE::ActorValue::kGrabbed)>0)) rejected=true;
            else if(!actor && selected.mode==Mode::grab && !pickable(ref.get(),true)) rejected=true;
            // Do not stack continuously while held or shade the entire actor for an unavailable weapon mesh.
            if(!held && (selected.mode!=Mode::disarm || node)) {
                bool object=selected.mode==Mode::disarm || (!actor && selected.mode==Mode::grab);
                feedback::shader(ref.get(),previewShader(object,rejected),.18f,object && !node ? ref->Get3D() : node);
            }
        }
    }
    void grab(bool quiet=false,bool shift=false) {
        if(held || pendingWeapon) { drop(); return; }
        auto selected=selectTarget(shift,true);
        if(selected.mode==Mode::disarm) { disarm(selected,quiet); return; }
        if(selected.mode==Mode::catchSpell) { catchMissile(selected.ref,quiet); return; }
        auto ref=selected.ref.get();
        if(!ref || !pickable(ref.get(),true)) {
            if(!quiet) SKSE::log::info("No eligible target in view");
            return;
        }
        auto* player=RE::PlayerCharacter::GetSingleton(); auto playerBounds=actorBounds(player);
        Vec origin=shift ? (playerBounds.low+playerBounds.high)*.5f : vec(RE::PlayerCamera::GetActiveCameraPosition());
        Vec point=pickCenter(ref.get());
        if(length(point-origin)>std::min(shift ? cfg.nearbyRadius : cfg.range,acquisitionRange(ref.get()))) return;
        if(!visible(ref.get(),origin,point)) return;
        if(grip(ref,quiet)) feedback::sound(0x53a5d,point,.6f);
    }
    void launch(bool slam) {
        auto ref=held.get(); if(!ref) return;
        if(!ref->As<RE::Actor>() && !grasp.ready) {
            SKSE::log::info("Release before full grasp: dropping {:08X}",ref->GetFormID());
            drop(); return;
        }
        if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) { returnMissile(missile); return; }
        auto launchState=sample(ref.get()); if(!launchState.count) return;
        if(auto* a=ref->As<RE::Actor>(); a && !a->IsDead() && !a->IsInRagdollState()) return;
        if(static_cast<int>(flights.size())>=cfg.maxFlights) { SKSE::log::warn("{}","Too many objects in flight."); return; }
        bool actor=ref->As<RE::Actor>()!=nullptr;
        float launchSpeed=actor ? cfg.actorLaunchSpeed : cfg.launchSpeed;
        float slamSpeed=actor ? cfg.actorSlamSpeed : cfg.slamSpeed;
        Vec direction=aim();
        if(orbitSession && !slam) {
            Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition());
            auto ignored=orbitHandles();
            auto hit=ray(ref->GetParentCell(),origin,origin+direction*cfg.range,ref.get(),ignored);
            float targetDistance=hit.hit ? cfg.range*hit.fraction : cfg.range;
            if(targetDistance<80.f) { SKSE::log::warn("{}","Orbit throw blocked: aim farther from the wall."); return; }
            // Converge from the ring to the exact crosshair ray; never home toward an actor.
            direction=crosshairLaunchDirection(launchState.position,origin,direction,targetDistance);
        }
        Vec speed=slam ? Vec{0,0,-slamSpeed} : direction*launchSpeed;
        Vec launchDirection=unit(speed);
        if(!finite(launchDirection) || length(launchDirection)<.5f || !spend(cfg.launchCost*costFactor)) return;
        if(!velocity(ref.get(),speed,actor ? nullptr : &launchDirection)) { drop(); return; }
        auto s=sample(ref.get());
        float mass=actor ? 0.f : std::clamp(ref->GetWeight(),cfg.objectMassFloor,cfg.massCap);
        flights.push_back({held,s.position,speed,s.halfExtent,mass,actor ? cfg.actorFlightSeconds : cfg.flightSeconds,0,0,s.position.z,slam,false});
        if(auto* weapon=ref->GetBaseObject()->As<RE::TESObjectWEAP>()) {
            lastThrownWeapon=held;
            flights.back().baseDamage=static_cast<float>(weapon->GetAttackDamage());
            flights.back().style=weapon->IsOneHandedDagger() ? WeaponStyle::dagger :
                (weapon->IsOneHandedMace() || weapon->HasKeywordString("WeapTypeWarhammer")) ? WeaponStyle::blunt :
                weapon->IsRanged() ? WeaponStyle::ranged : WeaponStyle::blade;
        }
        cancelFinisher(); searchAge=100;
        feedback::sound(0x53a5e,s.position,.8f);
        if(!actor) SKSE::log::info("Prop launch {:08X}: speed {:.1f}, half extents {:.1f}/{:.1f}/{:.1f}",
            ref->GetFormID(),length(speed),s.halfExtent.x,s.halfExtent.y,s.halfExtent.z);
        // Keep the brief grabbed-state effect for the flight; it expires on its own.
        charged=0; execDown=false; pulling=false; pushing=false; slamDown=false; recalledWeapon=false; grasp={};
        if(orbitSession && !orbitItems.empty()) {
            auto next=orbitItems.front(); orbitItems.erase(orbitItems.begin());
            held=next.ref; anchor=next.anchor; heldSlot=next.slot; grasp=next.grasp; holdAge=0; costFactor=1;
        } else {
            held={}; holdWorld=nullptr; orbitSession=false; gripInput=RE::BSFixedString();
        }
    }
    void execute(RE::Actor* a) {
        if(!weak(a)) { cancelFinisher(); return; }
        if(!spend(cfg.executionCost*costFactor)) {
            cancelFinisher(false); SKSE::log::info("Crush cancelled - insufficient Magicka"); return;
        }
        hurt(a,a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)+1000.f);
        if(a->IsDead() || a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)<=0) {
            // Wait for engine death state instead of beheading a living actor during notification.
            if(executions.size()<8) executions.push_back({RE::ActorHandle{a}});
            SKSE::log::info("Crush struck - awaiting death");
        } else { SKSE::log::info("Target resisted the crush"); }
        cancelFinisher(false); drop(false);
    }
    void tick() {
        auto now=Clock::now(); float dt=std::chrono::duration<float>(now-last).count(); last=now;
        if(!ready) return;
        struct Timer {
            Combat& owner; Clock::time_point start=Clock::now();
            ~Timer() { if(cfg.profile) { double ms=std::chrono::duration<double,std::milli>(Clock::now()-start).count();
                owner.profileTotal+=ms; owner.profilePeak=std::max(owner.profilePeak,ms); ++owner.profileTicks; } }
        } timer{*this};
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* ui=RE::UI::GetSingleton();
        if(!p || !p->Get3D() || !p->GetParentCell() || !ui ||
           ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) || ui->IsMenuOpen(RE::MainMenu::MENU_NAME)) { reset(); return; }
        settings::pumpMenu(); // Menu callbacks can precede the old box closing; retry on game-thread ticks.
        dt=std::clamp(dt,0.f,.05f);
        updateEquipHint(dt);
        if(ui->GameIsPaused()) return; // Preserve the grip and freeze costs/flight timers while paused.
        dismember::tick(dt,cfg.dismemberment);
        lastPoll=std::max(.016f,dt);
        combatTime+=dt; searchAge+=dt; cacheAge+=dt; previewAge+=dt; stickyAge+=dt; shakeAge+=dt;
        xpBudget=std::min(cfg.xpPerMinute,xpBudget+cfg.xpPerMinute*dt/60.f);
        std::erase_if(xpCooldown,[&](auto& value){return combatTime-value.second>60;});
        std::erase_if(reactionCooldown,[&](auto& value){return combatTime-value.second>2;});
        settings::tick(dt);
        if(settingsRevision!=settings::revision) {
            settingsRevision=settings::revision; cacheAge=searchAge=100; slowSelection={}; stickyTarget={}; stickyAge=100;
            shiftLeft=shiftRight=false; xpBudget=std::min(xpBudget,cfg.xpPerMinute);
        }
        if(usable() && !held && !pendingWeapon) cacheCandidates();
        if(cfg.preview && previewAge>=.16f) { previewAge=0; targetPreview(); }
        profileAge+=dt;
        if(cfg.profile && profileAge>=5.f && profileTicks) {
            SKSE::log::info("Controller profile: mean {:.3f} ms, peak {:.3f} ms, {} ticks, {} cache scans, {} actors/{} props",
                profileTotal/profileTicks,profilePeak,profileTicks,cacheScans,actorCache.size(),objectCache.size());
            profileAge=0; profileTotal=profilePeak=0; profileTicks=cacheScans=0;
        }
        for(auto it=executions.begin();it!=executions.end();) {
            auto actor=it->ref.get(); it->remaining-=dt;
            if(!actor || !actor->Get3D() || actor->IsDisabled() || !sameWorld(actor.get())) {
                it=executions.erase(it); continue;
            }
            if(it->remaining<=0) {
                SKSE::log::info("Crush: death was not confirmed");
                it=executions.erase(it); continue;
            }
            if(actor->IsDead() && !actor->IsInKillMove()) {
                SKSE::ModCallbackEvent event{RE::BSFixedString("TKC_Execution"),RE::BSFixedString("crush"),0.f,actor.get()};
                SKSE::GetModCallbackEventSource()->SendEvent(&event);
                auto* race=actor->GetRace();
                bool success=cfg.decapitate && actor->HasKeywordString("ActorTypeNPC") && race &&
                    (race->decapitateArmors[0] || race->decapitateArmors[1]) && actor->Decapitate();
                if(cfg.feedback) {
                    if(executionSpell) if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
                        caster->CastSpellImmediate(executionSpell,false,actor.get(),1.f,false,0.f,p);
                    feedback::sound(0xe4f24,pickCenter(actor.get()));
                    feedback::shader(actor.get(),0x57c67,.3f);
                }
                SKSE::log::info("CRUSH - target killed");
                SKSE::log::info("Execution death confirmed {:08X}; decapitation {}",actor->GetFormID(),success);
                it=executions.erase(it); continue;
            }
            ++it;
        }
        if(castingHeld && !usable()) drop();
        if(pendingWeapon) {
            pendingWeaponTime-=dt; auto ref=pendingWeapon.get();
            if(!usable() || !ref || ref->IsDisabled() || !sameWorld(ref.get())) drop();
            else if(ref->Get3D() && pickable(ref.get(),true)) {
                pendingWeapon={}; pendingWeaponTime=0;
                if(!grip(ref,true,true)) drop();
            } else if(pendingWeaponTime<=0) {
                SKSE::log::warn("{}","Disarmed weapon dropped; its physics could not be loaded."); drop();
            }
        }
        if(!held && !pendingWeapon && castingHeld) {
            retry+=dt;
            if(retry>=(castingShift ? .016f : .08f)) { retry=0; grab(true,castingShift); if(held || pendingWeapon) gripInput=castingInput; }
        }
        if(held && (!usable() || p->GetParentCell()->GetbhkWorld()!=holdWorld)) drop();
        if(orbitSession && !held.get()) { drop(); }
        Vec weaponTarget{};
        if(auto ref=held.get(); cfg.orient && ref && !ref->As<RE::Actor>() && !ref->As<RE::MissileProjectile>()) weaponTarget=weaponAimPoint();
        updateOrbit(dt,weaponTarget);
        if(auto ref=held.get()) {
            holdAge+=dt; refresh+=dt;
            auto* actor=ref->As<RE::Actor>();
            if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) holdMissile(missile,dt);
            else if(ref->IsDisabled() || !ref->Get3D() || !sameWorld(ref.get()) || (actor && !allowed(actor)) || !spend(cfg.holdCost*costFactor*dt)) { drop(); }
            else {
                if(actor && !actor->IsDead() && refresh>=1.f) { castHold(actor); refresh=0; }
                auto s=sample(ref.get());
                if(!finite(s.position) || !finite(s.velocity)) { drop(); }
                else if(!s.count || (actor && !actor->IsDead() && !actor->IsInRagdollState())) {
                    if(holdAge>1.5f) { SKSE::log::warn("{}","Cannot establish a ragdoll grip."); drop(); }
                } else {
                    distance+=((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt;
                    distance=orbitSession ? orbitHoldDistance(distance) : std::clamp(distance,cfg.minDistance,cfg.maxDistance);
                    Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
                    auto* camera=RE::PlayerCamera::GetSingleton();
                    float rayDistance=actor ? distance : itemRayDistance(origin,direction,vec(p->GetPosition()),
                        orbitSession ? orbitHoldDistance(distance) : visibleDepth(ref.get(),distance),camera && camera->IsInThirdPerson());
                    auto ignored=orbitHandles();
                    std::span<const RE::ObjectRefHandle> skip=orbitSession ? std::span<const RE::ObjectRefHandle>(ignored) : std::span<const RE::ObjectRefHandle>{};
                    auto wall=ray(p->GetParentCell(),origin,origin+direction*rayDistance,ref.get(),skip);
                    float safeDistance=wall.hit ? std::max(80.f,rayDistance*wall.fraction-60.f) : rayDistance;
                    if(gripTooFar(origin,s.position,cfg.range,cfg.maxDistance,recalledWeapon)) { drop(); }
                    else {
                        Vec previous=anchor;
                        float speedLimit=!actor && length(s.position-origin)>rayDistance+200.f ? cfg.pickupSpeed : cfg.holdSpeed;
                        Vec goal=origin+direction*safeDistance;
                        if(orbitSession) {
                            goal=goal+orbitOffset(direction,orbitPhase,heldSlot,orbitSpacingRadius,orbitHoldDistance(distance));
                            auto offsetWall=ray(p->GetParentCell(),origin,goal,ref.get(),skip);
                            if(offsetWall.hit) goal=origin+(goal-origin)*std::max(0.f,offsetWall.fraction-30.f/std::max(1.f,length(goal-origin)));
                        }
                        if(!actor) grasp.update(s.position,s.velocity,goal,dt);
                        auto next=gripAnchor(anchor,goal,speedLimit,dt,!actor && length(s.position-goal)>200.f);
                        // Sweep the body's path too: turning toward a wall clamps the grip instead of dropping it.
                        auto blocked=ray(ref->GetParentCell(),s.position,next,ref.get(),skip);
                        if(blocked.hit) {
                            Vec delta=next-s.position; float travel=length(delta);
                            next=s.position+unit(delta)*std::max(0.f,travel*blocked.fraction-30.f);
                        }
                        anchor=next;
                        // Physics angular steering preserves the COM instead of moving it through transform edits.
                        Vec facing=unit(weaponTarget-s.position);
                        velocity(ref.get(),holdVelocity(previous,anchor,s.position,dt,cfg.gain,speedLimit),actor ? nullptr : &facing,!actor,dt);
                        if(execDown && finisherReady(actor)) {
                            charged+=dt;
                            int step=static_cast<int>(finisherProgress(charged,cfg.charge)*4.f);
                            if(step!=chargeStep) {
                                chargeStep=step;
                                if(cfg.feedback) { feedback::shader(actor,0x57c67,.25f); chargeSound.SetFrequency(.8f+.4f*step/4.f); }
                            }
                            if(charged>=cfg.charge) execute(actor);
                        } else if(execDown) cancelFinisher();
                    }
                }
            }
        } else { cancelFinisher(); held={}; recalledWeapon=false; grasp={}; missile_hold::clear(); projectileCaster={}; projectileSpell=0; }
        // Refresh cached handles slowly, but update physical bounds and motion every flight tick.
        std::vector<Target> targets;
        if(!flights.empty()) {
            cacheCandidates();
            for(auto handle:actorCache) if(auto actor=handle.get(); actor && actor->Get3D() && !actor->IsDead() &&
                !actor->IsDisabled() && sameWorld(actor.get())) targets.push_back({handle,{}});
        }
        // Query physics after releasing cell reference locks.
        for(auto& target:targets) {
            auto actor=target.ref.get(); if(!actor) continue;
            target.bounds=actorBounds(actor.get());
            auto old=std::find_if(previousTargets.begin(),previousTargets.end(),[&](auto& t){return t.ref==target.ref;});
            if(old!=previousTargets.end()) {
                target.movement=(target.bounds.low+target.bounds.high-old->bounds.low-old->bounds.high)*.5f;
                if(length(target.movement)>512.f) target.movement={}; // Teleporting actors have no swept combat path.
            }
        }
        for(auto it=flights.begin();it!=flights.end();) {
            auto ref=it->ref.get(); it->remaining-=dt; it->elapsed+=dt; it->refresh+=dt;
            auto s=ref ? sample(ref.get()) : Sample{};
            if(!ref || !s.count || ref->IsDisabled() || !sameWorld(ref.get()) || it->remaining<=0 ||
                !finite(s.position) || !finite(s.velocity) || length(s.position-it->previous)>cfg.range) {
                if(ref && !ref->As<RE::Actor>()) SKSE::log::info("Prop flight ended {:08X}: {}",ref->GetFormID(),
                    it->remaining<=0 ? "expired without confirmed contact" : "physics/scene unavailable");
                it=flights.erase(it); continue;
            }
            auto* thrown=ref->As<RE::Actor>();
            if(thrown && !thrown->IsDead() && !it->impactApplied && allowed(thrown) && it->refresh>=1.f) { castHold(thrown); it->refresh=0; }
            it->peakZ=std::max(it->peakZ,s.position.z);
            float speed=length(it->velocity);
            float loss=dot(it->velocity-s.velocity,unit(it->velocity));
            bool slowed=it->elapsed>.06f && loss>std::max(cfg.minimum,speed*.4f);
            // A ray covers static geometry; swept actor bounds cover high-speed tunnelling.
            auto wall=ray(ref->GetParentCell(),it->previous,s.position,ref.get());
            bool paddedContact=false;
            if(!thrown && !wall.hit && contactVelocityChanged(it->velocity,s.velocity) && speed>=cfg.minimum) {
                Vec extent{std::max(it->halfExtent.x,s.halfExtent.x),std::max(it->halfExtent.y,s.halfExtent.y),std::max(it->halfExtent.z,s.halfExtent.z)};
                // shortcut: a bounded probe after native velocity change approximates tip contact; exact contacts need Havok callbacks.
                auto probe=ray(ref->GetParentCell(),s.position,s.position+unit(it->velocity)*contactProbeReach(extent,it->velocity),ref.get());
                auto obstacle=probe.ref.get();
                if(probe.hit && finite(probe.point) && (!obstacle || !obstacle->As<RE::Actor>())) {
                    wall=probe; wall.fraction=1.f; paddedContact=true;
                }
            }
            auto wallRef=wall.ref.get();
            RE::Actor* victim=wallRef ? wallRef->As<RE::Actor>() : nullptr;
            float closest=wall.hit ? wall.fraction : 1.f;
            Vec victimMovement{};
            Vec step=s.position-it->previous;
            for(auto& target:targets) {
                auto a=target.ref.get(); if(!a || a.get()==ref.get()) continue;
                auto bounds=target.bounds;
                Vec extent=thrown ? Vec{} : Vec{std::max(it->halfExtent.x,s.halfExtent.x),
                    std::max(it->halfExtent.y,s.halfExtent.y),std::max(it->halfExtent.z,s.halfExtent.z)};
                // ponytail: swept AABBs approximate blade/limb contact; exact mesh contacts need Havok callbacks.
                float t=movingBoxHit(it->previous,s.position,bounds.low,bounds.high,extent,cfg.radius,target.movement);
                if(t>=0 && t<=closest) {
                    // Test to the body itself, not only its padded entry, so long blades cannot reach through walls.
                    auto obstruction=ray(ref->GetParentCell(),it->previous,(bounds.low+bounds.high)*.5f,ref.get());
                    auto obstructionRef=obstruction.ref.get();
                    if(!obstruction.hit || obstructionRef.get()==a.get()) { victim=a.get(); closest=t; victimMovement=target.movement; }
                }
            }
            // Ignore the initial settling tick. Directional velocity loss catches wall/floor impacts.
            bool collision=confirmedImpact(victim!=nullptr,wall.hit,thrown!=nullptr,
                slowed);
            if(!thrown) speed=std::min(4500.f,std::max({speed,length(s.velocity),length(step)/std::max(dt,.001f)}));
            bool fall=thrown && !it->slam && lethalFall(it->peakZ,s.position.z,it->velocity.z,cfg.cliffDrop,cfg.minimum);
            if(collision && speed>=cfg.minimum && (!it->impactApplied || fall)) {
                if(!thrown) {
                    Vec contact=victim ? it->previous+step*closest : wall.point;
                    Vec bounced=(!victim && it->ricochets==0) ? glanceVelocity(it->velocity,wall.normal) : Vec{};
                    if(length(bounced)<cfg.minimum) bounced={};
                    bool deflected=length(bounced)>0;
                    Vec center=paddedContact && !victim ? s.position : contact;
                    stopProp(ref.get(),center+(deflected ? unit(wall.normal)*6.f : unit(it->velocity)*-2.f));
                    if(victim) {
                        float raw=combatObjectDamage(speed,it->mass,it->baseDamage,it->style,cfg.multiplier,
                            cfg.weaponBaseScale,cfg.damageScale,cfg.minimum,cfg.damageCap,
                            it->style==WeaponStyle::clutter ? cfg.objectHitMinimum : cfg.weaponHitMinimum);
                        float amount=physicalDamage(victim,raw,it->style);
                        SKSE::log::info("Prop hit {:08X} -> {:08X}: speed {:.1f}, weight {:.1f}, damage {:.1f}",
                            ref->GetFormID(),victim->GetFormID(),speed,it->mass,amount);
                        float before=victim->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth);
                        // Broad damage detection includes this existing forward tolerance; resolve it against posed anatomy.
                        Vec limbFrom=it->previous+victimMovement,limbEnd=s.position+unit(it->velocity)*cfg.radius;
                        Vec limbExtent{std::max(it->halfExtent.x,s.halfExtent.x),std::max(it->halfExtent.y,s.halfExtent.y),std::max(it->halfExtent.z,s.halfExtent.z)};
                        dismember::Contact limb;
                        if(cfg.dismemberment && dismember::api && before>0 && amount>=before) {
                            auto limbWall=ray(ref->GetParentCell(),limbFrom,limbEnd,ref.get());
                            if(limbWall.hit && limbWall.ref.get().get()!=victim) limbEnd=limbWall.point;
                            limb=dismember::hitContact(victim,limbFrom,limbEnd,limbExtent);
                        }
                        if(cfg.dismemberment && dismember::api && before>0 && amount>=before)
                            SKSE::log::info("DF lethal candidate {:08X}: region {} -> DF node {} via {} ({} joints, {} body shapes)",
                                victim->GetFormID(),limb.region.empty() ? "<no body contact>" : limb.region,
                                limb.node.empty() ? "<none>" : limb.node,limb.method,limb.joints,limb.shapes);
                        float dealt=hurt(victim,amount);
                        float after=victim->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth);
                        dismember::queue(victim,std::move(limb.node),ref->GetBaseObject()->As<RE::TESObjectWEAP>(),before,after,dealt);
                        react(victim,dealt,speed,it->mass,it->style);
                    }
                    else SKSE::log::info("Prop contact {:08X}: geometry/non-actor obstruction",ref->GetFormID());
                    feedback::impact(ref->GetParentCell(),ref->GetBaseObject()->As<RE::TESObjectWEAP>(),it->style,
                        victim ? RE::MATERIAL_ID::kSkin : wall.material,contact,unit(it->velocity),speed,it->mass,shakeAge>=.2f);
                    shakeAge=0;
                    Vec bounceDirection=unit(bounced);
                    if(deflected && velocity(ref.get(),bounced,&bounceDirection)) {
                        it->previous=sample(ref.get()).position; it->velocity=bounced; ++it->ricochets;
                        SKSE::log::info("Prop {:08X}: glancing deflection, speed {:.1f}",ref->GetFormID(),length(bounced));
                        ++it; continue;
                    }
                    it=flights.erase(it); continue;
                }
                if(victim || wall.hit) {
                    feedback::impact(ref->GetParentCell(),nullptr,WeaponStyle::clutter,victim ? RE::MATERIAL_ID::kSkin : wall.material,it->previous+step*closest,unit(it->velocity),speed,20.f,shakeAge>=.2f);
                    shakeAge=0;
                }
                auto actorDamage=[&](RE::Actor* target,bool slammed,bool falling) {
                    auto* values=target->AsActorValueOwner();
                    float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
                        target->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
                    return actorImpactDamage(values->GetActorValue(RE::ActorValue::kHealth),maximum,p->GetLevel(),target->GetLevel(),
                        speed,slammed ? cfg.actorSlamSpeed : cfg.actorLaunchSpeed,
                        slammed ? cfg.slamFraction : cfg.throwFraction,cfg.actorDamageCap,cfg.lethalLevelAdvantage,falling,slammed);
                };
                if(!it->impactApplied && victim) {
                    float dealt=hurt(victim,actorDamage(victim,false,false));
                    react(victim,dealt,speed,20.f,WeaponStyle::blunt);
                }
                if(!thrown->IsDead()) {
                    hurt(thrown,actorDamage(thrown,it->slam,fall));
                    if(it->slam && !thrown->IsDead() && allowed(thrown)) {
                        if(auto* queue=RE::TaskQueueInterface::GetSingleton()) {
                            RE::ActorHandle target{thrown},caster{p}; queue->QueueActorDisarm(target,caster);
                            SKSE::log::info("Nonlethal slam: disarm queued for {:08X}",thrown->GetFormID());
                        }
                    }
                }
                it->impactApplied=true;
                // One ordinary hit; continue tracking a surviving throw for a later cliff landing.
                if(it->slam || thrown->IsDead()) { it=flights.erase(it); continue; }
            }
            it->previous=s.position; it->velocity=s.velocity; ++it;
        }
        previousTargets=std::move(targets);
    }
    struct Button {
        std::uint32_t key; RE::INPUT_DEVICE device; RE::BSFixedString action;
        bool down,up,pressed;
    };
    void input(const std::vector<Button>& buttons) {
        for(const auto& button:buttons) {
            if(settings::capture(button.key,button.device,button.down)) return;
            if(cfg.settingsEnabled && button.device==RE::INPUT_DEVICE::kKeyboard && button.key==cfg.settingsKey && button.down) {
                auto* p=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
                if(ready && active && p && p->Get3D() && !p->IsDead() && ui && !ui->GameIsPaused()) {
                    drop(); settings::open(); searchAge=cacheAge=100;
                }
                return;
            }
        }
        // Snapshot both modifier keys before casting actions, including presses in the same input batch.
        for(const auto& button:buttons) if(button.device==RE::INPUT_DEVICE::kKeyboard && (button.key==cfg.modifierKey || (cfg.modifierKey2 && button.key==cfg.modifierKey2))) {
            auto& key=button.key==cfg.modifierKey ? shiftLeft : shiftRight;
            if(button.down) key=true;
            if(button.up) key=false;
        }
        if(!shiftLeft && !shiftRight) ignoreInitialShift=false;
        slamDown=shiftSlam(static_cast<bool>(held),shiftLeft,shiftRight,ignoreInitialShift);
        for(const auto& button:buttons) {
            auto key=button.key; auto device=button.device; auto userEvent=button.action;
            auto* user=RE::UserEvents::GetSingleton();
            if(!user) continue;
            // Use Skyrim's mapped casting actions, including remapped mouse/gamepad buttons.
            bool castInput=userEvent==user->leftAttack || userEvent==user->rightAttack;
            if(castInput) {
                auto* player=RE::PlayerCharacter::GetSingleton();
                bool controlHand=player && player->GetEquippedObject(userEvent==user->leftAttack)==controlSpell;
                auto action=castAction(button.down,button.up,static_cast<bool>(held) || static_cast<bool>(pendingWeapon),userEvent==gripInput,controlHand);
                if(button.up) {
                    if(userEvent==castingInput) { castingHeld=false; castingInput=RE::BSFixedString(); }
                    if(action==CastAction::release) {
                        auto released=held;
                        if(usable()) launch(slamDown);
                        // A successful orbit shot promotes another handle; failures release all held items.
                        if(failedCastRelease(held==released,static_cast<bool>(pendingWeapon))) drop();
                    } else if(userEvent==finisherInput) { cancelFinisher(); }
                    continue;
                }
                if(!usable()) continue;
                if(resumeOrbitCast(button.down,controlHand,orbitSession,userEvent==gripInput)) {
                    castingHeld=true; castingInput=userEvent; retry=0;
                } else if(action==CastAction::grab) {
                    castingHeld=true; castingInput=userEvent; retry=0;
                    castingShift=shiftLeft || shiftRight; ignoreInitialShift=castingShift; slamDown=false;
                    grab(false,castingShift); if(held || pendingWeapon) gripInput=userEvent;
                } else if(action==CastAction::charge) {
                    beginFinisher(userEvent);
                }
                continue;
            }
            if(device==RE::INPUT_DEVICE::kKeyboard && (key==cfg.modifierKey || (cfg.modifierKey2 && key==cfg.modifierKey2))) continue;
            if(!usable()) continue;
            if(recallAction(button.down,userEvent==user->activate,shiftLeft || shiftRight,static_cast<bool>(held) || static_cast<bool>(pendingWeapon))) {
                // shortcut: Skyrim also receives Activate; aim at clear space to avoid its normal interaction.
                recallWeapon(); continue;
            }
            if((held || pendingWeapon) && userEvent==user->activate) {
                if(button.down) {
                    auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
                    if(pendingWeapon || (ref && ref->As<RE::MissileProjectile>())) drop();
                    else if(weak(actor)) beginFinisher(userEvent);
                    else if(ref && !actor) {
                        auto body=sample(ref.get());
                        auto* player=RE::PlayerCharacter::GetSingleton();
                        auto bounds=actorBounds(player); Vec origin=(bounds.low+bounds.high)*.5f;
                        auto obstacle=ray(ref->GetParentCell(),origin,body.position,ref.get());
                        bool close=body.count && length(body.position-origin)<=cfg.pickupReach;
                        drop();
                        if(close && !obstacle.hit) {
                            if(lastThrownWeapon==ref->GetHandle()) lastThrownWeapon={};
                            bool activated=ref->ActivateRef(RE::PlayerCharacter::GetSingleton(),0,nullptr,std::max(1,static_cast<int>(ref->extraList.GetCount())),false);
                            SKSE::log::info("Held item {:08X}: native activation {}",ref->GetFormID(),activated);
                        }
                    } else drop();
                } else if(button.up && finisherInput==userEvent) { drop(); }
                continue;
            }
            if(held && device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9) && button.pressed) {
                distance+=(key==8 ? -50.f : 50.f);
                distance=orbitSession ? orbitHoldDistance(distance) : std::clamp(distance,cfg.minDistance,cfg.maxDistance);
                continue;
            }
            if(!cfg.legacyHotkeys || device!=RE::INPUT_DEVICE::kKeyboard) continue;
            if(button.up) {
                if(key==cfg.execute) cancelFinisher();
                if(key==cfg.pull) pulling=false;
                if(key==cfg.push) pushing=false;
            }
            if(!usable() || !button.down) continue;
            if(key==cfg.grab) { ignoreInitialShift=shiftLeft || shiftRight; slamDown=false; grab(false,ignoreInitialShift); }
            else if(key==cfg.launch) launch(false);
            else if(key==cfg.slam) launch(true);
            else if(key==cfg.pull) pulling=true;
            else if(key==cfg.push) pushing=true;
            else if(key==cfg.execute && held) beginFinisher(userEvent);
        }
    }
    RE::BSEventNotifyControl ProcessEvent(RE::InputEvent* const* events,RE::BSTEventSource<RE::InputEvent*>*) override {
        if(!events || !ready) return RE::BSEventNotifyControl::kContinue;
        std::vector<Button> buttons;
        for(auto* event=*events;event;event=event->next) {
            auto* button=event->AsButtonEvent();
            if(!button) continue;
            auto key=button->GetIDCode(); auto device=button->GetDevice();
            if(button->IsDown() || button->IsUp() || (device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9)))
                buttons.push_back({key,device,button->QUserEvent(),button->IsDown(),button->IsUp(),button->IsPressed()});
        }
        // Input can arrive on worker threads. Own a snapshot and mutate game state on the game thread.
        if(!buttons.empty()) SKSE::GetTaskInterface()->AddTask([buttons=std::move(buttons)] {
            auto& state=Combat::get(); if(state.ready) state.input(buttons);
        });
        return RE::BSEventNotifyControl::kContinue;
    }
};

std::jthread ticker;
void message(SKSE::MessagingInterface::Message* msg) {
    auto& combat=Combat::get();
    switch(msg->type) {
    case SKSE::MessagingInterface::kDataLoaded:
        combat.resolve();
        missile_hold::install(); // Acquisition toggle is live; every unheld missile forwards unchanged.
        RE::BSInputDeviceManager::GetSingleton()->AddEventSink(&combat);
        ticker=std::jthread([](std::stop_token stop) {
            while(!stop.stop_requested()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(16));
                auto& c=Combat::get();
                if(!c.ready || c.queued.exchange(true)) continue;
                SKSE::GetTaskInterface()->AddTask([] {
                    auto& state=Combat::get();
                    try { state.tick(); } catch(const std::exception& e) { SKSE::log::error("Tick: {}",e.what()); }
                    state.queued=false;
                });
            }
        });
        break;
    case SKSE::MessagingInterface::kSaveGame:
        // SKSE dispatches before serialization: do not save a frozen hostile missile with zero velocity.
        if(missile_hold::suspended.load(std::memory_order_acquire)!=0) combat.drop();
        break;
    case SKSE::MessagingInterface::kPreLoadGame:
        combat.ready=false; combat.reset(); break;
    case SKSE::MessagingInterface::kPostLoadGame:
    case SKSE::MessagingInterface::kNewGame:
        combat.reset(); dismember::load(); combat.ready=true; break;
    default: break;
    }
}
}

SKSEPluginLoad(const SKSE::LoadInterface* skse) {
    auto directory=SKSE::log::log_directory();
    if(!directory) return false;
    auto sink=std::make_shared<spdlog::sinks::basic_file_sink_mt>((*directory/"TelekinesisCombat.log").string(),true);
    auto logger=std::make_shared<spdlog::logger>("TKC",sink);
    spdlog::set_default_logger(logger); spdlog::flush_on(spdlog::level::info);
    SKSE::Init(skse);
    if(REL::Module::IsVR()) { SKSE::log::error("VR is not supported"); return false; }
    const auto runtime=REL::Module::get().version();
    const std::array supported{REL::Version{1,5,97,0},REL::Version{1,6,640,0},REL::Version{1,6,659,0},
        REL::Version{1,6,1170,0},REL::Version{1,6,1179,0},REL::Version{1,7,104,0}};
    if(std::find(supported.begin(),supported.end(),runtime)==supported.end()) {
        SKSE::log::error("Runtime {} is outside the target list",runtime.string()); return false;
    }
    return SKSE::GetMessagingInterface()->RegisterListener(message);
}
