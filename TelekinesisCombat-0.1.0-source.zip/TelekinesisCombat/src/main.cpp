#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <Windows.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <atomic>
#include <array>
#include <chrono>
#include <filesystem>
#include <thread>
#include <stdexcept>
#include <vector>
#include "combat_math.h"
#include "controls.h"
#include "raycast.h"
#include "missile_hold.h"

namespace {
using namespace tkc;
using Clock=std::chrono::steady_clock;
Vec vec(RE::NiPoint3 p) { return {p.x,p.y,p.z}; }
RE::NiPoint3 ni(Vec p) { return {p.x,p.y,p.z}; }
Vec vec(const RE::hkVector4& p) {
    return {p.quad.m128_f32[0],p.quad.m128_f32[1],p.quad.m128_f32[2]};
}
RE::hkVector4 hk(Vec p) { return {p.x,p.y,p.z,0.f}; }

struct Config {
    std::string plugin="TelekinesisCombat.esp";
    std::uint32_t control=0x800, hold=0x801, execution=0;
    std::uint32_t grab=34, launch=35, pull=36, push=37, slam=38, execute=45;
    bool legacyHotkeys=false;
    float grabCost=15, holdCost=12, launchCost=10, executionCost=40, disarmCost=25;
    float nearbyRadius=300, disarmRange=1800;
    bool catchProjectiles=true;
    float projectileRadius=400, projectileCost=15, projectileHoldSeconds=8;
    float levelFactor=.04f, maxScale=1.5f, maxHeight=260, maxExtent=360, executionHealth=.35f, charge=1.f;
    bool undead=true, creatures=true, corpses=true, protect=true, orient=true, decapitate=true;
    float range=6000, aimAssist=3, pickupSpeed=10000, distance=300, minDistance=140, maxDistance=650, adjustSpeed=240;
    float gain=10, holdSpeed=4500, launchSpeed=3600, slamSpeed=3000;
    float minimum=450, multiplier=8, damageCap=2000, objectMassFloor=5, massCap=40;
    float objectHitMinimum=125, weaponHitMinimum=350;
    float actorLaunchSpeed=1600, actorSlamSpeed=1400, throwFraction=.20f, slamFraction=.30f, actorDamageCap=.45f;
    float cliffDrop=800, actorFlightSeconds=15, itemDistance=160, pickupReach=260;
    int lethalLevelAdvantage=10;
    float radius=26, flightSeconds=4;
    int maxFlights=8;
    void load() {
        auto path=std::filesystem::absolute("Data/SKSE/Plugins/TelekinesisCombat.ini").string();
        auto read=[&](const char* section,const char* key,const std::string& fallback) {
            char buffer[512]{};
            GetPrivateProfileStringA(section,key,fallback.c_str(),buffer,sizeof(buffer),path.c_str());
            return std::string(buffer);
        };
        auto number=[&](const char* section,const char* key,float fallback,float lo,float hi) {
            try {
                auto s=read(section,key,std::to_string(fallback)); size_t used=0;
                float n=std::stof(s,&used);
                if(used!=s.size() || !std::isfinite(n)) throw std::invalid_argument(key);
                return std::clamp(n,lo,hi);
            } catch(...) { SKSE::log::warn("Invalid INI {}.{}; using default",section,key); return fallback; }
        };
        auto form=[&](const char* key,std::uint32_t fallback) {
            try {
                auto s=read("Forms",key,std::to_string(fallback)); size_t used=0;
                auto n=std::stoul(s,&used,0);
                if(used!=s.size() || n>0xFFFFFF) throw std::invalid_argument(key);
                return static_cast<std::uint32_t>(n);
            } catch(...) { SKSE::log::warn("Invalid form {}",key); return fallback; }
        };
        plugin=read("Forms","Plugin",plugin);
        legacyHotkeys=number("Controls","LegacyHotkeys",0,0,1)!=0;
        control=form("ControlSpell",control); hold=form("HoldSpell",hold); execution=form("ExecutionSpell",execution);
#define KEY(member,name) member=static_cast<std::uint32_t>(number("Controls",name,static_cast<float>(member),1,255))
        KEY(grab,"Grab"); KEY(launch,"Launch"); KEY(pull,"Pull"); KEY(push,"Push"); KEY(slam,"Slam"); KEY(execute,"Execute");
#undef KEY
#define G(member,name,lo,hi) member=number("Gameplay",name,member,lo,hi)
        G(grabCost,"GrabCost",0,500); G(holdCost,"HoldCostPerSecond",0,500);
        G(launchCost,"LaunchCost",0,500); G(executionCost,"ExecutionCost",0,1000);
        G(projectileRadius,"ProjectileCaptureRadius",100,1000); G(projectileCost,"ProjectileGrabCost",0,500);
        G(projectileHoldSeconds,"MaxProjectileHoldSeconds",1,30);
        G(disarmCost,"DisarmCost",0,500); G(nearbyRadius,"NearbyPickupRadius",100,800); G(disarmRange,"DisarmRange",200,6000);
        G(levelFactor,"LevelResistance",0,.2f); G(maxScale,"MaxActorScale",.5f,2);
        G(maxHeight,"MaxActorHeight",50,500); G(maxExtent,"MaxActorExtent",100,800); G(executionHealth,"ExecutionHealthFraction",.01f,.5f);
        G(charge,"ExecutionChargeSeconds",.25f,5);
        lethalLevelAdvantage=static_cast<int>(number("Gameplay","LethalLevelAdvantage",10,1,100));
#undef G
        catchProjectiles=number("Gameplay","CatchProjectiles",1,0,1)!=0;
        undead=number("Gameplay","AllowUndead",1,0,1)!=0;
        creatures=number("Gameplay","AllowCreatures",1,0,1)!=0;
        corpses=number("Gameplay","AllowCorpses",1,0,1)!=0;
        protect=number("Gameplay","ProtectProtectedActors",1,0,1)!=0;
        orient=number("Physics","OrientSwords",1,0,1)!=0;
        decapitate=number("Gameplay","ExecutionDecapitation",1,0,1)!=0;
#define P(member,name,lo,hi) member=number("Physics",name,member,lo,hi)
        P(range,"Range",200,8000); P(aimAssist,"AimAssistDegrees",.25f,5);
        P(pickupSpeed,"PickupSpeed",1000,20000); P(minDistance,"MinHoldDistance",80,500);
        P(maxDistance,"MaxHoldDistance",minDistance,1000); P(distance,"HoldDistance",minDistance,maxDistance);
        P(itemDistance,"ItemHoldDistance",minDistance,maxDistance); P(pickupReach,"PickupReach",100,300);
        P(adjustSpeed,"PullPushSpeed",20,600); P(gain,"SpringGain",1,12); P(holdSpeed,"MaxHoldSpeed",100,8000);
        P(launchSpeed,"LaunchSpeed",500,4500); P(slamSpeed,"SlamSpeed",500,4500);
        P(minimum,"ImpactMinSpeed",100,2000); P(multiplier,"ImpactDamageMultiplier",0,10);
        P(damageCap,"MaxImpactDamage",0,10000); P(massCap,"ObjectMassCap",1,100);
        P(objectMassFloor,"ObjectMassFloor",1,massCap);
        P(objectHitMinimum,"ObjectMinHitDamage",0,damageCap); P(weaponHitMinimum,"WeaponMinHitDamage",0,damageCap);
        P(actorLaunchSpeed,"ActorLaunchSpeed",500,3000); P(actorSlamSpeed,"ActorSlamSpeed",500,3000);
        P(throwFraction,"ActorThrowDamageFraction",.01f,.5f); P(slamFraction,"ActorSlamDamageFraction",.01f,.5f);
        P(actorDamageCap,"ActorDamageCapFraction",.05f,.8f);
        P(cliffDrop,"CliffLethalDrop",400,4000); P(actorFlightSeconds,"ActorFlightSeconds",4,30);
        P(radius,"HitRadius",10,80); P(flightSeconds,"FlightSeconds",.5f,8);
#undef P
        maxFlights=static_cast<int>(number("Physics","MaxFlights",8,1,16));
        std::vector<std::uint32_t> keys{grab,launch,pull,push,slam,execute};
        std::sort(keys.begin(),keys.end());
        if(std::adjacent_find(keys.begin(),keys.end())!=keys.end()) {
            SKSE::log::warn("Duplicate controls; restoring defaults");
            grab=34; launch=35; pull=36; push=37; slam=38; execute=45;
        }
    }
} cfg;

// No body/scene pointers survive a game-thread task or world-lock scope.
void bodies(RE::NiAVObject* object,std::vector<RE::bhkRigidBody*>& out) {
    if(!object || out.size()>=128) return;
    if(auto* collision=object->collisionObject ? object->collisionObject->AsBhkNiCollisionObject() : nullptr) {
        if(auto* body=collision->body ? collision->body->AsBhkRigidBody() : nullptr) {
            if(auto* rigid=body->GetRigidBody(); rigid && rigid->motion.GetMass()>0 &&
                std::find(out.begin(),out.end(),body)==out.end()) out.push_back(body);
        }
    }
    if(auto* node=object->AsNode()) for(auto& child:node->children) bodies(child.get(),out);
}
struct Sample { Vec position{}, velocity{}, halfExtent{}; int count{}; };
Sample sample(RE::TESObjectREFR* ref) {
    Sample s;
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return s;
    RE::BSReadLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float inverse=RE::bhkWorld::GetWorldScaleInverse();
    Vec low{INFINITY,INFINITY,INFINITY},high{-INFINITY,-INFINITY,-INFINITY};
    bool prop=ref->As<RE::Actor>()==nullptr;
    for(auto* body:list) {
        RE::hkVector4 pos; body->GetCenterOfMassWorld(pos);
        s.position=s.position+vec(pos)*inverse;
        s.velocity=s.velocity+vec(body->GetRigidBody()->motion.linearVelocity)*inverse;
        if(prop) {
            RE::hkAabb bounds; body->GetAabbWorldspace(bounds);
            auto a=vec(bounds.min)*inverse,b=vec(bounds.max)*inverse;
            if(finite(a) && finite(b)) {
                low={std::min(low.x,a.x),std::min(low.y,a.y),std::min(low.z,a.z)};
                high={std::max(high.x,b.x),std::max(high.y,b.y),std::max(high.z,b.z)};
            }
        }
        ++s.count;
    }
    if(s.count) { s.position=s.position*(1.f/s.count); s.velocity=s.velocity*(1.f/s.count); }
    if(prop && s.count && finite(low) && finite(high)) {
        // Include blade length and offset centres, without giving malformed meshes an unlimited hit box.
        s.halfExtent={std::clamp(std::max(s.position.x-low.x,high.x-s.position.x),0.f,120.f),
                      std::clamp(std::max(s.position.y-low.y,high.y-s.position.y),0.f,120.f),
                      std::clamp(std::max(s.position.z-low.z,high.z-s.position.z),0.f,120.f)};
    }
    return s;
}
bool velocity(RE::TESObjectREFR* ref,Vec speed,Vec* direction=nullptr,bool stabilize=false) {
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D() || !finite(speed)) return false;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float scale=RE::bhkWorld::GetWorldScale();
    Vec average{};
    bool actor=ref->As<RE::Actor>()!=nullptr;
    if(actor && !list.empty()) {
        for(auto* body:list) average=average+vec(body->GetRigidBody()->motion.linearVelocity);
        average=average*(1.f/list.size());
    }
    for(auto* body:list) {
        auto* rigid=body->GetRigidBody();
        // Activate sleeping bodies, and preserve relative limb motion in a ragdoll.
        Vec relative=actor ? vec(rigid->motion.linearVelocity)-average : Vec{};
        rigid->SetLinearVelocity(hk(speed*scale+relative));
        // Suppress collision-induced spin only while holding props, never on ragdoll limbs.
        if(stabilize && !actor) rigid->SetAngularVelocity(RE::hkVector4{});
    }
    if(direction && cfg.orient && list.size()==1) {
        auto* weapon=ref->GetBaseObject()->As<RE::TESObjectWEAP>();
        if(weapon && (weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kTwoHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandDagger)) {
            // ponytail: vanilla sword meshes use local +Z; custom mesh axes need per-mesh calibration.
            auto d=unit(*direction); float w=1+d.z;
            Vec axis{-d.y,d.x,0}; float norm=std::sqrt(dot(axis,axis)+w*w);
            RE::hkQuaternion rotation;
            rotation.vec=norm>.001f ? RE::hkVector4(axis.x/norm,axis.y/norm,0,w/norm) : RE::hkVector4(1,0,0,0);
            list.front()->SetRotation(rotation);
            list.front()->SetAngularVelocity(RE::hkVector4{});
        }
    }
    return !list.empty();
}

// Resolve a swept prop contact visually as well as applying damage; never reposition an actor.
void stopProp(RE::TESObjectREFR* ref,Vec contact) {
    if(!ref || ref->As<RE::Actor>() || !finite(contact)) return;
    auto state=sample(ref); if(!state.count) return;
    auto* cell=ref->GetParentCell(); auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    Vec offset=(contact-state.position)*RE::bhkWorld::GetWorldScale();
    for(auto* body:list) {
        RE::hkVector4 position; body->GetPosition(position);
        position=hk(vec(position)+offset); body->SetPosition(position);
        body->GetRigidBody()->SetLinearVelocity(RE::hkVector4{});
        body->GetRigidBody()->SetAngularVelocity(RE::hkVector4{});
    }
}

struct RayHit { bool hit{}; float fraction=1; RE::ObjectRefHandle ref; };
RayHit ray(RE::TESObjectCELL* cell,Vec from,Vec to,RE::TESObjectREFR* ignore) {
    RayHit result;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || length(to-from)<.1f) return result;
    RE::BSReadLockGuard lock(world->worldLock);
    Vec start=from, dir=unit(to-from); float total=length(to-from);
    // Skip source body hits without globally changing any collision filter.
    for(int i=0;i<32;++i) {
        // Reaching the end after skipping only source/player bodies is a clear ray, not a wall.
        if(!rayHasRemaining(start,to,dir)) return result;
        RE::bhkPickData pick{};
        preparePickRay(pick,start,to,RE::bhkWorld::GetWorldScale());
        pick.rayInput.filterInfo.SetCollisionLayer(RE::COL_LAYER::kLOS);
        world->PickObject(pick);
        if(!pick.rayOutput.HasHit()) return result;
        auto* ref=RE::TESHavokUtilities::FindCollidableRef(*pick.rayOutput.rootCollidable);
        Vec point=start+(to-start)*pick.rayOutput.hitFraction;
        if((!ignore || ref!=ignore) && ref!=RE::PlayerCharacter::GetSingleton()) {
            result.hit=true; result.fraction=std::clamp(length(point-from)/total,0.f,1.f);
            if(ref) result.ref=ref->GetHandle();
            return result;
        }
        start=point+dir*8;
    }
    // Conservative: an unresolved obstruction stops targeting/hold travel.
    result.hit=true; result.fraction=0;
    return result;
}

class Combat final : public RE::BSTEventSink<RE::InputEvent*> {
    struct Flight {
        RE::ObjectRefHandle ref;
        Vec previous{}, velocity{}, halfExtent{};
        float mass{}, multiplier=1, remaining{}, elapsed{}, refresh{}, peakZ{};
        bool slam{}, impactApplied{};
    };
    RE::ObjectRefHandle held;
    RE::ObjectRefHandle projectileCaster;
    RE::FormID projectileSpell{};
    float projectilePower=1, projectileScale=1, projectileSpeed{};
    RE::bhkWorld* holdWorld{}; // identity only; never dereferenced after a world change
    Vec anchor{};
    std::vector<Flight> flights;
    struct Decapitation { RE::ActorHandle ref; float remaining=2.f; };
    std::vector<Decapitation> executions;
    RE::SpellItem* controlSpell{};
    RE::SpellItem* holdSpell{};
    RE::SpellItem* executionSpell{};
    bool active=false, execDown=false, pulling=false, pushing=false;
    bool slamDown=false, shiftLeft=false, shiftRight=false, ignoreInitialShift=false;
    RE::ObjectRefHandle pendingWeapon;
    float pendingWeaponTime{};
    bool castingShift=false;
    RE::BSFixedString gripInput;
    RE::BSFixedString castingInput;
    RE::BSFixedString finisherInput;
    bool castingHeld=false;
    float retry{}, holdAge{}, refresh{}, costFactor=1, charged{}, distance=300;
    Clock::time_point last=Clock::now();
public:
    std::atomic_bool ready=false, queued=false;
    static Combat& get() { static auto* instance=new Combat; return *instance; }
    void resolve() {
        cfg.load();
        auto* data=RE::TESDataHandler::GetSingleton();
        controlSpell=data->LookupForm<RE::SpellItem>(cfg.control,cfg.plugin);
        holdSpell=data->LookupForm<RE::SpellItem>(cfg.hold,cfg.plugin);
        executionSpell=cfg.execution ? data->LookupForm<RE::SpellItem>(cfg.execution,cfg.plugin) : nullptr;
        bool ragdollHold=false;
        if(holdSpell) for(auto* effect:holdSpell->effects) {
            if(effect && effect->baseEffect && effect->baseEffect->GetArchetype()==RE::EffectArchetypes::ArchetypeID::kValueModifier &&
               effect->baseEffect->data.primaryAV==RE::ActorValue::kGrabbed &&
               effect->GetDuration()==2 && effect->GetMagnitude()==1.f) ragdollHold=true;
        }
        active=controlSpell && ragdollHold;
        SKSE::log::info("Gameplay layer {} (control {:X}, hold {:X})",active ? "ready" : "MISSING/INVALID",cfg.control,cfg.hold);
        if(!active) RE::SendHUDMessage::ShowHUDMessage("Telekinesis Combat: missing/invalid companion spells. See README.");
        ready=true;
    }
    bool usable() const {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
        return ready && active && p && p->Get3D() && p->GetParentCell() && !p->IsDead() && !p->IsInKillMove() &&
            ui && !ui->GameIsPaused() && !ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) &&
            !ui->IsMenuOpen(RE::MainMenu::MENU_NAME) && !ui->IsMenuOpen(RE::DialogueMenu::MENU_NAME) &&
            (p->GetEquippedObject(false)==controlSpell || p->GetEquippedObject(true)==controlSpell);
    }
    void drop(bool stop=true) {
        if(auto ref=held.get()) {
            if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) missile->Kill();
            else if(stop) velocity(ref.get(),{});
            if(auto* a=ref->As<RE::Actor>(); a && holdSpell) {
                if(auto* player=RE::PlayerCharacter::GetSingleton()) {
                    RE::ActorHandle actorCaster{player};
                    a->AsMagicTarget()->DispelEffect(holdSpell,actorCaster);
                }
            }
        }
        missile_hold::clear(); projectileCaster={}; projectileSpell=0;
        held={}; pendingWeapon={}; pendingWeaponTime=0; holdWorld=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        ignoreInitialShift=false; castingShift=false;
        gripInput=RE::BSFixedString(); slamDown=false;
        castingInput=RE::BSFixedString(); castingHeld=false; finisherInput=RE::BSFixedString();
    }
    void reset() { drop(); shiftLeft=false; shiftRight=false; flights.clear(); previousTargets.clear(); executions.clear(); last=Clock::now(); }
    bool allowed(RE::Actor* a) const {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || (a->IsDead() && !cfg.corpses) || a->IsChild() || a->IsEssential() ||
            (cfg.protect && a->IsProtected()) || a->IsInKillMove() || a->GetScale()>cfg.maxScale ||
            a->HasKeywordString("ActorTypeDragon") || a->HasKeywordString("ActorTypeGiant")) return false;
        auto* race=a->GetRace();
        auto extent=vec(a->GetBoundMax())-vec(a->GetBoundMin());
        if(!race || !finite(extent) || extent.z>cfg.maxHeight ||
           std::max({extent.x,extent.y,extent.z})>cfg.maxExtent) return false;
        if(a->HasKeywordString("ActorTypeUndead")) return cfg.undead;
        return a->HasKeywordString("ActorTypeNPC") || cfg.creatures;
    }
    Vec aim() const {
        auto* camera=RE::PlayerCamera::GetSingleton();
        if(camera && camera->cameraRoot) {
            auto& r=camera->cameraRoot->world.rotate;
            return unit({r.entry[0][1],r.entry[1][1],r.entry[2][1]});
        }
        return {0,1,0};
    }
    bool spend(float amount) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* values=p->AsActorValueOwner();
        if(values->GetActorValue(RE::ActorValue::kMagicka)<amount) return false;
        values->DamageActorValue(RE::ActorValue::kMagicka,amount); return true;
    }
    void castHold(RE::Actor* a) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool refreshed=false;
        if(auto* effects=a->AsMagicTarget()->GetActiveEffectList()) for(auto* effect:*effects) {
            if(effect && effect->spell==holdSpell && !effect->flags.any(RE::ActiveEffect::Flag::kDispelled) &&
               effect->GetCasterActor().get()==p) {
                effect->duration=effect->elapsedSeconds+2.f; refreshed=true;
            }
        }
        if(refreshed) return;
        if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(holdSpell,true,a,1.f,false,1.f,p);
    }
    void hurt(RE::Actor* a,float amount) {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || a->IsDead() || a->IsChild() || a->IsEssential() ||
           (cfg.protect && a->IsProtected()) || !std::isfinite(amount) || amount<=0) return;
        auto* p=RE::PlayerCharacter::GetSingleton();
        a->StartCombat(p);
        auto* values=a->AsActorValueOwner();
        float before=values->GetActorValue(RE::ActorValue::kHealth);
        values->DamageActorValue(RE::ActorValue::kHealth,amount);
        // HandleHealthDamage is a post-damage death/attacker notification, not subtraction.
        a->HandleHealthDamage(p,amount);
        SKSE::log::info("Impact/finish {:08X}: {:.1f} damage, health {:.1f} -> {:.1f}",
            a->GetFormID(),amount,before,values->GetActorValue(RE::ActorValue::kHealth));
    }
    bool weak(RE::Actor* a) const {
        if(!a || a->IsDead() || !allowed(a)) return false;
        auto* values=a->AsActorValueOwner();
        float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
            a->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
        return weakened(values->GetActorValue(RE::ActorValue::kHealth),maximum,cfg.executionHealth);
    }
    void beginFinisher(const RE::BSFixedString& input) {
        auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
        if(!weak(actor)) { RE::SendHUDMessage::ShowHUDMessage("Finisher requires a weakened target."); return; }
        if(execDown) return;
        finisherInput=input; execDown=true; charged=0;
        SKSE::log::info("Finisher charging on {:08X}",actor->GetFormID());
        RE::SendHUDMessage::ShowHUDMessage("Crushing target... keep the finisher control held.");
    }
    bool sameWorld(RE::TESObjectREFR* ref) const {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* playerCell=p ? p->GetParentCell() : nullptr;
        auto* cell=ref ? ref->GetParentCell() : nullptr;
        auto* world=playerCell ? playerCell->GetbhkWorld() : nullptr;
        return world && cell && cell->GetbhkWorld()==world;
    }
    bool pickable(RE::TESObjectREFR* ref) const {
        if(!ref || ref==RE::PlayerCharacter::GetSingleton() || !ref->Get3D() || ref->IsDisabled() || !sameWorld(ref)) return false;
        if(ref->As<RE::Actor>()) return true; // Immunities are checked before spending or changing actor state.
        auto* base=ref->GetBaseObject(); if(!base) return false;
        auto type=base->GetFormType();
        return type==RE::FormType::Weapon || type==RE::FormType::Misc || type==RE::FormType::Armor ||
            type==RE::FormType::Ingredient || type==RE::FormType::AlchemyItem;
    }
    struct Bounds { Vec low,high; };
    Bounds actorBounds(RE::Actor* actor) const {
        Vec low=vec(actor->GetBoundMin()),high=vec(actor->GetBoundMax());
        Vec center=(low+high)*.5f, position=vec(actor->GetPosition());
        // Native controller bounds are world coordinates; base-form fallback bounds are local.
        if(length(center-position)>length(high-low)+256.f) { low=low+position; high=high+position; }
        if(actor->IsDead() || actor->IsInRagdollState()) {
            auto body=sample(actor);
            if(body.count) { Vec offset=body.position-(low+high)*.5f; low=low+offset; high=high+offset; }
        }
        return {low,high};
    }
    struct Target { RE::ActorHandle ref; Bounds bounds; Vec movement{}; };
    std::vector<Target> previousTargets;
    Vec pickCenter(RE::TESObjectREFR* ref) const {
        if(auto* actor=ref->As<RE::Actor>()) { auto b=actorBounds(actor); return (b.low+b.high)*.5f; }
        auto body=sample(ref);
        return body.count ? body.position : vec(ref->Get3D()->worldBound.center);
    }
    RE::NiPointer<RE::TESObjectREFR> pick(Vec origin,Vec direction) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto visible=[&](RE::TESObjectREFR* ref,Vec center) {
            // Small floor-level props may have a hollow/offset mesh centre. Try visible upper points too.
            float lift=std::clamp(ref->Get3D()->worldBound.radius*.3f,4.f,24.f);
            for(Vec point:{center,center+Vec{0,0,lift},center+Vec{0,0,lift*.5f}}) {
                auto obstruction=ray(p->GetParentCell(),origin,point,nullptr);
                if(!obstruction.hit || obstruction.ref.get().get()==ref) return true;
            }
            return false;
        };
        if(auto* picker=RE::CrosshairPickData::GetSingleton()) {
            for(auto handle:{picker->grabPickRef,picker->GetActiveTarget()}) {
                auto ref=handle.get();
                if(pickable(ref.get())) {
                    Vec center=pickCenter(ref.get());
                    if(aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,cfg.range,cfg.aimAssist)>=0 && visible(ref.get(),center)) return ref;
                }
            }
        }
        auto hit=ray(p->GetParentCell(),origin,origin+direction*cfg.range,nullptr);
        auto direct=hit.ref.get();
        if(pickable(direct.get())) return direct;
        // A small aim cone catches distant clutter that a single pixel-width ray misses.
        // Keep only eight candidates, then verify visibility; walls remain blockers.
        struct Candidate { RE::ObjectRefHandle ref; Vec center; float score; };
        std::vector<Candidate> candidates;
        if(auto* world=RE::TES::GetSingleton()) world->ForEachReferenceInRange(p,cfg.range+500.f,[&](RE::TESObjectREFR* ref) {
            if(!pickable(ref)) return RE::BSContainer::ForEachResult::kContinue;
            Vec center=pickCenter(ref);
            float score=aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,cfg.range,cfg.aimAssist);
            if(score<0) return RE::BSContainer::ForEachResult::kContinue;
            candidates.push_back({ref->GetHandle(),center,score});
            std::sort(candidates.begin(),candidates.end(),[](auto& a,auto& b){ return a.score<b.score; });
            if(candidates.size()>8) candidates.pop_back();
            return RE::BSContainer::ForEachResult::kContinue;
        });
        for(auto& candidate:candidates) {
            auto ref=candidate.ref.get();
            if(ref && visible(ref.get(),candidate.center)) return ref;
        }
        return {};
    }
    bool grip(RE::NiPointer<RE::TESObjectREFR> ref,bool quiet=false,bool paid=false) {
        if(!ref || !ref->Get3D() || ref->IsDisabled() || !sameWorld(ref.get())) return false;
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool tracked=std::any_of(flights.begin(),flights.end(),[&](auto& f){return f.ref==ref->GetHandle();});
        costFactor=1;
        if(auto* a=ref->As<RE::Actor>()) {
            auto* process=a->GetActorRuntimeData().currentProcess;
            bool dead=a->IsDead();
            if(!allowed(a) || (dead && !sample(a).count) || (!dead && (!process ||
               a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kParalysis)>0 ||
               (a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kGrabbed)>0 && !tracked)))) {
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Target resists telekinesis."); return false;
            }
            costFactor=resistance(a->GetScale(),dead ? p->GetLevel() : a->GetLevel(),p->GetLevel(),cfg.levelFactor);
            if(!spend(cfg.grabCost*costFactor)) return false;
            if(!dead) {
                // Existing live ragdolls need suspension, not another knockdown. Corpses need neither.
                if(!a->IsInRagdollState()) process->KnockExplosion(a,a->GetPosition(),0.f);
                castHold(a); a->StartCombat(p);
            }
        } else {
            auto* base=ref->GetBaseObject();
            if(!base) return false;
            // Loose carryable objects only. Never change static/animated/door physics.
            auto type=base->GetFormType();
            if(type!=RE::FormType::Weapon && type!=RE::FormType::Misc && type!=RE::FormType::Armor &&
               type!=RE::FormType::Ingredient && type!=RE::FormType::AlchemyItem) return false;
            if(!sample(ref.get()).count) {
                SKSE::log::warn("Target {:08X} has no movable rigid bodies",ref->GetFormID());
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Telekinesis: this object has no movable physics body."); return false;
            }
            if(!paid && !spend(cfg.grabCost)) return false;
        }
        std::erase_if(flights,[&](auto& f){return f.ref==ref->GetHandle();});
        held=ref->GetHandle(); holdWorld=p->GetParentCell()->GetbhkWorld(); holdAge=0; refresh=0; charged=0;
        distance=ref->As<RE::Actor>() ? cfg.distance : cfg.itemDistance;
        auto initial=sample(ref.get()); anchor=initial.count ? initial.position : pickCenter(ref.get());
        SKSE::log::info("Grip established on {:08X}",ref->GetFormID());
        return true;
    }

    Vec weaponPoint(RE::Actor* actor,RE::TESObjectWEAP* weapon,bool left) const {
        auto bounds=actorBounds(actor); Vec point=(bounds.low+bounds.high)*.5f;
        if(auto* hand=actor->Get3D()->GetObjectByName(RE::BSFixedString(left ? "NPC L Hand [LHnd]" : "NPC R Hand [RHnd]")))
            point=vec(hand->world.translate);
        // Choose the equipped mesh closest to that hand, including identical dual-wielded base forms.
        if(auto& biped=actor->GetBiped(); biped) {
            float closest=300.f; const Vec handPoint=point;
            for(auto& part:biped->objects) if(part.item==weapon && part.partClone) {
                auto center=vec(part.partClone->worldBound.center); float d=length(center-handPoint);
                if(finite(center) && d<closest) { closest=d; point=center; }
            }
        }
        return point;
    }
    bool disarm(Vec origin,Vec direction,bool quiet) {
        struct Choice { RE::ActorHandle actor; RE::FormID weapon{}; bool left{}; Vec point{}; float score{}; };
        std::vector<RE::ActorHandle> actors;
        auto* p=RE::PlayerCharacter::GetSingleton();
        RE::TES::GetSingleton()->ForEachCell([&](RE::TESObjectCELL* cell) {
            if(cell && cell->GetbhkWorld()==p->GetParentCell()->GetbhkWorld()) cell->ForEachReference([&](RE::TESObjectREFR* ref) {
                if(auto* a=ref->As<RE::Actor>(); a && a!=p && a->Get3D() && !a->IsDisabled()) actors.emplace_back(a);
                return RE::BSContainer::ForEachResult::kContinue;
            });
        });
        std::vector<Choice> choices;
        for(auto handle:actors) if(auto actor=handle.get()) {
            if(actor->IsDead() || !allowed(actor.get()) || !actor->IsHostileToActor(p) ||
               !actor->AsActorState()->IsWeaponDrawn()) continue;
            auto bounds=actorBounds(actor.get());
            float bodyScore=aimScore(origin,direction,(bounds.low+bounds.high)*.5f,32,cfg.disarmRange,cfg.aimAssist);
            for(bool left:{false,true}) {
                auto* entry=actor->GetEquippedEntryData(left);
                auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
                if(!weapon || weapon->IsBound() || weapon->IsHandToHandMelee() || entry->IsQuestObject()) continue;
                Vec point=weaponPoint(actor.get(),weapon,left);
                float score=aimScore(origin,direction,point,32,cfg.disarmRange,cfg.aimAssist);
                // Direct weapon aim wins; aiming at its wielder is a fallback, with right-hand priority.
                if(score<0 && bodyScore>=0 && length(point-origin)<=cfg.disarmRange) score=2.f+bodyScore+(left ? .1f : 0.f);
                if(score>=0) choices.push_back({handle,weapon->GetFormID(),left,point,score});
            }
        }
        std::sort(choices.begin(),choices.end(),[](auto& a,auto& b){return a.score<b.score;});
        for(auto& choice:choices) {
            auto actor=choice.actor.get(); if(!actor) continue;
            auto obstruction=ray(p->GetParentCell(),origin,choice.point,nullptr);
            if(obstruction.hit && obstruction.ref.get().get()!=actor.get()) continue;
            auto* entry=actor->GetEquippedEntryData(choice.left);
            auto* weapon=entry && entry->object ? entry->object->As<RE::TESObjectWEAP>() : nullptr;
            if(!weapon || weapon->GetFormID()!=choice.weapon || entry->IsQuestObject() || weapon->IsBound()) continue;
            RE::ExtraDataList* extra=nullptr;
            if(entry->extraLists) for(auto* list:*entry->extraLists) if(list &&
                (choice.left ? list->HasType<RE::ExtraWornLeft>() : list->HasType<RE::ExtraWorn>())) { extra=list; break; }
            // Never substitute a different enchanted/tempered copy if the worn instance is ambiguous.
            if(!extra) continue;
            float cost=cfg.disarmCost*resistance(actor->GetScale(),actor->GetLevel(),p->GetLevel(),cfg.levelFactor);
            if(!spend(cost)) {
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Not enough Magicka to disarm this enemy.");
                return true;
            }
            Vec point=choice.point+unit(origin-choice.point)*20.f+Vec{0,0,8}; auto location=ni(point);
            // Drop exactly the worn instance; native DropObject handles unequipping and inventory removal.
            auto dropped=actor->DropObject(weapon,extra,1,&location,nullptr);
            if(!dropped) {
                p->AsActorValueOwner()->RestoreActorValue(RE::ActorValue::kMagicka,cost);
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("That weapon could not be disarmed.");
                return true;
            }
            pendingWeapon=dropped; pendingWeaponTime=1.5f;
            SKSE::log::info("Disarm {:08X}: worn weapon {:08X} -> loose ref; waiting for physics",actor->GetFormID(),choice.weapon);
            return true;
        }
        return false;
    }
    RE::NiPointer<RE::TESObjectREFR> nearestObject() {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto b=actorBounds(p); Vec origin=(b.low+b.high)*.5f;
        std::vector<RE::ObjectRefHandle> objects;
        RE::TES::GetSingleton()->ForEachCell([&](RE::TESObjectCELL* cell) {
            if(cell && cell->GetbhkWorld()==p->GetParentCell()->GetbhkWorld()) cell->ForEachReference([&](RE::TESObjectREFR* ref) {
                if(!ref->As<RE::Actor>() && pickable(ref)) objects.push_back(ref->GetHandle());
                return RE::BSContainer::ForEachResult::kContinue;
            });
        });
        RE::NiPointer<RE::TESObjectREFR> closest; float distance=cfg.nearbyRadius;
        for(auto handle:objects) if(auto ref=handle.get()) {
            auto body=sample(ref.get()); if(!body.count) continue;
            float score=nearbyScore(origin,body.position,cfg.nearbyRadius);
            if(score<0 || score>distance) continue;
            auto obstruction=ray(p->GetParentCell(),origin,body.position,ref.get());
            if(!obstruction.hit) { closest=ref; distance=score; }
        }
        return closest;
    }
    bool catchMissile(bool quiet) {
        if(!cfg.catchProjectiles) return false;
        auto* manager=RE::Projectile::Manager::GetSingleton();
        auto* player=RE::PlayerCharacter::GetSingleton();
        if(!manager) return false;
        std::vector<RE::ProjectileHandle> candidates;
        {
            RE::BSSpinLockGuard lock(manager->projectileLock);
            for(auto& list:{&manager->limited,&manager->unlimited})
                for(auto handle:*list) candidates.push_back(handle);
        }
        auto bounds=actorBounds(player); Vec center=(bounds.low+bounds.high)*.5f;
        RE::NiPointer<RE::Projectile> closest; float best=cfg.projectileRadius;
        for(auto handle:candidates) if(auto projectile=handle.get()) {
            auto* missile=projectile->As<RE::MissileProjectile>();
            if(!missile || !missile->Get3D() || missile->IsDisabled() || !sameWorld(missile)) continue;
            auto& data=missile->GetProjectileRuntimeData();
            auto* base=missile->GetProjectileBase();
            auto* spell=data.spell ? data.spell->As<RE::SpellItem>() : nullptr;
            auto shooter=data.shooter.get(); auto* caster=shooter ? shooter->As<RE::Actor>() : nullptr;
            using Flags=RE::Projectile::Flags;
            using BaseFlags=RE::BGSProjectileData::BGSProjectileFlags;
            if(!base || !base->IsMissile() || !spell || !caster || caster==player || !caster->IsHostileToActor(player) ||
               !spell->IsHostile() || spell->GetCastingType()!=RE::MagicSystem::CastingType::kFireAndForget ||
               spell->GetDelivery()!=RE::MagicSystem::Delivery::kAimed || !spell->GetAVEffect() ||
               spell->GetAVEffect()!=data.avEffect || data.avEffect->data.projectileBase!=base ||
               data.weaponSource || data.ammoSource || data.flags.any(Flags::kDestroyed,Flags::kFading,Flags::kProcessedImpacts,Flags::kHitScan) ||
               base->data.flags.any(BaseFlags::kHitScan,BaseFlags::kExplosionAltTrigger,BaseFlags::kContinuousUpdate) ||
               missile->GetMissileRuntimeData().waitingToInitialize3D ||
               missile->GetMissileRuntimeData().impactResult!=RE::ImpactResult::kNone ||
               !std::isfinite(data.power) || data.power<=0 || !std::isfinite(data.scale) || data.scale<=0) continue;
            Vec position=vec(missile->GetPosition()), speed=vec(data.linearVelocity);
            float score=incomingMissileScore(center,position,speed,cfg.projectileRadius);
            if(score<0 || score>=best) continue;
            Vec eye=vec(RE::PlayerCamera::GetActiveCameraPosition());
            auto obstruction=ray(player->GetParentCell(),eye,position,missile);
            if(obstruction.hit) continue;
            best=score; closest=projectile;
        }
        if(!closest) return false;
        auto* missile=closest->As<RE::MissileProjectile>(); auto& data=missile->GetProjectileRuntimeData();
        if(!spend(cfg.projectileCost)) {
            if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Not enough Magicka to catch this projectile.");
            return true;
        }
        projectileCaster=data.shooter; projectileSpell=data.spell->GetFormID();
        projectilePower=data.power; projectileScale=data.scale; projectileSpeed=length(vec(data.linearVelocity));
        held=missile->GetHandle(); holdWorld=player->GetParentCell()->GetbhkWorld();
        holdAge=0; refresh=0; charged=0; costFactor=1; distance=cfg.itemDistance; anchor=vec(missile->GetPosition());
        // Suppression starts before moving the reference. The hook touches no controller pointers.
        missile_hold::suspend(missile); data.linearVelocity={}; data.velocity={}; data.desiredTarget={};
        SKSE::log::info("Caught missile {:08X}, source spell {:08X}; release to return",missile->GetFormID(),projectileSpell);
        RE::SendHUDMessage::ShowHUDMessage("Projectile held. Release to return; Activate to dissipate.");
        return true;
    }
    void holdMissile(RE::MissileProjectile* missile,float dt) {
        auto* player=RE::PlayerCharacter::GetSingleton();
        if(!missile_hold::matches(missile) || missile->IsDisabled() || !missile->Get3D() || !sameWorld(missile) ||
           missile->GetProjectileRuntimeData().flags.any(RE::Projectile::Flags::kDestroyed) ||
           holdAge>=cfg.projectileHoldSeconds || !spend(cfg.holdCost*dt)) { drop(); return; }
        distance=std::clamp(distance+((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt,cfg.minDistance,cfg.maxDistance);
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
        auto* camera=RE::PlayerCamera::GetSingleton();
        float reach=itemRayDistance(origin,direction,vec(player->GetPosition()),distance,camera && camera->IsInThirdPerson());
        auto wall=ray(player->GetParentCell(),origin,origin+direction*reach,missile);
        Vec goal=origin+direction*(wall.hit ? std::max(0.f,reach*wall.fraction-50.f) : reach);
        auto next=advanceAnchor(anchor,goal,cfg.pickupSpeed,dt);
        auto obstacle=ray(player->GetParentCell(),anchor,next,missile);
        if(obstacle.hit) next=anchor+(next-anchor)*std::max(0.f,obstacle.fraction-.05f);
        anchor=next;
        missile->SetPosition(ni(anchor));
        // Native missile movement writes the root's local translation from reference position.
        // Update3D then publishes world transforms. No Havok prop controller is used here.
        missile->Get3D()->local.translate=ni(anchor); missile->Update3D();
    }
    void returnMissile(RE::MissileProjectile* missile) {
        auto* player=RE::PlayerCharacter::GetSingleton();
        auto* spell=RE::TESForm::LookupByID<RE::SpellItem>(projectileSpell);
        if(!spell || !spell->GetAVEffect() || spell->GetAVEffect()->data.projectileBase!=missile->GetProjectileBase() ||
           !spend(cfg.launchCost)) { drop(); return; }
        Vec origin=vec(missile->GetPosition()), direction=aim();
        if(auto ref=projectileCaster.get()) if(auto* caster=ref->As<RE::Actor>(); caster && !caster->IsDead() &&
            !caster->IsDisabled() && caster->Get3D() && sameWorld(caster)) {
            auto bounds=actorBounds(caster); Vec target=(bounds.low+bounds.high)*.5f;
            auto obstruction=ray(player->GetParentCell(),origin,target,missile);
            if(!obstruction.hit || obstruction.ref.get().get()==caster) direction=unit(target-origin);
        }
        if(!finite(direction) || length(direction)<.5f) { drop(); return; }
        auto angles=missileAngles(direction);
        RE::Projectile::LaunchData launch(player,ni(origin),{angles.x,angles.z},spell);
        launch.power=projectilePower; launch.scale=projectileScale;
        RE::ProjectileHandle result; RE::Projectile::Launch(&result,launch);
        if(auto returned=result.get()) {
            auto& data=returned->GetProjectileRuntimeData();
            auto* base=returned->GetProjectileBase(); float baseSpeed=base ? base->data.speed : 0.f;
            // Native launch gives the return missile the player's collision group and damage attribution.
            if(baseSpeed>0 && std::isfinite(projectileSpeed)) data.speedMult=projectileSpeed/baseSpeed;
            data.linearVelocity=ni(direction*projectileSpeed); data.desiredTarget={};
            SKSE::log::info("Returned source spell {:08X} as missile {:08X}",projectileSpell,returned->GetFormID());
        } else RE::SendHUDMessage::ShowHUDMessage("Projectile return failed; dissipating safely.");
        // Kill has native cleanup without impact/explosion. Never resume the hostile collision group.
        drop();
    }
    void grab(bool quiet=false,bool shift=false) {
        if(held || pendingWeapon) { drop(); return; }
        Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition());
        if(shift && disarm(origin,aim(),quiet)) return;
        if(shift && catchMissile(quiet)) return;
        auto ref=shift ? nearestObject() : pick(origin,aim());
        if(ref || !quiet) SKSE::log::info("{} grab target {:08X}",shift ? "Shift" : "Aim",ref ? ref->GetFormID() : 0);
        if(!ref || !ref->Get3D() || ref->IsDisabled()) {
            if(!quiet) RE::SendHUDMessage::ShowHUDMessage(shift ? "Shift-cast: enemy weapon, incoming spell missile, or nearby item." :
                "Telekinesis: aim at a loose object or creature.");
            return;
        }
        grip(ref,quiet);
    }
    void launch(bool slam) {
        auto ref=held.get(); if(!ref) return;
        if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) { returnMissile(missile); return; }
        if(!sample(ref.get()).count) return;
        if(auto* a=ref->As<RE::Actor>(); a && !a->IsDead() && !a->IsInRagdollState()) return;
        if(static_cast<int>(flights.size())>=cfg.maxFlights) { RE::SendHUDMessage::ShowHUDMessage("Too many objects in flight."); return; }
        if(!spend(cfg.launchCost*costFactor)) return;
        bool actor=ref->As<RE::Actor>()!=nullptr;
        float launchSpeed=actor ? cfg.actorLaunchSpeed : cfg.launchSpeed;
        float slamSpeed=actor ? cfg.actorSlamSpeed : cfg.slamSpeed;
        Vec speed=slam ? Vec{0,0,-slamSpeed} : aim()*launchSpeed;
        Vec launchDirection=unit(speed);
        if(!velocity(ref.get(),speed,actor ? nullptr : &launchDirection)) { drop(); return; }
        auto s=sample(ref.get());
        float mass=actor ? 0.f : std::clamp(ref->GetWeight(),cfg.objectMassFloor,cfg.massCap);
        float mult=ref->GetBaseObject()->As<RE::TESObjectWEAP>() ? 2.f : 1.f;
        flights.push_back({held,s.position,speed,s.halfExtent,mass,mult,actor ? cfg.actorFlightSeconds : cfg.flightSeconds,0,0,s.position.z,slam,false});
        if(!actor) SKSE::log::info("Prop launch {:08X}: speed {:.1f}, half extents {:.1f}/{:.1f}/{:.1f}",
            ref->GetFormID(),length(speed),s.halfExtent.x,s.halfExtent.y,s.halfExtent.z);
        // Keep the brief grabbed-state effect for the flight; it expires on its own.
        held={}; holdWorld=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        gripInput=RE::BSFixedString(); slamDown=false;
    }
    void execute(RE::Actor* a) {
        if(!weak(a)) { charged=0; execDown=false; return; }
        if(!spend(cfg.executionCost*costFactor)) {
            RE::SendHUDMessage::ShowHUDMessage("Not enough Magicka for the finisher.");
            charged=0; execDown=false; return;
        }
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(executionSpell) if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(executionSpell,false,a,1.f,false,0.f,p);
        hurt(a,a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)+1000.f);
        if(a->IsDead() || a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)<=0) {
            SKSE::ModCallbackEvent event{RE::BSFixedString("TKC_Execution"),RE::BSFixedString("crush"),0.f,a};
            SKSE::GetModCallbackEventSource()->SendEvent(&event);
            // Wait for engine death state instead of beheading a living actor during notification.
            auto* race=a->GetRace();
            if(cfg.decapitate && a->HasKeywordString("ActorTypeNPC") && race &&
               (race->decapitateArmors[0] || race->decapitateArmors[1]) && executions.size()<8)
                executions.push_back({RE::ActorHandle{a}});
            RE::SendHUDMessage::ShowHUDMessage("Telekinetic crush!");
        } else { RE::SendHUDMessage::ShowHUDMessage("Target resisted the finisher."); }
        drop(false);
    }
    void tick() {
        auto now=Clock::now(); float dt=std::chrono::duration<float>(now-last).count(); last=now;
        if(!ready) return;
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* ui=RE::UI::GetSingleton();
        if(!p || !p->Get3D() || !p->GetParentCell() || !ui ||
           ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) || ui->IsMenuOpen(RE::MainMenu::MENU_NAME)) { reset(); return; }
        if(ui->GameIsPaused()) return; // Preserve the grip and freeze costs/flight timers while paused.
        dt=std::clamp(dt,0.f,.05f);
        for(auto it=executions.begin();it!=executions.end();) {
            auto actor=it->ref.get(); it->remaining-=dt;
            if(!actor || !actor->Get3D() || actor->IsDisabled() || !sameWorld(actor.get()) || it->remaining<=0) {
                it=executions.erase(it); continue;
            }
            if(actor->IsDead() && !actor->IsInKillMove()) {
                bool success=actor->Decapitate();
                SKSE::log::info("Execution decapitation {:08X}: {}",actor->GetFormID(),success ? "applied" : "unsupported/already applied");
                it=executions.erase(it); continue;
            }
            ++it;
        }
        if(castingHeld && !usable()) drop();
        if(pendingWeapon) {
            pendingWeaponTime-=dt; auto ref=pendingWeapon.get();
            if(!usable() || !ref || ref->IsDisabled() || !sameWorld(ref.get())) drop();
            else if(ref->Get3D() && sample(ref.get()).count) {
                pendingWeapon={}; pendingWeaponTime=0;
                if(!grip(ref,true,true)) drop();
            } else if(pendingWeaponTime<=0) {
                RE::SendHUDMessage::ShowHUDMessage("Disarmed weapon dropped; its physics could not be loaded."); drop();
            }
        }
        if(!held && !pendingWeapon && castingHeld) {
            retry+=dt;
            if(retry>=(castingShift ? .016f : .08f)) { retry=0; grab(true,castingShift); if(held || pendingWeapon) gripInput=castingInput; }
        }
        if(held && (!usable() || p->GetParentCell()->GetbhkWorld()!=holdWorld)) drop();
        if(auto ref=held.get()) {
            holdAge+=dt; refresh+=dt;
            auto* actor=ref->As<RE::Actor>();
            if(auto* missile=ref->As<RE::MissileProjectile>(); missile && missile_hold::matches(missile)) holdMissile(missile,dt);
            else if(ref->IsDisabled() || !ref->Get3D() || !sameWorld(ref.get()) || (actor && !allowed(actor)) || !spend(cfg.holdCost*costFactor*dt)) { drop(); }
            else {
                if(actor && !actor->IsDead() && refresh>=1.f) { castHold(actor); refresh=0; }
                auto s=sample(ref.get());
                if(!finite(s.position) || !finite(s.velocity)) { drop(); }
                else if(!s.count || (actor && !actor->IsDead() && !actor->IsInRagdollState())) {
                    if(holdAge>1.5f) { RE::SendHUDMessage::ShowHUDMessage("Cannot establish a ragdoll grip."); drop(); }
                } else {
                    distance=std::clamp(distance+((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt,cfg.minDistance,cfg.maxDistance);
                    Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
                    auto* camera=RE::PlayerCamera::GetSingleton();
                    float rayDistance=actor ? distance : itemRayDistance(origin,direction,vec(p->GetPosition()),
                        distance,camera && camera->IsInThirdPerson());
                    auto wall=ray(p->GetParentCell(),origin,origin+direction*rayDistance,ref.get());
                    float safeDistance=wall.hit ? std::max(80.f,rayDistance*wall.fraction-60.f) : rayDistance;
                    if(length(s.position-origin)>cfg.range*2.f+cfg.maxDistance) { drop(); }
                    else {
                        Vec previous=anchor;
                        float speedLimit=!actor && length(s.position-origin)>rayDistance+200.f ? cfg.pickupSpeed : cfg.holdSpeed;
                        auto next=advanceAnchor(anchor,origin+direction*safeDistance,speedLimit,dt);
                        // Sweep the body's path too: turning toward a wall clamps the grip instead of dropping it.
                        auto blocked=ray(ref->GetParentCell(),s.position,next,ref.get());
                        if(blocked.hit) {
                            Vec delta=next-s.position; float travel=length(delta);
                            next=s.position+unit(delta)*std::max(0.f,travel*blocked.fraction-30.f);
                        }
                        anchor=next;
                        // Do not rotate a held mesh every tick: its COM offset would move underneath this controller.
                        velocity(ref.get(),holdVelocity(previous,anchor,s.position,dt,cfg.gain,speedLimit),nullptr,!actor);
                        if(execDown && weak(actor)) {
                            charged+=dt; if(charged>=cfg.charge) execute(actor);
                        } else charged=0;
                    }
                }
            }
        } else { held={}; missile_hold::clear(); projectileCaster={}; projectileSpell=0; }
        // Use loaded actor handles/physical bounds once per tick, not stale logical-origin range filters.
        std::vector<Target> targets;
        if(!flights.empty()) RE::TES::GetSingleton()->ForEachCell([&](RE::TESObjectCELL* cell) {
            if(cell && cell->GetbhkWorld()==p->GetParentCell()->GetbhkWorld()) cell->ForEachReference([&](RE::TESObjectREFR* ref) {
                auto* actor=ref->As<RE::Actor>();
                if(actor && actor!=p && actor->Get3D() && !actor->IsDead() && !actor->IsDisabled()) {
targets.push_back({RE::ActorHandle{actor},{}});
                }
                return RE::BSContainer::ForEachResult::kContinue;
            });
        });
        // Query physics after releasing cell reference locks.
        for(auto& target:targets) {
            auto actor=target.ref.get(); if(!actor) continue;
            target.bounds=actorBounds(actor.get());
            auto old=std::find_if(previousTargets.begin(),previousTargets.end(),[&](auto& t){return t.ref==target.ref;});
            if(old!=previousTargets.end()) {
                target.movement=(target.bounds.low+target.bounds.high-old->bounds.low-old->bounds.high)*.5f;
                if(length(target.movement)>512.f) target.movement={}; // Teleporting actors have no swept combat path.
            }
        }
        for(auto it=flights.begin();it!=flights.end();) {
            auto ref=it->ref.get(); it->remaining-=dt; it->elapsed+=dt; it->refresh+=dt;
            auto s=ref ? sample(ref.get()) : Sample{};
            if(!ref || !s.count || ref->IsDisabled() || !sameWorld(ref.get()) || it->remaining<=0 ||
                !finite(s.position) || !finite(s.velocity) || length(s.position-it->previous)>cfg.range) {
                if(ref && !ref->As<RE::Actor>()) SKSE::log::info("Prop flight ended {:08X}: {}",ref->GetFormID(),
                    it->remaining<=0 ? "expired without confirmed contact" : "physics/scene unavailable");
                it=flights.erase(it); continue;
            }
            auto* thrown=ref->As<RE::Actor>();
            if(thrown && !thrown->IsDead() && !it->impactApplied && allowed(thrown) && it->refresh>=1.f) { castHold(thrown); it->refresh=0; }
            it->peakZ=std::max(it->peakZ,s.position.z);
            float speed=length(it->velocity);
            // A ray covers static geometry; swept actor bounds cover high-speed tunnelling.
            auto wall=ray(ref->GetParentCell(),it->previous,s.position,ref.get());
            auto wallRef=wall.ref.get();
            RE::Actor* victim=wallRef ? wallRef->As<RE::Actor>() : nullptr;
            float closest=wall.hit ? wall.fraction : 1.f;
            Vec step=s.position-it->previous;
            for(auto& target:targets) {
                auto a=target.ref.get(); if(!a || a.get()==ref.get()) continue;
                auto bounds=target.bounds;
                Vec extent=thrown ? Vec{} : Vec{std::max(it->halfExtent.x,s.halfExtent.x),
                    std::max(it->halfExtent.y,s.halfExtent.y),std::max(it->halfExtent.z,s.halfExtent.z)};
                // ponytail: swept AABBs approximate blade/limb contact; exact mesh contacts need Havok callbacks.
                float t=movingBoxHit(it->previous,s.position,bounds.low,bounds.high,extent,cfg.radius,target.movement);
                if(t>=0 && t<=closest) {
                    // Test to the body itself, not only its padded entry, so long blades cannot reach through walls.
                    auto obstruction=ray(ref->GetParentCell(),it->previous,(bounds.low+bounds.high)*.5f,ref.get());
                    auto obstructionRef=obstruction.ref.get();
                    if(!obstruction.hit || obstructionRef.get()==a.get()) { victim=a.get(); closest=t; }
                }
            }
            // Ignore the initial settling tick. Directional velocity loss catches wall/floor impacts.
            float loss=dot(it->velocity-s.velocity,unit(it->velocity));
            bool collision=confirmedImpact(victim!=nullptr,wall.hit,thrown!=nullptr,
                it->elapsed>.06f && loss>std::max(cfg.minimum,speed*.4f));
            if(!thrown) speed=std::min(4500.f,std::max({speed,length(s.velocity),length(step)/std::max(dt,.001f)}));
            bool fall=thrown && !it->slam && lethalFall(it->peakZ,s.position.z,it->velocity.z,cfg.cliffDrop,cfg.minimum);
            if(collision && speed>=cfg.minimum && (!it->impactApplied || fall)) {
                if(!thrown) {
                    Vec contact=it->previous+step*closest;
                    stopProp(ref.get(),contact-unit(it->velocity)*2.f);
                    if(victim) {
                        float amount=objectImpactDamage(speed,it->mass,cfg.multiplier*it->multiplier,cfg.minimum,cfg.damageCap,
                            it->multiplier>1.f ? cfg.weaponHitMinimum : cfg.objectHitMinimum);
                        SKSE::log::info("Prop hit {:08X} -> {:08X}: speed {:.1f}, weight {:.1f}, damage {:.1f}",
                            ref->GetFormID(),victim->GetFormID(),speed,it->mass,amount);
                        hurt(victim,amount);
                        if(!victim->IsDead() && !victim->IsInRagdollState() && !victim->IsInKillMove() &&
                           !victim->IsChild() && !victim->IsEssential() && !(cfg.protect && victim->IsProtected())) {
                            victim->SetGraphVariableFloat(RE::BSFixedString("staggerMagnitude"),.75f);
                            victim->NotifyAnimationGraph(RE::BSFixedString("staggerStart"));
                        }
                    }
                    else SKSE::log::info("Prop contact {:08X}: geometry/non-actor obstruction",ref->GetFormID());
                    it=flights.erase(it); continue;
                }
                auto actorDamage=[&](RE::Actor* target,bool slammed,bool falling) {
                    auto* values=target->AsActorValueOwner();
                    float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
                        target->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
                    return actorImpactDamage(values->GetActorValue(RE::ActorValue::kHealth),maximum,p->GetLevel(),target->GetLevel(),
                        speed,slammed ? cfg.actorSlamSpeed : cfg.actorLaunchSpeed,
                        slammed ? cfg.slamFraction : cfg.throwFraction,cfg.actorDamageCap,cfg.lethalLevelAdvantage,falling,slammed);
                };
                if(!it->impactApplied && victim) hurt(victim,actorDamage(victim,false,false));
                if(!thrown->IsDead()) {
                    hurt(thrown,actorDamage(thrown,it->slam,fall));
                    if(it->slam && !thrown->IsDead() && allowed(thrown)) {
                        if(auto* queue=RE::TaskQueueInterface::GetSingleton()) {
                            RE::ActorHandle target{thrown},caster{p}; queue->QueueActorDisarm(target,caster);
                            SKSE::log::info("Nonlethal slam: disarm queued for {:08X}",thrown->GetFormID());
                        }
                    }
                }
                it->impactApplied=true;
                // One ordinary hit; continue tracking a surviving throw for a later cliff landing.
                if(it->slam || thrown->IsDead()) { it=flights.erase(it); continue; }
            }
            it->previous=s.position; it->velocity=s.velocity; ++it;
        }
        previousTargets=std::move(targets);
    }
    struct Button {
        std::uint32_t key; RE::INPUT_DEVICE device; RE::BSFixedString action;
        bool down,up,pressed;
    };
    void input(const std::vector<Button>& buttons) {
        // Snapshot both Shift keys before casting actions, including presses in the same input batch.
        for(const auto& button:buttons) if(button.device==RE::INPUT_DEVICE::kKeyboard && (button.key==42 || button.key==54)) {
            auto& key=button.key==42 ? shiftLeft : shiftRight;
            if(button.down) key=true;
            if(button.up) key=false;
        }
        if(!shiftLeft && !shiftRight) ignoreInitialShift=false;
        slamDown=shiftSlam(static_cast<bool>(held),shiftLeft,shiftRight,ignoreInitialShift);
        for(const auto& button:buttons) {
            auto key=button.key; auto device=button.device; auto userEvent=button.action;
            auto* user=RE::UserEvents::GetSingleton();
            if(!user) continue;
            // Use Skyrim's mapped casting actions, including remapped mouse/gamepad buttons.
            bool castInput=userEvent==user->leftAttack || userEvent==user->rightAttack;
            if(castInput) {
                auto* player=RE::PlayerCharacter::GetSingleton();
                bool controlHand=player && player->GetEquippedObject(userEvent==user->leftAttack)==controlSpell;
                auto action=castAction(button.down,button.up,static_cast<bool>(held) || static_cast<bool>(pendingWeapon),userEvent==gripInput,controlHand);
                if(button.up) {
                    if(userEvent==castingInput) { castingHeld=false; castingInput=RE::BSFixedString(); }
                    if(action==CastAction::release) {
                        if(usable()) launch(slamDown);
                        // Failed launch (Magicka, ragdoll or flight limit) must release the grip.
                        if(held || pendingWeapon) drop();
                    } else if(userEvent==finisherInput) { execDown=false; charged=0; finisherInput=RE::BSFixedString(); }
                    continue;
                }
                if(!usable()) continue;
                if(action==CastAction::grab) {
                    castingHeld=true; castingInput=userEvent; retry=0;
                    castingShift=shiftLeft || shiftRight; ignoreInitialShift=castingShift; slamDown=false;
                    grab(false,castingShift); if(held || pendingWeapon) gripInput=userEvent;
                } else if(action==CastAction::charge) {
                    beginFinisher(userEvent);
                }
                continue;
            }
            if(device==RE::INPUT_DEVICE::kKeyboard && (key==42 || key==54)) continue;
            if(!usable()) continue;
            if((held || pendingWeapon) && userEvent==user->activate) {
                if(button.down) {
                    auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
                    if(pendingWeapon || (ref && ref->As<RE::MissileProjectile>())) drop();
                    else if(weak(actor)) beginFinisher(userEvent);
                    else if(ref && !actor) {
                        auto body=sample(ref.get());
                        auto* player=RE::PlayerCharacter::GetSingleton();
                        auto bounds=actorBounds(player); Vec origin=(bounds.low+bounds.high)*.5f;
                        auto obstacle=ray(ref->GetParentCell(),origin,body.position,ref.get());
                        bool close=body.count && length(body.position-origin)<=cfg.pickupReach;
                        drop();
                        if(close && !obstacle.hit) {
                            bool activated=ref->ActivateRef(RE::PlayerCharacter::GetSingleton(),0,nullptr,std::max(1,static_cast<int>(ref->extraList.GetCount())),false);
                            SKSE::log::info("Held item {:08X}: native activation {}",ref->GetFormID(),activated);
                        }
                    } else drop();
                } else if(button.up && finisherInput==userEvent) { drop(); }
                continue;
            }
            if(held && device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9) && button.pressed) {
                distance=std::clamp(distance+(key==8 ? -50.f : 50.f),cfg.minDistance,cfg.maxDistance);
                continue;
            }
            if(!cfg.legacyHotkeys || device!=RE::INPUT_DEVICE::kKeyboard) continue;
            if(button.up) {
                if(key==cfg.execute) { execDown=false; charged=0; }
                if(key==cfg.pull) pulling=false;
                if(key==cfg.push) pushing=false;
            }
            if(!usable() || !button.down) continue;
            if(key==cfg.grab) { ignoreInitialShift=shiftLeft || shiftRight; slamDown=false; grab(false,ignoreInitialShift); }
            else if(key==cfg.launch) launch(false);
            else if(key==cfg.slam) launch(true);
            else if(key==cfg.pull) pulling=true;
            else if(key==cfg.push) pushing=true;
            else if(key==cfg.execute && held) beginFinisher(userEvent);
        }
    }
    RE::BSEventNotifyControl ProcessEvent(RE::InputEvent* const* events,RE::BSTEventSource<RE::InputEvent*>*) override {
        if(!events || !ready) return RE::BSEventNotifyControl::kContinue;
        std::vector<Button> buttons;
        for(auto* event=*events;event;event=event->next) {
            auto* button=event->AsButtonEvent();
            if(!button) continue;
            auto key=button->GetIDCode(); auto device=button->GetDevice();
            if(button->IsDown() || button->IsUp() || (device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9)))
                buttons.push_back({key,device,button->QUserEvent(),button->IsDown(),button->IsUp(),button->IsPressed()});
        }
        // Input can arrive on worker threads. Own a snapshot and mutate game state on the game thread.
        if(!buttons.empty()) SKSE::GetTaskInterface()->AddTask([buttons=std::move(buttons)] {
            auto& state=Combat::get(); if(state.ready) state.input(buttons);
        });
        return RE::BSEventNotifyControl::kContinue;
    }
};

std::jthread ticker;
void message(SKSE::MessagingInterface::Message* msg) {
    auto& combat=Combat::get();
    switch(msg->type) {
    case SKSE::MessagingInterface::kDataLoaded:
        combat.resolve();
        if(cfg.catchProjectiles) missile_hold::install();
        RE::BSInputDeviceManager::GetSingleton()->AddEventSink(&combat);
        ticker=std::jthread([](std::stop_token stop) {
            while(!stop.stop_requested()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(16));
                auto& c=Combat::get();
                if(!c.ready || c.queued.exchange(true)) continue;
                SKSE::GetTaskInterface()->AddTask([] {
                    auto& state=Combat::get();
                    try { state.tick(); } catch(const std::exception& e) { SKSE::log::error("Tick: {}",e.what()); }
                    state.queued=false;
                });
            }
        });
        break;
    case SKSE::MessagingInterface::kSaveGame:
        // SKSE dispatches before serialization: do not save a frozen hostile missile with zero velocity.
        if(missile_hold::suspended.load(std::memory_order_acquire)!=0) combat.drop();
        break;
    case SKSE::MessagingInterface::kPreLoadGame:
        combat.ready=false; combat.reset(); break;
    case SKSE::MessagingInterface::kPostLoadGame:
    case SKSE::MessagingInterface::kNewGame:
        combat.reset(); combat.ready=true; break;
    default: break;
    }
}
}

SKSEPluginLoad(const SKSE::LoadInterface* skse) {
    auto directory=SKSE::log::log_directory();
    if(!directory) return false;
    auto sink=std::make_shared<spdlog::sinks::basic_file_sink_mt>((*directory/"TelekinesisCombat.log").string(),true);
    auto logger=std::make_shared<spdlog::logger>("TKC",sink);
    spdlog::set_default_logger(logger); spdlog::flush_on(spdlog::level::info);
    SKSE::Init(skse);
    if(REL::Module::IsVR()) { SKSE::log::error("VR is not supported"); return false; }
    const auto runtime=REL::Module::get().version();
    const std::array supported{REL::Version{1,5,97,0},REL::Version{1,6,640,0},REL::Version{1,6,659,0},
        REL::Version{1,6,1170,0},REL::Version{1,6,1179,0},REL::Version{1,7,104,0}};
    if(std::find(supported.begin(),supported.end(),runtime)==supported.end()) {
        SKSE::log::error("Runtime {} is outside the target list",runtime.string()); return false;
    }
    return SKSE::GetMessagingInterface()->RegisterListener(message);
}
