#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <Windows.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <atomic>
#include <array>
#include <chrono>
#include <filesystem>
#include <thread>
#include <stdexcept>
#include <vector>
#include "combat_math.h"
#include "controls.h"
#include "raycast.h"

namespace {
using namespace tkc;
using Clock=std::chrono::steady_clock;
Vec vec(RE::NiPoint3 p) { return {p.x,p.y,p.z}; }
RE::NiPoint3 ni(Vec p) { return {p.x,p.y,p.z}; }
Vec vec(const RE::hkVector4& p) {
    return {p.quad.m128_f32[0],p.quad.m128_f32[1],p.quad.m128_f32[2]};
}
RE::hkVector4 hk(Vec p) { return {p.x,p.y,p.z,0.f}; }

struct Config {
    std::string plugin="TelekinesisCombat.esp";
    std::uint32_t control=0x800, hold=0x801, execution=0;
    std::uint32_t grab=34, launch=35, pull=36, push=37, slam=38, execute=45;
    bool legacyHotkeys=false;
    float grabCost=15, holdCost=12, launchCost=10, executionCost=40;
    float levelFactor=.04f, maxScale=1.5f, maxHeight=260, maxExtent=360, executionHealth=.35f, charge=1.f;
    bool undead=true, creatures=true, corpses=true, protect=true, orient=true;
    float range=6000, aimAssist=3, pickupSpeed=10000, distance=300, minDistance=140, maxDistance=650, adjustSpeed=240;
    float gain=10, holdSpeed=4500, launchSpeed=3600, slamSpeed=3000;
    float minimum=450, multiplier=6, damageCap=1500, objectMassFloor=5, massCap=40;
    float actorLaunchSpeed=1600, actorSlamSpeed=1400, throwFraction=.20f, slamFraction=.30f, actorDamageCap=.45f;
    float cliffDrop=800, actorFlightSeconds=15, itemDistance=160, pickupReach=260;
    int lethalLevelAdvantage=10;
    float radius=26, flightSeconds=4;
    int maxFlights=8;
    void load() {
        auto path=std::filesystem::absolute("Data/SKSE/Plugins/TelekinesisCombat.ini").string();
        auto read=[&](const char* section,const char* key,const std::string& fallback) {
            char buffer[512]{};
            GetPrivateProfileStringA(section,key,fallback.c_str(),buffer,sizeof(buffer),path.c_str());
            return std::string(buffer);
        };
        auto number=[&](const char* section,const char* key,float fallback,float lo,float hi) {
            try {
                auto s=read(section,key,std::to_string(fallback)); size_t used=0;
                float n=std::stof(s,&used);
                if(used!=s.size() || !std::isfinite(n)) throw std::invalid_argument(key);
                return std::clamp(n,lo,hi);
            } catch(...) { SKSE::log::warn("Invalid INI {}.{}; using default",section,key); return fallback; }
        };
        auto form=[&](const char* key,std::uint32_t fallback) {
            try {
                auto s=read("Forms",key,std::to_string(fallback)); size_t used=0;
                auto n=std::stoul(s,&used,0);
                if(used!=s.size() || n>0xFFFFFF) throw std::invalid_argument(key);
                return static_cast<std::uint32_t>(n);
            } catch(...) { SKSE::log::warn("Invalid form {}",key); return fallback; }
        };
        plugin=read("Forms","Plugin",plugin);
        legacyHotkeys=number("Controls","LegacyHotkeys",0,0,1)!=0;
        control=form("ControlSpell",control); hold=form("HoldSpell",hold); execution=form("ExecutionSpell",execution);
#define KEY(member,name) member=static_cast<std::uint32_t>(number("Controls",name,static_cast<float>(member),1,255))
        KEY(grab,"Grab"); KEY(launch,"Launch"); KEY(pull,"Pull"); KEY(push,"Push"); KEY(slam,"Slam"); KEY(execute,"Execute");
#undef KEY
#define G(member,name,lo,hi) member=number("Gameplay",name,member,lo,hi)
        G(grabCost,"GrabCost",0,500); G(holdCost,"HoldCostPerSecond",0,500);
        G(launchCost,"LaunchCost",0,500); G(executionCost,"ExecutionCost",0,1000);
        G(levelFactor,"LevelResistance",0,.2f); G(maxScale,"MaxActorScale",.5f,2);
        G(maxHeight,"MaxActorHeight",50,500); G(maxExtent,"MaxActorExtent",100,800); G(executionHealth,"ExecutionHealthFraction",.01f,.5f);
        G(charge,"ExecutionChargeSeconds",.25f,5);
        lethalLevelAdvantage=static_cast<int>(number("Gameplay","LethalLevelAdvantage",10,1,100));
#undef G
        undead=number("Gameplay","AllowUndead",1,0,1)!=0;
        creatures=number("Gameplay","AllowCreatures",1,0,1)!=0;
        corpses=number("Gameplay","AllowCorpses",1,0,1)!=0;
        protect=number("Gameplay","ProtectProtectedActors",1,0,1)!=0;
        orient=number("Physics","OrientSwords",1,0,1)!=0;
#define P(member,name,lo,hi) member=number("Physics",name,member,lo,hi)
        P(range,"Range",200,8000); P(aimAssist,"AimAssistDegrees",.25f,5);
        P(pickupSpeed,"PickupSpeed",1000,20000); P(minDistance,"MinHoldDistance",80,500);
        P(maxDistance,"MaxHoldDistance",minDistance,1000); P(distance,"HoldDistance",minDistance,maxDistance);
        P(itemDistance,"ItemHoldDistance",minDistance,maxDistance); P(pickupReach,"PickupReach",100,300);
        P(adjustSpeed,"PullPushSpeed",20,600); P(gain,"SpringGain",1,12); P(holdSpeed,"MaxHoldSpeed",100,8000);
        P(launchSpeed,"LaunchSpeed",500,4500); P(slamSpeed,"SlamSpeed",500,4500);
        P(minimum,"ImpactMinSpeed",100,2000); P(multiplier,"ImpactDamageMultiplier",0,10);
        P(damageCap,"MaxImpactDamage",0,10000); P(massCap,"ObjectMassCap",1,100);
        P(objectMassFloor,"ObjectMassFloor",1,massCap);
        P(actorLaunchSpeed,"ActorLaunchSpeed",500,3000); P(actorSlamSpeed,"ActorSlamSpeed",500,3000);
        P(throwFraction,"ActorThrowDamageFraction",.01f,.5f); P(slamFraction,"ActorSlamDamageFraction",.01f,.5f);
        P(actorDamageCap,"ActorDamageCapFraction",.05f,.8f);
        P(cliffDrop,"CliffLethalDrop",400,4000); P(actorFlightSeconds,"ActorFlightSeconds",4,30);
        P(radius,"HitRadius",10,80); P(flightSeconds,"FlightSeconds",.5f,8);
#undef P
        maxFlights=static_cast<int>(number("Physics","MaxFlights",8,1,16));
        std::vector<std::uint32_t> keys{grab,launch,pull,push,slam,execute};
        std::sort(keys.begin(),keys.end());
        if(std::adjacent_find(keys.begin(),keys.end())!=keys.end()) {
            SKSE::log::warn("Duplicate controls; restoring defaults");
            grab=34; launch=35; pull=36; push=37; slam=38; execute=45;
        }
    }
} cfg;

// No body/scene pointers survive a game-thread task or world-lock scope.
void bodies(RE::NiAVObject* object,std::vector<RE::bhkRigidBody*>& out) {
    if(!object || out.size()>=128) return;
    if(auto* collision=object->collisionObject ? object->collisionObject->AsBhkNiCollisionObject() : nullptr) {
        if(auto* body=collision->body ? collision->body->AsBhkRigidBody() : nullptr) {
            if(auto* rigid=body->GetRigidBody(); rigid && rigid->motion.GetMass()>0 &&
                std::find(out.begin(),out.end(),body)==out.end()) out.push_back(body);
        }
    }
    if(auto* node=object->AsNode()) for(auto& child:node->children) bodies(child.get(),out);
}
struct Sample { Vec position{}, velocity{}; int count{}; };
Sample sample(RE::TESObjectREFR* ref) {
    Sample s;
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D()) return s;
    RE::BSReadLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float inverse=RE::bhkWorld::GetWorldScaleInverse();
    for(auto* body:list) {
        RE::hkVector4 pos; body->GetCenterOfMassWorld(pos);
        s.position=s.position+vec(pos)*inverse;
        s.velocity=s.velocity+vec(body->GetRigidBody()->motion.linearVelocity)*inverse;
        ++s.count;
    }
    if(s.count) { s.position=s.position*(1.f/s.count); s.velocity=s.velocity*(1.f/s.count); }
    return s;
}
bool velocity(RE::TESObjectREFR* ref,Vec speed,Vec* direction=nullptr,bool stabilize=false) {
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || !ref->Get3D() || !finite(speed)) return false;
    RE::BSWriteLockGuard lock(world->worldLock);
    std::vector<RE::bhkRigidBody*> list; bodies(ref->Get3D(),list);
    float scale=RE::bhkWorld::GetWorldScale();
    Vec average{};
    bool actor=ref->As<RE::Actor>()!=nullptr;
    if(actor && !list.empty()) {
        for(auto* body:list) average=average+vec(body->GetRigidBody()->motion.linearVelocity);
        average=average*(1.f/list.size());
    }
    for(auto* body:list) {
        auto* rigid=body->GetRigidBody();
        // Activate sleeping bodies, and preserve relative limb motion in a ragdoll.
        Vec relative=actor ? vec(rigid->motion.linearVelocity)-average : Vec{};
        rigid->SetLinearVelocity(hk(speed*scale+relative));
        // Suppress collision-induced spin only while holding props, never on ragdoll limbs.
        if(stabilize && !actor) rigid->SetAngularVelocity(RE::hkVector4{});
    }
    if(direction && cfg.orient && list.size()==1) {
        auto* weapon=ref->GetBaseObject()->As<RE::TESObjectWEAP>();
        if(weapon && (weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kTwoHandSword ||
                      weapon->GetWeaponType()==RE::WEAPON_TYPE::kOneHandDagger)) {
            // ponytail: vanilla sword meshes use local +Z; custom mesh axes need per-mesh calibration.
            auto d=unit(*direction); float w=1+d.z;
            Vec axis{-d.y,d.x,0}; float norm=std::sqrt(dot(axis,axis)+w*w);
            RE::hkQuaternion rotation;
            rotation.vec=norm>.001f ? RE::hkVector4(axis.x/norm,axis.y/norm,0,w/norm) : RE::hkVector4(1,0,0,0);
            list.front()->SetRotation(rotation);
            list.front()->SetAngularVelocity(RE::hkVector4{});
        }
    }
    return !list.empty();
}

struct RayHit { bool hit{}; float fraction=1; RE::ObjectRefHandle ref; };
RayHit ray(RE::TESObjectCELL* cell,Vec from,Vec to,RE::TESObjectREFR* ignore) {
    RayHit result;
    auto* world=cell ? cell->GetbhkWorld() : nullptr;
    if(!world || length(to-from)<.1f) return result;
    RE::BSReadLockGuard lock(world->worldLock);
    Vec start=from, dir=unit(to-from); float total=length(to-from);
    // Skip source body hits without globally changing any collision filter.
    for(int i=0;i<32 && length(start-from)<total;++i) {
        RE::bhkPickData pick{};
        preparePickRay(pick,start,to,RE::bhkWorld::GetWorldScale());
        pick.rayInput.filterInfo.SetCollisionLayer(RE::COL_LAYER::kLOS);
        world->PickObject(pick);
        if(!pick.rayOutput.HasHit()) return result;
        auto* ref=RE::TESHavokUtilities::FindCollidableRef(*pick.rayOutput.rootCollidable);
        Vec point=start+(to-start)*pick.rayOutput.hitFraction;
        if((!ignore || ref!=ignore) && ref!=RE::PlayerCharacter::GetSingleton()) {
            result.hit=true; result.fraction=std::clamp(length(point-from)/total,0.f,1.f);
            if(ref) result.ref=ref->GetHandle();
            return result;
        }
        start=point+dir*8;
    }
    // Conservative: an unresolved obstruction stops targeting/hold travel.
    result.hit=true; result.fraction=0;
    return result;
}

class Combat final : public RE::BSTEventSink<RE::InputEvent*> {
    struct Flight {
        RE::ObjectRefHandle ref;
        Vec previous{}, velocity{};
        float mass{}, multiplier=1, remaining{}, elapsed{}, refresh{}, peakZ{};
        bool slam{}, impactApplied{};
    };
    RE::ObjectRefHandle held;
    RE::bhkWorld* holdWorld{}; // identity only; never dereferenced after a world change
    Vec anchor{};
    std::vector<Flight> flights;
    RE::SpellItem* controlSpell{};
    RE::SpellItem* holdSpell{};
    RE::SpellItem* executionSpell{};
    bool active=false, execDown=false, pulling=false, pushing=false;
    bool slamDown=false;
    RE::BSFixedString gripInput;
    RE::BSFixedString castingInput;
    RE::BSFixedString finisherInput;
    bool castingHeld=false;
    float retry{}, holdAge{}, refresh{}, costFactor=1, charged{}, distance=300;
    Clock::time_point last=Clock::now();
public:
    std::atomic_bool ready=false, queued=false;
    static Combat& get() { static auto* instance=new Combat; return *instance; }
    void resolve() {
        cfg.load();
        auto* data=RE::TESDataHandler::GetSingleton();
        controlSpell=data->LookupForm<RE::SpellItem>(cfg.control,cfg.plugin);
        holdSpell=data->LookupForm<RE::SpellItem>(cfg.hold,cfg.plugin);
        executionSpell=cfg.execution ? data->LookupForm<RE::SpellItem>(cfg.execution,cfg.plugin) : nullptr;
        bool ragdollHold=false;
        if(holdSpell) for(auto* effect:holdSpell->effects) {
            if(effect && effect->baseEffect && effect->baseEffect->GetArchetype()==RE::EffectArchetypes::ArchetypeID::kValueModifier &&
               effect->baseEffect->data.primaryAV==RE::ActorValue::kGrabbed &&
               effect->GetDuration()==2 && effect->GetMagnitude()==1.f) ragdollHold=true;
        }
        active=controlSpell && ragdollHold;
        SKSE::log::info("Gameplay layer {} (control {:X}, hold {:X})",active ? "ready" : "MISSING/INVALID",cfg.control,cfg.hold);
        if(!active) RE::SendHUDMessage::ShowHUDMessage("Telekinesis Combat: missing/invalid companion spells. See README.");
        ready=true;
    }
    bool usable() const {
        auto* p=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
        return ready && active && p && p->Get3D() && p->GetParentCell() && !p->IsDead() && !p->IsInKillMove() &&
            ui && !ui->GameIsPaused() && !ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) &&
            !ui->IsMenuOpen(RE::MainMenu::MENU_NAME) && !ui->IsMenuOpen(RE::DialogueMenu::MENU_NAME) &&
            (p->GetEquippedObject(false)==controlSpell || p->GetEquippedObject(true)==controlSpell);
    }
    void drop(bool stop=true) {
        if(auto ref=held.get()) {
            if(stop) velocity(ref.get(),{});
            if(auto* a=ref->As<RE::Actor>(); a && holdSpell) {
                if(auto* player=RE::PlayerCharacter::GetSingleton()) {
                    RE::ActorHandle actorCaster{player};
                    a->AsMagicTarget()->DispelEffect(holdSpell,actorCaster);
                }
            }
        }
        held={}; holdWorld=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        gripInput=RE::BSFixedString(); slamDown=false;
        castingInput=RE::BSFixedString(); castingHeld=false; finisherInput=RE::BSFixedString();
    }
    void reset() { drop(); flights.clear(); last=Clock::now(); }
    bool allowed(RE::Actor* a) const {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || (a->IsDead() && !cfg.corpses) || a->IsChild() || a->IsEssential() ||
            (cfg.protect && a->IsProtected()) || a->IsInKillMove() || a->GetScale()>cfg.maxScale ||
            a->HasKeywordString("ActorTypeDragon") || a->HasKeywordString("ActorTypeGiant")) return false;
        auto* race=a->GetRace();
        auto extent=vec(a->GetBoundMax())-vec(a->GetBoundMin());
        if(!race || !finite(extent) || extent.z>cfg.maxHeight ||
           std::max({extent.x,extent.y,extent.z})>cfg.maxExtent) return false;
        if(a->HasKeywordString("ActorTypeUndead")) return cfg.undead;
        return a->HasKeywordString("ActorTypeNPC") || cfg.creatures;
    }
    Vec aim() const {
        auto* camera=RE::PlayerCamera::GetSingleton();
        if(camera && camera->cameraRoot) {
            auto& r=camera->cameraRoot->world.rotate;
            return unit({r.entry[0][1],r.entry[1][1],r.entry[2][1]});
        }
        return {0,1,0};
    }
    bool spend(float amount) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* values=p->AsActorValueOwner();
        if(values->GetActorValue(RE::ActorValue::kMagicka)<amount) return false;
        values->DamageActorValue(RE::ActorValue::kMagicka,amount); return true;
    }
    void castHold(RE::Actor* a) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        bool refreshed=false;
        if(auto* effects=a->AsMagicTarget()->GetActiveEffectList()) for(auto* effect:*effects) {
            if(effect && effect->spell==holdSpell && !effect->flags.any(RE::ActiveEffect::Flag::kDispelled) &&
               effect->GetCasterActor().get()==p) {
                effect->duration=effect->elapsedSeconds+2.f; refreshed=true;
            }
        }
        if(refreshed) return;
        if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(holdSpell,true,a,1.f,false,1.f,p);
    }
    void hurt(RE::Actor* a,float amount) {
        if(!a || a==RE::PlayerCharacter::GetSingleton() || a->IsDead() || a->IsChild() || a->IsEssential() ||
           (cfg.protect && a->IsProtected()) || !std::isfinite(amount) || amount<=0) return;
        auto* p=RE::PlayerCharacter::GetSingleton();
        a->StartCombat(p);
        auto* values=a->AsActorValueOwner();
        float before=values->GetActorValue(RE::ActorValue::kHealth);
        values->DamageActorValue(RE::ActorValue::kHealth,amount);
        // HandleHealthDamage is a post-damage death/attacker notification, not subtraction.
        a->HandleHealthDamage(p,amount);
        SKSE::log::info("Impact/finish {:08X}: {:.1f} damage, health {:.1f} -> {:.1f}",
            a->GetFormID(),amount,before,values->GetActorValue(RE::ActorValue::kHealth));
    }
    bool weak(RE::Actor* a) const {
        if(!a || a->IsDead() || !allowed(a)) return false;
        auto* values=a->AsActorValueOwner();
        float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
            a->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
        return weakened(values->GetActorValue(RE::ActorValue::kHealth),maximum,cfg.executionHealth);
    }
    void beginFinisher(const RE::BSFixedString& input) {
        auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
        if(!weak(actor)) { RE::SendHUDMessage::ShowHUDMessage("Finisher requires a weakened target."); return; }
        if(execDown) return;
        finisherInput=input; execDown=true; charged=0;
        SKSE::log::info("Finisher charging on {:08X}",actor->GetFormID());
        RE::SendHUDMessage::ShowHUDMessage("Crushing target... keep the finisher control held.");
    }
    bool sameWorld(RE::TESObjectREFR* ref) const {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* playerCell=p ? p->GetParentCell() : nullptr;
        auto* cell=ref ? ref->GetParentCell() : nullptr;
        auto* world=playerCell ? playerCell->GetbhkWorld() : nullptr;
        return world && cell && cell->GetbhkWorld()==world;
    }
    bool pickable(RE::TESObjectREFR* ref) const {
        if(!ref || ref==RE::PlayerCharacter::GetSingleton() || !ref->Get3D() || ref->IsDisabled() || !sameWorld(ref)) return false;
        if(ref->As<RE::Actor>()) return true; // Immunities are checked before spending or changing actor state.
        auto* base=ref->GetBaseObject(); if(!base) return false;
        auto type=base->GetFormType();
        return type==RE::FormType::Weapon || type==RE::FormType::Misc || type==RE::FormType::Armor ||
            type==RE::FormType::Ingredient || type==RE::FormType::AlchemyItem;
    }
    struct Bounds { Vec low,high; };
    Bounds actorBounds(RE::Actor* actor) const {
        Vec low=vec(actor->GetBoundMin()),high=vec(actor->GetBoundMax());
        Vec center=(low+high)*.5f, position=vec(actor->GetPosition());
        // Native controller bounds are world coordinates; base-form fallback bounds are local.
        if(length(center-position)>length(high-low)+256.f) { low=low+position; high=high+position; }
        if(actor->IsDead() || actor->IsInRagdollState()) {
            auto body=sample(actor);
            if(body.count) { Vec offset=body.position-(low+high)*.5f; low=low+offset; high=high+offset; }
        }
        return {low,high};
    }
    Vec pickCenter(RE::TESObjectREFR* ref) const {
        if(auto* actor=ref->As<RE::Actor>()) { auto b=actorBounds(actor); return (b.low+b.high)*.5f; }
        auto body=sample(ref);
        return body.count ? body.position : vec(ref->Get3D()->worldBound.center);
    }
    RE::NiPointer<RE::TESObjectREFR> pick(Vec origin,Vec direction) {
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto visible=[&](RE::TESObjectREFR* ref,Vec center) {
            // Small floor-level props may have a hollow/offset mesh centre. Try visible upper points too.
            float lift=std::clamp(ref->Get3D()->worldBound.radius*.3f,4.f,24.f);
            for(Vec point:{center,center+Vec{0,0,lift},center+Vec{0,0,lift*.5f}}) {
                auto obstruction=ray(p->GetParentCell(),origin,point,nullptr);
                if(!obstruction.hit || obstruction.ref.get().get()==ref) return true;
            }
            return false;
        };
        if(auto* picker=RE::CrosshairPickData::GetSingleton()) {
            for(auto handle:{picker->grabPickRef,picker->GetActiveTarget()}) {
                auto ref=handle.get();
                if(pickable(ref.get())) {
                    Vec center=pickCenter(ref.get());
                    if(aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,cfg.range,cfg.aimAssist)>=0 && visible(ref.get(),center)) return ref;
                }
            }
        }
        auto hit=ray(p->GetParentCell(),origin,origin+direction*cfg.range,nullptr);
        auto direct=hit.ref.get();
        if(pickable(direct.get())) return direct;
        // A small aim cone catches distant clutter that a single pixel-width ray misses.
        // Keep only eight candidates, then verify visibility; walls remain blockers.
        struct Candidate { RE::ObjectRefHandle ref; Vec center; float score; };
        std::vector<Candidate> candidates;
        if(auto* world=RE::TES::GetSingleton()) world->ForEachReferenceInRange(p,cfg.range+500.f,[&](RE::TESObjectREFR* ref) {
            if(!pickable(ref)) return RE::BSContainer::ForEachResult::kContinue;
            Vec center=pickCenter(ref);
            float score=aimScore(origin,direction,center,ref->Get3D()->worldBound.radius,cfg.range,cfg.aimAssist);
            if(score<0) return RE::BSContainer::ForEachResult::kContinue;
            candidates.push_back({ref->GetHandle(),center,score});
            std::sort(candidates.begin(),candidates.end(),[](auto& a,auto& b){ return a.score<b.score; });
            if(candidates.size()>8) candidates.pop_back();
            return RE::BSContainer::ForEachResult::kContinue;
        });
        for(auto& candidate:candidates) {
            auto ref=candidate.ref.get();
            if(ref && visible(ref.get(),candidate.center)) return ref;
        }
        return {};
    }
    void grab(bool quiet=false) {
        if(held) { drop(); return; }
        auto* p=RE::PlayerCharacter::GetSingleton(); Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition());
        auto ref=pick(origin,aim());
        if(ref || !quiet) SKSE::log::info("Grab target {:08X}",ref ? ref->GetFormID() : 0);
        if(!ref || !ref->Get3D() || ref->IsDisabled()) {
            if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Telekinesis: aim at a loose object or creature."); return;
        }
        bool tracked=std::any_of(flights.begin(),flights.end(),[&](auto& f){return f.ref==ref->GetHandle();});
        costFactor=1;
        if(auto* a=ref->As<RE::Actor>()) {
            auto* process=a->GetActorRuntimeData().currentProcess;
            bool dead=a->IsDead();
            if(!allowed(a) || (dead && !sample(a).count) || (!dead && (!process ||
               a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kParalysis)>0 ||
               (a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kGrabbed)>0 && !tracked)))) {
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Target resists telekinesis."); return;
            }
            costFactor=resistance(a->GetScale(),dead ? p->GetLevel() : a->GetLevel(),p->GetLevel(),cfg.levelFactor);
            if(!spend(cfg.grabCost*costFactor)) return;
            if(!dead) {
                // Existing live ragdolls need suspension, not another knockdown. Corpses need neither.
                if(!a->IsInRagdollState()) process->KnockExplosion(a,a->GetPosition(),0.f);
                castHold(a); a->StartCombat(p);
            }
        } else {
            auto* base=ref->GetBaseObject();
            if(!base) return;
            // Loose carryable objects only. Never change static/animated/door physics.
            auto type=base->GetFormType();
            if(type!=RE::FormType::Weapon && type!=RE::FormType::Misc && type!=RE::FormType::Armor &&
               type!=RE::FormType::Ingredient && type!=RE::FormType::AlchemyItem) return;
            if(!sample(ref.get()).count) {
                SKSE::log::warn("Target {:08X} has no movable rigid bodies",ref->GetFormID());
                if(!quiet) RE::SendHUDMessage::ShowHUDMessage("Telekinesis: this object has no movable physics body."); return;
            }
            if(!spend(cfg.grabCost)) return;
        }
        std::erase_if(flights,[&](auto& f){return f.ref==ref->GetHandle();});
        held=ref->GetHandle(); holdWorld=p->GetParentCell()->GetbhkWorld(); holdAge=0; refresh=0; charged=0;
        distance=ref->As<RE::Actor>() ? cfg.distance : cfg.itemDistance;
        auto initial=sample(ref.get()); anchor=initial.count ? initial.position : pickCenter(ref.get());
        SKSE::log::info("Grip established on {:08X}",ref->GetFormID());
    }
    void launch(bool slam) {
        auto ref=held.get(); if(!ref || !sample(ref.get()).count) return;
        if(auto* a=ref->As<RE::Actor>(); a && !a->IsDead() && !a->IsInRagdollState()) return;
        if(static_cast<int>(flights.size())>=cfg.maxFlights) { RE::SendHUDMessage::ShowHUDMessage("Too many objects in flight."); return; }
        if(!spend(cfg.launchCost*costFactor)) return;
        bool actor=ref->As<RE::Actor>()!=nullptr;
        float launchSpeed=actor ? cfg.actorLaunchSpeed : cfg.launchSpeed;
        float slamSpeed=actor ? cfg.actorSlamSpeed : cfg.slamSpeed;
        Vec speed=slam ? Vec{0,0,-slamSpeed} : aim()*launchSpeed;
        Vec launchDirection=unit(speed);
        if(!velocity(ref.get(),speed,actor ? nullptr : &launchDirection)) { drop(); return; }
        auto s=sample(ref.get());
        float mass=actor ? 0.f : std::clamp(ref->GetWeight(),cfg.objectMassFloor,cfg.massCap);
        float mult=ref->GetBaseObject()->As<RE::TESObjectWEAP>() ? 2.f : 1.f;
        flights.push_back({held,s.position,speed,mass,mult,actor ? cfg.actorFlightSeconds : cfg.flightSeconds,0,0,s.position.z,slam,false});
        // Keep the brief grabbed-state effect for the flight; it expires on its own.
        held={}; holdWorld=nullptr; charged=0; execDown=false; pulling=false; pushing=false;
        gripInput=RE::BSFixedString(); slamDown=false;
    }
    void execute(RE::Actor* a) {
        if(!weak(a)) { charged=0; execDown=false; return; }
        if(!spend(cfg.executionCost*costFactor)) {
            RE::SendHUDMessage::ShowHUDMessage("Not enough Magicka for the finisher.");
            charged=0; execDown=false; return;
        }
        auto* p=RE::PlayerCharacter::GetSingleton();
        if(executionSpell) if(auto* caster=p->GetMagicCaster(RE::MagicSystem::CastingSource::kInstant))
            caster->CastSpellImmediate(executionSpell,false,a,1.f,false,0.f,p);
        hurt(a,a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)+1000.f);
        if(a->IsDead() || a->AsActorValueOwner()->GetActorValue(RE::ActorValue::kHealth)<=0) {
            SKSE::ModCallbackEvent event{RE::BSFixedString("TKC_Execution"),RE::BSFixedString("crush"),0.f,a};
            SKSE::GetModCallbackEventSource()->SendEvent(&event);
            RE::SendHUDMessage::ShowHUDMessage("Telekinetic crush!");
        } else { RE::SendHUDMessage::ShowHUDMessage("Target resisted the finisher."); }
        drop(false);
    }
    void tick() {
        auto now=Clock::now(); float dt=std::chrono::duration<float>(now-last).count(); last=now;
        if(!ready) return;
        auto* p=RE::PlayerCharacter::GetSingleton();
        auto* ui=RE::UI::GetSingleton();
        if(!p || !p->Get3D() || !p->GetParentCell() || !ui ||
           ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) || ui->IsMenuOpen(RE::MainMenu::MENU_NAME)) { reset(); return; }
        if(ui->GameIsPaused()) return; // Preserve the grip and freeze costs/flight timers while paused.
        dt=std::clamp(dt,0.f,.05f);
        if(castingHeld && !usable()) drop();
        if(!held && castingHeld) {
            retry+=dt;
            if(retry>=.08f) { retry=0; grab(true); if(held) gripInput=castingInput; }
        }
        if(held && (!usable() || p->GetParentCell()->GetbhkWorld()!=holdWorld)) drop();
        if(auto ref=held.get()) {
            holdAge+=dt; refresh+=dt;
            auto* actor=ref->As<RE::Actor>();
            if(ref->IsDisabled() || !ref->Get3D() || !sameWorld(ref.get()) || (actor && !allowed(actor)) || !spend(cfg.holdCost*costFactor*dt)) { drop(); }
            else {
                if(actor && !actor->IsDead() && refresh>=1.f) { castHold(actor); refresh=0; }
                auto s=sample(ref.get());
                if(!finite(s.position) || !finite(s.velocity)) { drop(); }
                else if(!s.count || (actor && !actor->IsDead() && !actor->IsInRagdollState())) {
                    if(holdAge>1.5f) { RE::SendHUDMessage::ShowHUDMessage("Cannot establish a ragdoll grip."); drop(); }
                } else {
                    distance=std::clamp(distance+((pushing ? 1.f:0.f)-(pulling ? 1.f:0.f))*cfg.adjustSpeed*dt,cfg.minDistance,cfg.maxDistance);
                    Vec origin=vec(RE::PlayerCamera::GetActiveCameraPosition()), direction=aim();
                    auto* camera=RE::PlayerCamera::GetSingleton();
                    float rayDistance=actor ? distance : itemRayDistance(origin,direction,vec(p->GetPosition()),
                        distance,camera && camera->IsInThirdPerson());
                    auto wall=ray(p->GetParentCell(),origin,origin+direction*rayDistance,ref.get());
                    float safeDistance=wall.hit ? std::max(80.f,rayDistance*wall.fraction-60.f) : rayDistance;
                    if(length(s.position-origin)>cfg.range*2.f+cfg.maxDistance) { drop(); }
                    else {
                        Vec previous=anchor;
                        float speedLimit=!actor && length(s.position-origin)>rayDistance+200.f ? cfg.pickupSpeed : cfg.holdSpeed;
                        auto next=advanceAnchor(anchor,origin+direction*safeDistance,speedLimit,dt);
                        // Sweep the body's path too: turning toward a wall clamps the grip instead of dropping it.
                        auto blocked=ray(ref->GetParentCell(),s.position,next,ref.get());
                        if(blocked.hit) {
                            Vec delta=next-s.position; float travel=length(delta);
                            next=s.position+unit(delta)*std::max(0.f,travel*blocked.fraction-30.f);
                        }
                        anchor=next;
                        // Do not rotate a held mesh every tick: its COM offset would move underneath this controller.
                        velocity(ref.get(),holdVelocity(previous,anchor,s.position,dt,cfg.gain,speedLimit),nullptr,!actor);
                        if(execDown && weak(actor)) {
                            charged+=dt; if(charged>=cfg.charge) execute(actor);
                        } else charged=0;
                    }
                }
            }
        } else held={};
        for(auto it=flights.begin();it!=flights.end();) {
            auto ref=it->ref.get(); it->remaining-=dt; it->elapsed+=dt; it->refresh+=dt;
            auto s=ref ? sample(ref.get()) : Sample{};
            if(!ref || !s.count || ref->IsDisabled() || !sameWorld(ref.get()) || it->remaining<=0 ||
                !finite(s.position) || !finite(s.velocity) || length(s.position-it->previous)>cfg.range) { it=flights.erase(it); continue; }
            auto* thrown=ref->As<RE::Actor>();
            if(thrown && !thrown->IsDead() && !it->impactApplied && allowed(thrown) && it->refresh>=1.f) { castHold(thrown); it->refresh=0; }
            it->peakZ=std::max(it->peakZ,s.position.z);
            float speed=length(it->velocity);
            // A ray covers static geometry; swept actor bounds cover high-speed tunnelling.
            auto wall=ray(ref->GetParentCell(),it->previous,s.position,ref.get());
            auto wallRef=wall.ref.get();
            RE::Actor* victim=wallRef ? wallRef->As<RE::Actor>() : nullptr;
            float closest=wall.hit ? wall.fraction : 1.f;
            Vec step=s.position-it->previous;
            // Havok can move the body without updating the reference's logical origin.
            auto checkVictim=[&](RE::TESObjectREFR* candidate) {
                auto* a=candidate->As<RE::Actor>();
                if(!a || a==ref.get() || a==p || !a->Get3D() || a->IsDead() || !sameWorld(a)) return RE::BSContainer::ForEachResult::kContinue;
                auto bounds=actorBounds(a);
                // ponytail: swept bounds approximate body contact; exact limb/weapon contact needs Havok contacts.
                float t=boxHit(it->previous,s.position,bounds.low,bounds.high,cfg.radius);
                if(t>=0 && t<=closest) {
                    auto obstruction=ray(ref->GetParentCell(),it->previous,it->previous+step*t,ref.get());
                    auto obstructionRef=obstruction.ref.get();
                    if(!obstruction.hit || obstructionRef.get()==a) { victim=a; closest=t; }
                }
                return RE::BSContainer::ForEachResult::kContinue;
            };
            RE::TES::GetSingleton()->ForEachCell([&](RE::TESObjectCELL* cell) {
                if(cell && cell->GetbhkWorld()==ref->GetParentCell()->GetbhkWorld())
                    cell->ForEachReferenceInRange(ni((it->previous+s.position)*.5f),300.f+length(step)*.5f,checkVictim);
            });
            // Ignore the initial settling tick. Directional velocity loss catches wall/floor impacts.
            float loss=dot(it->velocity-s.velocity,unit(it->velocity));
            bool collision=victim || wall.hit || (it->elapsed>.06f && loss>std::max(cfg.minimum,speed*.4f));
            bool fall=thrown && !it->slam && lethalFall(it->peakZ,s.position.z,it->velocity.z,cfg.cliffDrop,cfg.minimum);
            if(collision && speed>=cfg.minimum && (!it->impactApplied || fall)) {
                if(!thrown) {
                    if(victim) hurt(victim,damage(speed,it->mass,cfg.multiplier*it->multiplier,cfg.minimum,cfg.damageCap));
                    it=flights.erase(it); continue;
                }
                auto actorDamage=[&](RE::Actor* target,bool slammed,bool falling) {
                    auto* values=target->AsActorValueOwner();
                    float maximum=values->GetPermanentActorValue(RE::ActorValue::kHealth)+
                        target->GetActorValueModifier(RE::ACTOR_VALUE_MODIFIER::kTemporary,RE::ActorValue::kHealth);
                    return actorImpactDamage(values->GetActorValue(RE::ActorValue::kHealth),maximum,p->GetLevel(),target->GetLevel(),
                        speed,slammed ? cfg.actorSlamSpeed : cfg.actorLaunchSpeed,
                        slammed ? cfg.slamFraction : cfg.throwFraction,cfg.actorDamageCap,cfg.lethalLevelAdvantage,falling,slammed);
                };
                if(!it->impactApplied && victim) hurt(victim,actorDamage(victim,false,false));
                if(!thrown->IsDead()) {
                    hurt(thrown,actorDamage(thrown,it->slam,fall));
                    if(it->slam && !thrown->IsDead() && allowed(thrown)) {
                        if(auto* queue=RE::TaskQueueInterface::GetSingleton()) {
                            RE::ActorHandle target{thrown},caster{p}; queue->QueueActorDisarm(target,caster);
                            SKSE::log::info("Nonlethal slam: disarm queued for {:08X}",thrown->GetFormID());
                        }
                    }
                }
                it->impactApplied=true;
                // One ordinary hit; continue tracking a surviving throw for a later cliff landing.
                if(it->slam || thrown->IsDead()) { it=flights.erase(it); continue; }
            }
            it->previous=s.position; it->velocity=s.velocity; ++it;
        }
    }
    struct Button {
        std::uint32_t key; RE::INPUT_DEVICE device; RE::BSFixedString action;
        bool down,up,pressed;
    };
    void input(const std::vector<Button>& buttons) {
        for(const auto& button:buttons) {
            auto key=button.key; auto device=button.device; auto userEvent=button.action;
            auto* user=RE::UserEvents::GetSingleton();
            if(!user) continue;
            // Use Skyrim's mapped casting actions, including remapped mouse/gamepad buttons.
            bool castInput=userEvent==user->leftAttack || userEvent==user->rightAttack;
            if(castInput) {
                auto* player=RE::PlayerCharacter::GetSingleton();
                bool controlHand=player && player->GetEquippedObject(userEvent==user->leftAttack)==controlSpell;
                auto action=castAction(button.down,button.up,static_cast<bool>(held),userEvent==gripInput,controlHand);
                if(button.up) {
                    if(userEvent==castingInput) { castingHeld=false; castingInput=RE::BSFixedString(); }
                    if(action==CastAction::release) {
                        if(usable()) launch(slamDown);
                        // Failed launch (Magicka, ragdoll or flight limit) must release the grip.
                        if(held) drop();
                    } else if(userEvent==finisherInput) { execDown=false; charged=0; finisherInput=RE::BSFixedString(); }
                    continue;
                }
                if(!usable()) continue;
                if(action==CastAction::grab) {
                    castingHeld=true; castingInput=userEvent; retry=0;
                    grab(); if(held) gripInput=userEvent;
                } else if(action==CastAction::charge) {
                    beginFinisher(userEvent);
                }
                continue;
            }
            if(device==RE::INPUT_DEVICE::kKeyboard && (key==42 || key==54)) {
                if(button.up) slamDown=false;
                else if(button.down && usable()) slamDown=true;
            }
            if(!usable()) continue;
            if(held && userEvent==user->activate) {
                if(button.down) {
                    auto ref=held.get(); auto* actor=ref ? ref->As<RE::Actor>() : nullptr;
                    if(weak(actor)) beginFinisher(userEvent);
                    else if(ref && !actor) {
                        auto body=sample(ref.get());
                        auto* player=RE::PlayerCharacter::GetSingleton();
                        auto bounds=actorBounds(player); Vec origin=(bounds.low+bounds.high)*.5f;
                        auto obstacle=ray(ref->GetParentCell(),origin,body.position,ref.get());
                        bool close=body.count && length(body.position-origin)<=cfg.pickupReach;
                        drop();
                        if(close && !obstacle.hit) {
                            bool activated=ref->ActivateRef(RE::PlayerCharacter::GetSingleton(),0,nullptr,std::max(1,static_cast<int>(ref->extraList.GetCount())),false);
                            SKSE::log::info("Held item {:08X}: native activation {}",ref->GetFormID(),activated);
                        }
                    } else drop();
                } else if(button.up && finisherInput==userEvent) { drop(); }
                continue;
            }
            if(held && device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9) && button.pressed) {
                distance=std::clamp(distance+(key==8 ? -50.f : 50.f),cfg.minDistance,cfg.maxDistance);
                continue;
            }
            if(!cfg.legacyHotkeys || device!=RE::INPUT_DEVICE::kKeyboard) continue;
            if(button.up) {
                if(key==cfg.execute) { execDown=false; charged=0; }
                if(key==cfg.pull) pulling=false;
                if(key==cfg.push) pushing=false;
            }
            if(!usable() || !button.down) continue;
            if(key==cfg.grab) grab();
            else if(key==cfg.launch) launch(false);
            else if(key==cfg.slam) launch(true);
            else if(key==cfg.pull) pulling=true;
            else if(key==cfg.push) pushing=true;
            else if(key==cfg.execute && held) beginFinisher(userEvent);
        }
    }
    RE::BSEventNotifyControl ProcessEvent(RE::InputEvent* const* events,RE::BSTEventSource<RE::InputEvent*>*) override {
        if(!events || !ready) return RE::BSEventNotifyControl::kContinue;
        std::vector<Button> buttons;
        for(auto* event=*events;event;event=event->next) {
            auto* button=event->AsButtonEvent();
            if(!button) continue;
            auto key=button->GetIDCode(); auto device=button->GetDevice();
            if(button->IsDown() || button->IsUp() || (device==RE::INPUT_DEVICE::kMouse && (key==8 || key==9)))
                buttons.push_back({key,device,button->QUserEvent(),button->IsDown(),button->IsUp(),button->IsPressed()});
        }
        // Input can arrive on worker threads. Own a snapshot and mutate game state on the game thread.
        if(!buttons.empty()) SKSE::GetTaskInterface()->AddTask([buttons=std::move(buttons)] {
            auto& state=Combat::get(); if(state.ready) state.input(buttons);
        });
        return RE::BSEventNotifyControl::kContinue;
    }
};

std::jthread ticker;
void message(SKSE::MessagingInterface::Message* msg) {
    auto& combat=Combat::get();
    switch(msg->type) {
    case SKSE::MessagingInterface::kDataLoaded:
        combat.resolve();
        RE::BSInputDeviceManager::GetSingleton()->AddEventSink(&combat);
        ticker=std::jthread([](std::stop_token stop) {
            while(!stop.stop_requested()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(16));
                auto& c=Combat::get();
                if(!c.ready || c.queued.exchange(true)) continue;
                SKSE::GetTaskInterface()->AddTask([] {
                    auto& state=Combat::get();
                    try { state.tick(); } catch(const std::exception& e) { SKSE::log::error("Tick: {}",e.what()); }
                    state.queued=false;
                });
            }
        });
        break;
    case SKSE::MessagingInterface::kPreLoadGame:
        combat.ready=false; combat.reset(); break;
    case SKSE::MessagingInterface::kPostLoadGame:
    case SKSE::MessagingInterface::kNewGame:
        combat.reset(); combat.ready=true; break;
    default: break;
    }
}
}

SKSEPluginLoad(const SKSE::LoadInterface* skse) {
    auto directory=SKSE::log::log_directory();
    if(!directory) return false;
    auto sink=std::make_shared<spdlog::sinks::basic_file_sink_mt>((*directory/"TelekinesisCombat.log").string(),true);
    auto logger=std::make_shared<spdlog::logger>("TKC",sink);
    spdlog::set_default_logger(logger); spdlog::flush_on(spdlog::level::info);
    SKSE::Init(skse);
    if(REL::Module::IsVR()) { SKSE::log::error("VR is not supported"); return false; }
    const auto runtime=REL::Module::get().version();
    const std::array supported{REL::Version{1,5,97,0},REL::Version{1,6,640,0},REL::Version{1,6,659,0},
        REL::Version{1,6,1170,0},REL::Version{1,6,1179,0},REL::Version{1,7,104,0}};
    if(std::find(supported.begin(),supported.end(),runtime)==supported.end()) {
        SKSE::log::error("Runtime {} is outside the target list",runtime.string()); return false;
    }
    return SKSE::GetMessagingInterface()->RegisterListener(message);
}
