#pragma once
#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <RE/I/IMessageBoxCallback.h>
#include <functional>
#include <format>

// Optional native message-box settings. No SkyUI, Papyrus or custom Scaleform movie is needed.
namespace settings {
inline std::uint64_t generation=0, revision=0;
inline std::uint32_t* binding=nullptr;
inline float rebindTime=0;
inline bool pending=false;
inline void cancelRebind() { binding=nullptr; rebindTime=0; pending=false; ++generation; }
inline void save() {
    ++revision;
    if(!cfg.save()) RE::SendHUDMessage::ShowHUDMessage("Settings apply this session, but the INI could not be saved. Check log/file permissions.");
}
inline void tick(float dt) {
    if(binding && (rebindTime-=dt)<=0) { binding=nullptr; RE::SendHUDMessage::ShowHUDMessage("Rebind timed out."); }
}
inline bool capture(std::uint32_t key,RE::INPUT_DEVICE device,bool down) {
    if(!binding) return false;
    if(device!=RE::INPUT_DEVICE::kKeyboard || !down) return true;
    if(key==1) { binding=nullptr; RE::SendHUDMessage::ShowHUDMessage("Rebind cancelled."); return true; }
    if(key<2 || key>255) return true;
    for(auto* other:{&cfg.settingsKey,&cfg.modifierKey,&cfg.modifierKey2,&cfg.grab,&cfg.launch,&cfg.pull,&cfg.push,&cfg.slam,&cfg.execute}) {
        if(other!=binding && *other==key) { RE::SendHUDMessage::ShowHUDMessage("That key is already assigned. Press another key or Escape."); return true; }
    }
    *binding=key;
    if(binding==&cfg.modifierKey) cfg.modifierKey2=0;
    binding=nullptr; save();
    RE::SendHUDMessage::ShowHUDMessage("Telekinesis control saved."); return true;
}
inline void rebind(std::uint32_t& key) {
    binding=&key; rebindTime=10;
    RE::SendHUDMessage::ShowHUDMessage("Press a keyboard key within 10 seconds. Escape cancels.");
}
inline void open(int page=0);
inline void choose(int page,std::uint8_t button);
class Callback final : public RE::IMessageBoxCallback {
    int page;
    std::uint64_t epoch;
public:
    explicit Callback(int value) : page(value),epoch(generation) { pad0C=0; }
    void Run(std::uint8_t button) override {
        auto savedPage=page; auto savedEpoch=epoch;
        SKSE::GetTaskInterface()->AddTask([savedPage,savedEpoch,button] {
            if(savedEpoch!=generation) return;
            pending=false; choose(savedPage,button);
        });
    }
};
inline void open(int page) {
    if(pending || binding || !cfg.settingsEnabled) return;
    auto* player=RE::PlayerCharacter::GetSingleton(); auto* ui=RE::UI::GetSingleton();
    if(!player || !player->Get3D() || !ui || ui->IsMenuOpen(RE::LoadingMenu::MENU_NAME) ||
       ui->IsMenuOpen(RE::MainMenu::MENU_NAME) || ui->IsMenuOpen(RE::MessageBoxMenu::MENU_NAME)) return;
    std::string text="Telekinesis Combat 0.2.0\n";
    std::vector<const char*> labels;
    switch(page) {
    case 0:
        text+="Select a page or preset. Changes apply immediately and save to the INI. Presets preserve your controls and NPC throw/slam lethality.";
        labels={"Balanced preset","Powerful preset","Object damage","Costs / Alteration XP","Projectiles","Resistance","Controls","Feedback / performance","Reload INI","Close"}; break;
    case 1:
        text+=std::format("Object scale {:.2f}; cap {:.0f}; weapon base scale {:.0f}\nArmor: {}; difficulty: {}",cfg.damageScale,cfg.damageCap,cfg.weaponBaseScale,cfg.armor,cfg.difficulty);
        labels={"Damage -","Damage +","Cycle damage cap","Weapon base -","Weapon base +","Toggle armor","Toggle difficulty","Back"}; break;
    case 2:
        text+=std::format("Grab {:.1f}; hold/s {:.1f}; launch {:.1f}; execute {:.1f}; disarm {:.1f}; catch {:.1f}\nPerks/enchantments: {}; XP scale {:.1f}; XP budget {:.0f}/minute",cfg.grabCost,cfg.holdCost,cfg.launchCost,cfg.executionCost,cfg.disarmCost,cfg.projectileCost,cfg.costPerks,cfg.xpScale,cfg.xpPerMinute);
        labels={"All costs -20%","All costs +20%","Toggle cost reductions","Cycle XP scale","Cycle XP budget","Back"}; break;
    case 3:
        text+=std::format("Capture: {}; radius {:.0f}; look ahead {:.2f}s; threat radius {:.0f}\nReturn: {}; hold limit {:.0f}s",cfg.catchProjectiles,cfg.projectileRadius,cfg.predictionSeconds,cfg.threatRadius,cfg.returnMode ? "Crosshair" : "Original caster (aim fallback)",cfg.projectileHoldSeconds);
        labels={"Toggle capture","Radius -","Radius +","Prediction -","Prediction +","Toggle return direction","Cycle hold limit","Cycle threat radius","Back"}; break;
    case 4:
        text+=std::format("Level resistance {:.2f}; max scale {:.2f}; execute below {:.0f}%\nLethal level advantage {}; protect protected actors: {}; creatures: {}\nDragon, giant, child and essential immunities always apply.",cfg.levelFactor,cfg.maxScale,cfg.executionHealth*100,cfg.lethalLevelAdvantage,cfg.protect,cfg.creatures);
        labels={"Level resistance -","Level resistance +","Max scale -","Max scale +","Cycle execution health","Cycle lethal level gap","Toggle protected immunity","Toggle creatures","Back"}; break;
    case 5:
        text+=std::format("Settings scan code {}; modifier {} / {}; legacy keys: {}\nCasting/Activate follow Skyrim's own mappings. Wheel adjusts hold distance. Rebinding takes the next keyboard key; Escape cancels.",cfg.settingsKey,cfg.modifierKey,cfg.modifierKey2,cfg.legacyHotkeys);
        labels={"Rebind settings key","Rebind modifier","Toggle legacy controls","Legacy bindings","Restore default keys","Back"}; break;
    case 6:
        text+=std::format("Legacy scan codes: grab {}, launch {}, pull {}, push {}, slam {}, execute {}",cfg.grab,cfg.launch,cfg.pull,cfg.push,cfg.slam,cfg.execute);
        labels={"Rebind grab","Rebind launch","Rebind pull","Rebind push","Rebind slam","Rebind execute","Back"}; break;
    case 7:
        text+=std::format("Preview: {}; sounds/VFX: {}; decapitation: {}\nProfile log: {}; candidate cache {:.2f}s; target search {:.2f}s",cfg.preview,cfg.feedback,cfg.decapitate,cfg.profile,cfg.cacheInterval,cfg.searchInterval);
        labels={"Toggle preview","Toggle sounds/VFX","Toggle decapitation","Toggle profile log","Cycle candidate interval","Cycle search interval","Back"}; break;
    default: return;
    }
    RE::BSString message(text.c_str()); RE::BSTArray<RE::BSString> buttons;
    for(auto label:labels) buttons.emplace_back(label);
    RE::BSTSmartPointer<RE::IMessageBoxCallback> callback{new Callback(page)};
    pending=RE::MessageBoxMenu::Create(message,callback,0,0,10,buttons);
    if(!pending) RE::SendHUDMessage::ShowHUDMessage("Telekinesis settings menu could not be opened.");
}
inline void choose(int page,std::uint8_t button) {
    if(button==255) return;
    if(page==0) {
        if(button==9) return;
        if(button<2) { cfg.preset(button==1); save(); open(); return; }
        if(button==8) { cfg=Config{}; cfg.load(); ++revision; open(); return; }
        static constexpr int pages[]{1,2,3,4,5,7};
        if(button>=2 && button<=7) open(pages[button-2]);
        return;
    }
    switch(page) {
    case 1:
        if(button==7) { open(); return; }
        if(button==0) cfg.damageScale=std::max(0.f,cfg.damageScale-.25f);
        if(button==1) cfg.damageScale=std::min(5.f,cfg.damageScale+.25f);
        if(button==2) cfg.damageCap=cfg.damageCap<1200 ? 1200 : cfg.damageCap<2000 ? 2000 : 600;
        if(button==3) cfg.weaponBaseScale=std::max(0.f,cfg.weaponBaseScale-2.f);
        if(button==4) cfg.weaponBaseScale=std::min(30.f,cfg.weaponBaseScale+2.f);
        if(button==5) cfg.armor=!cfg.armor;
        if(button==6) cfg.difficulty=!cfg.difficulty;
        break;
    case 2:
        if(button==5) { open(); return; }
        if(button<2) for(auto* cost:{&cfg.grabCost,&cfg.holdCost,&cfg.launchCost,&cfg.executionCost,&cfg.disarmCost,&cfg.projectileCost})
            *cost=std::clamp(*cost*(button ? 1.25f : .8f),0.f,500.f);
        if(button==2) cfg.costPerks=!cfg.costPerks;
        if(button==3) cfg.xpScale=cfg.xpScale<.5f ? .5f : cfg.xpScale<1 ? 1 : cfg.xpScale<2 ? 2 : 0;
        if(button==4) cfg.xpPerMinute=cfg.xpPerMinute<60 ? 60 : cfg.xpPerMinute<120 ? 120 : 30;
        break;
    case 3:
        if(button==8) { open(); return; }
        if(button==0) cfg.catchProjectiles=!cfg.catchProjectiles;
        if(button==1) cfg.projectileRadius=std::max(100.f,cfg.projectileRadius-50);
        if(button==2) cfg.projectileRadius=std::min(1000.f,cfg.projectileRadius+50);
        if(button==3) cfg.predictionSeconds=std::max(.02f,cfg.predictionSeconds-.05f);
        if(button==4) cfg.predictionSeconds=std::min(.75f,cfg.predictionSeconds+.05f);
        if(button==5) cfg.returnMode=1-cfg.returnMode;
        if(button==6) cfg.projectileHoldSeconds=cfg.projectileHoldSeconds<8 ? 8 : cfg.projectileHoldSeconds<15 ? 15 : 3;
        if(button==7) cfg.threatRadius=cfg.threatRadius<110 ? 110 : cfg.threatRadius<160 ? 160 : 60;
        break;
    case 4:
        if(button==8) { open(); return; }
        if(button==0) cfg.levelFactor=std::max(0.f,cfg.levelFactor-.01f);
        if(button==1) cfg.levelFactor=std::min(.2f,cfg.levelFactor+.01f);
        if(button==2) cfg.maxScale=std::max(.5f,cfg.maxScale-.1f);
        if(button==3) cfg.maxScale=std::min(2.f,cfg.maxScale+.1f);
        if(button==4) cfg.executionHealth=cfg.executionHealth<.25f ? .25f : cfg.executionHealth<.35f ? .35f : cfg.executionHealth<.5f ? .5f : .15f;
        if(button==5) cfg.lethalLevelAdvantage=cfg.lethalLevelAdvantage<10 ? 10 : cfg.lethalLevelAdvantage<20 ? 20 : 5;
        if(button==6) cfg.protect=!cfg.protect;
        if(button==7) cfg.creatures=!cfg.creatures;
        break;
    case 5:
        if(button==5) { open(); return; }
        if(button==0) { rebind(cfg.settingsKey); return; }
        if(button==1) { rebind(cfg.modifierKey); return; }
        if(button==2) cfg.legacyHotkeys=!cfg.legacyHotkeys;
        if(button==3) { open(6); return; }
        if(button==4) { cfg.settingsKey=68; cfg.modifierKey=42; cfg.modifierKey2=54;
            cfg.grab=34; cfg.launch=35; cfg.pull=36; cfg.push=37; cfg.slam=38; cfg.execute=45; }
        break;
    case 6:
        if(button==6) { open(5); return; }
        if(button<6) { std::uint32_t* keys[]{&cfg.grab,&cfg.launch,&cfg.pull,&cfg.push,&cfg.slam,&cfg.execute}; rebind(*keys[button]); }
        return;
    case 7:
        if(button==6) { open(); return; }
        if(button==0) cfg.preview=!cfg.preview;
        if(button==1) cfg.feedback=!cfg.feedback;
        if(button==2) cfg.decapitate=!cfg.decapitate;
        if(button==3) cfg.profile=!cfg.profile;
        if(button==4) cfg.cacheInterval=cfg.cacheInterval<.25f ? .25f : cfg.cacheInterval<.5f ? .5f : .1f;
        if(button==5) cfg.searchInterval=cfg.searchInterval<.12f ? .12f : cfg.searchInterval<.25f ? .25f : .06f;
        break;
    default: return;
    }
    save(); open(page);
}
}
