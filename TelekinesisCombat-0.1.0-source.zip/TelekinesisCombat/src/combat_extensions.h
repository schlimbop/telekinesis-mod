#pragma once
#include "combat_math.h"

namespace tkc {
inline constexpr int captureLimit=6;
inline float throwCharge(float age,float duration) {
    return std::isfinite(age) && std::isfinite(duration) && duration>0 ? std::clamp(age/duration,0.f,1.f) : 0.f;
}
inline float chargedThrowSpeed(float base,float charge,float bonus) {
    if(!std::isfinite(base) || !std::isfinite(charge) || !std::isfinite(bonus)) return 0;
    return std::clamp(base*(1.f+std::clamp(charge,0.f,1.f)*std::clamp(bonus,0.f,1.f)),0.f,4500.f);
}
inline Vec captureOffset(Vec direction,int slot) {
    if(slot<0 || slot>=captureLimit || !finite(direction)) return {};
    Vec right=unit(cross(direction,{0,0,1}));
    if(length(right)<.5f) right={1,0,0};
    Vec up=unit(cross(right,direction));
    float angle=6.28318530718f*slot/captureLimit;
    return right*(std::cos(angle)*48.f)+up*(std::sin(angle)*35.f);
}
// Both actors share one bounded collision budget; larger bodies transfer more of it.
inline float bodyCollisionDamage(float health,float maximum,float otherMaximum,float speed,float reference,float size,float otherSize,float fraction) {
    if(!std::isfinite(health) || !std::isfinite(maximum) || !std::isfinite(otherMaximum) || !std::isfinite(speed) ||
       !std::isfinite(reference) || !std::isfinite(size) || !std::isfinite(otherSize) || !std::isfinite(fraction) ||
       health<=0 || maximum<=0 || otherMaximum<=0 || reference<=0 || size<=0 || otherSize<=0 || speed<=0) return 0;
    float ratio=std::clamp(speed/reference,0.f,2.f);
    float weight=std::clamp(otherSize*otherSize*otherSize/(size*size*size),.25f,2.f);
    return std::min(health-std::min(health,1.f),std::min(maximum,otherMaximum)*std::clamp(fraction,0.f,.3f)*std::min(1.5f,ratio*ratio)*weight);
}
}
