# Acceptance checks — required before a playable release

## Evidence from this task

- Version 0.1.2 failed on 1.7.104: pressing cast crashes. Installed DLL SHA256 is `5CE128B753D894284E6EBE07469CE8059EF03E53F0FD1D42E65FC4581F18771A`, matching the remote build. Official Crash Logger 1.25.0 captured an access violation in the plugin at offset `0x22DA5`, calling virtual slot `+0x08` with Magicka argument 25 and `this` equal to player plus `0x98`. Target acquisition and the physics-body query had already succeeded for a jug. The incorrectly adjusted ActorValueOwner caused the crash; modern AE requires player plus `0xB8`.
- Version 0.1.3 routes all ActorValueOwner calls through `AsActorValueOwner()` and private-effect removal through `AsMagicTarget()`. The standalone SDK test checks both interface addresses under four mocked executable versions, without a Skyrim installation. Release builds retain matching debug symbols. Compilation and in-game retest are pending; a working playable release is not yet claimed.
- In-game report for 0.1.1 on 1.7.104: DLL loads, companion records resolve, and casting shows the aim-at-target message, but neither nearby objects nor NPCs are selected. This is a failed gameplay check. Root cause found in the source: `bhkPickData.ray` was left empty.
- Version 0.1.2 fills the Havok ray displacement, uses Skyrim's native crosshair target for nearby selection, and logs target/grip results. Re-test objects, NPCs, walls, and impacts; a build passing checks alone does not resolve the in-game failure.
- Six Python tests passed: tagged-record parsing, extended-size parsing, corrupt input rejection, group boundaries, companion forms and archetypes, multiple-effect Paralyze selection, x64-DLL packaging guard, source archive hashes.
- Included companion generated from the installed Skyrim.esm; validated header, lengths, ESL flag, master, local IDs and effect references.
- Native signatures manually checked against CommonLibSSE NG 10.1.0 headers.
- Version 0.1.2 Release x64 compilation/linking passed on GitHub Actions Windows Server 2022. Run 37614875041, source commit 4df3a87872b9d09bf7181de7e240707deec5768a.
- CTest: 2/2 passed (combat math/casting controls and the actual CommonLib pick-ray structure). Python unittest: 6/6 checks passed in the same remote build and locally.
- Downloaded artifact SHA256 matched GitHub's digest. DLL PE32+ x64 and all three SKSE exports checked without loading it. Only KERNEL32, ole32, VERSION, USER32, and SHELL32 are imported; no build-tool or third-party runtime DLL is required.
- SSEEdit validation and the 0.1.3 gameplay checks below are **not run**. The earlier 0.1.1 and 0.1.2 gameplay tests failed as described above. Successful compilation does not certify in-game behavior or compatibility across the runtime list.

## Build checks

1. Build Release x64 using README instructions. Resolve every compiler/linker error, do not suppress them to obtain a DLL.
2. Run CTest and Python tests. Verify exported SKSE entry points/version metadata in the resulting DLL. Packaging must reject a text file, x86 DLL and missing DLL.
3. Load the ESP in SSEEdit. Check for Errors must show no unresolved references or malformed fields; inspect all six records. Verify no master overrides. Confirm neither cosmetic MGEF has a gameplay-damage archetype/script.
4. Run the Windows workflow from the project root when checking CI; the generated source ZIP preserves `.github/workflows` there.

## First in-game pass (separate profile/save)

| Check | Required behavior |
| --- | --- |
| Initialization | SKSE loads DLL; log says gameplay layer ready; invalid/missing ESP disables controls |
| Control gating | Hotkeys act only with Combat Telekinesis equipped and menus closed |
| Grab | Ordinary bandit ragdolls within 0.75 sec or safely aborts; no standing-pose levitation |
| Targeting regression | Nearby loose sword with a vanilla crosshair prompt selects via `crosshair` in the log; a farther visible bandit selects via `physics`; an intervening wall prevents selection |
| Suspend | Aim moves anchor without actor teleportation or explosive stretching; player/target collision remains |
| Obstacles | Grip stays in front of wall; blocked close-space hold drops; targeting cannot pass through walls |
| Release | Activate (normally E) drops, removes only private suspension, actor resumes normally |
| Costs | Grab/hold/launch/execute charge expected amounts; empty Magicka releases; high level/scale costs more |
| Pull/push | Wheel up/down adjusts distance within configured bounds; no action when nothing held |
| Actor launch | Release the gripping cast button to apply forward ragdoll velocity; wall/floor impact applies damage once, attributable to player |
| Slam | Shift-release drives downward; sufficient impact can kill; no damage simply from slow free fall |
| Weapon | Loose sword/dagger holds, faces approximately point-forward, launches, damages one target; mesh remains visible |
| Other items | Eligible objects tumble/launch; statics/doors/equipped items never change physics |
| Human projectile | Thrown actor colliding with another hurts both; no duplicate native damage later in flight |
| Immunity | Child/essential/dragon/giant/oversized/already-paralyzed target rejects grab; protected target rejects by default |
| Finisher | With the spell in both hands, hold the opposite cast button; above threshold cannot execute; releasing cancels; sound/VFX plays at kill |
| Lifecycle | Unequip/pause/load/fast travel/cell transition clears hold; effects expire in ≤2 sec; no crash or permanent paralysis |
| Save/load | Save during hold and during flight, then reload; native state resets; surviving short effects expire without orphaned handles |
| Bounded flights | Limit rejects extra launches until old flights expire; repeated holds/throws do not leak growing state |

Repeat at low frame rates and after deliberately opening the menu mid-charge. Try indoors with narrow spaces, outdoors and after a cell boundary. Test adjacent walls and thin meshes at increasing speeds to tune tunnelling limits. A bad physics result is a failure even if the target dies.

## Compatibility matrix to complete

Run the same pass on 1.5.97, each supported AE target, and 1.7.104 with their matching SKSE/Address Library. Record executable version, SKSE version, DLL hash and mod list with each result. Add other telekinesis, collision, skeleton, animation and paralysis mods one at a time. Check player kill attribution, crime reporting, essential behavior and recovery under those stacks. Measure frame times with 1 and 8 simultaneous flights in a busy cell. Expand runtime support only after checking CommonLib layouts/relocations and repeating the pass.
