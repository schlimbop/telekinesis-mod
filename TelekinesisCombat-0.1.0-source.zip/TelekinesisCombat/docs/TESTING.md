# Acceptance checks — required before a playable release

## Evidence from this task

- The user confirmed basic 0.1.4 operation. Version 0.1.5 adds creature eligibility, physics-centre/visibility targeting, fast retrieval and actor-bound impact sweeps. Read-only inspection of installed 1.7.104 shows Actor vtable slot 0x104 (`HandleHealthDamage`, RVA 0x6CC3D0) reads current Health and performs death notification without subtracting it. The plugin now subtracts health before notifying the engine in the shared impact/finisher function. Maximum health includes temporary modifiers. Activate-hold executes weakened actors, with a clear insufficient-Magicka message. C++ compilation and gameplay retest are pending; six Python checks passed locally.

- The user confirmed 0.1.3 works without crashing on 1.7.104. Remaining gameplay problems: short pickup range, grip loss during camera movement, and stiff paralysis. Version 0.1.4 implements wider visible-target acquisition with continuous retries, smooth bounded anchor travel, sleeping-body activation, adjacent-cell physics-world checks and a native zero-force knockdown plus recovering Grabbed AV modifier. Relative limb velocities are preserved. GitHub Actions run 37629583026 compiled Release x64 from commit 3b8e4a1dc3fdd8a171d90d309d9f8b9139960253. Both CTests and all six Python checks passed; distant cone selection and bounded camera-turn holding are covered by the math test. Artifact SHA256 matched GitHub, all eight package-file hashes and SKSE exports passed verification, and matching debug symbols are included. DLL SHA256: `ff4859f34db60ff28308a56624d6cc1e9c8d6cb2d52e10aae1b9266dc5678266`. The revised gameplay checks below remain pending.

- Version 0.1.2 failed on 1.7.104: pressing cast crashes. Installed DLL SHA256 is `5CE128B753D894284E6EBE07469CE8059EF03E53F0FD1D42E65FC4581F18771A`, matching the remote build. Official Crash Logger 1.25.0 captured an access violation in the plugin at offset `0x22DA5`, calling virtual slot `+0x08` with Magicka argument 25 and `this` equal to player plus `0x98`. Target acquisition and the physics-body query had already succeeded for a jug. The incorrectly adjusted ActorValueOwner caused the crash; modern AE requires player plus `0xB8`.
- Version 0.1.3 routes all ActorValueOwner calls through `AsActorValueOwner()` and private-effect removal through `AsMagicTarget()`. GitHub Actions run 37619899203 compiled Release x64 from commit f487eb981e8cc0ffd3df9ca46ed80397ad0920f9. Both CTests and all six Python checks passed. The SDK test checked both interface addresses under four mocked executable versions, without a Skyrim installation. Release builds retain matching debug symbols. Downloaded artifact SHA256 matched GitHub; eight package-file hashes and SKSE exports passed verification. DLL SHA256: `7c6c0d4826fd635334e0565519b111b30ab13887691fe628d5047f869adedaa5`. The user subsequently confirmed basic operation without crashes; range, camera holding and NPC suspension remain subject to the 0.1.4 improvements.
- In-game report for 0.1.1 on 1.7.104: DLL loads, companion records resolve, and casting shows the aim-at-target message, but neither nearby objects nor NPCs are selected. This is a failed gameplay check. Root cause found in the source: `bhkPickData.ray` was left empty.
- Version 0.1.2 fills the Havok ray displacement, uses Skyrim's native crosshair target for nearby selection, and logs target/grip results. Re-test objects, NPCs, walls, and impacts; a build passing checks alone does not resolve the in-game failure.
- Six Python tests passed: tagged-record parsing, extended-size parsing, corrupt input rejection, group boundaries, companion forms and archetypes, multiple-effect Paralyze selection, x64-DLL packaging guard, source archive hashes.
- Included companion generated from the installed Skyrim.esm; validated header, lengths, ESL flag, master, local IDs and effect references.
- Native signatures manually checked against CommonLibSSE NG 10.1.0 headers.
- Version 0.1.2 Release x64 compilation/linking passed on GitHub Actions Windows Server 2022. Run 37614875041, source commit 4df3a87872b9d09bf7181de7e240707deec5768a.
- CTest: 2/2 passed (combat math/casting controls and the actual CommonLib pick-ray structure). Python unittest: 6/6 checks passed in the same remote build and locally.
- Version 0.1.2's downloaded artifact SHA256 matched GitHub's digest. DLL PE32+ x64 and all three SKSE exports were checked without loading it. Version 0.1.3 imports Windows system libraries (including Direct3D, cryptography and debug support); no Visual Studio or separately installed third-party runtime DLL is required.
- SSEEdit validation and the complete 0.1.5 gameplay matrix below are **not run**. The user verified basic 0.1.3 operation without crashes, rather than every listed behavior. Successful compilation does not certify in-game behavior or compatibility across the runtime list.

## Build checks

1. Build Release x64 using README instructions. Resolve every compiler/linker error, do not suppress them to obtain a DLL.
2. Run CTest and Python tests. Verify exported SKSE entry points/version metadata in the resulting DLL. Packaging must reject a text file, x86 DLL and missing DLL.
3. Load the ESP in SSEEdit. Check for Errors must show no unresolved references or malformed fields; inspect all six records. Verify no master overrides. Confirm neither cosmetic MGEF has a gameplay-damage archetype/script.
4. Run the Windows workflow from the project root when checking CI; the generated source ZIP preserves `.github/workflows` there.

## First in-game pass (separate profile/save)

| Check | Required behavior |
| --- | --- |
| Initialization | SKSE loads DLL; log says gameplay layer ready; invalid/missing ESP disables controls |
| Control gating | Hotkeys act only with Combat Telekinesis equipped and menus closed |
| Grab | Ordinary bandit ragdolls within 1.5 sec or safely aborts; limbs bend/move rather than remaining a stiff paralysis pose; no drain while held |
| Targeting regression | Nearby loose sword and visible small clutter at 5500 units select; a farther visible bandit selects; an intervening wall prevents selection; aiming at a target after starting a cast acquires it without repressing cast |
| Suspend | Aim moves anchor without actor teleportation or explosive stretching; player/target collision remains |
| Camera/obstacles | Quick 90/180 degree camera turns preserve the same target; grip follows smoothly and stays in front of walls; targeting cannot pass through walls |
| Exterior boundary | Grip and tracked impacts continue across adjacent attached cells in the same physics world |
| Pause/hitch | Pausing with cast held freezes updates/costs; a frame hitch does not cancel the grip |
| Release | Activate (normally E) drops, removes only private suspension, actor resumes normally |
| Fast retrieval | A visible distant prop pulls in rapidly (10000-unit speed cap), settles near the crosshair, and retains its grip on camera turns |
| Creatures | Wolves, bears and normal-sized creatures ragdoll; low creature bounds receive thrown hits; dragons/giants and oversized creatures remain immune to suspension |
| Costs | Grab/hold/launch/execute charge expected amounts; empty Magicka releases; high level/scale costs more |
| Pull/push | Wheel up/down adjusts distance within configured bounds; no action when nothing held |
| Actor launch | Release the gripping cast button to apply forward ragdoll velocity; wall/floor impact applies damage once, attributable to player |
| Slam | Shift-release drives downward; sufficient impact can kill; no damage simply from slow free fall |
| Weapon | Log shows real Health subtraction and native death on lethal impacts; loose sword/dagger holds, faces approximately point-forward, launches, damages one target; mesh remains visible |
| Other items | Eligible objects tumble/launch; statics/doors/equipped items never change physics |
| Human projectile | Thrown actor colliding with another hurts both; no duplicate native damage later in flight |
| Immunity | Child/essential/dragon/giant/oversized/already-paralyzed/externally-grabbed target rejects grab; protected target rejects by default |
| Finisher | Hold cast plus Activate/E for 1 second on an eligible actor at <=35% health; health reaches zero and native death occurs. Early Activate release drops. Temporary health buffs use the correct maximum; insufficient Magicka reports failure. Opposite cast with both spell hands also works |
| Lifecycle | Unequip/load/fast travel/physics-world change clears hold; private Grabbed modifier recovers in ≤2 sec of game time; Paralysis AV remains unchanged; no crash or stuck ragdoll |
| Save/load | Save during hold and during flight, then reload; native state resets; surviving short effects expire without orphaned handles |
| Bounded flights | Limit rejects extra launches until old flights expire; repeated holds/throws do not leak growing state |

Repeat at low frame rates and after deliberately opening the menu mid-charge. Try indoors with narrow spaces, outdoors and after a cell boundary. Test adjacent walls and thin meshes at increasing speeds to tune tunnelling limits. A bad physics result is a failure even if the target dies.

## Compatibility matrix to complete

Run the same pass on 1.5.97, each supported AE target, and 1.7.104 with their matching SKSE/Address Library. Record executable version, SKSE version, DLL hash and mod list with each result. Add other telekinesis, collision, skeleton, animation and paralysis mods one at a time. Check player kill attribution, crime reporting, essential behavior and recovery under those stacks. Measure frame times with 1 and 8 simultaneous flights in a busy cell. Expand runtime support only after checking CommonLib layouts/relocations and repeating the pass.
