# Acceptance checks — required before a playable release

## Evidence from this task

- Six Python tests passed: tagged-record parsing, extended-size parsing, corrupt input rejection, group boundaries, companion forms and archetypes, multiple-effect Paralyze selection, x64-DLL packaging guard, source archive hashes.
- Included companion generated from the installed Skyrim.esm; validated header, lengths, ESL flag, master, local IDs and effect references.
- Native signatures manually checked against CommonLibSSE NG 10.1.0 headers.
- No MSVC/CMake available. DLL compile/link, C++ math executable, workflow run, SSEEdit validation and all gameplay checks below are **not run**. Do not infer those results from the Python tests.

## Build checks

1. Build Release x64 using README instructions. Resolve every compiler/linker error, do not suppress them to obtain a DLL.
2. Run CTest and Python tests. Verify exported SKSE entry points/version metadata in the resulting DLL. Packaging must reject a text file, x86 DLL and missing DLL.
3. Load the ESP in SSEEdit. Check for Errors must show no unresolved references or malformed fields; inspect all six records. Verify no master overrides. Confirm neither cosmetic MGEF has a gameplay-damage archetype/script.
4. Run the Windows workflow from the project root when checking CI; the generated source ZIP preserves `.github/workflows` there.

## First in-game pass (separate profile/save)

| Check | Required behavior |
| --- | --- |
| Initialization | SKSE loads DLL; log says gameplay layer ready; invalid/missing ESP disables controls |
| Control gating | Hotkeys act only with Combat Telekinesis equipped and menus closed |
| Grab | Ordinary bandit ragdolls within 0.75 sec or safely aborts; no standing-pose levitation |
| Suspend | Aim moves anchor without actor teleportation or explosive stretching; player/target collision remains |
| Obstacles | Grip stays in front of wall; blocked close-space hold drops; targeting cannot pass through walls |
| Release | G drops, removes only private suspension, actor resumes normally |
| Costs | Grab/hold/launch/execute charge expected amounts; empty Magicka releases; high level/scale costs more |
| Pull/push | J/K smoothly adjust distance within configured bounds; no action when nothing held |
| Actor launch | H applies forward ragdoll velocity; wall/floor impact applies damage once, attributable to player |
| Slam | L drives downward; sufficient impact can kill; no damage simply from slow free fall |
| Weapon | Loose sword/dagger holds, faces approximately point-forward, launches, damages one target; mesh remains visible |
| Other items | Eligible objects tumble/launch; statics/doors/equipped items never change physics |
| Human projectile | Thrown actor colliding with another hurts both; no duplicate native damage later in flight |
| Immunity | Child/essential/dragon/giant/oversized/already-paralyzed target rejects grab; protected target rejects by default |
| Finisher | Above threshold cannot execute; below threshold X must stay held full charge; releasing cancels; sound/VFX plays at kill |
| Lifecycle | Unequip/pause/load/fast travel/cell transition clears hold; effects expire in ≤2 sec; no crash or permanent paralysis |
| Save/load | Save during hold and during flight, then reload; native state resets; surviving short effects expire without orphaned handles |
| Bounded flights | Limit rejects extra launches until old flights expire; repeated holds/throws do not leak growing state |

Repeat at low frame rates and after deliberately opening the menu mid-charge. Try indoors with narrow spaces, outdoors and after a cell boundary. Test adjacent walls and thin meshes at increasing speeds to tune tunnelling limits. A bad physics result is a failure even if the target dies.

## Compatibility matrix to complete

Run the same pass on 1.5.97, each supported AE target, and 1.7.104 with their matching SKSE/Address Library. Record executable version, SKSE version, DLL hash and mod list with each result. Add other telekinesis, collision, skeleton, animation and paralysis mods one at a time. Check player kill attribution, crime reporting, essential behavior and recovery under those stacks. Measure frame times with 1 and 8 simultaneous flights in a busy cell. Expand runtime support only after checking CommonLib layouts/relocations and repeating the pass.
