# Companion records and manual setup

The generated `Data/TelekinesisCombat.esp` already implements the core layer. Use SSEEdit to inspect and **Check for Errors**; it has not been opened in CK/SSEEdit during this task. Regenerate it using `tools/companion.py` and your original Skyrim.esm if needed. The script does not modify Skyrim.esm, update installed mods or write to the game's Data directory.

## Exact contract

Master: `Skyrim.esm` only. TES4 version 1.7, author TelekinesisCombat, ESL flag, record Form Version 44. New local IDs fit 0x800–0xFFF for compatibility with older SE. No overrides, quest, scripts, perk or world records are required.

| Local ID | Type | EditorID | Purpose |
| --- | --- | --- | --- |
| 800 | SPEL | TKC_CombatTelekinesis | Equipped control spell |
| 801 | SPEL | TKC_Hold | Internal short paralysis spell |
| 802 | MGEF | TKC_HoldEffect | Private paralysis |
| 803 | MGEF | TKC_ControlEffect | Harmless scripted effect with no attached script |
| 804 | SPEL | TKC_CrushVisual | Visual/sound finisher |
| 805 | MGEF | TKC_CrushEffect | Private cosmetic scripted effect |

The on-disk IDs are `01000800` etc. because Skyrim.esm is master index 0 and the new file is index 1. In the INI use only `0x800`, `0x801`, `0x804`. At runtime the DLL resolves the actual load-order IDs by filename. Do not use the example on-disk prefix in console commands; use `help` to find your loaded FormID.

## Recreate in Creation Kit/xEdit

Create a new plugin with Skyrim.esm as its only master. Duplicate vanilla records as **new records**; never edit the originals. Creation Kit may allocate different IDs: write the resulting local spell IDs into `[Forms]` in the INI. ESL-flag after confirming every new ID fits the old light-plugin range. Do not compact a plugin already used by a save.

1. Duplicate the vanilla **Telekinesis** spell for TKC_CombatTelekinesis. Name it **Combat Telekinesis**. Keep its equip slot and menu display object. Spell Type Spell, Casting Concentration, Delivery Self, Manual Cost 0, charge time 0, cast duration 0, range 0, no half-cost perk. Flags Manual Cost, Ignore Resistance, No Absorb/Reflect. Replace all effects with one TKC_ControlEffect: magnitude 1, area 0, duration 0, no conditions. Description: “Equip this spell and use G/H/J/K/L/X. See TelekinesisCombat README.”
2. Duplicate **TelekinesisEffect** as TKC_ControlEffect. Set Archetype Script, attach **no script**, associated item None, primary/secondary AV None, skill Alteration, minimum skill 0, resist value None, base cost 0, skill usage multiplier 0. Concentration/Self. Set No Hit Event, No Area, No Magnitude, No Duration. Clear Hostile/Detrimental. Clear projectile, explosion, equip ability, perk, counter effects, conditions, keywords and VMAD. Clear casting light, hit/enchant shader, hit art, casting art, impact set, visuals and imagespace modifier. Retain stock Telekinesis sound descriptors if desired. The DLL only checks whether this spell is equipped; its mouse-cast effect is intentionally harmless.
3. Duplicate the **Paralyze** spell as TKC_Hold. Spell/Fire and Forget/Target Actor, cost 0, charge 0, range 0, Manual Cost, Ignore Resistance, No Absorb/Reflect, no perk. Remove every effect, including StaggerPushFFAimed. Add only TKC_HoldEffect with magnitude 1, area 0, duration **2 seconds**, no effect conditions.
4. Duplicate the vanilla **paralysis MGEF used by Paralyze** as TKC_HoldEffect (do not choose its stagger effect). Archetype Paralysis, primary AV Paralysis, secondary AV None, skill Alteration, resist None, minimum skill 0, base cost 0, usage multiplier 0. Fire and Forget/Target Actor. Flags Hostile, Detrimental, No Hit Event, No Area, No Magnitude, Hide in UI. **No Recast off**, **No Duration off**, power/duration modifiers off. Clear projectile/explosion, associated item, counter effects, conditions, VMAD, keywords, perk, equip ability and imagespace modifier. Keep stock paralysis hit shader/art/sound data. The native call skips hit-effect art while holding; the effect's real purpose is ragdoll activation/recovery.
5. Duplicate a stock shock-hit effect such as **ShockDamageFFContact** as TKC_CrushEffect. Archetype Script, no attached script, primary/secondary AV None, associated item None. Fire and Forget/Target Actor. Skill Alteration, resist None, min skill 0, base cost 0, usage 0. Flags No Hit Event, No Area, No Magnitude; not Hostile/Detrimental/No Duration. Clear projectile/explosion, counter effects, conditions, VMAD, keywords, equip ability, perk, imagespace and enchant visuals. Retain the stock hit shader, hit art, impact set and hit sound descriptors. It must cause **zero damage**; the plugin applies the lethal damage.
6. Duplicate Paralyze as TKC_CrushVisual. Replace effects with only TKC_CrushEffect: magnitude 1, area 0, duration 1. Same targeted casting/cost/flags as TKC_Hold. Set ExecutionSpell to its local ID in the INI. Setting this ID to 0 disables its visual while leaving the lethal damage active.

The generator performs these transformations with fixed IDs. It copies effect data and sound fields, not assets. For its cosmetic template it falls back to paralysis visuals if ShockDamageFFContact is unavailable. The included spell is not automatically learned: use the README console acquisition step or add a normal spell tome/vendor entry yourself.

## Optional dedicated crack sound and shader

The generated layer already has stock effect art/sounds. For a more recognizable crush, create a Start Game Enabled quest `TKC_FXQuest`, attach `TKC_ExecutionFX.psc`, and create a player reference alias with `TKC_PlayerAlias.psc`. Set its Controller property to this quest. Compile using CK's Papyrus compiler with the Skyrim and SKSE script sources installed. Put resulting PEX files in `Data/Scripts`; no compiler is bundled here.

Set the quest script's CrushSound to a chosen existing SNDR or your own licensed crack sound descriptor, and CrushShader to an EFSH. The `TKC_Execution` mod event sends the victim as sender; the script runs only at execution, never for physics updates. It plays the shader briefly and the sound at the victim. It does not simulate a head fracture. The player alias re-registers the quest listener after save loading. Include the new quest, alias/property data and PEX together if you choose this optional route; the included ESP contains none of them.
