#include <RE/Skyrim.h>
#include "raycast.h"
#include "prop_physics.h"
#include "combat_math.h"
#include <limits>
#include <cstdlib>
#include <iostream>
#include <array>
void check(bool value) { if(!value) { std::cerr<<"Ray/interface check failed\n"; std::exit(1); } }
void weaponAxes() {
    for(tkc::Vec target:{tkc::Vec{0,1,0},tkc::Vec{0,-1,0},tkc::Vec{0,0,1},tkc::Vec{1,0,0},tkc::unit({1,-2,3})}) {
        auto q=tkc::weaponRotation(target);
        RE::hkQuaternion native; native.vec=RE::hkVector4(q.x,q.y,q.z,q.w);
        auto& v=native.vec.quad;
        RE::NiQuaternion scene(v.m128_f32[3],v.m128_f32[0],v.m128_f32[1],v.m128_f32[2]);
        auto matrix=scene.ToRotation();
        // The SDK matrix independently transforms the stock mesh's +Y tip/head axis.
        tkc::Vec forward{matrix.entry[0][1],matrix.entry[1][1],matrix.entry[2][1]};
        check(tkc::length(forward-target)<.001f);
    }
}
void actorInterfaces(REL::Version version, std::size_t valuesOffset, std::size_t magicOffset) {
    check(REL::Module::mock(version));
    // Only the SDK's pointer-adjustment accessors run; no Actor is constructed,
    // no vtable is dereferenced, and no engine function or Address Library is needed.
    alignas(RE::Actor) std::array<std::byte,0x300> storage{};
    auto* actor=reinterpret_cast<RE::Actor*>(storage.data());
    check(reinterpret_cast<std::byte*>(actor->AsActorValueOwner())==storage.data()+valuesOffset);
    check(reinterpret_cast<std::byte*>(actor->AsMagicTarget())==storage.data()+magicOffset);
    check(reinterpret_cast<std::byte*>(actor->AsActorState())==storage.data()+valuesOffset+8);
    alignas(RE::PlayerCharacter) std::array<std::byte,0x1000> playerStorage{};
    auto* player=reinterpret_cast<RE::PlayerCharacter*>(playerStorage.data());
    std::size_t difficultyOffset=version>=REL::Version{1,7,99,0} ? 0xB08 : version>=REL::Version{1,6,629,0} ? 0xB00 : 0xAF8;
    check(reinterpret_cast<std::byte*>(&player->GetGameStatsData())==playerStorage.data()+difficultyOffset);
    auto* missile=reinterpret_cast<RE::MissileProjectile*>(storage.data());
    bool modern=version>=REL::Version{1,6,629,0};
    check(reinterpret_cast<std::byte*>(&missile->GetProjectileRuntimeData())==storage.data()+(modern ? 0xA0 : 0x98));
    check(reinterpret_cast<std::byte*>(&missile->GetMissileRuntimeData())==storage.data()+(modern ? 0x1E0 : 0x1D8));
}
void propInterfaces() {
    for(auto type:{RE::WEAPON_TYPE::kOneHandSword,RE::WEAPON_TYPE::kOneHandDagger,
                   RE::WEAPON_TYPE::kOneHandAxe,RE::WEAPON_TYPE::kOneHandMace,
                   RE::WEAPON_TYPE::kTwoHandSword,RE::WEAPON_TYPE::kTwoHandAxe}) check(tkc::aimableMeleeType(type));
    for(auto type:{RE::WEAPON_TYPE::kHandToHandMelee,RE::WEAPON_TYPE::kBow,RE::WEAPON_TYPE::kStaff,
                   RE::WEAPON_TYPE::kCrossbow,RE::WEAPON_TYPE::kTotal}) check(!tkc::aimableMeleeType(type));
    using Type=RE::hkpMotion::MotionType;
    using State=tkc::PropMotion;
    alignas(RE::hkpMotion) std::array<std::byte,sizeof(RE::hkpMotion)> storage{};
    auto* motion=reinterpret_cast<RE::hkpMotion*>(storage.data());
    // Inline field-only queries: no vtable, engine conversion, or saved-motion dereference.
    for(auto type:{Type::kDynamic,Type::kSphereInertia,Type::kBoxInertia,Type::kThinBoxInertia}) {
        motion->type=type; motion->inertiaAndMassInv=RE::hkVector4(1,1,1,.2f);
        check(tkc::propMotion(*motion)==State::dynamic); // Zero velocity/sleep does not reject a prop.
        for(float invalid:{0.f,-1.f,std::numeric_limits<float>::quiet_NaN(),std::numeric_limits<float>::infinity()}) {
            motion->inertiaAndMassInv=RE::hkVector4(0,0,0,invalid);
            check(tkc::propMotion(*motion)==State::unavailable);
        }
    }
    for(auto type:{Type::kFixed,Type::kKeyframed}) {
        motion->type=type; motion->inertiaAndMassInv=RE::hkVector4{}; motion->savedMotion=nullptr;
        check(tkc::propMotion(*motion)==State::unavailable);
        motion->savedMotion=reinterpret_cast<RE::hkpMaxSizeMotion*>(std::uintptr_t{1});
        check(tkc::propMotion(*motion)==State::dormant);
        motion->savedMotion=nullptr; motion->inertiaAndMassInv=RE::hkVector4(1,1,1,.2f);
        check(tkc::propMotion(*motion)==State::dormant);
    }
    for(auto type:{Type::kInvalid,Type::kCharacter,Type::kTotal}) {
        motion->type=type;
        check(tkc::propMotion(*motion)==State::unavailable);
    }
    for(auto type:{RE::FormType::Book,RE::FormType::Misc,RE::FormType::Weapon,RE::FormType::Armor,
                  RE::FormType::AlchemyItem,RE::FormType::Ingredient,RE::FormType::Scroll,
                  RE::FormType::Ammo,RE::FormType::SoulGem,RE::FormType::KeyMaster}) check(tkc::carryableType(type));
    for(auto type:{RE::FormType::Static,RE::FormType::Furniture,RE::FormType::Door,RE::FormType::Activator})
        check(!tkc::carryableType(type));
    check(!tkc::carryableType(RE::FormType::Light));
    check(tkc::carryableType(RE::FormType::Light,true));
    check(tkc::previewShader(true,false)==0x5d608 && tkc::previewShader(true,true)==0xd7661);
    check(tkc::previewShader(false,false)==0x146 && tkc::previewShader(false,true)==0xdc209);
}
int main() {
    weaponAxes();
    propInterfaces();
    // No vtable or native material resolver may run: even a valid MOPP ray can lack a material table.
    check(tkc::rayMaterial(nullptr)==RE::MATERIAL_ID::kStone);
    alignas(RE::hkpShape) std::array<std::byte,sizeof(RE::hkpShape)> shapeStorage{};
    alignas(RE::bhkShape) std::array<std::byte,sizeof(RE::bhkShape)> wrapperStorage{};
    auto* shape=reinterpret_cast<RE::hkpShape*>(shapeStorage.data());
    auto* wrapper=reinterpret_cast<RE::bhkShape*>(wrapperStorage.data());
    shape->type=RE::hkpShapeType::kBox;
    check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kStone);
    shape->userData=wrapper; wrapper->materialID=RE::MATERIAL_ID::kMetalSolid;
    check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kMetalSolid);
    wrapper->materialID=RE::MATERIAL_ID::kNone;
    check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kStone);
    shape->userData=reinterpret_cast<RE::bhkShape*>(std::uintptr_t{1});
    for(auto type:{RE::hkpShapeType::kMOPP,RE::hkpShapeType::kBVTree,RE::hkpShapeType::kCompressedMesh,
                  RE::hkpShapeType::kCollection,RE::hkpShapeType::kList,RE::hkpShapeType::kTransform}) {
        shape->type=type;
        check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kStone);
    }

    RE::bhkPickData pick{};
    tkc::preparePickRay(pick,{1000,-2000,3000},{1500,-1800,2900},.01f);
    auto& from=pick.rayInput.from.quad;
    auto& to=pick.rayInput.to.quad;
    auto& delta=pick.ray.quad;
    check(from.m128_f32[0]==10 && from.m128_f32[1]==-20 && from.m128_f32[2]==30 && from.m128_f32[3]==1);
    check(to.m128_f32[0]==0 && to.m128_f32[1]==0 && to.m128_f32[2]==0 && to.m128_f32[3]==0);
    check(delta.m128_f32[0]==5 && delta.m128_f32[1]==2 && delta.m128_f32[2]==-1 && delta.m128_f32[3]==1);
    check(!pick.rayOutput.HasHit());
    // Moving the origin must preserve the segment displacement (source-body skipping).
    tkc::preparePickRay(pick,{1100,-2000,3000},{1500,-1800,2900},.01f);
    check(pick.ray.quad.m128_f32[0]==4);
    actorInterfaces({1,5,97,0},0xB0,0x98);
    actorInterfaces({1,6,640,0},0xB8,0xA0);
    actorInterfaces({1,6,1170,0},0xB8,0xA0);
    actorInterfaces({1,7,104,0},0xB8,0xA0);
}
