#include <RE/Skyrim.h>
#include "raycast.h"
#include <cstdlib>
#include <iostream>
#include <array>
void check(bool value) { if(!value) { std::cerr<<"Ray/interface check failed\n"; std::exit(1); } }
void actorInterfaces(REL::Version version, std::size_t valuesOffset, std::size_t magicOffset) {
    check(REL::Module::mock(version));
    // Only the SDK's pointer-adjustment accessors run; no Actor is constructed,
    // no vtable is dereferenced, and no engine function or Address Library is needed.
    alignas(RE::Actor) std::array<std::byte,0x300> storage{};
    auto* actor=reinterpret_cast<RE::Actor*>(storage.data());
    check(reinterpret_cast<std::byte*>(actor->AsActorValueOwner())==storage.data()+valuesOffset);
    check(reinterpret_cast<std::byte*>(actor->AsMagicTarget())==storage.data()+magicOffset);
    check(reinterpret_cast<std::byte*>(actor->AsActorState())==storage.data()+valuesOffset+8);
    auto* missile=reinterpret_cast<RE::MissileProjectile*>(storage.data());
    bool modern=version>=REL::Version{1,6,629,0};
    check(reinterpret_cast<std::byte*>(&missile->GetProjectileRuntimeData())==storage.data()+(modern ? 0xA0 : 0x98));
    check(reinterpret_cast<std::byte*>(&missile->GetMissileRuntimeData())==storage.data()+(modern ? 0x1E0 : 0x1D8));
}
int main() {
    RE::bhkPickData pick{};
    tkc::preparePickRay(pick,{1000,-2000,3000},{1500,-1800,2900},.01f);
    auto& from=pick.rayInput.from.quad;
    auto& to=pick.rayInput.to.quad;
    auto& delta=pick.ray.quad;
    check(from.m128_f32[0]==10 && from.m128_f32[1]==-20 && from.m128_f32[2]==30 && from.m128_f32[3]==1);
    check(to.m128_f32[0]==0 && to.m128_f32[1]==0 && to.m128_f32[2]==0 && to.m128_f32[3]==0);
    check(delta.m128_f32[0]==5 && delta.m128_f32[1]==2 && delta.m128_f32[2]==-1 && delta.m128_f32[3]==1);
    check(!pick.rayOutput.HasHit());
    // Moving the origin must preserve the segment displacement (source-body skipping).
    tkc::preparePickRay(pick,{1100,-2000,3000},{1500,-1800,2900},.01f);
    check(pick.ray.quad.m128_f32[0]==4);
    actorInterfaces({1,5,97,0},0xB0,0x98);
    actorInterfaces({1,6,640,0},0xB8,0xA0);
    actorInterfaces({1,6,1170,0},0xB8,0xA0);
    actorInterfaces({1,7,104,0},0xB8,0xA0);
}
