#include <RE/Skyrim.h>
#include "raycast.h"
#include <cstdlib>
#include <iostream>
void check(bool value) { if(!value) { std::cerr<<"Pick ray check failed\n"; std::exit(1); } }
int main() {
    RE::bhkPickData pick{};
    tkc::preparePickRay(pick,{1000,-2000,3000},{1500,-1800,2900},.01f);
    auto& from=pick.rayInput.from.quad;
    auto& to=pick.rayInput.to.quad;
    auto& delta=pick.ray.quad;
    check(from.m128_f32[0]==10 && from.m128_f32[1]==-20 && from.m128_f32[2]==30 && from.m128_f32[3]==1);
    check(to.m128_f32[0]==0 && to.m128_f32[1]==0 && to.m128_f32[2]==0 && to.m128_f32[3]==0);
    check(delta.m128_f32[0]==5 && delta.m128_f32[1]==2 && delta.m128_f32[2]==-1 && delta.m128_f32[3]==1);
    check(!pick.rayOutput.HasHit());
    // Moving the origin must preserve the segment displacement (source-body skipping).
    tkc::preparePickRay(pick,{1100,-2000,3000},{1500,-1800,2900},.01f);
    check(pick.ray.quad.m128_f32[0]==4);
}
