#include <RE/Skyrim.h>
#include "raycast.h"
#include "prop_physics.h"
#include "combat_math.h"
#include "projectile_rules.h"
#include "missile_hold.h"
#include "dismember.h"
#include <limits>
#include <cstdlib>
#include <iostream>
#include <array>
void check(bool value) { if(!value) { std::cerr<<"Ray/interface check failed\n"; std::exit(1); } }
void weaponAxes() {
    for(tkc::Vec target:{tkc::Vec{0,1,0},tkc::Vec{0,-1,0},tkc::Vec{0,0,1},tkc::Vec{1,0,0},tkc::unit({1,-2,3})}) {
        auto q=tkc::weaponRotation(target);
        RE::hkQuaternion native; native.vec=RE::hkVector4(q.x,q.y,q.z,q.w);
        auto& v=native.vec.quad;
        RE::NiQuaternion scene(v.m128_f32[3],v.m128_f32[0],v.m128_f32[1],v.m128_f32[2]);
        auto matrix=scene.ToRotation();
        // The SDK matrix independently transforms the stock mesh's +Y tip/head axis.
        tkc::Vec forward{matrix.entry[0][1],matrix.entry[1][1],matrix.entry[2][1]};
        check(tkc::length(forward-target)<.001f);
    }
}
template<class T> void suspensionHooks(T* missile) {
    using Hook=missile_hold::Hooks<T>;
    static int updates=0,impacts=0,contacts=0;
    updates=impacts=contacts=0;
    Hook::update=reinterpret_cast<std::uintptr_t>(+[](T*,float dt) { check(dt==.25f); ++updates; });
    Hook::impacts=reinterpret_cast<std::uintptr_t>(+[](T*) { ++impacts; return true; });
    Hook::addImpact=reinterpret_cast<std::uintptr_t>(+[](T*,RE::TESObjectREFR*,const RE::NiPoint3&,const RE::NiPoint3&,RE::hkpCollidable*,std::int32_t,std::uint32_t) { ++contacts; });
    missile_hold::clear();
    Hook::updateHook(missile,.25f); check(Hook::impactsHook(missile));
    Hook::addImpactHook(missile,nullptr,{},{},nullptr,0,0);
    check(updates==1 && impacts==1 && contacts==1);
    missile_hold::suspend(missile); missile->GetProjectileRuntimeData().livingTime=20;
    Hook::updateHook(missile,.25f); check(!Hook::impactsHook(missile));
    Hook::addImpactHook(missile,nullptr,{},{},nullptr,0,0);
    check(missile->GetProjectileRuntimeData().livingTime==0 && updates==1 && impacts==1 && contacts==1);
    missile_hold::clear(); check(!missile_hold::matches(missile));
}
void arrowInterfaces(REL::Version version) {
    bool modern=version>=REL::Version{1,6,629,0};
    alignas(RE::ArrowProjectile) std::array<std::byte,0x300> arrowStorage{};
    alignas(RE::TESAmmo) std::array<std::byte,0x200> ammoStorage{};
    alignas(RE::BGSProjectile) std::array<std::byte,sizeof(RE::BGSProjectile)> baseStorage{};
    alignas(RE::TESObjectWEAP) std::array<std::byte,sizeof(RE::TESObjectWEAP)> weaponStorage{};
    auto* arrow=reinterpret_cast<RE::ArrowProjectile*>(arrowStorage.data());
    auto* ammo=reinterpret_cast<RE::TESAmmo*>(ammoStorage.data());
    auto* base=reinterpret_cast<RE::BGSProjectile*>(baseStorage.data());
    auto* weapon=reinterpret_cast<RE::TESObjectWEAP*>(weaponStorage.data());
    // Field-only SDK access; no native object constructors, vtables or engine launch run here.
    arrow->formType=RE::FormType::ProjectileArrow; arrow->formID=0x1234;
    check(arrow->As<RE::MissileProjectile>()==arrow);
    check(reinterpret_cast<std::byte*>(&arrow->GetArrowRuntimeData())==arrowStorage.data()+(modern ? 0x1E8 : 0x1E0));
    auto& data=arrow->GetProjectileRuntimeData();
    data.power=data.scale=1; data.weaponDamage=35; data.linearVelocity={0,4000,0};
    data.ammoSource=ammo; data.weaponSource=weapon;
    base->data.types=RE::BGSProjectileData::Type::kArrow;
    ammo->GetRuntimeData().data.projectile=base;
    for(auto type:{RE::WEAPON_TYPE::kBow,RE::WEAPON_TYPE::kCrossbow}) {
        weapon->weaponData.animationType=type;
        check(tkc::catchableProjectile(arrow,base));
    }
    weapon->weaponData.animationType=RE::WEAPON_TYPE::kStaff;
    check(!tkc::catchableProjectile(arrow,base));
    weapon->weaponData.animationType=RE::WEAPON_TYPE::kBow;
    data.ammoSource=nullptr; check(!tkc::catchableProjectile(arrow,base)); data.ammoSource=ammo;
    data.weaponSource=nullptr; check(!tkc::catchableProjectile(arrow,base)); data.weaponSource=weapon;
    ammo->GetRuntimeData().data.projectile=nullptr;
    check(!tkc::catchableProjectile(arrow,base)); ammo->GetRuntimeData().data.projectile=base;
    for(auto flag:{RE::Projectile::Flags::kDestroyed,RE::Projectile::Flags::kFading,RE::Projectile::Flags::kProcessedImpacts,RE::Projectile::Flags::kHitScan}) {
        data.flags=flag; check(!tkc::catchableProjectile(arrow,base));
    }
    data.flags=RE::Projectile::Flags::kNone;
    for(auto flag:{RE::BGSProjectileData::BGSProjectileFlags::kExplosion,RE::BGSProjectileData::BGSProjectileFlags::kExplosionAltTrigger,
                  RE::BGSProjectileData::BGSProjectileFlags::kContinuousUpdate,RE::BGSProjectileData::BGSProjectileFlags::kHitScan}) {
        base->data.flags=flag; check(!tkc::catchableProjectile(arrow,base));
    }
    base->data.flags=RE::BGSProjectileData::BGSProjectileFlags::kNone;
    arrow->GetMissileRuntimeData().waitingToInitialize3D=true;
    check(!tkc::catchableProjectile(arrow,base)); arrow->GetMissileRuntimeData().waitingToInitialize3D=false;
    for(float damage:{0.f,-1.f,std::numeric_limits<float>::quiet_NaN(),std::numeric_limits<float>::infinity()}) {
        data.weaponDamage=damage; check(!tkc::catchableProjectile(arrow,base));
    }
    data.weaponDamage=35; data.linearVelocity.x=std::numeric_limits<float>::quiet_NaN();
    check(!tkc::catchableProjectile(arrow,base)); data.linearVelocity.x=0;
    data.linearVelocity={}; check(!tkc::catchableProjectile(arrow,base)); data.linearVelocity={0,4000,0};
    check(tkc::catchableProjectile(arrow,base));
    arrow->GetMissileRuntimeData().impactResult=static_cast<RE::ImpactResult>(1);
    check(!tkc::catchableProjectile(arrow,base)); arrow->GetMissileRuntimeData().impactResult=RE::ImpactResult::kNone;
    check(!tkc::catchableProjectile(nullptr,base) && !tkc::catchableProjectile(arrow,nullptr));
    suspensionHooks(arrow);
    suspensionHooks(static_cast<RE::MissileProjectile*>(arrow));

}
void actorInterfaces(REL::Version version, std::size_t valuesOffset, std::size_t magicOffset) {
    check(REL::Module::mock(version));
    arrowInterfaces(version);
    // Only the SDK's pointer-adjustment accessors run; no Actor is constructed,
    // no vtable is dereferenced, and no engine function or Address Library is needed.
    alignas(RE::Actor) std::array<std::byte,0x300> storage{};
    auto* actor=reinterpret_cast<RE::Actor*>(storage.data());
    check(reinterpret_cast<std::byte*>(actor->AsActorValueOwner())==storage.data()+valuesOffset);
    check(reinterpret_cast<std::byte*>(actor->AsMagicTarget())==storage.data()+magicOffset);
    check(reinterpret_cast<std::byte*>(actor->AsActorState())==storage.data()+valuesOffset+8);
    alignas(RE::PlayerCharacter) std::array<std::byte,0x1000> playerStorage{};
    auto* player=reinterpret_cast<RE::PlayerCharacter*>(playerStorage.data());
    std::size_t difficultyOffset=version>=REL::Version{1,7,99,0} ? 0xB08 : version>=REL::Version{1,6,629,0} ? 0xB00 : 0xAF8;
    check(reinterpret_cast<std::byte*>(&player->GetGameStatsData())==playerStorage.data()+difficultyOffset);
    auto* missile=reinterpret_cast<RE::MissileProjectile*>(storage.data());
    bool modern=version>=REL::Version{1,6,629,0};
    check(reinterpret_cast<std::byte*>(&missile->GetProjectileRuntimeData())==storage.data()+(modern ? 0xA0 : 0x98));
    check(reinterpret_cast<std::byte*>(&missile->GetMissileRuntimeData())==storage.data()+(modern ? 0x1E0 : 0x1D8));
}
void propInterfaces() {
    for(auto type:{RE::WEAPON_TYPE::kOneHandSword,RE::WEAPON_TYPE::kOneHandDagger,
                   RE::WEAPON_TYPE::kOneHandAxe,RE::WEAPON_TYPE::kOneHandMace,
                   RE::WEAPON_TYPE::kTwoHandSword,RE::WEAPON_TYPE::kTwoHandAxe}) check(tkc::aimableMeleeType(type));
    for(auto type:{RE::WEAPON_TYPE::kHandToHandMelee,RE::WEAPON_TYPE::kBow,RE::WEAPON_TYPE::kStaff,
                   RE::WEAPON_TYPE::kCrossbow,RE::WEAPON_TYPE::kTotal}) check(!tkc::aimableMeleeType(type));
    using Type=RE::hkpMotion::MotionType;
    using State=tkc::PropMotion;
    alignas(RE::hkpMotion) std::array<std::byte,sizeof(RE::hkpMotion)> storage{};
    auto* motion=reinterpret_cast<RE::hkpMotion*>(storage.data());
    // Inline field-only queries: no vtable, engine conversion, or saved-motion dereference.
    for(auto type:{Type::kDynamic,Type::kSphereInertia,Type::kBoxInertia,Type::kThinBoxInertia}) {
        motion->type=type; motion->inertiaAndMassInv=RE::hkVector4(1,1,1,.2f);
        check(tkc::propMotion(*motion)==State::dynamic); // Zero velocity/sleep does not reject a prop.
        for(float invalid:{0.f,-1.f,std::numeric_limits<float>::quiet_NaN(),std::numeric_limits<float>::infinity()}) {
            motion->inertiaAndMassInv=RE::hkVector4(0,0,0,invalid);
            check(tkc::propMotion(*motion)==State::unavailable);
        }
    }
    for(auto type:{Type::kFixed,Type::kKeyframed}) {
        motion->type=type; motion->inertiaAndMassInv=RE::hkVector4{}; motion->savedMotion=nullptr;
        check(tkc::propMotion(*motion)==State::unavailable);
        motion->savedMotion=reinterpret_cast<RE::hkpMaxSizeMotion*>(std::uintptr_t{1});
        check(tkc::propMotion(*motion)==State::dormant);
        motion->savedMotion=nullptr; motion->inertiaAndMassInv=RE::hkVector4(1,1,1,.2f);
        check(tkc::propMotion(*motion)==State::dormant);
    }
    for(auto type:{Type::kInvalid,Type::kCharacter,Type::kTotal}) {
        motion->type=type;
        check(tkc::propMotion(*motion)==State::unavailable);
    }
    for(auto type:{RE::FormType::Book,RE::FormType::Misc,RE::FormType::Weapon,RE::FormType::Armor,
                  RE::FormType::AlchemyItem,RE::FormType::Ingredient,RE::FormType::Scroll,
                  RE::FormType::Ammo,RE::FormType::SoulGem,RE::FormType::KeyMaster}) check(tkc::carryableType(type));
    for(auto type:{RE::FormType::Static,RE::FormType::Furniture,RE::FormType::Door,RE::FormType::Activator})
        check(!tkc::carryableType(type));
    check(!tkc::carryableType(RE::FormType::Light));
    check(tkc::carryableType(RE::FormType::Light,true));
    check(tkc::previewShader(true,false)==0x5d608 && tkc::previewShader(true,true)==0xd7661);
    check(tkc::previewShader(false,false)==0x146 && tkc::previewShader(false,true)==0xdc209);
}
void dismemberInterfaces() {
    using namespace tkc::dismember;
    struct FakeAPI final : API {
        std::size_t version=apiVersion;
        std::size_t GetVersion() const override { return version; }
        void Dismember(RE::Actor*,const RE::BSFixedString&,RE::Actor*,RE::TESObjectWEAP*,const Params*) const override {}
        bool IsDismembered(RE::Actor*) const override { return false; }
        bool IsDismemberedNode(RE::Actor*,const RE::BSFixedString&) const override { return false; }
        void RefreshActorDismemberedState(RE::Actor*) const override {}
    } fake;
    check(!bind(nullptr) && api==nullptr); check(bind(&fake) && api==&fake);
    fake.version=0x010002; check(bind(&fake) && api==&fake && detectedVersion==0x010002);
    for(std::size_t version:{0x010000,0x010003,0x010100,0x020000}) {
        fake.version=version; check(!bind(&fake) && api==nullptr && detectedVersion==version);
    }
    fake.version=apiVersion; check(bind(&fake));
    Params params;
    check(!params.forceExecution && params.specificNode.empty() && !params.ignoreArmorClass && !params.hitData);
    pending.push_back({{},"NPC Head [Head]",0});
    tick(.016f,false); check(pending.empty()); // Disabled feature never touches engine or API.
    bind(nullptr); pending.push_back({{},"NPC Head [Head]",0});
    tick(.016f,true); check(pending.empty()); // Missing/incompatible API also remains inert.
    check(hitContact(nullptr,{},{1,0,0},{}).node.empty());
    RE::hkTransform transform{};
    transform.rotation.col0={0,1,0,0}; transform.rotation.col1={-1,0,0,0}; transform.rotation.col2={0,0,1,0};
    transform.translation={10,20,30,0};
    auto local=localPoint({8,21,33},transform);
    check(local.x==1 && local.y==2 && local.z==3);
    // Field-only SDK shape and a stub vtable prove local endpoints and the CastRay slot, without engine calls.
    alignas(RE::hkpShape) std::array<std::byte,sizeof(RE::hkpShape)> storage{};
    std::array<std::uintptr_t,9> table{};
    static float fraction=.25f;
    table[8]=reinterpret_cast<std::uintptr_t>(+[](const RE::hkpShape*,const RE::hkpShapeRayCastInput& input,RE::hkpShapeRayCastOutput& output) {
        check(input.from.quad.m128_f32[0]==1 && input.from.quad.m128_f32[1]==2 && input.from.quad.m128_f32[2]==3);
        check(input.to.quad.m128_f32[0]==5 && input.to.quad.m128_f32[1]==2 && input.to.quad.m128_f32[2]==3);
        output.hitFraction=fraction; return true;
    });
    auto* shape=reinterpret_cast<RE::hkpShape*>(storage.data());
    *reinterpret_cast<std::uintptr_t**>(shape)=table.data(); shape->type=RE::hkpShapeType::kCapsule;
    for(float value:{.25f,0.f}) { fraction=value; check(shapeContact(shape,transform,{8,21,33},{8,25,33})==value); }
    for(float value:{1.f,-.1f,std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN()}) {
        fraction=value; check(shapeContact(shape,transform,{8,21,33},{8,25,33})<0);
    }
    check(shapeContact(nullptr,transform,{},{})<0);
    check(shapeContact(shape,transform,{NAN,0,0},{8,25,33})<0);
    check(shapeContact(shape,transform,{8,21,33},{8,21,33})<0);
    for(auto type:{RE::hkpShapeType::kMOPP,RE::hkpShapeType::kList,RE::hkpShapeType::kCompressedMesh,RE::hkpShapeType::kTransform}) {
        shape->type=type; check(shapeContact(shape,transform,{8,21,33},{8,25,33})<0);
    }
}
int main() {
    dismemberInterfaces();
    weaponAxes();
    propInterfaces();
    // No vtable or native material resolver may run: even a valid MOPP ray can lack a material table.
    check(tkc::rayMaterial(nullptr)==RE::MATERIAL_ID::kStone);
    alignas(RE::hkpShape) std::array<std::byte,sizeof(RE::hkpShape)> shapeStorage{};
    alignas(RE::bhkShape) std::array<std::byte,sizeof(RE::bhkShape)> wrapperStorage{};
    auto* shape=reinterpret_cast<RE::hkpShape*>(shapeStorage.data());
    auto* wrapper=reinterpret_cast<RE::bhkShape*>(wrapperStorage.data());
    shape->type=RE::hkpShapeType::kBox;
    check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kStone);
    shape->userData=wrapper; wrapper->materialID=RE::MATERIAL_ID::kMetalSolid;
    check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kMetalSolid);
    wrapper->materialID=RE::MATERIAL_ID::kNone;
    check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kStone);
    shape->userData=reinterpret_cast<RE::bhkShape*>(std::uintptr_t{1});
    for(auto type:{RE::hkpShapeType::kMOPP,RE::hkpShapeType::kBVTree,RE::hkpShapeType::kCompressedMesh,
                  RE::hkpShapeType::kCollection,RE::hkpShapeType::kList,RE::hkpShapeType::kTransform}) {
        shape->type=type;
        check(tkc::rayMaterial(shape)==RE::MATERIAL_ID::kStone);
    }

    RE::bhkPickData pick{};
    tkc::preparePickRay(pick,{1000,-2000,3000},{1500,-1800,2900},.01f);
    auto& from=pick.rayInput.from.quad;
    auto& to=pick.rayInput.to.quad;
    auto& delta=pick.ray.quad;
    check(from.m128_f32[0]==10 && from.m128_f32[1]==-20 && from.m128_f32[2]==30 && from.m128_f32[3]==1);
    check(to.m128_f32[0]==0 && to.m128_f32[1]==0 && to.m128_f32[2]==0 && to.m128_f32[3]==0);
    check(delta.m128_f32[0]==5 && delta.m128_f32[1]==2 && delta.m128_f32[2]==-1 && delta.m128_f32[3]==1);
    check(!pick.rayOutput.HasHit());
    // Moving the origin must preserve the segment displacement (source-body skipping).
    tkc::preparePickRay(pick,{1100,-2000,3000},{1500,-1800,2900},.01f);
    check(pick.ray.quad.m128_f32[0]==4);
    actorInterfaces({1,5,97,0},0xB0,0x98);
    actorInterfaces({1,6,640,0},0xB8,0xA0);
    actorInterfaces({1,6,1170,0},0xB8,0xA0);
    actorInterfaces({1,7,104,0},0xB8,0xA0);
}
