"""Standard-library checks: malformed input, generated forms, release safeguards."""
import sys
from pathlib import Path
import struct
import tempfile
import unittest
import zipfile
import hashlib
import json
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
from companion import sub, subrecords, record, group, records, validate, generate
from package import check_dll, package, ROOT

class Tools(unittest.TestCase):
    def test_roundtrip_and_truncation(self):
        value = b'x'*70000
        self.assertEqual(list(subrecords(sub(b'DNAM',value))), [(b'DNAM',value)])
        for bad in (b'EDID', b'EDID\x02\x00x', b'XXXX\x04\x00\x05\x00\x00\x00'):
            with self.assertRaises(ValueError): list(subrecords(bad))

    def test_group_boundaries(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'test.esp'
            data = group(b'MGEF',[record(b'MGEF',0x1000800,[(b'EDID','test')])])
            path.write_bytes(data)
            self.assertEqual(list(records(path))[0][1],0x1000800)
            path.write_bytes(data[:-1])
            with self.assertRaises(ValueError): list(records(path))

    def test_companion(self):
        path = ROOT/'Data/TelekinesisCombat.esp'
        validate(path)
        forms = {form: fields for tag,form,flags,fields in records(path)}
        self.assertEqual(struct.unpack_from('<I',forms[0x1000802][b'DATA'],64)[0],21)
        for local in (0x803,0x805):
            self.assertEqual(struct.unpack_from('<I',forms[0x1000000+local][b'DATA'],64)[0],1)
        self.assertEqual(struct.unpack_from('<I',forms[0x1000801][b'SPIT'],20)[0],3)
        self.assertNotIn(b'VMAD',forms[0x1000802])

    def test_generator_multiple_effects(self):
        # A spell's final effect can be stagger; identify paralysis by archetype.
        with tempfile.TemporaryDirectory() as tmp:
            master = Path(tmp)/'Skyrim.esm'; output=Path(tmp)/'out.esp'
            def mgef(form, archetype):
                data=bytearray(152); struct.pack_into('<I',data,64,archetype)
                return record(b'MGEF',form,[(b'EDID',str(form)),(b'DATA',bytes(data))])
            def spell(form, name, effects):
                return record(b'SPEL',form,[(b'EDID',name)]+[(b'EFID',struct.pack('<I',e)) for e in effects])
            master.write_bytes(group(b'MGEF',[mgef(1,20),mgef(2,21),mgef(3,33)])+
                               group(b'SPEL',[spell(4,'Telekinesis',[1]),spell(5,'Paralyze',[2,3])]))
            generate(master,output); validate(output)

    def test_release_requires_x64_dll(self):
        with self.assertRaises(ValueError): package()
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'bad.dll'; path.write_bytes(b'not a dll')
            with self.assertRaises(ValueError): check_dll(path)
            data=bytearray(256); data[:2]=b'MZ'; struct.pack_into('<I',data,0x3c,128)
            data[128:132]=b'PE\0\0'; struct.pack_into('<H',data,132,0x14c)
            struct.pack_into('<H',data,150,0x2000); path.write_bytes(data)
            with self.assertRaises(ValueError): check_dll(path)

    def test_source_archive_hashes(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=package(source=True,output=Path(tmp)/'source.zip')
            with zipfile.ZipFile(path) as archive:
                hashes=json.loads(archive.read('SHA256SUMS.json'))
                self.assertIn('TelekinesisCombat/src/main.cpp',hashes)
                for name,expected in hashes.items():
                    self.assertEqual(hashlib.sha256(archive.read(name)).hexdigest(),expected)

if __name__ == '__main__': unittest.main()
