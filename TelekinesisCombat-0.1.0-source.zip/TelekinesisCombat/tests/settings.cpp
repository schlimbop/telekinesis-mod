#include "config.h"
#include <chrono>
#include <cstdlib>
#include <iostream>
void check(bool value) { if(!value) { std::cerr<<"Settings check failed\n"; std::exit(1); } }
int main() {
    namespace fs=std::filesystem;
    auto original=fs::current_path();
    auto root=fs::temp_directory_path()/("tkc-settings-"+std::to_string(GetCurrentProcessId())+"-"+
        std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    check(!fs::exists(root)); fs::create_directories(root/"Data/SKSE/Plugins"); fs::current_path(root);
    Config balanced; Config powerful; powerful.preset(true);
    check(powerful.damageScale>balanced.damageScale && powerful.holdCost<balanced.holdCost);
    check(powerful.throwFraction==balanced.throwFraction && powerful.slamFraction==balanced.slamFraction);
    check(powerful.lethalLevelAdvantage==balanced.lethalLevelAdvantage && powerful.protect==balanced.protect);
    check(powerful.modifierKey==balanced.modifierKey && powerful.settingsKey==balanced.settingsKey);
    powerful.returnMode=1; powerful.grab=30; powerful.modifierKey=29; powerful.modifierKey2=0;
    powerful.settingsKey=67; powerful.preview=false; powerful.profile=true; powerful.xpScale=.5f;
    check(powerful.save()); Config restored; restored.load();
    check(restored.returnMode==1 && restored.grab==30 && restored.modifierKey==29 && restored.modifierKey2==0);
    check(restored.settingsKey==67 && !restored.preview && restored.profile && restored.xpScale==.5f);
    check(restored.damageScale==powerful.damageScale && restored.projectileRadius==powerful.projectileRadius);
    auto path=fs::absolute("Data/SKSE/Plugins/TelekinesisCombat.ini").string();
    check(WritePrivateProfileStringA("Gameplay","ProjectileLookAheadSeconds","999",path.c_str()));
    check(WritePrivateProfileStringA("Gameplay","ProjectileThreatRadius","-10",path.c_str()));
    check(WritePrivateProfileStringA("Physics","ObjectDamageScale","nan",path.c_str()));
    check(WritePrivateProfileStringA("Controls","SettingsKey","29",path.c_str()));
    Config bounded; bounded.load();
    check(bounded.predictionSeconds==.75f && bounded.threatRadius==30 && bounded.damageScale==1);
    check(bounded.settingsKey==68 && bounded.modifierKey==42 && bounded.modifierKey2==54);
    fs::current_path(original); fs::remove_all(root);
}
