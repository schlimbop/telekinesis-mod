#include "config.h"
#include <chrono>
#include <cstdlib>
#include <iostream>
void check(bool value) { if(!value) { std::cerr<<"Settings check failed\n"; std::exit(1); } }
int main() {
    namespace fs=std::filesystem;
    auto original=fs::current_path();
    auto root=fs::temp_directory_path()/("tkc-settings-"+std::to_string(GetCurrentProcessId())+"-"+
        std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    check(!fs::exists(root)); fs::create_directories(root/"Data/SKSE/Plugins"); fs::current_path(root);
    Config balanced; Config powerful; powerful.preset(true);
    check(powerful.damageScale>balanced.damageScale && powerful.holdCost<balanced.holdCost);
    check(powerful.throwFraction==balanced.throwFraction && powerful.slamFraction==balanced.slamFraction);
    check(powerful.lethalLevelAdvantage==balanced.lethalLevelAdvantage && powerful.protect==balanced.protect);
    check(powerful.modifierKey==balanced.modifierKey && powerful.settingsKey==balanced.settingsKey);
    powerful.returnMode=1; powerful.grab=30; powerful.modifierKey=29; powerful.modifierKey2=0;
    powerful.settingsKey=67; powerful.preview=false; powerful.profile=true; powerful.xpScale=.5f;
    check(powerful.save()); Config restored; restored.load();
    check(restored.returnMode==1 && restored.grab==30 && restored.modifierKey==29 && restored.modifierKey2==0);
    check(restored.settingsKey==67 && !restored.preview && restored.profile && restored.xpScale==.5f);
    check(restored.damageScale==powerful.damageScale && restored.projectileRadius==powerful.projectileRadius);
    // Both preset buttons change their documented fields and survive an INI reload.
    for(bool strong:{false,true}) {
        Config selected;
        selected.preset(!strong); // start from the other preset so a no-op would fail
        selected.grab=30; selected.throwFraction=.12f; selected.slamFraction=.22f;
        selected.lethalLevelAdvantage=20; selected.protect=false;
        selected.preset(strong); check(selected.save());
        Config loaded; loaded.load();
        check(loaded.damageScale==(strong ? 1.8f : 1.f));
        check(loaded.damageCap==(strong ? 2000.f : 1200.f));
        check(loaded.grabCost==(strong ? 10.f : 15.f));
        check(loaded.holdCost==(strong ? 7.f : 12.f));
        check(loaded.launchCost==(strong ? 6.f : 10.f));
        check(loaded.executionCost==(strong ? 30.f : 40.f));
        check(loaded.disarmCost==(strong ? 18.f : 25.f));
        check(loaded.projectileCost==(strong ? 10.f : 15.f));
        check(loaded.levelFactor==(strong ? .02f : .04f));
        check(loaded.executionHealth==(strong ? .4f : .35f));
        check(loaded.projectileRadius==(strong ? 550.f : 400.f));
        check(loaded.predictionSeconds==(strong ? .35f : .25f));
        check(loaded.grab==30 && loaded.throwFraction==.12f && loaded.slamFraction==.22f);
        check(loaded.lethalLevelAdvantage==20 && !loaded.protect);
    }
    auto path=fs::absolute("Data/SKSE/Plugins/TelekinesisCombat.ini").string();
    check(WritePrivateProfileStringA("Gameplay","ProjectileLookAheadSeconds","999",path.c_str()));
    check(WritePrivateProfileStringA("Gameplay","ProjectileThreatRadius","-10",path.c_str()));
    check(WritePrivateProfileStringA("Physics","ObjectDamageScale","nan",path.c_str()));
    check(WritePrivateProfileStringA("Controls","SettingsKey","42",path.c_str()));
    Config bounded; bounded.load();
    check(bounded.predictionSeconds==.75f && bounded.threatRadius==30 && bounded.damageScale==1);
    check(bounded.settingsKey==68 && bounded.modifierKey==42 && bounded.modifierKey2==54);
    fs::current_path(original); fs::remove_all(root);
}
