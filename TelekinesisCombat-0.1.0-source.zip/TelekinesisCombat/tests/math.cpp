#include "math.h"
#include <cstdlib>
#include <iostream>
void check(bool value) { if(!value) { std::cerr<<"Check failed\n"; std::exit(1); } }
int main() {
    using namespace tkc;
    check(std::abs(segmentDistance({0,0,0},{100,0,0},{50,20,0})-20)<0.001f);
    check(segmentDistance({0,0,0},{0,0,0},{0,0,10})==10);
    check(segmentDistance({0,0,0},{100,0,0},{150,0,0})==50);
    check(length(limit({3000,4000,0},1000))<1000.01f);
    check(length(unit({0,0,0}))==0);
    check(resistance(1,10,20,.04f)==1);
    check(resistance(2,100,1,.04f)==8);
    check(damage(299,70,1,300,1000)==0);
    check(damage(3000,70,1,300,1000)==630);
    check(damage(10000,70,1,300,1000)==1000);
}
