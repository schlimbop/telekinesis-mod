#include "combat_math.h"
#include "controls.h"
#include "settings_layout.h"
#include "hud_text.h"
#include <cstdlib>
#include <iostream>
void check(bool value) { if(!value) { std::cerr<<"Check failed\n"; std::exit(1); } }
int main() {
    using namespace tkc;
    // All settings remain reachable with <=4 short buttons; navigation never becomes an action.
    using namespace settings;
    MenuRequest requested{3,2};
    check(!requested.ready(true,true));
    check(!requested.ready(true,false)); // callback arrived before old box closed
    check(!requested.ready(false,true)); // another pause menu is still open
    check(requested.page==3 && requested.section==2); // retry retains the exact destination
    check(requested.ready(false,false));
    auto destination=requested; requested.cancel();
    check(destination.page==3 && destination.section==2);
    check(!requested.ready(false,false)); // consumed/cancelled requests never reopen a menu
    requested={0,0}; requested.cancel(); // load/reset cancellation
    check(!requested.ready(false,false));

    check(MenuLayout(0).action(0)==MenuLayout::cancelled);
    check(MenuLayout(1).action(0)==0 && MenuLayout(1).buttonCount==1);
    for(const auto& page:menuPages) {
        std::array<bool,10> seen{};
        MenuLayout start(page.labels.size());
        for(std::size_t group=0;group<start.sections;++group) {
            MenuLayout layout(page.labels.size(),group);
            check(layout.buttonCount<=4);
            check(layout.next()==(group+1)%start.sections);
            check(layout.action(255)==MenuLayout::cancelled);
            check(layout.action(layout.buttonCount)==MenuLayout::cancelled);
            check(layout.action(layout.actions)==MenuLayout::more);
            check(layout.action(layout.buttonCount-1)==static_cast<int>(page.labels.size()-1));
            std::size_t characters=0;
            for(std::size_t button=0;button<layout.buttonCount;++button) {
                auto action=layout.action(button);
                if(action==MenuLayout::more) { characters+=4; continue; }
                check(action>=0 && static_cast<std::size_t>(action)<page.labels.size());
                std::string_view label=page.labels[action];
                check(label.size()<=15); characters+=label.size(); seen[action]=true;
            }
            check(characters<=42);
        }
        for(std::size_t action=0;action<page.labels.size();++action) check(seen[action]);
        check(MenuLayout(page.labels.size(),999).section==start.sections-1);
    }
    MenuLayout lastHome(std::size(homeLabels),4);
    check(lastHome.actions==1 && lastHome.buttonCount==3);
    check(lastHome.action(0)==8 && lastHome.action(1)==MenuLayout::more && lastHome.action(2)==9);
    check(lastHome.next()==0);
    MenuLayout singlePage(3);
    check(singlePage.buttonCount==3 && singlePage.action(2)==2);

    check(resumeOrbitCast(true,true,true,true));
    check(!resumeOrbitCast(true,true,true,false));
    check(!resumeOrbitCast(false,true,true,true));
    check(!resumeOrbitCast(true,false,true,true));
    check(!resumeOrbitCast(true,true,false,true));
    check(!failedCastRelease(false,false)); // promoted orbit item survives a successful shot
    check(failedCastRelease(true,false)); // failed launch releases the whole grip
    check(failedCastRelease(false,true));
    check(orbitLimit==3);
    check(orbitHoldDistance(160)==160);
    check(orbitHoldDistance(0)==140 && orbitHoldDistance(650)==220);
    float orbitDepth=160;
    for(int i=0;i<100;++i) orbitDepth=orbitHoldDistance(orbitDepth+24);
    check(orbitDepth==220);
    orbitDepth=orbitHoldDistance(orbitDepth-24); check(orbitDepth==196); // immediate pull after holding push at the limit
    for(Vec forward:{Vec{0,1,0},Vec{1,0,0},Vec{0,0,1},Vec{0,0,-1},unit(Vec{1,1,1})}) {
        for(float phase:{0.f,.5f,3.f,6.28318530718f}) {
            for(float depth:{80.f,140.f,160.f,220.f,600.f}) {
                for(float requested:{25.f,50.f,60.f,110.f}) {
                    Vec center{};
                    std::array<Vec,orbitLimit> offsets{};
                    float radius=std::min(requested,depth*.28f);
                    for(int slot=0;slot<orbitLimit;++slot) {
                        offsets[slot]=orbitOffset(forward,phase,slot,requested,depth);
                        check(finite(offsets[slot])); check(std::abs(dot(offsets[slot],forward))<.001f);
                        check(length(offsets[slot])/depth<=.28001f); // all centers inside a 15.65-degree cone
                        center=center+offsets[slot]*(1.f/3.f);
                    }
                    check(length(center)<.001f); // ring centered on the exact crosshair, with no upward drift
                    for(int slot=0;slot<orbitLimit;++slot) {
                        check(std::abs(length(offsets[slot])-radius)<.001f);
                        check(std::abs(length(offsets[slot]-offsets[(slot+1)%orbitLimit])-radius*std::sqrt(3.f))<.001f);
                    }
                }
            }
        }
    }
    check(length(orbitOffset({0,1,0},0,0,50,160)-orbitOffset({0,1,0},6.28318530718f,0,50,160))<.001f);
    // Near-player depth in both camera modes; third-person retains the camera-to-player adjustment.
    Vec orbitCamera{0,-400,100}, orbitPlayer{0,0,0}, orbitForward{0,1,0};
    check(itemRayDistance(orbitCamera,orbitForward,orbitPlayer,orbitHoldDistance(650),true)==620);
    check(itemRayDistance(orbitCamera,orbitForward,orbitPlayer,orbitHoldDistance(650),false)==220);
    check(length(orbitOffset(orbitForward,0,0,50,160)-orbitOffset(orbitForward,0,1,50,160))<80);
    Vec shot=crosshairLaunchDirection({110,220,66},{0,0,0},{0,1,0},600);
    check(length(shot-unit(Vec{-110,380,-66}))<.0001f);
    check(segmentDistance({110,220,66},Vec{110,220,66}+shot*1000,{0,600,0})<.001f);
    check(length(crosshairLaunchDirection({0,0,0},{0,0,0},{0,1,0},0))==0);
    check(length(crosshairLaunchDirection({NAN,0,0},{0,0,0},{0,1,0},100))==0);
    // Rotate a forward axis by an angular velocity, independently of the steering calculation.
    auto integrateTurn=[](Vec forward,Vec omega,float dt) {
        float speed=length(omega); if(speed<.00001f) return forward;
        Vec axis=omega*(1.f/speed); float angle=speed*dt;
        return unit(forward*std::cos(angle)+cross(axis,forward)*std::sin(angle)+axis*(dot(axis,forward)*(1-std::cos(angle))));
    };
    // Stock loose melee NIFs point hilt-to-head along +Y, independently of our alignment helpers.
    check(length(weaponForward({0,0,0,1})-Vec{0,1,0})<.001f);
    auto rotateVertex=[](WeaponRotation q,Vec vertex) {
        Vec axis{q.x,q.y,q.z};
        return vertex+cross(axis,vertex)*(2*q.w)+cross(axis,cross(axis,vertex))*2;
    };
    for(Vec target:{Vec{0,0,1},Vec{0,0,-1},Vec{0,1,0},Vec{0,-1,0},Vec{1,0,0},Vec{-1,0,0},unit(Vec{1,-2,3})}) {
        auto q=weaponRotation(target);
        // Iron longsword's measured local hilt/tip Y extents; rotate geometry, not weaponForward.
        Vec tip=rotateVertex(q,{0,64.13797f,0}),hilt=rotateVertex(q,{0,-10.73667f,0});
        check(dot(unit(tip-hilt),target)>.9999f);
        check(length(weaponForward(q)-target)<.001f);
        check(length(weaponForward({q.x*2,q.y*2,q.z*2,q.w*2})-target)<.001f);
        for(float dt:{1.f/30,1.f/60,1.f/144}) {
            for(Vec initial:{Vec{0,0,1},target*-1.f,unit(Vec{1,2,-3})}) {
                Vec facing=initial;
                for(int step=0;step<static_cast<int>(1.5f/dt);++step) {
                    auto omega=weaponTurnVelocity(facing,target,dt);
                    check(finite(omega) && length(omega)<=8.001f);
                    Vec next=integrateTurn(facing,omega,dt);
                    check(dot(next,target)+.00001f>=dot(facing,target));
                    facing=next;
                }
                check(dot(facing,target)>.9999f);
                check(length(weaponTurnVelocity(target,target,dt))==0);
            }
        }
    }
    check(length(weaponForward({0,0,0,0}))==0);
    check(length(weaponForward({NAN,0,0,1}))==0);
    check(length(weaponTurnVelocity({0,0,1},{NAN,0,0},.016f))==0);
    check(length(weaponTurnVelocity({0,0,1},{0,0,0},.016f))==0);
    check(length(weaponTurnVelocity({0,0,1},{0,1,0},0))==0);
    check(length(weaponTurnVelocity({0,0,1},{0,1,0},NAN))==0);
    // All offset weapons face the same close crosshair point as the ring rotates.
    for(int slot=0;slot<orbitLimit;++slot) {
        Vec facing{0,0,1}; float dt=1.f/60;
        for(int step=0;step<240;++step) {
            Vec body=Vec{0,160,0}+orbitOffset({0,1,0},step*dt*.45f,slot,50,160);
            Vec target=unit(Vec{0,600,0}-body);
            facing=integrateTurn(facing,weaponTurnVelocity(facing,target,dt),dt);
            if(step>120) check(dot(facing,target)>.999f);
        }
    }
    check(impactFeedbackStrength(3600,10)>impactFeedbackStrength(900,10));
    check(impactFeedbackStrength(3600,40)>impactFeedbackStrength(3600,1));
    check(impactFeedbackStrength(99999,99999)<=1.5f);
    check(impactFeedbackStrength(-1,10)==0);
    check(impactFeedbackStrength(NAN,10)==0);
    check(impactCameraStrength(1.5f,0)<=.14f);
    check(impactCameraStrength(1.5f,1000)==0);
    check(impactCameraStrength(1.5f,500)<impactCameraStrength(1.5f,0));
    check(castAction(true,false,false,false,true)==CastAction::grab);
    check(!shiftSlam(true,true,false,true)); // Shift-cast does not auto-slam the new grip
    check(shiftSlam(true,true,false,false)); check(shiftSlam(true,false,true,false));
    check(shiftSlam(true,true,true,false)); // either Shift key can arm an existing grip
    check(!shiftSlam(false,true,true,false)); check(!shiftSlam(true,false,false,false));
    check(nearbyScore({0,0,80},{0,0,0},300)==80); // floor item
    check(nearbyScore({0,0,0},{-300,0,0},300)==300); // behind player, boundary included
    check(nearbyScore({0,0,0},{301,0,0},300)<0);
    check(nearbyScore({0,0,0},{100,0,0},300)<nearbyScore({0,0,0},{200,0,0},300));

    // Incoming/outgoing/stationary missiles and radius limits; returning angles use Skyrim's +Y forward axis.
    for(Vec direction:{Vec{0,1,0},Vec{1,0,0},Vec{0,-1,0},Vec{-1,0,0},Vec{0,1,1},Vec{1,0,-1}}) {
        auto angles=missileAngles(direction);
        Vec restored{std::sin(angles.z)*std::cos(angles.x),std::cos(angles.z)*std::cos(angles.x),-std::sin(angles.x)};
        check(length(restored-unit(direction))<.0001f);
    }
    check(castAction(false,true,true,true,true)==CastAction::release);
    check(castAction(false,true,true,true,false)==CastAction::release);
    check(castAction(false,false,true,true,true)==CastAction::none);
    check(castAction(true,false,true,false,true)==CastAction::charge);
    check(castAction(false,true,true,false,true)==CastAction::cancelCharge);
    check(castAction(true,false,false,false,false)==CastAction::none);
    check(std::abs(segmentDistance({0,0,0},{100,0,0},{50,20,0})-20)<0.001f);
    check(segmentDistance({0,0,0},{0,0,0},{0,0,10})==10);
    check(segmentDistance({0,0,0},{100,0,0},{150,0,0})==50);
    check(length(limit({3000,4000,0},1000))<1000.01f);
    check(length(unit({0,0,0}))==0);
    check(resistance(1,10,20,.04f)==1);
    check(resistance(2,100,1,.04f)==8);
    check(aimScore({0,0,0},{1,0,0},{3500,35,0},16,4000)>=0);
    check(aimScore({0,0,0},{1,0,0},{3500,600,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{-100,0,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{4100,0,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{5500,200,0},8,6000,3)>=0);
    check(aimScore({0,0,0},{1,0,0},{5500,200,0},8,6000,1)<0);
    check(weakened(35,100,.35f)); check(!weakened(36,100,.35f));
    check(weakened(60,200,.35f)); // temporary health buffs belong in maximum
    check(!weakened(0,100,.35f)); check(!weakened(1,0,.35f));
    check(std::abs(boxHit({-100,0,20},{100,0,20},{-40,-20,0},{40,20,45},0)-.3f)<.001f); // low wolf
    check(boxHit({-100,0,80},{100,0,80},{-40,-20,0},{40,20,45},0)<0);
    check(boxHit({0,0,20},{0,0,20},{-40,-20,0},{40,20,45},0)==0);
    check(boxHit({100,0,20},{-100,0,20},{-40,-20,0},{40,20,45},0)>=0);
    check(boxHit({-100,30,20},{100,30,20},{-40,-20,0},{40,20,45},12)>=0);
    // Similar-level healthy actors survive even fast impacts; a ten-level advantage or long fall can kill.
    check(actorImpactDamage(100,100,20,20,1600,1600,.20f,.45f,10,false)==20);
    check(std::abs(actorImpactDamage(100,100,20,20,1400,1400,.30f,.45f,10,false)-30)<.001f);
    check(actorImpactDamage(100,100,29,20,1600,1600,.20f,.45f,10,false)<100);
    check(actorImpactDamage(100,100,30,20,1600,1600,.20f,.45f,10,false)>100);
    check(actorImpactDamage(100,100,10,30,1600,1600,.20f,.45f,10,false)<20);
    check(actorImpactDamage(100,100,20,20,9000,1600,.20f,.45f,10,false)<=45.01f);
    check(actorImpactDamage(100,100,20,20,900,1600,.20f,.45f,10,true)>100);
    check(actorImpactDamage(0,100,20,20,1600,1600,.20f,.45f,10,false)==0);
    check(actorImpactDamage(5,100,20,20,1400,1400,.30f,.45f,10,false,true)==4); // nonlethal slam still disarms
    check(actorImpactDamage(1,100,20,20,1400,1400,.30f,.45f,10,false,true)==0);
    check(actorImpactDamage(5,100,30,20,1400,1400,.30f,.45f,10,false,true)>5);
    check(actorImpactDamage(100,100,20,20,1400,1400,.30f,.45f,10,true,true)<100); // slam is not a cliff execution

    check(!lethalFall(1000,300,-1000,800,450));
    check(lethalFall(1000,200,-1000,800,450));
    check(!lethalFall(1000,200,1000,800,450));
    check(!lethalFall(1000,200,-200,800,450));
    // Source-body skipping must finish with a clear ray when the cursor passes its endpoint.
    check(rayHasRemaining({0,0,0},{60,0,0},{1,0,0}));
    check(!rayHasRemaining({64,0,0},{60,0,0},{1,0,0}));
    check(!rayHasRemaining({60,0,0},{60,0,0},{1,0,0}));
    check(!rayHasRemaining({-64,0,0},{-60,0,0},{-1,0,0}));
    // A thin sword crosses an NPC in one low-FPS update; its blade tip can hit before its COM.
    check(movingBoxHit({-200,0,70},{200,0,70},{-20,-20,0},{20,20,130},{3,3,50},0,{})>=0);
    check(boxHit({-200,0,150},{-70,0,150},{-20,-20,0},{20,20,130},0)<0);
    check(movingBoxHit({-200,0,150},{-70,0,150},{-20,-20,0},{20,20,130},{60,3,30},0,{})>=0);
    // Actor crosses the projectile between frames; neither static endpoint box would catch it.
    check(boxHit({-100,0,70},{100,0,70},{-10,90,0},{10,110,130},0)<0);
    check(movingBoxHit({-100,0,70},{100,0,70},{-10,90,0},{10,110,130},{},0,{0,200,0})>=0);
    check(movingBoxHit({-100,0,200},{100,0,200},{-10,90,0},{10,110,130},{},0,{0,200,0})<0);
    check(!confirmedImpact(false,false,false,true)); // incidental slowdown must not retire a sword
    check(confirmedImpact(false,false,true,true)); // preserve actor landing rules
    check(confirmedImpact(true,false,false,false)); check(confirmedImpact(false,true,false,false));
    // First-person uses actual camera height/pitch; third-person still stays on that same ray.
    Vec eye{0,0,130},look{0,1,0},player{0,0,0};
    float d=itemRayDistance(eye,look,player,160,false);
    check(d==160); check(length((eye+look*d)-Vec{0,160,130})<.001f);
    Vec thirdCamera{30,-400,180};
    d=itemRayDistance(thirdCamera,look,player,160,true);
    check(d==560); check(length((thirdCamera+look*d)-Vec{30,160,180})<.001f);
    Vec pitched=unit({0,1,.5f});
    d=itemRayDistance(eye,pitched,player,160,false);
    Vec point=eye+pitched*d;
    check(point.z>eye.z && std::abs(length(point-eye)-160)<.001f);
    Vec down=unit({0,1,-.5f});
    d=itemRayDistance(eye,down,player,160,false);
    check(d==160); // looking down must not add the depth to the player's feet
    check(itemRayDistance({0,400,130},look,player,160,true)==160);
    // A far pickup pulls in without teleporting; a rapid camera turn remains bounded.
    Vec anchor{3500,0,0},body=anchor;
    for(int i=0;i<240;++i) {
        Vec goal=i<120 ? Vec{300,0,0} : Vec{0,300,0};
        auto previous=anchor; anchor=advanceAnchor(anchor,goal,2500,.016f);
        check(length(anchor-previous)<=40.01f);
        auto speed=holdVelocity(previous,anchor,body,.016f,8,2500);
        check(finite(speed) && length(speed)<=2500.01f);
        body=body+speed*.016f;
    }
    check(length(body-Vec{0,300,0})<1);
    check(length(advanceAnchor(anchor,{999,999,999},2500,0)-anchor)==0);
    anchor={6000,0,0}; body=anchor;
    for(int i=0;i<75;++i) {
        auto before=anchor;
        float cap=length(body)>500 ? 10000.f : 4500.f;
        anchor=advanceAnchor(anchor,{300,0,0},cap,.016f);
        auto speed=holdVelocity(before,anchor,body,.016f,10,cap);
        check(finite(speed) && length(speed)<=cap+.01f);
        body=body+speed*.016f;
    }
    check(length(body-Vec{300,0,0})<4); // 6000-unit retrieval settles within 1.2 seconds

    // Prediction rejects near misses and favors the earliest threat, admitting a fast crossing next poll.
    float imminent=predictedMissileScore({0,0,0},{0,300,0},{0,-1500,0},400,.25f,110);
    check(std::abs(imminent-.2f)<.0001f);
    check(predictedMissileScore({0,0,0},{150,300,0},{0,-1500,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{0,1500,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{INFINITY,0,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{0,-500,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,450,0},{0,-6000,0},400,.25f,110)>0);
    check(predictedMissileScore({0,0,0},{0,900,0},{0,-6000,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,150,0},{0,-1500,0},400,.25f,110)<imminent);
    // Archetype, base damage, speed and bounded weight each matter independently.
    auto hit=[](float speed,float mass,float base,WeaponStyle style) {
        return combatObjectDamage(speed,mass,base,style,1.2f,12,1,450,1200,80);
    };
    float dagger=hit(3600,5,5,WeaponStyle::dagger),sword=hit(3600,10,10,WeaponStyle::blade);
    float hammer=hit(3600,25,25,WeaponStyle::blunt);
    check(dagger>120 && dagger<150); check(sword>270 && sword<280); check(hammer>sword);
    check(hit(1800,10,10,WeaponStyle::blade)<sword); check(hit(449,40,100,WeaponStyle::blunt)==0);
    check(hit(3600,10,20,WeaponStyle::blade)>sword);
    check(hit(3600,100000,100,WeaponStyle::blunt)==1200);
    check(hit(INFINITY,5,5,WeaponStyle::dagger)==0);
    check(combatObjectDamage(3600,5,0,WeaponStyle::clutter,1.2f,12,0,450,1200,25)==0);
    check(std::abs(mitigateObjectDamage(100,300,.0012f,.8f,0,1,.12f)-52)<.001f);
    check(std::abs(mitigateObjectDamage(100,10000,.0012f,.8f,0,1)-20)<.001f);
    check(mitigateObjectDamage(100,300,.0012f,.8f,penetration(WeaponStyle::blunt),1)>
          mitigateObjectDamage(100,300,.0012f,.8f,penetration(WeaponStyle::blade),1));
    check(mitigateObjectDamage(100,0,.0012f,.8f,0,.25f)==25);
    check(mitigateObjectDamage(100,-100,.0012f,.8f,0,1)==100);
    check(enchantmentCost(40,25)==30); check(enchantmentCost(40,200)==0); check(enchantmentCost(40,-10)==40);
    float budget=10; check(budgetedXP(8,budget)==8 && budget==2);
    check(budgetedXP(8,budget)==2 && budget==0); check(budgetedXP(1,budget)==0);
    budget=1; check(budgetedXP(-4,budget)==0 && budget==1);

    // Small nearby props tolerate a slightly missed crosshair, but far targeting stays bounded.
    check(aimScore({}, {0,1,0},{42,100,0},5,6000)>0);
    check(aimScore({}, {0,1,0},{250,5500,0},5,6000)<0);
    check(keepAimTarget(.5f,.4f,.48f,0)); // no flicker between similarly aimed props
    check(!keepAimTarget(.5f,.4f,.1f,0)); // a clearly better target preempts it
    check(keepAimTarget(-1,.9f,INFINITY,.23f));
    check(!keepAimTarget(-1,.9f,INFINITY,.25f));
    check(!keepAimTarget(-1,-1,INFINITY,.01f)); // camera has moved too far
    check(!keepAimTarget(-1,.9f,.7f,.01f)); // grace never hides a new eligible target
    for(float dt:{1.f/30,1.f/60,1.f/144,.05f}) {
        Vec body{0,160,0},a=body;
        float peak=0;
        for(int frame=0;frame<static_cast<int>(1.5f/dt);++frame) {
            float angle=std::min(1.5707963f,frame*dt*15.707963f);
            Vec goal{std::sin(angle)*160,std::cos(angle)*160,0};
            Vec previous=a; a=gripAnchor(a,goal,4500,dt,false);
            Vec speed=holdVelocity(previous,a,body,dt,10,4500);
            peak=std::max(peak,length(speed)); body=body+speed*dt;
            check(finite(body) && length(body)<240);
        }
        check(peak<2500 && length(body-Vec{160,0,0})<.1f);
        check(length(gripAnchor({}, {160,0,0},4500,dt,false))<160);
    }
    { Vec far{6000,0,0},body=far;
    for(int i=0;i<75;++i) {
        Vec previous=far;
        far=gripAnchor(far,{160,0,0},10000,.016f,length(body-Vec{160,0,0})>200);
        body=body+holdVelocity(previous,far,body,.016f,10,10000)*.016f;
    }
    check(length(body-Vec{160,0,0})<4); } // smooth settling retains fast retrieval
    check(std::abs(orbitSpacing(20,30,25,160)-(58.f/1.73205080757f))<.001f);
    check(orbitSpacing(40,50,50,220)>50);
    check(orbitSpacing(60,60,50,220)<0); // skip oversized extras instead of widening off screen
    check(orbitSpacing(20,30,50,140)<=140*.28f);
    check(survivorReaction(0,100,3600,40,true)==0);
    check(survivorReaction(10,0,3600,40,true)==0);
    check(survivorReaction(10,100,NAN,40,true)==0);
    check(survivorReaction(10,100,900,5,false)<survivorReaction(10,100,3600,5,false));
    check(survivorReaction(30,100,3600,20,true)>=.85f);
    check(survivorReaction(5,500,3600,10,false)<.85f);
    check(finisherProgress(.25f,1)==.25f && finisherProgress(2,1)==1);
    check(finisherProgress(-1,1)==0 && finisherProgress(1,0)==0 && finisherProgress(NAN,1)==0);
    for(auto size:{Vec{1280,720,0},Vec{1920,1080,0},Vec{3440,1440,0},Vec{800,600,0}}) {
        auto layout=hudLayout(-100,20,size.x,size.y);
        check(layout.x>=-100+size.x*.5f && layout.x+layout.width<size.x-100);
        check(layout.y>20 && layout.y+layout.height<20+size.y*.1f);
        check(layout.font>=10 && layout.font<=16);
        check(layout.height<30 && layout.width<=layout.font*25);
    }
    EquipHint hint;
    check(!hint.update(false,true,.016f));
    check(!hint.update(true,false,5)); // Equipping in the magic menu waits for gameplay.
    check(hint.update(true,true,0));
    check(hint.update(true,true,1));
    check(!hint.update(true,true,1));
    for(int i=0;i<1000;++i) check(!hint.update(true,true,.05f)); // No refresh while still equipped.
    check(!hint.update(false,true,.01f));
    check(hint.update(true,true,.01f)); // Genuine re-equip shows one new hint.
    check(!hint.update(true,false,1)); // Pause/dialogue hides without re-arming it.
    check(hint.update(true,true,1));
    check(!hint.update(true,true,1));
    check(!hint.update(false,true,0));
    check(hint.update(true,true,0));
    check(!hint.update(false,true,0)); // Unequipping dismisses immediately.
    check(hint.update(true,true,0));
    check(hint.update(true,true,NAN) && hint.remaining==2);
    check(hint.update(true,true,-1) && hint.remaining==2);
    check(!hint.update(true,true,3));
    check(!hint.update(true,true,0));
    for(float step:{1.f/30,1.f/60,1.f/144,.05f}) {
        EquipHint timed;
        check(timed.update(true,true,0));
        for(float age=0;age<2.1f;age+=step) timed.update(true,true,step);
        check(!timed.update(true,true,0));
    }
    // Deflections preserve the reflection direction but lose speed/energy; direct hits stop.
    Vec shallow{3000,-500,0}, normal{0,1,0};
    auto reflected=glanceVelocity(shallow,normal);
    check(reflected.x>0 && reflected.y>0);
    check(std::abs(length(reflected)-length(shallow)*.55f)<.01f);
    check(dot(reflected,normal)>0 && length(reflected)<length(shallow));
    check(length(glanceVelocity({0,-3000,0},normal))==0);
    check(length(glanceVelocity({3000,500,0},normal))==0);
    check(length(glanceVelocity({3000,-1,0},normal))==0); // Avoid near-tangent chatter.
    check(length(glanceVelocity(shallow,{}))==0);
    check(length(glanceVelocity({NAN,1,0},normal))==0);
    check(length(glanceVelocity(shallow,{INFINITY,0,0}))==0);
    check(contactProbeReach({10,100,20},{0,1,0})==106);
    check(contactProbeReach({10,100,20},{1,0,0})==16);
    check(contactProbeReach({1000,1000,1000},{1,1,1})==160);
    check(contactProbeReach({},{0,1,0})==6);
    check(contactProbeReach({10,100,20},{})==0);
    check(contactProbeReach({NAN,100,20},{1,0,0})==0);
    check(contactVelocityChanged(shallow,{3000,0,0}));
    check(contactVelocityChanged({0,3600,0},{}));
    check(!contactVelocityChanged({0,3600,0},{0,3600,-50})); // Ordinary gravity is not a contact.
    check(!contactVelocityChanged({},{0,100,0}));
    check(!contactVelocityChanged({NAN,0,0},{}));
    check(fallbackImpactSet(WeaponStyle::blade,false)==0x13cac);
    check(fallbackImpactSet(WeaponStyle::dagger,false)==0x13cac);
    check(fallbackImpactSet(WeaponStyle::blade,true)==0x949d5);
    check(fallbackImpactSet(WeaponStyle::blunt,false)==0x193b7);
    check(fallbackImpactSet(WeaponStyle::clutter,false)==0x193b7);
    check(fallbackImpactSet(WeaponStyle::blunt,true)==0xe4cb0);
    check(recallReach({10,0,0},{1010,0,0},1000));
    check(!recallReach({10,0,0},{1011,0,0},1000));
    check(!recallReach({NAN,0,0},{},1000) && !recallReach({}, {INFINITY,0,0},1000));
    check(!recallReach({}, {},0) && !recallReach({}, {},NAN));
    check(recallAction(true,true,true,false));
    check(!recallAction(false,true,true,false));
    check(!recallAction(true,false,true,false));
    check(!recallAction(true,true,false,false));
    check(!recallAction(true,true,true,true));
    check(projectileSpeedRatio(2000,4000)==2);
    check(projectileSpeedRatio(4000,2000)==.5f); // Native power/weapon speed multipliers are included.
    check(projectileSpeedRatio(0,4000)==0 && projectileSpeedRatio(2000,0)==0);
    check(projectileSpeedRatio(NAN,4000)==0 && projectileSpeedRatio(2000,INFINITY)==0);

}
