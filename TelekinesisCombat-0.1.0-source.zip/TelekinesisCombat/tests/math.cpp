#include "combat_math.h"
#include "controls.h"
#include "settings_layout.h"
#include <cstdlib>
#include <iostream>
void check(bool value) { if(!value) { std::cerr<<"Check failed\n"; std::exit(1); } }
int main() {
    using namespace tkc;
    // All settings remain reachable with <=4 short buttons; navigation never becomes an action.
    using namespace settings;
    MenuRequest requested{3,2};
    check(!requested.ready(true,true));
    check(!requested.ready(true,false)); // callback arrived before old box closed
    check(!requested.ready(false,true)); // another pause menu is still open
    check(requested.page==3 && requested.section==2); // retry retains the exact destination
    check(requested.ready(false,false));
    auto destination=requested; requested.cancel();
    check(destination.page==3 && destination.section==2);
    check(!requested.ready(false,false)); // consumed/cancelled requests never reopen a menu
    requested={0,0}; requested.cancel(); // load/reset cancellation
    check(!requested.ready(false,false));

    check(MenuLayout(0).action(0)==MenuLayout::cancelled);
    check(MenuLayout(1).action(0)==0 && MenuLayout(1).buttonCount==1);
    for(const auto& page:menuPages) {
        std::array<bool,10> seen{};
        MenuLayout start(page.labels.size());
        for(std::size_t group=0;group<start.sections;++group) {
            MenuLayout layout(page.labels.size(),group);
            check(layout.buttonCount<=4);
            check(layout.next()==(group+1)%start.sections);
            check(layout.action(255)==MenuLayout::cancelled);
            check(layout.action(layout.buttonCount)==MenuLayout::cancelled);
            check(layout.action(layout.actions)==MenuLayout::more);
            check(layout.action(layout.buttonCount-1)==static_cast<int>(page.labels.size()-1));
            std::size_t characters=0;
            for(std::size_t button=0;button<layout.buttonCount;++button) {
                auto action=layout.action(button);
                if(action==MenuLayout::more) { characters+=4; continue; }
                check(action>=0 && static_cast<std::size_t>(action)<page.labels.size());
                std::string_view label=page.labels[action];
                check(label.size()<=15); characters+=label.size(); seen[action]=true;
            }
            check(characters<=42);
        }
        for(std::size_t action=0;action<page.labels.size();++action) check(seen[action]);
        check(MenuLayout(page.labels.size(),999).section==start.sections-1);
    }
    MenuLayout lastHome(std::size(homeLabels),4);
    check(lastHome.actions==1 && lastHome.buttonCount==3);
    check(lastHome.action(0)==8 && lastHome.action(1)==MenuLayout::more && lastHome.action(2)==9);
    check(lastHome.next()==0);
    MenuLayout singlePage(3);
    check(singlePage.buttonCount==3 && singlePage.action(2)==2);

    check(resumeOrbitCast(true,true,true,true));
    check(!resumeOrbitCast(true,true,true,false));
    check(!resumeOrbitCast(false,true,true,true));
    check(!resumeOrbitCast(true,false,true,true));
    check(!resumeOrbitCast(true,true,false,true));
    check(!failedCastRelease(false,false)); // promoted orbit item survives a successful shot
    check(failedCastRelease(true,false)); // failed launch releases the whole grip
    check(failedCastRelease(false,true));
    check(orbitLimit==3);
    for(Vec forward:{Vec{0,1,0},Vec{1,0,0},Vec{0,0,1},Vec{0,0,-1},unit(Vec{1,1,1})}) {
        for(float phase:{0.f,.5f,3.f,6.28318530718f}) {
            Vec center{};
            std::array<Vec,orbitLimit> offsets{};
            for(int slot=0;slot<orbitLimit;++slot) {
                offsets[slot]=orbitOffset(forward,phase,slot,110.f);
                check(finite(offsets[slot])); check(std::abs(dot(offsets[slot],forward))<.001f);
                center=center+offsets[slot]*(1.f/3.f);
            }
            for(int slot=0;slot<orbitLimit;++slot) {
                check(std::abs(length(offsets[slot]-center)-110.f)<.001f);
                check(length(offsets[slot]-offsets[(slot+1)%orbitLimit])>190.f);
            }
        }
    }
    check(length(orbitOffset({0,1,0},0,0,110)-orbitOffset({0,1,0},6.28318530718f,0,110))<.001f);
    Vec shot=crosshairLaunchDirection({110,220,66},{0,0,0},{0,1,0},600);
    check(length(shot-unit(Vec{-110,380,-66}))<.0001f);
    check(segmentDistance({110,220,66},Vec{110,220,66}+shot*1000,{0,600,0})<.001f);
    check(length(crosshairLaunchDirection({0,0,0},{0,0,0},{0,1,0},0))==0);
    check(length(crosshairLaunchDirection({NAN,0,0},{0,0,0},{0,1,0},100))==0);
    check(impactFeedbackStrength(3600,10)>impactFeedbackStrength(900,10));
    check(impactFeedbackStrength(3600,40)>impactFeedbackStrength(3600,1));
    check(impactFeedbackStrength(99999,99999)<=1.5f);
    check(impactFeedbackStrength(-1,10)==0);
    check(impactFeedbackStrength(NAN,10)==0);
    check(impactCameraStrength(1.5f,0)<=.14f);
    check(impactCameraStrength(1.5f,1000)==0);
    check(impactCameraStrength(1.5f,500)<impactCameraStrength(1.5f,0));
    check(castAction(true,false,false,false,true)==CastAction::grab);
    check(!shiftSlam(true,true,false,true)); // Shift-cast does not auto-slam the new grip
    check(shiftSlam(true,true,false,false)); check(shiftSlam(true,false,true,false));
    check(shiftSlam(true,true,true,false)); // either Shift key can arm an existing grip
    check(!shiftSlam(false,true,true,false)); check(!shiftSlam(true,false,false,false));
    check(nearbyScore({0,0,80},{0,0,0},300)==80); // floor item
    check(nearbyScore({0,0,0},{-300,0,0},300)==300); // behind player, boundary included
    check(nearbyScore({0,0,0},{301,0,0},300)<0);
    check(nearbyScore({0,0,0},{100,0,0},300)<nearbyScore({0,0,0},{200,0,0},300));

    // Incoming/outgoing/stationary missiles and radius limits; returning angles use Skyrim's +Y forward axis.
    for(Vec direction:{Vec{0,1,0},Vec{1,0,0},Vec{0,-1,0},Vec{-1,0,0},Vec{0,1,1},Vec{1,0,-1}}) {
        auto angles=missileAngles(direction);
        Vec restored{std::sin(angles.z)*std::cos(angles.x),std::cos(angles.z)*std::cos(angles.x),-std::sin(angles.x)};
        check(length(restored-unit(direction))<.0001f);
    }
    check(castAction(false,true,true,true,true)==CastAction::release);
    check(castAction(false,true,true,true,false)==CastAction::release);
    check(castAction(false,false,true,true,true)==CastAction::none);
    check(castAction(true,false,true,false,true)==CastAction::charge);
    check(castAction(false,true,true,false,true)==CastAction::cancelCharge);
    check(castAction(true,false,false,false,false)==CastAction::none);
    check(std::abs(segmentDistance({0,0,0},{100,0,0},{50,20,0})-20)<0.001f);
    check(segmentDistance({0,0,0},{0,0,0},{0,0,10})==10);
    check(segmentDistance({0,0,0},{100,0,0},{150,0,0})==50);
    check(length(limit({3000,4000,0},1000))<1000.01f);
    check(length(unit({0,0,0}))==0);
    check(resistance(1,10,20,.04f)==1);
    check(resistance(2,100,1,.04f)==8);
    check(aimScore({0,0,0},{1,0,0},{3500,35,0},16,4000)>=0);
    check(aimScore({0,0,0},{1,0,0},{3500,600,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{-100,0,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{4100,0,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{5500,200,0},8,6000,3)>=0);
    check(aimScore({0,0,0},{1,0,0},{5500,200,0},8,6000,1)<0);
    check(weakened(35,100,.35f)); check(!weakened(36,100,.35f));
    check(weakened(60,200,.35f)); // temporary health buffs belong in maximum
    check(!weakened(0,100,.35f)); check(!weakened(1,0,.35f));
    check(std::abs(boxHit({-100,0,20},{100,0,20},{-40,-20,0},{40,20,45},0)-.3f)<.001f); // low wolf
    check(boxHit({-100,0,80},{100,0,80},{-40,-20,0},{40,20,45},0)<0);
    check(boxHit({0,0,20},{0,0,20},{-40,-20,0},{40,20,45},0)==0);
    check(boxHit({100,0,20},{-100,0,20},{-40,-20,0},{40,20,45},0)>=0);
    check(boxHit({-100,30,20},{100,30,20},{-40,-20,0},{40,20,45},12)>=0);
    // Similar-level healthy actors survive even fast impacts; a ten-level advantage or long fall can kill.
    check(actorImpactDamage(100,100,20,20,1600,1600,.20f,.45f,10,false)==20);
    check(std::abs(actorImpactDamage(100,100,20,20,1400,1400,.30f,.45f,10,false)-30)<.001f);
    check(actorImpactDamage(100,100,29,20,1600,1600,.20f,.45f,10,false)<100);
    check(actorImpactDamage(100,100,30,20,1600,1600,.20f,.45f,10,false)>100);
    check(actorImpactDamage(100,100,10,30,1600,1600,.20f,.45f,10,false)<20);
    check(actorImpactDamage(100,100,20,20,9000,1600,.20f,.45f,10,false)<=45.01f);
    check(actorImpactDamage(100,100,20,20,900,1600,.20f,.45f,10,true)>100);
    check(actorImpactDamage(0,100,20,20,1600,1600,.20f,.45f,10,false)==0);
    check(actorImpactDamage(5,100,20,20,1400,1400,.30f,.45f,10,false,true)==4); // nonlethal slam still disarms
    check(actorImpactDamage(1,100,20,20,1400,1400,.30f,.45f,10,false,true)==0);
    check(actorImpactDamage(5,100,30,20,1400,1400,.30f,.45f,10,false,true)>5);
    check(actorImpactDamage(100,100,20,20,1400,1400,.30f,.45f,10,true,true)<100); // slam is not a cliff execution

    check(!lethalFall(1000,300,-1000,800,450));
    check(lethalFall(1000,200,-1000,800,450));
    check(!lethalFall(1000,200,1000,800,450));
    check(!lethalFall(1000,200,-200,800,450));
    // Source-body skipping must finish with a clear ray when the cursor passes its endpoint.
    check(rayHasRemaining({0,0,0},{60,0,0},{1,0,0}));
    check(!rayHasRemaining({64,0,0},{60,0,0},{1,0,0}));
    check(!rayHasRemaining({60,0,0},{60,0,0},{1,0,0}));
    check(!rayHasRemaining({-64,0,0},{-60,0,0},{-1,0,0}));
    // A thin sword crosses an NPC in one low-FPS update; its blade tip can hit before its COM.
    check(movingBoxHit({-200,0,70},{200,0,70},{-20,-20,0},{20,20,130},{3,3,50},0,{})>=0);
    check(boxHit({-200,0,150},{-70,0,150},{-20,-20,0},{20,20,130},0)<0);
    check(movingBoxHit({-200,0,150},{-70,0,150},{-20,-20,0},{20,20,130},{60,3,30},0,{})>=0);
    // Actor crosses the projectile between frames; neither static endpoint box would catch it.
    check(boxHit({-100,0,70},{100,0,70},{-10,90,0},{10,110,130},0)<0);
    check(movingBoxHit({-100,0,70},{100,0,70},{-10,90,0},{10,110,130},{},0,{0,200,0})>=0);
    check(movingBoxHit({-100,0,200},{100,0,200},{-10,90,0},{10,110,130},{},0,{0,200,0})<0);
    check(!confirmedImpact(false,false,false,true)); // incidental slowdown must not retire a sword
    check(confirmedImpact(false,false,true,true)); // preserve actor landing rules
    check(confirmedImpact(true,false,false,false)); check(confirmedImpact(false,true,false,false));
    // First-person uses actual camera height/pitch; third-person still stays on that same ray.
    Vec eye{0,0,130},look{0,1,0},player{0,0,0};
    float d=itemRayDistance(eye,look,player,160,false);
    check(d==160); check(length((eye+look*d)-Vec{0,160,130})<.001f);
    Vec thirdCamera{30,-400,180};
    d=itemRayDistance(thirdCamera,look,player,160,true);
    check(d==560); check(length((thirdCamera+look*d)-Vec{30,160,180})<.001f);
    Vec pitched=unit({0,1,.5f});
    d=itemRayDistance(eye,pitched,player,160,false);
    Vec point=eye+pitched*d;
    check(point.z>eye.z && std::abs(length(point-eye)-160)<.001f);
    Vec down=unit({0,1,-.5f});
    d=itemRayDistance(eye,down,player,160,false);
    check(d==160); // looking down must not add the depth to the player's feet
    check(itemRayDistance({0,400,130},look,player,160,true)==160);
    // A far pickup pulls in without teleporting; a rapid camera turn remains bounded.
    Vec anchor{3500,0,0},body=anchor;
    for(int i=0;i<240;++i) {
        Vec goal=i<120 ? Vec{300,0,0} : Vec{0,300,0};
        auto previous=anchor; anchor=advanceAnchor(anchor,goal,2500,.016f);
        check(length(anchor-previous)<=40.01f);
        auto speed=holdVelocity(previous,anchor,body,.016f,8,2500);
        check(finite(speed) && length(speed)<=2500.01f);
        body=body+speed*.016f;
    }
    check(length(body-Vec{0,300,0})<1);
    check(length(advanceAnchor(anchor,{999,999,999},2500,0)-anchor)==0);
    anchor={6000,0,0}; body=anchor;
    for(int i=0;i<75;++i) {
        auto before=anchor;
        float cap=length(body)>500 ? 10000.f : 4500.f;
        anchor=advanceAnchor(anchor,{300,0,0},cap,.016f);
        auto speed=holdVelocity(before,anchor,body,.016f,10,cap);
        check(finite(speed) && length(speed)<=cap+.01f);
        body=body+speed*.016f;
    }
    check(length(body-Vec{300,0,0})<4); // 6000-unit retrieval settles within 1.2 seconds

    // Prediction rejects near misses and favors the earliest threat, admitting a fast crossing next poll.
    float imminent=predictedMissileScore({0,0,0},{0,300,0},{0,-1500,0},400,.25f,110);
    check(std::abs(imminent-.2f)<.0001f);
    check(predictedMissileScore({0,0,0},{150,300,0},{0,-1500,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{0,1500,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{INFINITY,0,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,300,0},{0,-500,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,450,0},{0,-6000,0},400,.25f,110)>0);
    check(predictedMissileScore({0,0,0},{0,900,0},{0,-6000,0},400,.25f,110)<0);
    check(predictedMissileScore({0,0,0},{0,150,0},{0,-1500,0},400,.25f,110)<imminent);
    // Archetype, base damage, speed and bounded weight each matter independently.
    auto hit=[](float speed,float mass,float base,WeaponStyle style) {
        return combatObjectDamage(speed,mass,base,style,1.2f,12,1,450,1200,80);
    };
    float dagger=hit(3600,5,5,WeaponStyle::dagger),sword=hit(3600,10,10,WeaponStyle::blade);
    float hammer=hit(3600,25,25,WeaponStyle::blunt);
    check(dagger>120 && dagger<150); check(sword>270 && sword<280); check(hammer>sword);
    check(hit(1800,10,10,WeaponStyle::blade)<sword); check(hit(449,40,100,WeaponStyle::blunt)==0);
    check(hit(3600,10,20,WeaponStyle::blade)>sword);
    check(hit(3600,100000,100,WeaponStyle::blunt)==1200);
    check(hit(INFINITY,5,5,WeaponStyle::dagger)==0);
    check(combatObjectDamage(3600,5,0,WeaponStyle::clutter,1.2f,12,0,450,1200,25)==0);
    check(std::abs(mitigateObjectDamage(100,300,.0012f,.8f,0,1,.12f)-52)<.001f);
    check(std::abs(mitigateObjectDamage(100,10000,.0012f,.8f,0,1)-20)<.001f);
    check(mitigateObjectDamage(100,300,.0012f,.8f,penetration(WeaponStyle::blunt),1)>
          mitigateObjectDamage(100,300,.0012f,.8f,penetration(WeaponStyle::blade),1));
    check(mitigateObjectDamage(100,0,.0012f,.8f,0,.25f)==25);
    check(mitigateObjectDamage(100,-100,.0012f,.8f,0,1)==100);
    check(enchantmentCost(40,25)==30); check(enchantmentCost(40,200)==0); check(enchantmentCost(40,-10)==40);
    float budget=10; check(budgetedXP(8,budget)==8 && budget==2);
    check(budgetedXP(8,budget)==2 && budget==0); check(budgetedXP(1,budget)==0);
    budget=1; check(budgetedXP(-4,budget)==0 && budget==1);

}
