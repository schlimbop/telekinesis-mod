#include "combat_math.h"
#include "controls.h"
#include <cstdlib>
#include <iostream>
void check(bool value) { if(!value) { std::cerr<<"Check failed\n"; std::exit(1); } }
int main() {
    using namespace tkc;
    check(castAction(true,false,false,false,true)==CastAction::grab);
    check(castAction(false,true,true,true,true)==CastAction::release);
    check(castAction(false,true,true,true,false)==CastAction::release);
    check(castAction(false,false,true,true,true)==CastAction::none);
    check(castAction(true,false,true,false,true)==CastAction::charge);
    check(castAction(false,true,true,false,true)==CastAction::cancelCharge);
    check(castAction(true,false,false,false,false)==CastAction::none);
    check(std::abs(segmentDistance({0,0,0},{100,0,0},{50,20,0})-20)<0.001f);
    check(segmentDistance({0,0,0},{0,0,0},{0,0,10})==10);
    check(segmentDistance({0,0,0},{100,0,0},{150,0,0})==50);
    check(length(limit({3000,4000,0},1000))<1000.01f);
    check(length(unit({0,0,0}))==0);
    check(resistance(1,10,20,.04f)==1);
    check(resistance(2,100,1,.04f)==8);
    check(damage(299,70,1,300,1000)==0);
    check(damage(3000,70,1,300,1000)==630);
    check(damage(10000,70,1,300,1000)==1000);
    check(aimScore({0,0,0},{1,0,0},{3500,35,0},16,4000)>=0);
    check(aimScore({0,0,0},{1,0,0},{3500,600,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{-100,0,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{4100,0,0},16,4000)<0);
    check(aimScore({0,0,0},{1,0,0},{5500,200,0},8,6000,3)>=0);
    check(aimScore({0,0,0},{1,0,0},{5500,200,0},8,6000,1)<0);
    check(weakened(35,100,.35f)); check(!weakened(36,100,.35f));
    check(weakened(60,200,.35f)); // temporary health buffs belong in maximum
    check(!weakened(0,100,.35f)); check(!weakened(1,0,.35f));
    check(std::abs(boxHit({-100,0,20},{100,0,20},{-40,-20,0},{40,20,45},0)-.3f)<.001f); // low wolf
    check(boxHit({-100,0,80},{100,0,80},{-40,-20,0},{40,20,45},0)<0);
    check(boxHit({0,0,20},{0,0,20},{-40,-20,0},{40,20,45},0)==0);
    check(boxHit({100,0,20},{-100,0,20},{-40,-20,0},{40,20,45},0)>=0);
    check(boxHit({-100,30,20},{100,30,20},{-40,-20,0},{40,20,45},12)>=0);
    check(damage(3600,10,6,450,3000)>700); // launched sword
    // A far pickup pulls in without teleporting; a rapid camera turn remains bounded.
    Vec anchor{3500,0,0},body=anchor;
    for(int i=0;i<240;++i) {
        Vec goal=i<120 ? Vec{300,0,0} : Vec{0,300,0};
        auto previous=anchor; anchor=advanceAnchor(anchor,goal,2500,.016f);
        check(length(anchor-previous)<=40.01f);
        auto speed=holdVelocity(previous,anchor,body,.016f,8,2500);
        check(finite(speed) && length(speed)<=2500.01f);
        body=body+speed*.016f;
    }
    check(length(body-Vec{0,300,0})<1);
    check(length(advanceAnchor(anchor,{999,999,999},2500,0)-anchor)==0);
    anchor={6000,0,0}; body=anchor;
    for(int i=0;i<75;++i) {
        auto before=anchor;
        float cap=length(body)>500 ? 10000.f : 4500.f;
        anchor=advanceAnchor(anchor,{300,0,0},cap,.016f);
        auto speed=holdVelocity(before,anchor,body,.016f,10,cap);
        check(finite(speed) && length(speed)<=cap+.01f);
        body=body+speed*.016f;
    }
    check(length(body-Vec{300,0,0})<4); // 6000-unit retrieval settles within 1.2 seconds

}
