Scriptname TKC_PlayerAlias extends ReferenceAlias
TKC_ExecutionFX Property Controller Auto
Event OnPlayerLoadGame()
    If Controller
        Controller.RegisterEvents()
    EndIf
EndEvent
