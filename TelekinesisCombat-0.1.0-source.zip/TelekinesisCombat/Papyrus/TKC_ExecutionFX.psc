Scriptname TKC_ExecutionFX extends Quest
; Optional cosmetic event listener. Nothing in the native core depends on it.
Sound Property CrushSound Auto
EffectShader Property CrushShader Auto

Event OnInit()
    RegisterForModEvent("TKC_Execution", "OnCrush")
EndEvent

; Attach to a player reference alias to reliably re-register after loading a save,
; or use TKC_PlayerAlias below on the same quest.
Function RegisterEvents()
    RegisterForModEvent("TKC_Execution", "OnCrush")
EndFunction

Event OnCrush(String eventName, String strArg, Float numArg, Form sender)
    Actor victim = sender as Actor
    If victim
        If CrushSound
            CrushSound.Play(victim)
        EndIf
        If CrushShader
            CrushShader.Play(victim, 0.4)
        EndIf
    EndIf
EndEvent
