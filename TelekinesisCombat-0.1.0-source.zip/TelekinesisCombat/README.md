# Telekinesis Combat — 0.1.8 thrown-object contacts and execution decapitation

An SKSE C++ combat telekinesis implementation for Skyrim SE/AE. Hold one eligible actor or loose object, move it with your aim, pull/push, throw, slam or execute a weakened target.

**Status: 0.1.8 source implemented; remote compilation and gameplay validation pending.** The user reports that 0.1.7 thrown weapons often pass through NPCs with little or no damage. The ray helper could report an obstruction after skipping only the source/player bodies all the way to the end of a short segment. That shared helper now returns a clear ray when its skip cursor reaches the endpoint. Projectile tracking no longer ends just because a prop slows down; actor landing detection keeps that fallback.

Thrown props sweep their bounded Havok shape extents, not only their centres, against loaded actor bounds. Actor motion between updates is included and logical-origin range filtering is removed. Actors are collected once per update while flights exist. The nearest visible contact wins; a ray to the target's actual body centre prevents a padded blade from reaching through a wall. At contact the prop is moved back along its just-travelled segment using native rigid-body positions, stopped once and returned to ordinary Havok motion. Surviving eligible victims receive a stagger animation. This is contact resolution, not repeated teleportation during holding or a permanent collision-layer change.

Object damage defaults to multiplier 8 and cap 2000. An above-threshold confirmed hit has a configurable floor of 125 damage for clutter and 350 for weapons, retaining the weight floor 5/cap 40 and 2x weapon bonus. At speed 3600 a light object calculates about 518 damage, a weight-5 weapon about 1037, and a weight-10 weapon reaches 2000. NPC launch/slam speeds, fractional damage, level/fall lethality, disarm and ragdoll rules are unchanged. Prop launch, confirmed hit, obstruction and expiry diagnostics are written to the log.

The charged finisher can now request native decapitation on supported humanoid races. It kills through the existing Health subtraction/death notification path first, then waits for actual death state on a later update before calling `Actor::Decapitate`. It uses safe handles, waits at most two seconds, and clears pending actions on reset/load/scene loss. It never decapitates a living target or adds a melee killcam. Unsupported races keep the damage/VFX finisher. `ExecutionDecapitation=0` disables beheading for incompatible custom head, skeleton or overlay setups. Native decapitation can inherit head-mod compatibility problems; the [Simple Beheading author's changelog](https://www.nexusmods.com/skyrimspecialedition/mods/117172) also documents deferred death handling and overlay-related crashes. No external decapitation mod is required by this implementation.

Held items retain the 0.1.7 camera-ray anchor, 160-unit default item distance, spin suppression, launch-only sword/dagger alignment and 260-unit collection reach from player bounds centre. Ordinary corpses and existing ragdolls remain grabbable. Hold casting to grab; release to launch; wheel pulls/pushes; Shift+release slams; Activate/E collects nearby props. Hold Activate for one second on a held actor at <=35% Health to execute. Six local Python checks pass; new C++ regressions cover source-ray exhaustion, blade extents, fast/moving targets, unconfirmed slowdown and damage floors. They still need the Windows CI build. Gameplay checks, including decapitation and visual contact resolution, are not yet run.

Version 0.1.7 [compiled and passed both CTests](https://github.com/schlimbop/telekinesis-mod/actions/runs/37773347262) from commit `9d3d1e68eb3ace2ef3ff3c7cad2dfef300166952` on 8 October 2026 (Sydney time). All six Python checks passed. The camera checks cover eye height, upward/downward pitch and third-person depth/offset. The uploaded source matched SHA256 `f522bd1d177da0cd9a81568053d14db80a7916dac7c65f2d400c0017d5eb0456`. The downloaded artifact SHA256 matched GitHub; all eight packaged-file hashes, x64 SKSE exports and DLL version 0.1.7.0 were verified. Matching PDB, ESP and INI were checked. DLL SHA256: `b06041e7bf01b8342d26160d27d4a7e76dd9d9424aa0af8e577cd1e55b1145cf`. Gameplay retesting of held-item placement and stability remains pending.

Version 0.1.6 [compiled and passed both CTests](https://github.com/schlimbop/telekinesis-mod/actions/runs/37767230285) from commit `5f5e0c0616dd53cc89cb283be2265ade5ccdfb58` on 8 October 2026 (Sydney time). Six Python checks also passed. C++ checks cover peer/high-level NPC damage, speed caps, nonlethal weakened-target slams, fall thresholds, stronger object damage, combat controls, targeting/retrieval, physics rays and runtime interfaces. The uploaded source matched SHA256 `e66615aa3d1db09b8edc270a3d838b42b3e541759bf04fb81fe483d830b830f1`. Downloaded artifact SHA256 matched GitHub; all eight packaged-file hashes, x64 SKSE exports and DLL version 0.1.6.0 were verified. Matching PDB, ESP and new INI were verified. DLL SHA256: `f2170615d51becc94d2ad80fa21c6fad46ebc6932a24fda1cbdb3c8d5ef52e9c`. In-game validation of the new behavior remains pending.

Version 0.1.5 [compiled and passed both CTests](https://github.com/schlimbop/telekinesis-mod/actions/runs/37758510648) from commit `8c903b175dc352cb9f6b22e424d7283d6f0e0f8d` on 8 October 2026 (Sydney time). All six Python checks also passed. C++ tests cover distant retrieval, aim assistance, low creature bounds, finisher health thresholds, combat controls, physics-ray layout and runtime actor interfaces. The uploaded source matches SHA256 `b92ee002ccda1a6bbd8522ac403a2c7b313b04c3d4e0f92bd31102100ba0e52b`. Downloaded artifact SHA256 matched GitHub; all eight packaged-file hashes, x64 architecture, SKSE exports and DLL version 0.1.5.0 were verified. Matching PDB included. DLL SHA256: `1848d8b86049d3f3687850c5dc8a4441138ca2d36900ff8a7afd095be2775525`. Gameplay retesting remains pending.

Version 0.1.4 [compiled and passed both CTests](https://github.com/schlimbop/telekinesis-mod/actions/runs/37629583026) from commit `3b8e4a1dc3fdd8a171d90d309d9f8b9139960253` on 8 October 2026 (Sydney time). All six Python checks also passed. The tests include distant aim-cone selection, a bounded anchor/velocity simulation through a rapid camera turn, physics-ray layout and runtime actor-interface offsets. Downloaded artifact SHA256 matched GitHub; all eight packaged-file hashes, x64 architecture and SKSE exports were verified. Matching PDB included. DLL SHA256: `ff4859f34db60ff28308a56624d6cc1e9c8d6cb2d52e10aae1b9266dc5678266`. The new gameplay behavior still requires an in-game retest.

Version 0.1.3 [compiled and passed both CTests](https://github.com/schlimbop/telekinesis-mod/actions/runs/37619899203) from commit `f487eb981e8cc0ffd3df9ca46ed80397ad0920f9` on 7 October 2026. The tests cover combat math/casting controls, the actual CommonLib physics-ray structure and runtime actor-interface offsets. Six Python checks also passed. The downloaded artifact matched GitHub's SHA256 digest; all eight package-file hashes and the x64 DLL's SKSE exports were verified. DLL SHA256: `7c6c0d4826fd635334e0565519b111b30ab13887691fe628d5047f869adedaa5`. The earlier 0.1.2 in-game test failed as described above.

Install `TelekinesisCombat-0.1.8-install.zip` directly; a C++ compiler is needed only if you choose to rebuild the source. Replace the old DLL, ESP and INI together, then deploy in Vortex. Companions from 0.1.3 and earlier using paralysis are rejected; the 0.1.4–0.1.8 companion contract is unchanged. All six local form IDs are unchanged; do not compact the ESP. Compilation is tracked in [GitHub Actions](https://github.com/schlimbop/telekinesis-mod/actions). Versions 0.1.0 and 0.1.1 contained a targeting error: the `bhkPickData.ray` displacement was never populated, so casting displayed the aim-at-target message without finding objects or actors. Version 0.1.2 initialized the origin and displacement expected by `bhkWorld::PickObject`, using the [working SmoothCam implementation](https://github.com/mwilsnd/SkyrimSE-SmoothCam/blob/master/SmoothCam/source/raycast.cpp) as API reference. That correction is retained for selection, visibility, obstruction checks and impact sweeps. Each successful grip is recorded in `TelekinesisCombat.log`.

## Contents

- `src/main.cpp`: engine integration, physics controller, keyboard input, impact damage, finisher, config validation, lifecycle cleanup.
- `src/combat_math.h`, `tests/math.cpp`: portable combat math and runnable C++ checks.
- `Data/TelekinesisCombat.esp`: six new forms, Skyrim.esm master, ESL flag, no vanilla overrides.
- `Data/SKSE/Plugins/TelekinesisCombat.ini`: controls, costs, forces, resistance and damage settings.
- `tools/companion.py`: regenerate the ESP from an owned Skyrim.esm without writing to the master.
- `tools/package.py`: source or mod-manager ZIP, hashes, DLL architecture check.
- `tools/inspect_binary.py`: read and check SKSE DLL exports/imports without executing it.
- `.github/workflows/build.yml`: Windows build, tests, package artifact.
- `Papyrus/`: optional cosmetic sound/shader listener; no Papyrus loop or native gameplay dependency.
- `docs/CreationKit.md`: exact records, manual recreation, optional sound integration.
- `docs/TESTING.md`: compilation and in-game acceptance gates.

## Runtime targets and requirements

Target list: SE **1.5.97**, AE **1.6.640 / 1.6.659 / 1.6.1170 / 1.6.1179**, and current Steam **1.7.104**. These are implementation targets, not a tested compatibility matrix. Unknown versions and VR are rejected. CommonLib's version-aware accessors and Address Library relocations are used; there are no hand-coded runtime instruction patches.

Install SKSE and Address Library for your **exact executable version**. The [official SKSE page](https://skse.silverlock.org/) lists Steam 1.7.104 with SKSE 2.3.1, GOG 1.6.1179 with 2.2.6, and SE 1.5.97 with 2.0.20 as of 6 October 2026. Older AE installations need their matching archived SKSE. Address Library must provide every relocation used by this build. Game Pass, Epic, consoles and VR are outside this project's scope.

For Steam 1.7.104, install **Address Library All in One (1.7.104.0) v13** or a later release that explicitly covers this runtime, from the [author's Files page](https://www.nexusmods.com/skyrimspecialedition/mods/32444?tab=files), and deploy it in Vortex. The game needs `Data/SKSE/Plugins/versionlib-1-7-104-0.bin`. A spell appearing in the magic menu only proves that the ESP loaded. If the DLL is disabled, all combat controls remain inactive. Check `Documents/My Games/Skyrim Special Edition/SKSE/skse64.log` for `TelekinesisCombat.dll`: `disabled, address library needs to be updated` means the correct database is missing. Do not bypass this loader check.

[CommonLibSSE NG v10.1.0](https://github.com/alandtse/CommonLibSSE-NG/releases/tag/v10.1.0) is pinned in CMake. You need Visual Studio 2022 with current Desktop Development with C++, Windows SDK, CMake 3.24+, Git, vcpkg, and Python 3.10+. spdlog, rapidcsv and DirectXTK are CommonLib build dependencies. The plugin itself adds no configuration-parser dependency.

## Build

Run from this project's directory in a Visual Studio developer PowerShell. Replace the vcpkg path with your installation:

```powershell
cmake -S . -B build -A x64 -DCMAKE_TOOLCHAIN_FILE=C:/vcpkg/scripts/buildsystems/vcpkg.cmake -DVCPKG_TARGET_TRIPLET=x64-windows-static -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
python -m unittest discover -s tests -v
python tools/package.py --dll build/Release/TelekinesisCombat.dll
```

The resulting `dist/TelekinesisCombat-0.1.0.zip` contains an ESP, INI, DLL and documentation. Packaging fails if the DLL is missing or is not an x64 Windows DLL. It cannot certify gameplay; complete the acceptance checks before treating a build as playable.

For portable math checks without CommonLib or Skyrim, configure with `-DTKC_MATH_ONLY=ON`, then build and run CTest. To regenerate the companion:

```powershell
python tools/companion.py "C:/Program Files (x86)/Steam/steamapps/common/Skyrim Special Edition/Data/Skyrim.esm"
```

The generator uses the [TES5Edit record definitions](https://github.com/TES5Edit/TES5Edit/blob/dev-4.1.5/Core/wbDefinitionsTES5.pas) for record layouts. It reads vanilla effect templates, copies a small whitelist of record fields, and writes a separate new ESP. It copies no game asset files. Open the ESP in SSEEdit and run **Check for Errors** before an in-game test. The included ESP was structurally checked by the Python validator, not by SSEEdit/Creation Kit.

## Installation and first use

Before updating from an older version, drop any held target, wait twenty seconds and save. Install the release ZIP with MO2 or Vortex, disable the previous version, enable `TelekinesisCombat.esp` and launch through SKSE. Replace DLL, ESP and INI together. Manual layout under your game's `Data` directory:

```text
TelekinesisCombat.esp
SKSE/Plugins/TelekinesisCombat.dll
SKSE/Plugins/TelekinesisCombat.ini
```

The companion uses the ESL flag and old-runtime-safe IDs 0x800–0x805. No FormID compaction is needed. Never compact or renumber it after installation; if rebuilding it manually, update the INI to the resulting local IDs.

For this first version, acquire the control spell through the console:

```text
help "Combat Telekinesis" 4
player.addspell <the SPEL FormID shown by help>
```

Equip **Combat Telekinesis** in one hand for grabbing, throwing and Activate-based execution; both hands also allow the opposite-cast finisher. Vanilla Telekinesis remains available separately.

| Control | Action |
| --- | --- |
| Hold the spell's casting button | Grab and suspend the aimed eligible actor or loose object |
| Release that casting button | Throw forward; a failed throw safely drops the target |
| Mouse wheel up/down | Pull nearer / push farther while gripping |
| Shift + release the casting button | Downward slam |
| Activate (normally E) | Nearby items: collect through normal activation; distant items/healthier actors: drop. Weakened actor: hold to execute; release early to drop |
| Hold the opposite casting button, with the spell in both hands | Charge execution for 1 second on a target at <=35% health |

Casting follows Skyrim's remapped left/right attack actions. Wheel and Shift are mouse/keyboard controls. Cast-button holds must remain pressed to retain the grip. Aim moves the suspension anchor. Allow a brief moment for the ragdoll to form before throwing. Optional legacy keyboard controls are disabled by default; set `LegacyHotkeys=1` to enable G/H/J/K/L/X.

## Configuration and gameplay

The INI uses Windows profile syntax. Close the game before editing it; configuration is loaded at DataLoaded. Legacy controls are DirectInput **keyboard scan codes**, not virtual-key numbers. Defaults are G=34, H=35, J=36, K=37, L=38, X=45. Duplicate controls reset to defaults. Invalid numbers fall back to defaults and are logged; valid values are bounded. Mapped casting actions also accept gamepad input; wheel adjustment and Shift slam currently require mouse/keyboard.

Costs default to 15 Magicka on grab, 12/second to hold, 10 to launch/slam and 40 to execute. Actor costs multiply by `clamp(scale³ × (1 + positive level difference × LevelResistance), 1, 8)`. Object holds use the base cost. Insufficient Magicka drops the target or rejects the action. This is manual cost accounting; Alteration cost-reduction perks and XP progression are not yet integrated.

Humanoids, undead (`AllowUndead=1`) and ordinary-sized animals/creatures (`AllowCreatures=1`) are eligible. Children, essential actors, dragons, giants, killmove actors, over-scale/over-height/over-extent actors and actors already paralyzed or grabbed by another effect are rejected. Protected actors are excluded by default. `AllowCorpses=1` permits ordinary dead ragdolls; alive ragdolls can also be gripped without a second knockdown. No combat or suspension effects are applied to corpses. Exclusions also apply to native damage where relevant. Custom creature skeletons may fail the ragdoll check and be released. Default limits are scale 1.5, height 260 and maximum dimension 360 game units; giant/dragon immunity also applies independently of dimensions. Dragons/large creatures can still be struck by a launched object, but cannot be suspended.

Objects must already have dynamic collision bodies and be loose weapons, armor, miscellaneous items, ingredients or potions. Doors, furniture, statics, containers, equipped items and objects in inventories are excluded. Taking an object for telekinesis does not silently transfer ownership. Normal Havok collisions/ownership behavior remains active.

`Range` defaults to 6000 game units (vanilla's base telekinesis distance is 2100), within loaded physics geometry. Increase it up to 8000 if desired; unloaded objects cannot be selected. Holding the cast button retries acquisition every 0.08 seconds until a target is found. `AimAssistDegrees` defaults to 3 and accepts 0.25–5 degrees. `PickupSpeed` defaults to 10000 units/second for distant props; `MaxHoldSpeed` defaults to 4500 for actors and near-camera props. Both bound anchor travel and corrective velocity. `SpringGain` defaults to 10 and controls responsiveness. Camera turns preserve the grip; walls clamp its path, and an extreme separation or unloaded scene still ends it.

`LaunchSpeed` and `SlamSpeed` are Skyrim world units/second; they are converted to Havok units using engine world-scale values. The hold uses bounded linear velocities and never repeatedly teleports the actor reference. Held props keep their existing orientation with angular velocity suppressed; no item is repeatedly rotated while gripped. On launch, swords/daggers receive approximate +Z-forward alignment once; axes/maces and multi-body/custom meshes resume ordinary Havok motion. Disable `OrientSwords` for incompatible meshes.

Object damage uses `max(minimum hit damage, clamped inventory weight × speed² × ImpactDamageMultiplier × weapon bonus / 1,000,000)`, capped by `MaxImpactDamage`. Below `ImpactMinSpeed=450`, no plugin damage is applied. Defaults: weight floor 5/cap 40, multiplier 8, weapon bonus 2×, damage cap 2000, `ObjectMinHitDamage=125`, `WeaponMinHitDamage=350`. The strongest finite pre-contact velocity/displacement estimate (capped at 4500) avoids sampling an already-stopped body as a zero-speed hit. Each prop damages one victim once and stops at its confirmed swept contact. Unconfirmed slowdown keeps tracking until a real contact, scene loss or the four-second expiry.

Living body impacts use `maximum Health × fraction × speed ratio² × level scale`, capped at `ActorDamageCapFraction` (45%). At equal levels and configured speed, throws deal 20% and slams 30%; the level scale is bounded 0.5–1.5. `LethalLevelAdvantage=10` allows a lethal impact when the player is at least 10 levels higher. A descending non-slam landing after `CliffLethalDrop=800` units can also kill. A slam below the lethal level threshold leaves at least 1 Health and disarms its target using `QueueActorDisarm`; creatures with no equipped weapon have nothing to drop. Already-weakened actors can die from ordinary partial damage. Object/NPC damage settings are independent; obsolete `ActorMass` is no longer used. Body throws apply one ordinary hit, then keep tracking only for a later lethal fall until `ActorFlightSeconds=15` expires or physics becomes unavailable. Recovery effects stop refreshing after the ordinary hit. Native Havok/fall damage and other mods can add damage; the plugin does not heal or resurrect targets to counter it.

`ItemHoldDistance=160` anchors props on the actual camera crosshair ray; third-person adds the projected player depth along the same ray. Actors retain `HoldDistance=300`. Activate/E collects a nearby held item using native activation when its physics position is within `PickupReach=260` of the player bounds centre and no wall intervenes. This preserves normal activation/ownership scripts rather than adding items directly to inventory. These behavior changes require gameplay retesting.

Executions use health damage, a stock magical visual/sound effect, a notification and a mod event. With `ExecutionDecapitation=1` they also request native beheading after actual death for NPC races with decapitation armor records. Unsupported actors still die through the ordinary finisher. No skull anatomy simulation, custom gore meshes or melee killmove animation is added. Optional Papyrus can add a more suitable crack sound and shader; see CreationKit.md.

## Stability and compatibility

Input edges are copied before being queued; all controller mutations and physics access execute on the game thread. A timer thread queues at most one task and touches no Skyrim objects. Havok queries/mutations use the cell's world lock. Bodies are discovered afresh; reference handles and a physics-world identity are retained across updates. Flight tracking is bounded. Pauses freeze controller updates/costs, and large frame hitches use a bounded timestep. Attached neighboring cells sharing the physics world retain a grip. Loading, a physics-world change, unequipping, invalid target or insufficient Magicka releases it. Dropping dispels only this plugin's private suspension spell.

Suspension begins with the native zero-force knockdown and a two-second recovering ValueModifier effect that adds 1 to `Grabbed` (AV 161). Active effects are extended in place rather than stacked. After an interruption or save/load, the state expires within two seconds of normal game time; no permanent actor-value edits, serialized native handles, gravity overrides or disabled AI are stored. A living throw refreshes that state until its first ordinary impact; subsequent fall tracking does not keep refreshing suspension. No paralysis or health-drain effect is used. Recovery under custom animation/physics stacks requires testing.

Avoid using Better Telekinesis or another ragdoll controller on the **same target**. Test separately with Precision, PLANCK-like actor physics changes, animation behavior replacements, custom skeletons and mods that alter paralysis recovery. A vanilla-effect overhaul should not replace these private effects, although broad runtime patches may still influence them. The ESP makes no vanilla overrides and needs only Skyrim.esm.

Known prototype limits: expanded actor/prop boxes approximate contact rather than exact mesh/limb intersection. Actor motion sweeps reduce moving-target misses; changing poses may still produce approximate contacts. Static geometry uses a centre ray and can miss grazing blade/environment contacts. A velocity-loss fallback remains only for thrown actors. Prop contact resolution is once per controller update, so a brief visual overshoot can still occur at low frame rates. No global Havok quality/filter patch is installed. Native beheading depends on compatible race/head assets; disable the option if head/overlay mods cause problems. Native player damage attribution is provided; full crime reporting, kill XP and perk interactions need in-game verification. No claim of established stability or measured frame-time performance is made.

If initialization fails, inspect `TelekinesisCombat.log` in the SKSE log directory. Missing companion spells disable gameplay and produce a notification. Never delete a required Address Library error to force an unsupported executable to run.

For removal, drop held targets, wait at least twenty seconds for tracked effects to expire, and save away from combat. Disable the plugin/ESP together in a test profile. Keep the original save when evaluating this development build.
