# Telekinesis Combat 0.2.2

An SKSE C++ combat telekinesis mod for Skyrim SE/AE. Grab an actor, corpse, loose item or eligible hostile spell missile; suspend, aim, pull/push, throw, slam, disarm or execute a weakened enemy.

**Status: 0.2.2 menu fix; portable checks passed; Windows DLL build and in-game layout check pending.** Every native settings screen now shows at most two options plus More and Back/Close, with short button labels and a page number. More cycles through the options; edits keep the current page. The 0.2.1 material-query crash fix is retained. Spell IDs and gameplay settings are unchanged.

## Improvements introduced in 0.2.0

1. Weapon-aware damage combines base weapon damage, archetype, bounded inventory weight and impact speed. Armor, hidden worn-piece defense and outgoing player difficulty scaling apply by default. NPC damage remains separate.
2. Short stock shaders highlight the selected actor/prop or exact worn weapon mesh. HUD text names grab/disarm/catch/execute mode and reports immunity, external control, no movable physics or insufficient Magicka. Missing biped weapon meshes get a text preview only.
3. Confirmed contacts play stock material sounds/particles (uniform primitive materials; stone fallback for compound/terrain) and force-sensitive stagger. Finisher charge has sound, brief shader pulses and 25% progress messages. Final sound/VFX/event and optional decapitation follow confirmed native death.
4. Incoming missile prediction checks closest approach inside a threat corridor and look-ahead interval. A short swept lead reduces capture-boundary misses; the earliest eligible threat wins. Return-to-caster and crosshair return are configurable.
5. Meaningful hostile combat actions grant bounded Alteration XP. Manual costs honor Fortify Alteration and native spell-cost perk entry points. Native F10 settings provide Balanced/Powerful presets, keyboard rebinding and gameplay adjustments without SkyUI or Papyrus.
6. Cached loaded handles and throttled actor/prop searches are independent of fast missile polling and flight physics. Optional local profiling measures controller execution time and cache work.

## Requirements and installation

Requires SKSE matching the game executable and the matching Address Library database. Targets: SE 1.5.97; AE 1.6.640, 1.6.659, 1.6.1170, 1.6.1179 and 1.7.104. VR and other runtime versions are rejected. Requires the Microsoft Visual C++ x64 runtime used by the Windows build. No required SkyUI, Papyrus extension, external decapitation mod or custom art assets.

Drop held targets, wait twenty seconds and save before updating. In Vortex, disable the old version, install the **installer** ZIP, enable `TelekinesisCombat.esp`, deploy and launch through SKSE. Replace DLL, ESP and INI together; this version changes object damage defaults. Keep a separate test save.

```text
Data/TelekinesisCombat.esp
Data/SKSE/Plugins/TelekinesisCombat.dll
Data/SKSE/Plugins/TelekinesisCombat.ini
```

The companion remains ESL-flagged with six private forms 0x800-0x805, requires Skyrim.esm only and makes no vanilla overrides. Existing spell IDs are unchanged. Never compact or renumber an installed companion. Regeneration/manual record setup: `docs/CreationKit.md`.

Acquire the spell through the console:

```text
help "Combat Telekinesis" 4
player.addspell <SPEL FormID shown by help>
```

Equip **Combat Telekinesis**. Vanilla Telekinesis remains available separately.

## Controls

| Control | Action |
| --- | --- |
| Hold the equipped spell's mapped casting button | Grab/suspend the aimed eligible actor or loose object; retry until available |
| Shift held when starting the cast | Disarm the aimed hostile drawn weapon; otherwise catch an incoming hostile aimed missile; otherwise grab the nearest visible loose item within 300 units, including behind the player |
| Release that casting button | Throw a prop/actor; return a held missile using the configured direction |
| Mouse wheel up/down | Pull nearer / push farther |
| Press Shift during an existing grip, then release cast | Downward slam. If Shift acquired the target, release it and press again to arm a slam. Missiles return instead |
| Activate (normally E) | Collect a nearby held item using native activation; dissipate a missile; otherwise drop. Hold on a weakened actor to execute; early release drops |
| Opposite casting button with the spell in both hands | Hold to charge execution on a weakened held actor |
| F10 | Open optional settings; releases any grip first. Spell need not be equipped |

Casting/Activate follow Skyrim mappings, including gamepad. Modifier/wheel/settings shortcuts use keyboard/mouse. Use **More** to cycle the compact numbered settings pages; **Back** returns to the main settings and **Close** exits. Edits stay on the current page. Rebind settings/modifier/legacy keys in F10 > Controls. Rebinding waits ten unpaused seconds for a keyboard key; Escape cancels, duplicates reject. Rebinding the primary modifier clears its secondary binding; restoring defaults reinstates both Shift keys. Legacy G/H/J/K/L/X controls remain disabled unless enabled.

## Object damage and presets

For a confirmed prop hit above `ImpactMinSpeed=450`:

```text
ratio = clamp(speed / 3600, 0, 1.25)
kinetic = boundedWeight * speed^2 * ImpactDamageMultiplier / 1,000,000
weapon = baseWeaponDamage * WeaponBaseDamageScale * ratio * archetypeFactor
raw = clamp(max(minimumHit * ratio, kinetic + weapon) * ObjectDamageScale, 0, MaxImpactDamage)
final = raw * (1 - cappedArmorReduction * (1 - penetration)) * outgoingDifficultyMultiplier
```

Defaults: weight floor 5/cap 40; kinetic scale 1.2; weapon base scale 12; clutter floor 25/weapon floor 80; raw cap 1200. Dagger factor 0.9 and 15% penetration; mace/warhammer factor 1.1 and 25% penetration; other weapons factor 1 and no penetration. Uses base record weapon damage; tempering, enchantment procs, poisons, blocking, sneak attacks and every melee-specific perk are not simulated. Disarmed items retain actual enchantment/tempering extras for pickup.

At speed 3600, before armor/difficulty:

| Example | Weight / base weapon damage | Balanced raw | Powerful raw |
| --- | --- | --- | --- |
| Light clutter | 5 / 0 | 77.8 | 140.0 |
| Dagger | 5 / 5 | 131.8 | 237.2 |
| Sword | 10 / 10 | 275.5 | 495.9 |
| Warhammer | 25 / 25 | 718.8 | 1293.8 |

Powerful uses scale 1.8, cap 2000, lower costs/resistance and wider capture. Balanced restores the defaults above. Both preserve controls, NPC throw/slam fractions, lethal level gap and immunity toggles. Armor/difficulty toggles are independent. Legendary's native outgoing multiplier further reduces damage.

Each prop damages one victim once. Bounded shape extents sweep against moving actor bounds to register fast blade hits when Havok misses. Visibility checks prevent through-wall hits; the prop stops at confirmed contact. Unconfirmed slowdown keeps tracking. Contacts approximate boxes, not exact blade/limb meshes.

NPC throws/slams retain their rules: at equal levels/configured speed, throws deal 20% of maximum Health and slams 30%, capped at 45%. A ten-level player advantage permits lethal impact. A descending non-slam cliff landing after at least 800 vertical units can kill independently of level. Otherwise a slam leaves at least 1 Health and queues native disarm. Weakened actors may die from ordinary throws. Native fall/Havok damage and other mods can add damage. New armor/difficulty calculations apply to loose objects; explicit NPC/finisher rules remain separate.

## Holding, missiles and finishers

Props hover on the actual camera crosshair ray 160 units ahead; third-person adds camera-to-player depth. Actors use 300 units. Props suppress spin while held; swords/daggers orient approximately point-first once at launch. Distant props retrieve at up to 10000 units/second. Walls constrain travel. E collects a visible prop within 260 units of player bounds centre through normal activation/ownership behavior.

Corpses and live ragdolls are supported. Living actors use native zero-force knockdown plus a recovering private `Grabbed` modifier refreshed without stacking. No paralysis or health drain. Children, essential actors, dragons, giants, killmove actors, oversized actors and externally controlled targets reject acquisition; protected actors are immune by default. Ordinary creatures/undead are enabled. Size/level resistance multiplies actor action/hold costs.

Incoming hostile fire-and-forget aimed missiles with matching source spell/effect qualify (e.g. Fireball, Ice Spike/Icy Spear). Closest approach must occur within `ProjectileLookAheadSeconds=0.25` and `ProjectileThreatRadius=110`. Capture radius is 400 units with one controller interval of swept lead. Player/friendly missiles, arrows, beams/flames/cones, hitscan, timed/proximity alternative triggers and continuous-update variants are excluded. Prediction uses the player's current centre; unusual acceleration or severe hitches can still evade capture.

The actual missile suspends visibly for up to eight seconds. Only its native movement/impact/lifetime handlers are suppressed. Return uses native launch with original spell/power/scale/speed and player collision group/attribution, then safely kills the held hostile reference. `ProjectileReturnMode=0` selects the original living, loaded, visible caster once, falling back to crosshair; mode 1 always uses the crosshair. No homing or extra prop damage on returned spells.

The three missile hooks install once so capture can toggle live. Every unheld missile forwards to previous handlers. `CatchProjectiles=0` prevents acquisition; it does not remove installed hooks. E, timeout, depleted Magicka, unequip, load/world loss or save dissipates the missile without intentionally detonating it. Pausing freezes costs/timers. Held missiles are not serialized.

Execution requires an eligible held actor at <=35% maximum Health, a full one-second charge and Magicka. Damage/death notification runs first. Final VFX/sound/event and optional native beheading wait up to two seconds for confirmed death. Decapitation requires a humanoid race with decapitation armor; unsupported races retain the lethal finisher. Disable decapitation for incompatible head/skeleton/overlay mods. Optional Papyrus cosmetic listeners remain available but are unnecessary and can duplicate native feedback.

## Settings, progression and performance

INI: `Data/SKSE/Plugins/TelekinesisCombat.ini`. Native settings apply immediately and persist using Windows profile APIs. Write failures produce a HUD message/log; session settings still apply. Vortex can replace deployed edits on redeployment: back up the INI or copy it into staging files. Reload INI resets defaults first. Form IDs/plugin identity require restart. `SettingsMenu=0`, `TargetPreview=0` and `EffectsAndSounds=0` disable the corresponding features independently.

Base costs: grab 15, hold 12/second, launch 10, disarm 25, catch 15, execution 40. Cost reduction applies Fortify Alteration, then native spell-cost entry points to the nonzero action amount. The private spell identifies as novice Alteration, so vanilla Novice Alteration applies its novice-spell reduction. Other perk overhauls depend on their conditions. The cosmetic spell's zero calculated cost is never substituted. Failed native disarm refunds exactly the reduced amount actually charged.

Successful actions against already-hostile eligible actors grant Alteration XP: impacts 1-8 units based on damage, disarm 6, catch 5, multiplied by `AlterationXPScale`. A two-second per-enemy cooldown and replenishing game-time budget (`MaxAlterationXPPerMinute=60`) limit repetition. Idle holding, ordinary item pickup, corpses and friendly targets grant no XP. Repeated combat actions remain eligible after cooldown; the budget/cooldowns are transient and not saved.

`CandidateCacheSeconds=0.25` caches loaded handles; `SearchInterval=0.12` throttles actor/prop selection. Missile acquisition polls at the 16 ms controller cadence while waiting in Shift mode. Existing flights update physical bounds/motion each tick. Handles revalidate before mutation; no Havok body or scene pointer is cached across tasks. Cache clears on world/load/settings changes. `Profile=1` logs five-second controller mean/peak execution time, ticks/scans and candidate counts locally; no telemetry. These counters support measurement and do not establish a measured frame-time improvement.

## Build and validation

Windows x64, Visual Studio 2022 C++ tools, CMake >=3.24 and vcpkg build the native DLL. CommonLibSSE NG v10.1.0 is pinned, using C++23 with SE/AE enabled and VR disabled. GitHub Actions can build without installing a compiler on the gaming PC.

```powershell
cmake -S . -B build -A x64 -DCMAKE_TOOLCHAIN_FILE=C:/vcpkg/scripts/buildsystems/vcpkg.cmake -DVCPKG_TARGET_TRIPLET=x64-windows-static -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
python -m unittest discover -s tests -v
python tools/package.py --dll build/Release/TelekinesisCombat.dll --output dist/TelekinesisCombat-0.2.2-install.zip
```

Three CTests cover compact menu navigation/label budgets, combat math, mocked SE/AE accessors and native settings persistence/presets/bounds. `-DTKC_MATH_ONLY=ON` builds math checks alone. Packaging rejects missing/non-x64 DLLs. Source: `python tools/package.py --source --output dist/TelekinesisCombat-0.2.2-source.zip`. `tools/inspect_binary.py` checks exports/imports without loading a DLL. Complete `docs/TESTING.md` in a test profile before treating this as stable.

## Compatibility and cleanup

Avoid multiple ragdoll/telekinesis controllers on the same target. Test custom skeletons/heads, actor physics, animation behaviors, projectile/reflection hooks and combat/armor overhauls individually. Armor/difficulty support does not recreate all native melee hit events, shields, crime reporting or enchantment procs. Stock record overrides can alter feedback. Native shaders/particles, message-box callbacks and missile hooks need in-game validation across target runtimes.

Controller mutations run on the game thread, with bounded flights and world locks for physics. Loading/scene loss clears cached handles and pending execution/rebind state. Private suspension expires within two unpaused seconds after interruption; no gravity/AI override or permanent paralysis is saved. Read `TelekinesisCombat.log` for errors; do not bypass a required Address Library error.

Before removal: drop targets, wait twenty seconds, save away from combat and disable DLL/ESP together in a test profile. Retain the original save.
