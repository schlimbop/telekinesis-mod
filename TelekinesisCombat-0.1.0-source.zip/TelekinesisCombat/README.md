# Telekinesis Combat 0.2.12

An SKSE C++ combat telekinesis mod for Skyrim SE/AE. Grab an actor, corpse, loose item or eligible hostile spell missile; suspend, aim, pull/push, throw, slam, disarm or execute a weakened enemy.

**Status: 0.2.12 source implemented; Windows DLL build and in-game testing pending.** Recall now has no software distance cap for the last thrown weapon while its physics is loaded in the same world. Ordinary grabs retain their existing range limits. Use **Shift + Activate (E) with an empty grip** to recall; Shift + cast remains disarm/projectile capture/nearby grab. Loaded physics, a clear path and normal Magicka costs still apply. No teleporting or unloaded-cell retrieval is added. Do not install a source ZIP as a playable mod; the compiled installer will be supplied after the Windows build passes.

## Distant recall and complete grasp in 0.2.12

- Removes `Physics.Range` from recall acquisition and bypasses the ordinary hold-distance cutoff for a recalled grip. A distant loaded weapon can travel all the way back without being dropped because of distance.
- Keeps a still-valid last weapon tracked when a blocked path, insufficient Magicka or temporarily unavailable physics prevents recall. The history also survives a successful recall followed by dropping the item; collecting it or loading another save clears it as before. Another thrown weapon replaces the history.
- Loose items must reach their intended hold position and settle before a throw or slam is allowed. Releasing cast during retrieval drops the grip immediately, without a queued throw or LaunchCost. Recalled weapons and each orbiting item have their own readiness state; promoting an already settled orbit item preserves its readiness. Normal camera movement after grasp does not disable throwing. Held spell missiles/arrows must also finish pulling in before return; early release dissipates them using normal projectile cleanup. Actor throw/slam behavior is unchanged.
- Normal grab limits, input bindings, impact damage and the quiet equip hint are unchanged. Recall failures and early releases are logged without gameplay text overlays.

## Recall, impacts and ammunition in 0.2.11

- With Combat Telekinesis equipped and an empty grip, **Shift + Activate (E)** recalls the last loose weapon you threw. Look at clear space to avoid Skyrim's normal Activate interaction. It must still be loaded, movable, in the same world, with a clear path. Recall has no software distance limit while that physics remains loaded. Recall uses the normal `GrabCost`, then ordinary hold/launch costs. The actual weapon returns to your grip; no inventory copies are created. Once the weapon has arrived and settled, click/release the spell's casting button to throw it again, or Activate within pickup reach to collect it. Release Shift before re-arming a slam. Load/new game clears recall history.
- Blade/dagger contacts fall back to stock sharp weapon impacts rather than the generic blunt set; two-handed blades and hammers use their matching stock sets. A weapon's own material-specific impact data remains preferred. Sound/particle strength still follows speed and weight; the EffectsAndSounds toggle remains available.
- Shallow surface hits can deflect once, retaining 55% speed (about 30% kinetic energy). A bounded tip-contact probe after a native velocity change catches wall contacts where Havok stops the object before its centre reaches the surface; it cannot award speculative actor damage. Head-on hits stop. A second contact stops tracking, and the original flight timer is never extended. The deflected prop can damage one enemy at its reduced speed; flesh hits remain terminal. Native collision stays enabled. Missing/invalid normals fall back to stopping safely. Compound/terrain material lookup keeps the existing stone fallback.
- **Shift + cast** now also catches an incoming hostile ordinary arrow or crossbow bolt, suspends it in front of you, and returns it on cast release. Activate dissipates it. The same Capture toggle, prediction, radius, grab/hold/launch costs, eight-second default hold limit and return-to-shooter/crosshair setting apply to both ammunition and spell missiles. Aimed disarms retain priority. Returned ammunition preserves its source ammo/weapon, damage, speed and any native enchantment/poison payload, with player damage attribution. The suspended original is destroyed before the replacement is launched; no ammo is added to inventory. Already-impacting, player/friendly, hitscan, exploding or continuously updated ammunition is excluded. Arrows/bolts require their separate native vtable hooks; other projectile hooks may conflict.

## Quiet HUD in 0.2.10

- Only an actual equip transition shows the short hint. Casting, aiming, holding, orbiting and hitting enemies never restart it. Switching the spell between hands while it remains equipped does not restart it.
- The hint has small right-aligned text and no background panel. Pause/dialogue hides it, unequipping dismisses it, and loading clears UI state. Equipping inside the magic menu starts the two-second display when gameplay resumes.
- Finisher feedback uses existing sound and shader pulses; success effects and optional decapitation still wait for native death. Gameplay failures are recorded in the SKSE log instead of interrupting play with text.
- `TargetPreview` now controls highlights only. The old `HitConfirmation` INI value is preserved for older configurations but has no effect; its obsolete menu toggle is removed. Deliberately opened settings menus and their save confirmations remain available.

## Combat polish retained from 0.2.9

- Close grip anchors ease toward camera motion instead of snapping each frame. Frame-step-aware velocity correction settles after fast turns; distant items retain the configured fast retrieval speed. Long stock melee weapons receive extra camera clearance where needed.
- Small nearby items have a wider minimum aim allowance. The aim cone is capped in world space at long range. A similar candidate does not steal the highlight; a briefly missed target has up to 0.24 seconds of grace within a slightly wider cone. Direct aim and a clearly better candidate take priority. Visibility, world, range and movable physics are rechecked when grabbing; grace never bypasses a wall.
- Orbit spacing uses transverse weapon record bounds and conservative clutter bounds. The formation can move slightly forward within the existing 140–220 range to fit; oversized extra items are skipped instead of widening beyond 60 units. Gathering waits for the primary item to settle. Physical collision remains enabled. Wall crowding, inaccurate custom bounds and custom weapon axes still need in-game checks.
- Surviving eligible enemies stagger according to actual Health loss, impact speed/weight and weapon type. Heavy hits can use native zero-force knockdown; it adds no scripted damage or launch velocity. Reactions have a 1.25-second cooldown per victim, respect size/immunity rules and skip already-ragdolled/held victims. Throw/slam lethal thresholds remain unchanged.

## Improvements introduced in 0.2.0

1. Weapon-aware damage combines base weapon damage, archetype, bounded inventory weight and impact speed. Armor, hidden worn-piece defense and outgoing player difficulty scaling apply by default. NPC damage remains separate.
2. Short stock shaders highlight the selected actor/prop or exact worn weapon mesh. Unaffordable or ineligible targets use the rejected highlight. A disarm preview requires a matching worn weapon mesh.
3. Confirmed contacts play stock material sounds/particles (uniform primitive materials; stone fallback for compound/terrain) and force-sensitive stagger. Finisher charge has sound and brief shader pulses. Final sound/VFX/event and optional decapitation follow confirmed native death.
4. Incoming missile prediction checks closest approach inside a threat corridor and look-ahead interval. A short swept lead reduces capture-boundary misses; the earliest eligible threat wins. Return-to-caster and crosshair return are configurable.
5. Meaningful hostile combat actions grant bounded Alteration XP. Manual costs honor Fortify Alteration and native spell-cost perk entry points. Native F10 settings provide Balanced/Powerful presets, keyboard rebinding and gameplay adjustments without SkyUI or Papyrus.
6. Cached loaded handles and throttled actor/prop searches are independent of fast missile polling and flight physics. Optional local profiling measures controller execution time and cache work.

## Requirements and installation

Requires SKSE matching the game executable and the matching Address Library database. Targets: SE 1.5.97; AE 1.6.640, 1.6.659, 1.6.1170, 1.6.1179 and 1.7.104. VR and other runtime versions are rejected. Requires the Microsoft Visual C++ x64 runtime used by the Windows build. No required SkyUI, Papyrus extension, external decapitation mod or custom art assets.

Drop held targets, wait twenty seconds and save before updating. In Vortex, disable the old version, install the **installer** ZIP, enable `TelekinesisCombat.esp`, deploy and launch through SKSE. Install matching release files. When updating from 0.2.1–0.2.11, you may keep a customized INI. Missing new keys use safe defaults: orbit off, camera shake off. The companion and spell IDs are unchanged. Keep a separate test save.

```text
Data/TelekinesisCombat.esp
Data/SKSE/Plugins/TelekinesisCombat.dll
Data/SKSE/Plugins/TelekinesisCombat.ini
```

The companion remains ESL-flagged with six private forms 0x800-0x805, requires Skyrim.esm only and makes no vanilla overrides. Existing spell IDs are unchanged. Never compact or renumber an installed companion. Regeneration/manual record setup: `docs/CreationKit.md`.

Acquire the spell through the console:

```text
help "Combat Telekinesis" 4
player.addspell <SPEL FormID shown by help>
```

Equip **Combat Telekinesis**. Vanilla Telekinesis remains available separately.

## Controls

| Control | Action |
| --- | --- |
| Hold the equipped spell's mapped casting button | Grab/suspend the aimed eligible actor or loose object; retry until available |
| Shift held when starting the cast | Disarm the aimed hostile drawn weapon; otherwise catch an incoming hostile aimed missile; otherwise grab the nearest visible loose item within 300 units, including behind the player |
| Release that casting button | Throw a prop/actor; return a held missile using the configured direction |
| Mouse wheel up/down | Pull nearer / push farther |
| Press Shift during an existing grip, then release cast | Downward slam. If Shift acquired the target, release it and press again to arm a slam. Missiles return instead |
| Activate (normally E) | Collect a nearby held item using native activation; dissipate a missile; otherwise drop. Hold on a weakened actor to execute; early release drops |
| Opposite casting button with the spell in both hands | Hold to charge execution on a weakened held actor |
| F10 | Open optional settings; releases any grip first. Spell need not be equipped |

Casting/Activate follow Skyrim mappings, including gamepad. Modifier/wheel/settings shortcuts use keyboard/mouse. Use **More** to cycle the compact numbered settings pages; **Back** returns to the main settings and **Close** exits. Edits stay on the current page. Transitions wait until the old box closes. Choosing Balanced/Powerful shows an applied-and-saved HUD message; the home screen also shows the current damage scale/cap/hold cost. Rebind settings/modifier/legacy keys in F10 > Controls. Rebinding waits ten unpaused seconds for a keyboard key; Escape cancels, duplicates reject. Rebinding the primary modifier clears its secondary binding; restoring defaults reinstates both Shift keys. Legacy G/H/J/K/L/X controls remain disabled unless enabled.

## Orbit and impact feedback (0.2.5–0.2.6)

Enable **F10 > Objects > More until Orbit > Orbit**. This mode affects loose items only; actors and caught spell missiles keep their existing controls. With orbit off, ordinary single-item grabbing stays on the crosshair.

Hold cast while aiming at visible clutter/weapons. Up to three items gather into a compact, crosshair-centered rotating ring, at most one extra item per 0.4 seconds once the primary grip settles. Acquisition uses the smaller of normal Range and `Orbit.AcquireRange` (1200 default); extra items must also be in a 10-degree cone and visible. Already flying items are excluded. Release cast to fire the current item; the others remain held. Press/release the same casting button again for each next shot. Holding again can refill free slots. There is no idle auto-refill or enemy homing. Shift slams one item. Activate/E collects the current item if it is within normal pickup reach, and releases the others; otherwise it drops the whole ring.

Every acquired item pays GrabCost; each held item pays HoldCostPerSecond, including between shots; each launched item pays LaunchCost. Existing perk/enchantment cost reductions still apply. Empty Magicka, unequipping, invalid/world-changing references, loading or opening settings safely release the ring. Pull/push keeps the ring 140–220 units ahead of the player (160 by default), with the usual third-person camera-depth adjustment. `Orbit.Radius` is a desired radius of 50 units, configurable from 25 to 60; the effective radius is also capped at 28% of camera depth (about 15.65 degrees from the crosshair). Existing 0.2.5 INIs with Radius=110 are automatically limited to 60. The ring has no upward center offset. Clutter spin stays suppressed, melee weapons turn toward the aimed point, and stable slots prevent the remaining items from changing positions when a shot is fired. Collision is preserved and wall sweeps constrain travel. Bounds-based spacing fits ordinary props and skips oversized extra items; large/custom meshes and wall crowding still require in-game checks. The visibility limit covers item centers, not entire meshes or unusually narrow/custom camera views.

Confirmed contacts use the existing material/weapon impact data with force-scaled particle size and sound levels. Combat text confirmations are disabled. **F10 > Feedback** offers the Camera shake toggle. Camera shake is off by default, limited to 0.14 strength/0.12 seconds, attenuated over 1000 units, and throttled to once per 0.2 seconds. EffectsAndSounds disables all of this feedback. No extra damage, slow motion, new art, scripts or companion records are added.

## Object damage and presets

For a confirmed prop hit above `ImpactMinSpeed=450`:

```text
ratio = clamp(speed / 3600, 0, 1.25)
kinetic = boundedWeight * speed^2 * ImpactDamageMultiplier / 1,000,000
weapon = baseWeaponDamage * WeaponBaseDamageScale * ratio * archetypeFactor
raw = clamp(max(minimumHit * ratio, kinetic + weapon) * ObjectDamageScale, 0, MaxImpactDamage)
final = raw * (1 - cappedArmorReduction * (1 - penetration)) * outgoingDifficultyMultiplier
```

Defaults: weight floor 5/cap 40; kinetic scale 1.2; weapon base scale 12; clutter floor 25/weapon floor 80; raw cap 1200. Dagger factor 0.9 and 15% penetration; mace/warhammer factor 1.1 and 25% penetration; other weapons factor 1 and no penetration. Uses base record weapon damage; tempering, enchantment procs, poisons, blocking, sneak attacks and every melee-specific perk are not simulated. Disarmed items retain actual enchantment/tempering extras for pickup.

At speed 3600, before armor/difficulty:

| Example | Weight / base weapon damage | Balanced raw | Powerful raw |
| --- | --- | --- | --- |
| Light clutter | 5 / 0 | 77.8 | 140.0 |
| Dagger | 5 / 5 | 131.8 | 237.2 |
| Sword | 10 / 10 | 275.5 | 495.9 |
| Warhammer | 25 / 25 | 718.8 | 1293.8 |

Presets immediately replace these settings and save them to the INI; they are tuning bundles, not a toggle that must stay enabled.

| Setting | Balanced | Powerful |
| --- | --- | --- |
| Object damage scale / raw cap | 1.0 / 1200 | 1.8 / 2000 |
| Grab / hold per second / launch Magicka | 15 / 12 / 10 | 10 / 7 / 6 |
| Execution / disarm / projectile catch Magicka | 40 / 25 / 15 | 30 / 18 / 10 |
| Level resistance factor | 0.04 | 0.02 |
| Finisher health threshold | 35% | 40% |
| Projectile capture radius / prediction | 400 / 0.25 seconds | 550 / 0.35 seconds |

Costs shown are before perk/enchantment reductions. Both presets also restore kinetic scale 1.2, weapon base scale 12 and clutter/weapon minimum hit values 25/80. Other settings retain their current values.

Powerful uses scale 1.8, cap 2000, lower costs/resistance and wider capture. Balanced restores the defaults above. Both preserve controls, NPC throw/slam fractions, lethal level gap and immunity toggles. Armor/difficulty toggles are independent. Legendary's native outgoing multiplier further reduces damage.

Each prop damages one victim once. Bounded shape extents sweep against moving actor bounds to register fast blade hits when Havok misses. Visibility checks prevent through-wall hits; the prop stops at confirmed contact. Unconfirmed slowdown keeps tracking. Contacts approximate boxes, not exact blade/limb meshes.

NPC throws/slams retain their rules: at equal levels/configured speed, throws deal 20% of maximum Health and slams 30%, capped at 45%. A ten-level player advantage permits lethal impact. A descending non-slam cliff landing after at least 800 vertical units can kill independently of level. Otherwise a slam leaves at least 1 Health and queues native disarm. Weakened actors may die from ordinary throws. Native fall/Havok damage and other mods can add damage. New armor/difficulty calculations apply to loose objects; explicit NPC/finisher rules remain separate.

## Holding, missiles and finishers

Props hover on the actual camera crosshair ray 160 units ahead; third-person adds camera-to-player depth. Actors use 300 units. Clutter suppresses spin while held. Single-body melee weapons face the crosshair point while held or orbiting: swords/daggers use their tips, axes/maces/clubs/hammers their head end. All use the measured stock local +Y hilt-to-tip/head axis; multi-body weapons retain their orientation, and custom mesh axes may need calibration. One shared aim ray ignores the player and other orbit items; each weapon turns toward that same point without enemy homing. Native angular steering preserves the held COM, while launch rotation preserves COM and faces travel direction. The legacy `Physics.OrientSwords=0` key disables melee aiming/alignment; 1 is the default. Distant props retrieve at up to 10000 units/second. Walls constrain travel. E collects a visible prop within 260 units of player bounds centre through normal activation/ownership behavior.

Corpses and live ragdolls are supported. Living actors use native zero-force knockdown plus a recovering private `Grabbed` modifier refreshed without stacking. No paralysis or health drain. Children, essential actors, dragons, giants, killmove actors, oversized actors and externally controlled targets reject acquisition; protected actors are immune by default. Ordinary creatures/undead are enabled. Size/level resistance multiplies actor action/hold costs.

Incoming hostile fire-and-forget aimed missiles with matching source spell/effect qualify (e.g. Fireball, Ice Spike/Icy Spear). Closest approach must occur within `ProjectileLookAheadSeconds=0.25` and `ProjectileThreatRadius=110`. Capture radius is 400 units with one controller interval of swept lead. Player/friendly missiles, beams/flames/cones, hitscan, timed/proximity alternative triggers and continuous-update variants are excluded. Ordinary hostile arrows/bolts are supported separately as described above; special exploding ammunition is excluded. Prediction uses the player's current centre; unusual acceleration or severe hitches can still evade capture.

The actual missile suspends visibly for up to eight seconds. Only its native movement/impact/lifetime handlers are suppressed. Return first safely kills the suspended hostile reference, then uses native launch with original source/power/scale/speed and player collision group/attribution. `ProjectileReturnMode=0` selects the original living, loaded, visible caster once, falling back to crosshair; mode 1 always uses the crosshair. No homing or extra prop damage on returned spells.

Movement/impact hooks install once on both missile and arrow vtables so capture can toggle live. Every unheld projectile forwards to previous handlers. `CatchProjectiles=0` prevents acquisition; it does not remove installed hooks. E, timeout, depleted Magicka, unequip, load/world loss or save dissipates the missile without intentionally detonating it. Pausing freezes costs/timers. Held missiles are not serialized.

Execution requires an eligible held actor at <=35% maximum Health, a full one-second charge and Magicka. Damage/death notification runs first. Final VFX/sound/event and optional native beheading wait up to two seconds for confirmed death. Decapitation requires a humanoid race with decapitation armor; unsupported races retain the lethal finisher. Disable decapitation for incompatible head/skeleton/overlay mods. Optional Papyrus cosmetic listeners remain available but are unnecessary and can duplicate native feedback.

## Settings, progression and performance

INI: `Data/SKSE/Plugins/TelekinesisCombat.ini`. Native settings apply immediately and persist using Windows profile APIs. Write failures produce a HUD message/log; session settings still apply. Vortex can replace deployed edits on redeployment: back up the INI or copy it into staging files. Reload INI resets defaults first. Form IDs/plugin identity require restart. `SettingsMenu=0`, `TargetPreview=0` and `EffectsAndSounds=0` disable the corresponding features independently.

Base costs: grab 15, hold 12/second, launch 10, disarm 25, catch 15, execution 40. Cost reduction applies Fortify Alteration, then native spell-cost entry points to the nonzero action amount. The private spell identifies as novice Alteration, so vanilla Novice Alteration applies its novice-spell reduction. Other perk overhauls depend on their conditions. The cosmetic spell's zero calculated cost is never substituted. Failed native disarm refunds exactly the reduced amount actually charged.

Successful actions against already-hostile eligible actors grant Alteration XP: impacts 1-8 units based on damage, disarm 6, catch 5, multiplied by `AlterationXPScale`. A two-second per-enemy cooldown and replenishing game-time budget (`MaxAlterationXPPerMinute=60`) limit repetition. Idle holding, ordinary item pickup, corpses and friendly targets grant no XP. Repeated combat actions remain eligible after cooldown; the budget/cooldowns are transient and not saved.

`CandidateCacheSeconds=0.25` caches loaded handles; `SearchInterval=0.12` throttles actor/prop selection. Missile acquisition polls at the 16 ms controller cadence while waiting in Shift mode. Existing flights update physical bounds/motion each tick. Handles revalidate before mutation; no Havok body or scene pointer is cached across tasks. Cache clears on world/load/settings changes. `Profile=1` logs five-second controller mean/peak execution time, ticks/scans and candidate counts locally; no telemetry. These counters support measurement and do not establish a measured frame-time improvement.

## Build and validation

Windows x64, Visual Studio 2022 C++ tools, CMake >=3.24 and vcpkg build the native DLL. CommonLibSSE NG v10.1.0 is pinned, using C++23 with SE/AE enabled and VR disabled. GitHub Actions can build without installing a compiler on the gaming PC.

```powershell
cmake -S . -B build -A x64 -DCMAKE_TOOLCHAIN_FILE=C:/vcpkg/scripts/buildsystems/vcpkg.cmake -DVCPKG_TARGET_TRIPLET=x64-windows-static -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
python -m unittest discover -s tests -v
python tools/package.py --dll build/Release/TelekinesisCombat.dll --output dist/TelekinesisCombat-0.2.12-install.zip
```

Three CTests cover compact menu navigation/label budgets, combat/orbit/impact math and input, mocked SE/AE accessors, prop motion/form eligibility and shader selection, and native settings persistence/presets/bounds. `-DTKC_MATH_ONLY=ON` builds math checks alone. Packaging rejects missing/non-x64 DLLs. Source: `python tools/package.py --source --output dist/TelekinesisCombat-0.2.12-source.zip`. `tools/inspect_binary.py` checks exports/imports without loading a DLL. Complete `docs/TESTING.md` in a test profile before treating this as stable.

## Compatibility and cleanup

Avoid multiple ragdoll/telekinesis controllers on the same target. Test custom skeletons/heads, actor physics, animation behaviors, projectile/reflection hooks and combat/armor overhauls individually. Armor/difficulty support does not recreate all native melee hit events, shields, crime reporting or enchantment procs. Stock record overrides can alter feedback. Native shaders/particles, message-box callbacks and missile hooks need in-game validation across target runtimes.

Controller mutations run on the game thread, with bounded flights and world locks for physics. Loading/scene loss clears cached handles and pending execution/rebind state. Private suspension expires within two unpaused seconds after interruption; no gravity/AI override or permanent paralysis is saved. Read `TelekinesisCombat.log` for errors; do not bypass a required Address Library error.

Before removal: drop targets, wait twenty seconds, save away from combat and disable DLL/ESP together in a test profile. Retain the original save.
