"""Produce a source archive or a mod-manager archive, never an empty DLL installer."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import zipfile
from companion import validate

ROOT = Path(__file__).resolve().parents[1]

def check_dll(path):
    data = Path(path).read_bytes()
    if len(data) < 128 or data[:2] != b'MZ':
        raise ValueError('Plugin is not a Windows PE binary')
    pe = struct.unpack_from('<I', data, 0x3C)[0]
    if pe+24 > len(data) or data[pe:pe+4] != b'PE\0\0':
        raise ValueError('Invalid PE header')
    machine, = struct.unpack_from('<H', data, pe+4)
    characteristics, = struct.unpack_from('<H', data, pe+22)
    if machine != 0x8664 or not characteristics & 0x2000:
        raise ValueError('Plugin must be an x64 DLL')

def package(source=False, dll=None, output=None):
    if source:
        output = Path(output or ROOT/'dist/TelekinesisCombat-0.1.0-source.zip')
        excluded = {'build', 'dist', '__pycache__', '.git', 'external'}
        entries = [(p, Path('TelekinesisCombat')/p.relative_to(ROOT))
                   for p in ROOT.rglob('*') if p.is_file() and
                   not any(part in excluded for part in p.relative_to(ROOT).parts)]
    else:
        if not dll:
            raise ValueError('Supply --dll build/Release/TelekinesisCombat.dll after a successful build')
        dll = Path(dll)
        check_dll(dll)
        validate(ROOT/'Data/TelekinesisCombat.esp')
        output = Path(output or ROOT/'dist/TelekinesisCombat-0.1.0.zip')
        entries = [(p, p.relative_to(ROOT/'Data')) for p in (ROOT/'Data').rglob('*') if p.is_file()]
        entries += [(dll, Path('SKSE/Plugins/TelekinesisCombat.dll')),
                    (ROOT/'README.md', Path('docs/TelekinesisCombat/README.md')),
                    (ROOT/'LICENSE', Path('docs/TelekinesisCombat/LICENSE'))]
        symbols = dll.with_suffix('.pdb')
        if symbols.is_file():
            entries.append((symbols, Path('SKSE/Plugins/TelekinesisCombat.pdb')))
        entries += [(p, Path('docs/TelekinesisCombat')/p.name) for p in (ROOT/'docs').glob('*.md')]
    output.parent.mkdir(parents=True, exist_ok=True)
    hashes = {}
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path, name in sorted(entries):
            archive.write(path, str(name).replace('\\', '/'))
            hashes[str(name).replace('\\', '/')] = hashlib.sha256(path.read_bytes()).hexdigest()
        archive.writestr('SHA256SUMS.json', json.dumps(hashes, indent=2)+'\n')
    return output

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', action='store_true')
    parser.add_argument('--dll', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        print(package(args.source, args.dll, args.output))
    except (ValueError, OSError) as error:
        parser.exit(1, str(error)+'\n')
