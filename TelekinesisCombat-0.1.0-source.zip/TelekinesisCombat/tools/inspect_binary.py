"""Read PE exports/imports without loading or executing a plugin."""
import argparse
import json
import struct
from pathlib import Path
from package import check_dll

def inspect(path):
    check_dll(path)
    data = Path(path).read_bytes()
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    count, = struct.unpack_from('<H', data, pe+6)
    size, = struct.unpack_from('<H', data, pe+20)
    optional = pe+24
    if struct.unpack_from('<H', data, optional)[0] != 0x20b:
        raise ValueError('Expected PE32+')
    sections = []
    for i in range(count):
        at = optional+size+i*40
        virtual_size, rva, raw_size, offset = struct.unpack_from('<IIII', data, at+8)
        sections.append((rva, max(virtual_size, raw_size), offset))
    def raw(rva):
        for base, length, offset in sections:
            if base <= rva < base+length:
                return offset+rva-base
        raise ValueError(f'Unmapped RVA {rva:x}')
    def string(rva):
        at = raw(rva)
        return data[at:data.index(b'\0', at)].decode('ascii')
    export_rva, = struct.unpack_from('<I', data, optional+112)
    exports = []
    if export_rva:
        at = raw(export_rva)
        names_count, = struct.unpack_from('<I', data, at+24)
        names_rva, = struct.unpack_from('<I', data, at+32)
        for i in range(names_count):
            name_rva, = struct.unpack_from('<I', data, raw(names_rva)+i*4)
            exports.append(string(name_rva))
    imports = []
    import_rva, = struct.unpack_from('<I', data, optional+120)
    if import_rva:
        at = raw(import_rva)
        while any(data[at:at+20]):
            name_rva, = struct.unpack_from('<I', data, at+12)
            imports.append(string(name_rva))
            at += 20
    required = {'SKSEPlugin_Load', 'SKSEPlugin_Version'}
    if not required.issubset(exports):
        raise ValueError(f'Missing SKSE exports: {required-set(exports)}')
    return {'architecture': 'x64', 'exports': exports, 'imports': imports}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dll', type=Path)
    print(json.dumps(inspect(parser.parse_args().dll), indent=2))
