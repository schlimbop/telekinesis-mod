"""Generate six new records from an owned, unmodified Skyrim.esm (read-only).

Only whitelisted record fields are copied; no textures, meshes, or master overrides.
Record layouts: TES5Edit's wbDefinitionsTES5.pas, SPEL/MGEF/TES4 definitions.
"""
from pathlib import Path
import argparse
import struct as s
import zlib

HEADER = s.Struct('<4sIIIIHH')
U32 = s.Struct('<I')

def subrecords(payload):
    cursor = 0
    extended = None
    while cursor < len(payload):
        if cursor + 6 > len(payload):
            raise ValueError('Truncated subrecord header')
        tag, size = s.unpack_from('<4sH', payload, cursor)
        cursor += 6
        if tag == b'XXXX':
            if size != 4 or cursor + 4 > len(payload):
                raise ValueError('Invalid extended subrecord')
            extended = U32.unpack_from(payload, cursor)[0]
            cursor += 4
            continue
        if extended is not None:
            size, extended = extended, None
        if cursor + size > len(payload):
            raise ValueError('Truncated subrecord')
        yield tag, payload[cursor:cursor+size]
        cursor += size
    if extended is not None:
        raise ValueError('Orphan XXXX')

def records(path, wanted=None):
    with Path(path).open('rb') as stream:
        def walk(end):
            while stream.tell() < end:
                start = stream.tell()
                header = stream.read(24)
                if len(header) != 24:
                    raise ValueError('Truncated record header')
                tag, size, flags, form, _, version, _ = HEADER.unpack(header)
                if tag == b'GRUP':
                    if size < 24 or start+size > end:
                        raise ValueError('Invalid group length')
                    yield from walk(start+size)
                    continue
                if stream.tell()+size > end:
                    raise ValueError('Record crosses group boundary')
                if wanted is not None and tag not in wanted:
                    stream.seek(size, 1)
                    continue
                payload = stream.read(size)
                if flags & 0x40000:
                    expected = U32.unpack_from(payload)[0]
                    payload = zlib.decompress(payload[4:])
                    if len(payload) != expected:
                        raise ValueError('Invalid compressed size')
                entries = list(subrecords(payload))
                fields = dict(entries)
                if tag == b'SPEL':
                    fields[b'_EFIDS'] = [v for k, v in entries if k == b'EFID']
                yield tag, form, flags, fields
        yield from walk(Path(path).stat().st_size)

def sub(tag, value):
    if isinstance(value, str):
        value = value.encode('utf-8') + b'\0'
    if len(value) > 65535:
        return b'XXXX\x04\x00' + U32.pack(len(value)) + tag + b'\0\0' + value
    return tag + s.pack('<H', len(value)) + value

def record(tag, form, fields, flags=0):
    payload = b''.join(sub(key, value) for key, value in fields)
    return HEADER.pack(tag, len(payload), flags, form, 0, 44, 0) + payload

def group(tag, items):
    data = b''.join(items)
    return s.pack('<4sI4sIHHI', b'GRUP', 24+len(data), tag, 0, 0, 0, 0) + data

def editor_id(fields):
    return fields.get(b'EDID', b'').rstrip(b'\0').decode('ascii')

def generate(master, destination):
    if Path(master).name.lower() != 'skyrim.esm':
        raise ValueError('Use the original Skyrim.esm, not an override plugin')
    spells = {}
    effects = {}
    for tag, form, flags, fields in records(master, {b'SPEL', b'MGEF'}):
        if form >> 24:
            raise ValueError('Unexpected non-Skyrim master FormID')
        if tag == b'MGEF':
            effects[form] = fields
        else:
            spells[editor_id(fields).lower()] = fields
    tele = spells.get('telekinesis')
    paralyze = spells.get('paralyze')
    if not tele or not paralyze:
        raise ValueError('Vanilla Telekinesis/Paralyze records not found')
    tele_effect = effects[U32.unpack(tele[b'EFID'])[0]]
    para_effect = next((effects[U32.unpack(v)[0]] for v in paralyze[b'_EFIDS']
                        if U32.unpack_from(effects[U32.unpack(v)[0]][b'DATA'], 64)[0] == 21), None)
    if para_effect is None:
        raise ValueError('Paralyze has no paralysis effect')
    if U32.unpack_from(tele_effect[b'DATA'], 64)[0] != 20:
        raise ValueError('Unexpected telekinesis archetype')
    if U32.unpack_from(para_effect[b'DATA'], 64)[0] != 21:
        raise ValueError('Unexpected paralysis archetype')
    shock = next((f for f in effects.values()
                  if editor_id(f).lower() == 'shockdamageffcontact'), para_effect)

    def effect(local, name, template, archetype, cast, delivery, cosmetic=False):
        data = bytearray(template[b'DATA'])
        if len(data) != 152:
            raise ValueError('Unexpected MGEF DATA layout')
        # Keep only inherited visual/sound fields. Clear gameplay references and conditions.
        flags = 0x800 | 0x400 | 0x10  # no area, no magnitude, no hit event
        if not cosmetic:
            flags |= 0x8000 | 1 | 4  # hidden, hostile, detrimental
        if cast == 2:
            flags |= 0x200  # duration comes from concentration
        s.pack_into('<I', data, 0, flags)
        s.pack_into('<f', data, 4, 0.)
        for offset in (8, 20, 40, 44, 48, 52, 56, 60, 72, 76, 108, 112, 116, 120, 124, 128, 132, 140, 144, 148):
            U32.pack_into(data, offset, 0)
        s.pack_into('<i', data, 12, 18)  # Alteration
        s.pack_into('<i', data, 16, -1)  # resistance handled by SKSE
        U32.pack_into(data, 64, archetype)
        s.pack_into('<i', data, 68, 53 if archetype == 21 else -1)
        U32.pack_into(data, 80, cast)
        U32.pack_into(data, 84, delivery)
        s.pack_into('<i', data, 88, -1)
        s.pack_into('<f', data, 104, 0.)
        if cosmetic and delivery == 0:
            for offset in (24, 32, 36, 92, 96, 100):
                U32.pack_into(data, offset, 0)
        fields = [(b'EDID', name), (b'FULL', 'Telekinetic grip'), (b'DATA', bytes(data))]
        if b'SNDD' in template:
            fields.append((b'SNDD', template[b'SNDD']))
        fields.append((b'DNAM', ''))
        return record(b'MGEF', 0x01000000 | local, fields)

    def spell(local, name, full, template, effect_local, cast, delivery, duration):
        fields = [(b'EDID', name), (b'OBND', template.get(b'OBND', bytes(12))), (b'FULL', full)]
        for tag in (b'MDOB', b'ETYP'):
            if tag in template:
                fields.append((tag, template[tag]))
        fields += [
            (b'DESC', 'Hold cast to grab; release to throw. Wheel adjusts distance; Shift-release slams. Equip in both hands for the finisher. See README.' if local == 0x800 else ''),
            (b'SPIT', s.pack('<IIIfIIffI', 0, 1 | 0x100000 | 0x200000, 0, 0., cast, delivery, 0., 0., 0)),
            (b'EFID', U32.pack(0x01000000 | effect_local)),
            (b'EFIT', s.pack('<fII', 1., 0, duration)),
        ]
        return record(b'SPEL', 0x01000000 | local, fields)

    mgefs = [effect(0x802, 'TKC_HoldEffect', para_effect, 21, 1, 3),
             effect(0x803, 'TKC_ControlEffect', tele_effect, 1, 2, 0, True),
             effect(0x805, 'TKC_CrushEffect', shock, 1, 1, 3, True)]
    spels = [spell(0x800, 'TKC_CombatTelekinesis', 'Combat Telekinesis', tele, 0x803, 2, 0, 0),
             spell(0x801, 'TKC_Hold', 'Telekinetic Suspension (internal)', paralyze, 0x802, 1, 3, 2),
             spell(0x804, 'TKC_CrushVisual', 'Telekinetic Crush (internal)', paralyze, 0x805, 1, 3, 1)]
    header = record(b'TES4', 0, [
        (b'HEDR', s.pack('<fII', 1.7, 6, 0x806)),
        (b'CNAM', 'TelekinesisCombat'),
        (b'SNAM', 'Combat Telekinesis 0.1: requires SKSE plugin. Six new forms, no overrides.'),
        (b'MAST', 'Skyrim.esm'), (b'DATA', bytes(8)),
    ], 0x200)  # ESL flag; old-runtime-safe IDs >= 0x800
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(header + group(b'MGEF', mgefs) + group(b'SPEL', spels))
    validate(destination)
    return destination

def validate(path):
    result = list(records(path))
    if len(result) != 7 or result[0][0] != b'TES4' or not result[0][2] & 0x200:
        raise ValueError('Invalid header/count/ESL flag')
    if {r[1] for r in result[1:]} != {0x01000800+i for i in range(6)}:
        raise ValueError('Unexpected form IDs')
    if result[0][3][b'MAST'] != b'Skyrim.esm\0':
        raise ValueError('Unexpected master')
    for tag, form, flags, fields in result[1:]:
        if tag == b'SPEL':
            if len(fields[b'SPIT']) != 36 or len(fields[b'EFIT']) != 12:
                raise ValueError('Invalid spell layout')
            if U32.unpack(fields[b'EFID'])[0] not in {0x01000802, 0x01000803, 0x01000805}:
                raise ValueError('Unresolved local effect')
            if form == 0x01000801 and U32.unpack_from(fields[b'EFIT'], 8)[0] != 2:
                raise ValueError('Hold must expire in two seconds')
        elif tag == b'MGEF':
            if len(fields[b'DATA']) != 152:
                raise ValueError('Invalid magic effect layout')
            if any(k in fields for k in (b'VMAD', b'CTDA', b'ESCE')):
                raise ValueError('Unexpected scripts/conditions/counter effects')
        else:
            raise ValueError('Unexpected override/record type')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('master', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1]/'Data/TelekinesisCombat.esp')
    args = parser.parse_args()
    print(generate(args.master, args.output))
