# Skyrim Dynasty 0.8.0

Choose **Breeding** in ordinary dialogue with a living adult female NPC who is neither hostile nor fighting. A named adult heir is summoned beside the player with a conjuration portal and sound. Player and speaker are the genetic parents. No Creation Kit assembly is needed.

## New in this build

- New heirs receive individual equipment drawn from playable weapons, armour and ammunition in the entire installed load order, including DLC, ESP and ESL mods. There are no preset-kit restrictions. Armour must have a model for the heir's sex/race; pieces cannot overlap occupied slots; ranged weapons receive matching arrows or bolts and two-handed weapons cannot be combined with shields. Every eligible item keeps a nonzero selection chance. Quality biases value without excluding tiers.
- Warrior, archer, mage, rogue and craftsman roles are weighted by inherited skills. Each heir receives an individually varied ground combat style. Dialogue can change the role. Mages can receive suitable installed Destruction combat spells; scripted and high-skill effects are excluded. Craftsman is a cautious combat role, not an autonomous crafting/economy simulator.
- Ordinary heir activation opens speech dialogue for following, waiting, trading equipment, assigning residence, going home, dismissal, ancestry, abilities and combat roles. The old activation command popup is no longer used. Enable subtitles; Fuz Ro D-oh is recommended for silent responses.
- Residents can wander locally and use available beds and eating furniture on daily schedules. Assigned locations must have usable navigation and furniture. Dismissed heirs return to their assigned home. Recall is available in the MCM and orders the heir to wait beside you.
- The optional SkyUI MCM configures living capacity (1–32), inherited skill/external morph strength, gear quality bias, female probability, summon effects, story-perk filtering and combat variation. Settings are stored in the SKSE co-save. Lowering capacity does not remove living heirs.
- The MCM includes a paged genealogy journal with parentage, generation, skills, residence and alive/dead/successor status. Historical entries are compact records; deaths do not retain every actor reference. There is no fixed lifetime entry/birth cap.
- The succession choice previews ancestry, role, strongest skills, inherited perk count and actual equipped items. The MCM's recall action lets you inspect a living heir's appearance before defeat. On defeat, choose a living adult; identity, inherited appearance, skills/perks and actual equipment transfer and their NPC slot is freed.

## Appearance inheritance

Native inheritance retains 19 independently sampled facial traits, parental nose/eye/mouth presets, eye parts, compatible hair, hair RGB, skin RGB, weight and height. The saved phenotype is stable across loads. The loaded face receives the same RGB skin colour as the body, and texture families follow the inherited race. Human/elf pairings can combine an elf-shaped head with a lighter skin tone and compatible red eyes. A parental race still supplies the skeleton/head family; this does not create a new hybrid mesh.

The optional RaceMenu bridge adds live BodyMorph slider inheritance when a compatible SKEE BodyMorph v4/v5 interface is available. Morph-enabled BodySlide meshes are required. It only writes its own `SkyrimDynasty` morph key. A compatible provider exposing the public Preset v1 interface can additionally supply custom face sliders and matched-topology sculpts. Stock upstream RaceMenu does not expose that Preset interface in its interface map, so custom sculpt transfer is **not guaranteed by installing RaceMenu**. The log reports both detected interfaces. Baked replacement faces, arbitrary overlays and body presets without live morph data cannot be reconstructed universally.

The v0.7.1 player-tint layout crash fix remains, including regression checks for Skyrim 1.7.104. The build uses CommonLib runtime accessors rather than the stale GetTintList offset.

## Installation and upgrading

Fully replace the previous Dynasty version in Vortex with `SkyrimDynasty_v0.8.0_Vortex.zip`, enable/deploy and leave `DynastyHeirs.esp` enabled. Restart through matching SKSE64 with Address Library. SkyUI is needed for the MCM; core birth and heir dialogue do not require it. RaceMenu is optional and must support your exact Skyrim runtime. Back up the ESS/SKSE save pair and keep the files together.

Existing v0.6/v0.7 heirs keep their current equipment and inventory changes. New heirs use the installed-item generator. Existing heirs can change combat role through dialogue; historical events before this version cannot be reconstructed if the old actor/genome has already been removed. Existing v0.6 native appearance data retains its migration path. Old deployed template FaceGen overrides from v0.5 must be removed if still present.

There are 32 reusable living slots and no lifetime birth cap. Heirs remain mortal and non-essential/non-protected. Summon arrival, courier-style greeting, follower commands, residence, save persistence and succession remain supported.

## Verification

See `VALIDATION.txt` for performed checks and `TESTING.md` for the in-game acceptance checks still needed. No gameplay or visual correctness is claimed from compilation. Corresponding source/build scripts are included under `Source`; see `LICENSE` and `THIRD_PARTY_NOTICES.txt`.
