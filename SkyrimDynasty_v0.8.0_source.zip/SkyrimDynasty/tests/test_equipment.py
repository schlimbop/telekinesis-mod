"""Exercise the actual equipment routine with a loaded/unloaded actor and saved choice."""
from pathlib import Path
from types import SimpleNamespace as NS
import re, unittest
S=(Path(__file__).resolve().parents[1]/'Data/Scripts/Source/DynastyLifecycleQuest.psc').read_text()
def routine(env):
    text=re.search(r'Function EquipRandomAdultLoadout\(Actor akAdult\)\n(.*?)\nEndFunction',S,re.S)[1]
    lines=['def equip(akAdult):','    global AdultLoadouts, LoadoutChoices'];depth=1
    for raw in text.splitlines():
        line=raw.split(';',1)[0].strip()
        if not line or line.startswith('Debug.Trace('):continue
        if line in ['endif','endwhile']:depth-=1;continue
        line=line.replace('items.Length','len(items)')
        line=line.replace('LoadoutChoices.Length', 'len(LoadoutChoices)').replace('new Int[32]', '[0]*32')
        line=line.replace('(item as Armor)','isinstance(item, Armor)').replace('item as Ammo','isinstance(item, Ammo)')
        line=re.sub(r'\s+as (?:FormList|Outfit)\b','',line)
        line=re.sub(r'^(?:Int|Outfit|FormList|Form\[\]|Form)\s+','',line)
        line=line.replace('&&',' and ').replace('||',' or ')
        line=re.sub(r'!(?!=)','not ',line)
        block=line.startswith(('if ','while '))
        lines.append('    '*depth+line+(':' if block else ''))
        if block:depth+=1
    exec('\n'.join(lines),env)
class Armor:pass
class Ammo:pass
class Actor:
    def __init__(self,loaded=True):self.loaded=loaded;self.inventory={};self.equipped=[];self.outfits=[]
    def Is3DLoaded(self):return self.loaded
    def SetOutfit(self,items,_):
        self.outfits.append(items)
        for item in items:self.inventory[item]=1
    def GetItemCount(self,item):return self.inventory.get(item,0)
    def AddItem(self,item,count,_):self.inventory[item]=self.GetItemCount(item)+count
    def EquipItem(self,item,*_):
        assert self.GetItemCount(item)>0
        self.equipped.append(item)
    def GetDisplayName(self):return 'Heir'
class EquipmentTests(unittest.TestCase):
    def setUp(self):
        self.armor=[Armor(),Armor(),Armor()];self.weapon=object();self.ammo=Ammo();self.rolls=[]
        items=self.armor+[self.weapon,self.ammo]
        def generate(*args):self.rolls.append(args);return items
        self.env=dict(Armor=Armor,Ammo=Ammo,LoadoutChoices=[0]*32,
            FindHeirIndex=lambda a:0,AdultLoadouts=None,
            DynastyNative=NS(GenerateLoadout=generate,PrepareOutfit=lambda actor:self.armor),
            GiveCombatSpells=lambda actor:None,Debug=NS(Trace=lambda s:None))
        routine(self.env)
    def test_equipment_requires_loaded_actor(self):
        actor=Actor(False);self.env['equip'](actor)
        self.assertEqual(actor.inventory,{})
        self.assertEqual(self.rolls,[])
    def test_complete_set_and_persistent_choice_without_duplicate_items(self):
        actor=Actor();self.env['equip'](actor)
        self.assertEqual(self.env['LoadoutChoices'][0],-1)
        self.assertEqual(actor.GetItemCount(self.ammo),40)
        self.assertEqual(actor.GetItemCount(self.weapon),1)
        self.assertTrue(all(actor.GetItemCount(x)==1 for x in self.armor))
        snapshot=actor.inventory.copy();self.env['equip'](actor)
        self.assertEqual(actor.inventory,snapshot)
        self.assertEqual(len(self.rolls),1)
        self.assertEqual(len(actor.outfits),1)
    def test_legacy_inventory_is_not_replaced(self):
        actor=Actor();actor.inventory[self.weapon]=7;self.env['LoadoutChoices'][0]=3
        self.env['equip'](actor)
        self.assertEqual(actor.inventory,{self.weapon:7});self.assertEqual(self.rolls,[])
    def test_failed_native_generation_retries_on_next_load(self):
        self.env['DynastyNative'].GenerateLoadout=lambda *args:[]
        actor=Actor();self.env['equip'](actor)
        self.assertEqual(self.env['LoadoutChoices'][0],0)
        self.assertEqual(actor.inventory,{})
if __name__=='__main__' :unittest.main()
