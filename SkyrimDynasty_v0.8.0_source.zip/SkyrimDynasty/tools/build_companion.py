"""Build the Dynasty companion from an owned Skyrim.esm; no Creation Kit required.
Binary layouts follow TES5Edit dev-4.1.5 Core/wbDefinitionsTES5.pas.
Reads the master only; generates new forms, never overrides existing NPCs.
"""
from pathlib import Path
import argparse, json, struct as s
from collections import defaultdict
from esp import records,record,group,sub,editor_id,U32

ROOT=Path(__file__).resolve().parents[1]
F=lambda n:0x01000000|n

def vm_string(value):
    b=value.encode('utf-8');return s.pack('<H',len(b))+b

def obj(form,alias=-1):return s.pack('<HhI',0,alias,form)
def script(name,props=()):
    data=vm_string(name)+b'\0'+s.pack('<H',len(props))
    for prop,form,alias in props:data+=vm_string(prop)+b'\x01\x01'+obj(form,alias)
    return data

def vmad(name,props=(),aliases=(),quest=0,fragment=None,action=None):
    encoded=script(name,props)
    if action is not None:
        encoded=vm_string(name)+b'\0'+s.pack('<H',1)+vm_string('Action')+b'\x03\x01'+s.pack('<i',action)
    b=s.pack('<HHH',5,2,1)+encoded
    if fragment is not None:
        b+=bytes([2,fragment])+vm_string(name)+b'\x01'+vm_string(name)+vm_string('Fragment_0')
    elif quest:
        b+=b'\x02'+s.pack('<H',0)+vm_string('')+s.pack('<H',len(aliases))
        for alias,aname,aprops in aliases:b+=obj(quest,alias)+s.pack('<HHH',5,2,1)+script(aname,aprops)
    return b

def cond(fn,param=0,value=0.0,op=0,run=0,reference=0):
    # 32-byte CTDA; all generated tests use AND, no OR/global/alias switches.
    return s.pack('<B3xfH2xIIIIi',op,value,fn,param,0,run,reference,-1)

def alias(index,name,flags=0,reference=None,packages=()):
    a=[(b'ALST',U32.pack(index)),(b'ALID',name),(b'FNAM',U32.pack(flags))]
    if reference is not None:a.append((b'ALFR',U32.pack(reference)))
    a += [(b'ALPC',U32.pack(p)) for p in packages]
    return a+[(b'VTCK',U32.pack(0)),(b'ALED',b'')]

def generate(master,dest):
    if Path(master).name.lower()!='skyrim.esm':raise ValueError('Use the owned original Skyrim.esm')
    by_name={};all_ids=set()
    for tag,form,flags,fields in records(master):
        all_ids.add(form)
        if tag in {b'NPC_',b'PACK',b'ARMO',b'WEAP',b'AMMO',b'STAT',b'RACE',b'ACTI',b'EFSH',b'SOUN',b'CSTY'}:
            by_name[editor_id(fields)]=(tag,form,fields)
    result=defaultdict(list);forms={};faces={};refs=[]
    def add(tag,local,name,fields):
        assert local not in forms
        forms[local]=(tag,name)
        entries=[(b'EDID',name),*fields]
        result[tag].append(record(tag,F(local),entries))
    def form(name):return by_name[name][1]
    def flst(local,name,values):
        refs.extend(values);add(b'FLST',local,name,[(b'LNAM',U32.pack(x)) for x in values])
    # Private juvenile races retain their child models, skeletons and face assets.
    # Removing engine child immunity makes only dynasty juveniles mortal.
    # Age is still excluded explicitly in both dialogue conditions and script.
    def mortal_race(local,name,source):
        fields=[]
        for k,v in by_name[source][2][b'_entries']:
            if k==b'EDID':continue
            if k==b'FULL':v='Dynasty juvenile'
            if k==b'DESC':v=''
            if k==b'DATA':
                v=bytearray(v);s.pack_into('<I',v,32,U32.unpack_from(v,32)[0]&~4);v=bytes(v)
            fields.append((k,v))
        add(b'RACE',local,name,fields)
    mortal_race(0x850,'DYNA_MortalNordJuvenile','NordRaceChild')
    mortal_race(0x851,'DYNA_MortalRedguardJuvenile','RedguardRaceChild')
    def npc(local,name,source,adult):
        tag,source_id,f=by_name[source]
        excluded={b'EDID',b'VMAD',b'ACBS',b'SNAM',b'INAM',b'TPLT',b'SPCT',b'SPLO',b'PRKZ',b'PRKR',b'COCT',b'CNTO',b'PKID',b'FULL',b'SHRT',b'AIDT',b'SPOR',b'OCOR',b'GWOR',b'ECOR',b'SOFT'}
        if adult:excluded.add(b'DOFT')
        fields=[]
        for k,v in f[b'_entries']:
            if k==b'ACBS':
                acbs=bytearray(v);s.pack_into('<I',acbs,0,(U32.unpack_from(v)[0]&1)|(0x14 if adult else 0x30))
                s.pack_into('<h',acbs,8,10 if adult else 1);s.pack_into('<H',acbs,10,1);s.pack_into('<H',acbs,12,100);s.pack_into('<H',acbs,18,0)
                fields.append((k,bytes(acbs)))
            elif k==b'AIDT':
                ai=bytearray(v);ai[0]=0;ai[1]=4;ai[5]=1;fields.append((k,bytes(ai)))
            elif k==b'RNAM' and not adult:fields.append((k,U32.pack(F(0x850 if source=='LarsBattleBorn' else 0x851))))
            elif k not in excluded:fields.append((k,v))
        # Put VMAD before OBND/configuration, package before the class field.
        fields.insert(0,(b'VMAD',vmad('DynastyHeirActor',[('ManagerQuest',F(0x800),-1)])))
        at=next(i for i,(k,v) in enumerate(fields) if k==b'CNAM')
        fields[at:at]=[(b'PKID',U32.pack(F(pack))) for pack in (0xA80,0xA81,0xA82,0x806)]
        at=next(i for i,(k,v) in enumerate(fields) if k==b'DATA')
        fields.insert(at,(b'FULL','Heir'))
        add(b'NPC_',local,name,fields);faces[local]=source_id
    npc(0x810,'DYNA_ChildHeirMale','LarsBattleBorn',False)
    npc(0x811,'DYNA_ChildHeirFemale','Braith',False)
    for i in range(32):
        npc(0x900+i,f'DYNA_AdultHeirMale{i:02d}','Hadvar',True)
        npc(0x940+i,f'DYNA_AdultHeirFemale{i:02d}','HousecarlWhiterun',True)
    flst(0x820,'DYNA_AdultMaleBases',[F(0x900+i) for i in range(32)])
    flst(0x821,'DYNA_AdultFemaleBases',[F(0x940+i) for i in range(32)])
    gear=[
      ['ArmorLeatherCuirass','ArmorLeatherBoots','ArmorLeatherGauntlets','IronSword','ArmorIronShield'],
      ['ArmorIronCuirass','ArmorIronBoots','ArmorIronGauntlets','IronGreatsword'],
      ['ArmorLeatherCuirass','ArmorLeatherBoots','ArmorLeatherGauntlets','HuntingBow','IronArrow','IronDagger'],
      ['EnchClothesRobesMageRegen01','ArmorLeatherBoots','IronDagger']]
    gear += [
      ['ArmorSteelCuirassA','ArmorSteelBootsA','ArmorSteelGauntletsA','SteelSword','ArmorSteelShield'],
      ['ArmorHideCuirass','ArmorHideBoots','ArmorHideGauntlets','IronWarAxe','ArmorHideShield'],
      ['ArmorElvenCuirass','ArmorElvenBoots','ArmorElvenGauntlets','ElvenSword','ArmorElvenShield'],
      ['ArmorDwarvenCuirass','ArmorDwarvenBoots','ArmorDwarvenGauntlets','DwarvenBattleaxe'],
      ['ArmorOrcishCuirass','ArmorOrcishBoots','ArmorOrcishGauntlets','OrcishMace','ArmorOrcishShield'],
      ['ArmorScaledCuirass','ArmorScaledBoots','ArmorScaledGauntlets','SteelGreatsword'],
      ['ArmorElvenCuirass','ArmorElvenBoots','ArmorElvenGauntlets','ElvenBow','ElvenArrow','ElvenDagger'],
      ['ArmorSteelCuirassA','ArmorSteelBootsA','ArmorSteelGauntletsA','SteelWarAxe','ArmorSteelShield']]
    for i,items in enumerate(gear):
        flst(0x830+i,f'DYNA_Loadout{i}',[form(x) for x in items])
        armor = [form(x) for x in items if by_name[x][0] == b'ARMO']
        refs.extend(armor)
        add(b'OTFT',0x870+i,f'DYNA_Outfit{i}',[(b'INAM',b''.join(U32.pack(x) for x in armor))])
    flst(0x822,'DYNA_AdultLoadouts',[F(0x830+i) for i in range(len(gear))])
    # Per-living-slot owned styles and outfits; native code never mutates shared gear.
    style_source=next(v for v in by_name.values() if v[0]==b'CSTY')
    for i in range(32):
        add(b'CSTY',0xA00+i,f'DYNA_CombatStyle{i:02d}',[(k,v) for k,v in style_source[2][b'_entries'] if k!=b'EDID'])
        add(b'OTFT',0xA40+i,f'DYNA_GeneratedOutfit{i:02d}',[(b'INAM',U32.pack(form('ArmorLeatherCuirass')))])
    add(b'FACT',0x824,'DYNA_HeirFaction',[(b'FULL','Dynasty heirs'),(b'DATA',U32.pack(0))])
    def cloned_pack(local,name,source,conditions=(),topic=None):
        entries=[];data_input=True;topic_replaced=False
        for k,v in by_name[source][2][b'_entries']:
            if k in {b'EDID',b'CTDA',b'VMAD',b'QNAM'}:continue
            if k==b'PKDT':
                v=bytearray(v);v[4]=18;v=bytes(v)
                entries.append((k,v));continue
            if k==b'PSDT':
                entries.append((k,v));entries.extend((b'CTDA',c) for c in conditions);continue
            if k==b'PKCU':entries.append((b'QNAM',U32.pack(F(0x801))))
            if k==b'PDTO' and topic is not None and not topic_replaced:
                v=s.pack('<II',0,topic);topic_replaced=True
            entries.append((k,v))
        add(b'PACK',local,name,entries)
    cloned_pack(0x804,'DYNA_ApproachPlayer','WE29CourierTravelNearPlayer',[cond(1,0x14,500.0,0x40)])
    cloned_pack(0x805,'DYNA_ForceGreetPlayer','WICourierDeliverToPlayer',topic=F(0x809))
    # Vanilla current-location sandbox has no quest aliases or scripted events.
    sandbox=by_name['DefaultSandboxCurrentLocation256'][2][b'_entries']
    add(b'PACK',0x806,'DYNA_DefaultSandbox',[(k,v) for k,v in sandbox if k not in {b'EDID',b'QNAM',b'VMAD'}])
    # Near-package-start location is anchored when the home package begins.
    # Rank 3 enables routines only at the assigned residence, never while following.
    for local,name,source in [(0xA80,'DYNA_HomeSleep','DefaultSleepEditorLoc22x6'),(0xA81,'DYNA_HomeBreakfast','DefaultEatEditorLoc6x1'),(0xA82,'DYNA_HomeDinner','DefaultEatEditorLoc18x1')]:
        entries=[]
        for k,v in by_name[source][2][b'_entries']:
            if k in {b'EDID',b'VMAD',b'QNAM',b'CTDA'}:continue
            if k==b'PLDT':v=s.pack('<iIi',2,0,512)
            entries.append((k,v))
            if k==b'PSDT':entries.append((b'CTDA',cond(73,F(0x824),3)))
        add(b'PACK',local,name,entries)
    buttons=['Follow me','Wait here','Make this your home','Go home','Dismiss','Talk normally','Never mind']
    add(b'MESG',0x803,'DYNA_HeirCommandMessage',[(b'DESC','Choose an heir command.'),(b'FULL','Dynasty heir'),(b'INAM',U32.pack(0)),(b'DNAM',U32.pack(1)),*[(b'ITXT',x) for x in buttons]])
    add(b'MESG',0x823,'DYNA_SuccessionMessage',[(b'DESC','Your life is ending. Continue your dynasty as <Alias=Successor>?\n\n<Alias=SuccessionDetails>'),(b'FULL','Dynasty succession'),(b'INAM',U32.pack(0)),(b'DNAM',U32.pack(1)),*[(b'ITXT',x) for x in ['Continue as this heir','Next heir','Previous heir','Normal death']]])
    manager_props=[('PlayerRef',0x14,-1),('AdultHeirBaseMale',F(0x900),-1),('AdultHeirBaseFemale',F(0x940),-1),('ChildHeirBaseMale',F(0x810),-1),('ChildHeirBaseFemale',F(0x811),-1),('AdultHeirBasesMale',F(0x820),-1),('AdultHeirBasesFemale',F(0x821),-1),('AdultLoadouts',F(0x822),-1),('GreetingQuest',F(0x801),-1),('HeirCommandMessage',F(0x803),-1),('HomeMarkerBase',form('XMarker'),-1),('ArrivalPortalBase',form('SummonTargetFXActivator'),-1),('ArrivalShader',form('HowlSummonWolfFXS'),-1),('ArrivalSound',form('MAGConjurePortal'),-1),('SuccessionMessage',F(0x823),-1),('Successor',F(0x800),1),('HeirFaction',F(0x824),-1),('SuccessionDetails',F(0x800),2)]
    def quest(local,name,script_name,props,start,aliases=(),alias_scripts=()):
        fields=[(b'VMAD',vmad(script_name,props,alias_scripts,F(local))),
                (b'FULL',name),(b'DNAM',s.pack('<HBBII',0x2000|(0x8000 if local!=0x800 else 0)|(1 if start else 0),30,0,0,0)),
                (b'NEXT',b''),(b'ANAM',U32.pack(len(aliases)))]
        for a in aliases:fields.extend(a)
        add(b'QUST',local,name,fields)
    quest(0x800,'DYNA_LifecycleQuest','DynastyLifecycleQuest',manager_props,True,
          [alias(0,'PlayerAlias',0x200,0x14),alias(1,'Successor',0x202),alias(2,'SuccessionDetails',0x202)],[(0,'DynastyPlayerAlias',[('ManagerQuest',F(0x800),-1)])])
    quest(0x801,'DYNA_AdultGreetingQuest','DynastyAdultGreetingQuest',[('AdultHeir',F(0x801),0),('PlayerRef',0x14,-1)],False,
          [alias(0,'AdultHeir',0x202,None,[F(0x804),F(0x805)])])
    quest(0x802,'DYNA_BreedingDialogueQuest','DynastyBreedingDialogueQuest',[('ManagerQuest',F(0x800),-1)],True)
    quest(0x825,'DYNA_HeirDialogueQuest','DynastyHeirDialogueQuest',[('ManagerQuest',F(0x800),-1),('Report',F(0x825),0)],True,[alias(0,'Report',0x202)])
    quest(0x826,'DYNA_MCMQuest','DynastyMCM',[('ManagerQuest',F(0x800),-1)],True)
    add(b'DLBR',0x807,'DYNA_BreedingBranch',[(b'QNAM',U32.pack(F(0x802))),(b'TNAM',U32.pack(0)),(b'DNAM',U32.pack(1)),(b'SNAM',U32.pack(F(0x808)))])
    def topic(local,name,text,questid,branch,subtype):
        fields=[(b'FULL',text),(b'PNAM',s.pack('<f',50.0)),(b'BNAM',U32.pack(branch)),(b'QNAM',U32.pack(questid)),(b'DATA',s.pack('<BBH',0,0,subtype)),(b'SNAM',b'CUS T'.replace(b' ',b'') if subtype==0 else b'PFGT'),(b'TIFC',U32.pack(1))]
        add(b'DIAL',local,name,fields)
    topic(0x808,'DYNA_BreedingTopic','Breeding',F(0x802),F(0x807),0)
    topic(0x809,'DYNA_AdultGreetingTopic','',F(0x801),0,1)
    # INFO child groups must be nested under the owning DIAL; do not top-group INFO.
    infos={}
    def info(local,topic,text,script_name,fragment,conditions,action=None):
        forms[local]=(b'INFO',script_name)
        fields=[(b'VMAD',vmad(script_name,fragment=fragment,action=action)),(b'ENAM',s.pack('<HH',0xA00,0)),(b'TPIC',U32.pack(topic)),(b'PNAM',U32.pack(0)),(b'CNAM',b'\0'),(b'TRDT',s.pack('<III B3x I B3x',0,0,0,1,0,0)),(b'NAM1',text),(b'NAM2',''),(b'NAM3','')]
        fields.extend((b'CTDA',c) for c in conditions)
        infos[topic]=record(b'INFO',F(local),fields)
    info(0x80A,F(0x808),'A new chapter for our family.','TIF_DYNA_Breeding',1,[cond(70,1,1),cond(46),cond(365),cond(289),cond(719,0x14),cond(136,0x14),cond(72,F(0x810)),cond(72,F(0x811))])
    info(0x80B,F(0x809),"I've finally found you. I thought it was time we spoke.",'TIF_DYNA_AdultGreeting',2,[cond(566,0,1)])
    commands=[
        ('Follow me.', 'I will follow you.',0),
        ('Wait here.', 'I will wait here.',1),
        ('Let us trade equipment.', 'Of course. What do you need?',2),
        ('Make this place your home.', 'I will settle here.',3),
        ('Return to your home.', 'I will head home, if I have a residence assigned.',4),
        ('You are dismissed.', 'Until we meet again.',5),
        ('Tell me about our family.', '<Alias=Report>',6),
        ('What are your abilities and equipment?', '<Alias=Report>',7),
        ('Choose the combat role that suits you.', 'I will put my strongest inherited abilities to use.',10),
        ('Fight as a warrior.', 'I will focus on close combat.',11),
        ('Fight as an archer.', 'I will favour ranged attacks.',12),
        ('Fight as a mage.', 'I will favour magic and staves.',13),
        ('Fight as a rogue.', 'I will favour light equipment and quick attacks.',14),
        ('Focus on craftsmanship.', 'I will take a more cautious approach to combat.',15),
        ('Choose a fresh equipment set.', 'I will prepare a different loadout.',8)]
    for i,(prompt,response,action) in enumerate(commands):
        topicid,branchid=0xB00+i,0xB40+i
        add(b'DLBR',branchid,f'DYNA_HeirBranch{i}',[(b'QNAM',U32.pack(F(0x825))),(b'TNAM',U32.pack(0)),(b'DNAM',U32.pack(1)),(b'SNAM',U32.pack(F(topicid)))])
        topic(topicid,f'DYNA_HeirTopic{i}',prompt,F(0x825),F(branchid),0)
        info(0xB80+i,F(topicid),response,'TIF_DYNA_HeirCommand',2,[cond(71,F(0x824),1),cond(46),cond(365),cond(289),cond(719,0x14)],action)
    groups=[]
    for tag,items in result.items():
        if tag==b'DIAL':
            nested=[]
            for data in items:
                fid=U32.unpack_from(data,12)[0];inf=infos[fid]
                nested += [data,s.pack('<4sIIIIHH',b'GRUP',24+len(inf),fid,7,0,0,0)+inf]
            groups.append(group(tag,nested))
        else:groups.append(group(tag,items))
    header=record(b'TES4',0,[(b'HEDR',s.pack('<fII',1.7,len(forms),max(forms)+1)),(b'CNAM','Skyrim Dynasty'),(b'SNAM','0.8.0 installed-item loadouts, heir dialogue and dynasty journal.'),(b'MAST','Skyrim.esm'),(b'DATA',bytes(8))],0x200)
    dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(header+b''.join(groups))
    seq=dest.parent/'SEQ/DynastyHeirs.seq';seq.parent.mkdir(exist_ok=True);seq.write_bytes(s.pack('<IIII',F(0x800),F(0x802),F(0x825),F(0x826)))
    (ROOT/'build_records.json').write_text(json.dumps({hex(F(k)):{'type':t.decode(),'edid':n} for k,(t,n) in forms.items()},indent=2)+'\n')
    (ROOT/'face_sources.json').write_text(json.dumps({f'{k:08X}':f'{v:08X}' for k,v in faces.items()},indent=2)+'\n')
    for ref in refs:assert (ref>>24==1 and (ref&0xFFFFFF) in forms) or ref in all_ids,hex(ref)
    print(f'Generated {dest}: {len(forms)} new records, no master overrides; SEQ included.')
    return dest

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('master');p.add_argument('--output',default=str(ROOT/'Data/DynastyHeirs.esp'));a=p.parse_args();generate(a.master,a.output)
