#include "Genetics.h"
#include "SkeeAPI.h"
#include <fstream>
#include <filesystem>
#include <cmath>
namespace Dynasty {
namespace {
Skee::IBodyMorphInterface* body{};
Skee::IPresetInterface* presets{};
std::filesystem::path Cache() {
    std::filesystem::path exe(REL::Module::get().filePath().data());
    auto path=exe.parent_path()/"Data"/"SKSE"/"Plugins"/"SkyrimDynasty"/"Cache";
    std::filesystem::create_directories(path);return path;
}
Json Export(RE::Actor* actor) {
    if(!presets||!actor)return Json::object();auto path=Cache()/std::format("capture_{:08X}.jslot",actor->GetFormID());
    // SKEE returns false even after writing a valid JSON preset. Validate the file.
    std::error_code ec;std::filesystem::remove(path,ec);presets->SavePreset(path.string().c_str(),nullptr,actor);
    if(!std::filesystem::exists(path)||std::filesystem::file_size(path)>4*1024*1024)return Json::object();
    std::ifstream in(path);auto data=Json::parse(in,nullptr,false);std::filesystem::remove(path,ec);return data.is_object()?data:Json::object();
}
struct BodyVisitor final:Skee::IBodyMorphInterface::MorphVisitor {
    Json values=Json::object();
    void Visit(RE::TESObjectREFR* actor,const char* name) override {
        if(!name||std::strlen(name)>128||values.size()>=512)return;auto value=body->GetBodyMorphs(actor,name);
        if(std::isfinite(value)&&std::abs(value)<=10)values[name]=value;
    }
};
Json Body(RE::Actor* actor){BodyVisitor visitor;if(body&&actor)body->VisitMorphs(actor,visitor);return visitor.values;}
Json Custom(const Json& preset) {
    Json values=Json::object();if(!preset.contains("morphs"))return values;
    auto list=preset["morphs"].value("custom",Json::array());if(!list.is_array())return values;
    for(const auto& item:list)if(item.is_object()&&item.contains("name")&&item.contains("value")) {
        auto name=item["name"].get<std::string>();auto value=item["value"].get<float>();
        if(name.size()<=128&&values.size()<512&&std::isfinite(value)&&std::abs(value)<=10)values[name]=value;
    }
    return values;
}
Json Blend(const Json& a,const Json& b,std::mt19937_64& rng,float strength) {
    Json result=Json::object();auto keys=a;for(auto it=b.begin();it!=b.end();++it)keys[it.key()]=it.value();
    for(auto it=keys.begin();it!=keys.end();++it) {
        float weight=std::uniform_real_distribution<float>(0.3F,0.7F)(rng);
        float value=(a.value(it.key(),0.0F)*weight+b.value(it.key(),0.0F)*(1-weight))*strength;
        if(std::isfinite(value))result[it.key()]=std::clamp(value,-10.0F,10.0F);
    }
    return result;
}
}
void GeneticsEngine::ConnectAppearanceBridge() {
    Skee::InterfaceExchangeMessage exchange;
    if(auto* messaging=SKSE::GetMessagingInterface())messaging->Dispatch(Skee::InterfaceExchangeMessage::kMessage_ExchangeInterface,&exchange,sizeof(exchange),"skee");
    if(exchange.interfaceMap) {
        auto* b=exchange.interfaceMap->QueryInterface("BodyMorph");if(b&&(b->GetVersion()==4||b->GetVersion()==5))body=static_cast<Skee::IBodyMorphInterface*>(b);
        auto* p=exchange.interfaceMap->QueryInterface("Preset");if(p&&p->GetVersion()==1)presets=static_cast<Skee::IPresetInterface*>(p);
    }
    SKSE::log::info("Optional appearance interfaces: body {}, preset {}",body!=nullptr,presets!=nullptr);
}
void GeneticsEngine::CaptureExternalLook(RE::Actor* actor,RE::Actor* father,RE::Actor* mother) {
    std::lock_guard lock(mutex_);if(!actor||!father||!mother||!GetGenome(actor)||!settings_.externalAppearance)return;
    try {
        auto& e=extras_[actor->GetFormID()];e.custom["body"]=Blend(Body(father),Body(mother),rng_,settings_.inheritance);
        auto a=Export(father),b=Export(mother);e.custom["face"]=Blend(Custom(a),Custom(b),rng_,settings_.inheritance);
        // Sculpt coordinates are retained only for identical parental head topology.
        // Cross-sex/race meshes with different topology keep the native inherited face.
        e.custom["sculpt"]=Json::array();
        if(presets&&father->GetActorBase()->GetSex()==mother->GetActorBase()->GetSex()&&father->GetActorBase()->GetSex()==actor->GetActorBase()->GetSex()&&a.contains("morphs")&&b.contains("morphs")) {
            auto sa=a["morphs"].value("sculpt",Json::array()),sb=b["morphs"].value("sculpt",Json::array());
            float da=a["morphs"].value("sculptDivisor",10000.0F),db=b["morphs"].value("sculptDivisor",10000.0F);
            if(sa.is_array()&&sb.is_array()&&da>0&&db>0)for(const auto& ha:sa)for(const auto& hb:sb) {
                if(ha.value("host","")!=hb.value("host","")||ha.value("vertices",0)!=hb.value("vertices",0))continue;
                const auto vertices=ha.value("vertices",0);if(vertices<=0||vertices>65535)continue;
                std::map<int,std::array<float,3>> offsets;const float w=std::uniform_real_distribution<float>(0.3F,0.7F)(rng_);
                bool valid=true;
                for(const auto& pair:std::array<std::pair<Json,float>,2>{{{ha,w/da},{hb,(1-w)/db}}})for(const auto& point:pair.first.value("data",Json::array())) {
                    if(!point.is_array()||point.size()!=4){valid=false;break;}int index=point[0];if(index<0||index>=vertices){valid=false;break;}
                    for(int i=0;i<3;++i){float v=point[i+1].get<float>()*pair.second;if(!std::isfinite(v)||std::abs(v)>20)valid=false;offsets[index][i]+=v;}
                }
                if(!valid)continue;Json host={{"host",ha.at("host")},{"vertices",vertices},{"data",Json::array()}};
                for(const auto& [index,delta]:offsets)host["data"].push_back({index,int(delta[0]*10000),int(delta[1]*10000),int(delta[2]*10000)});
                e.custom["sculpt"].push_back(host);
            }
        }
        e.lookApplied=false;
    }catch(const std::exception& ex){SKSE::log::warn("External inheritance capture skipped: {}",ex.what());}
}
void GeneticsEngine::ApplyExternalLook(RE::Actor* actor) {
    std::lock_guard lock(mutex_);if(!actor||!settings_.externalAppearance)return;
    auto it=extras_.find(actor->GetFormID());if(it==extras_.end()||it->second.lookApplied)return;
    auto& e=it->second;
    // Mark before LoadPreset queues another node update; never recursively reload.
    e.lookApplied=true;
    try {
        if(body&&e.custom.contains("body")&&e.custom["body"].is_object()) {
            body->ClearBodyMorphKeys(actor,"SkyrimDynasty");
            for(auto m=e.custom["body"].begin();m!=e.custom["body"].end();++m)if(m.key().size()<=128&&m.value().is_number()) {
                float v=m.value();if(std::isfinite(v)&&std::abs(v)<=10)body->SetMorph(actor,m.key().c_str(),"SkyrimDynasty",v);
            }
            body->ApplyBodyMorphs(actor,true);
        }
        if(!presets||!e.custom.contains("face"))return;
        auto baseline=Export(actor);if(!baseline.contains("morphs"))return;
        baseline["morphs"]["custom"]=Json::array();
        for(auto m=e.custom["face"].begin();m!=e.custom["face"].end();++m)baseline["morphs"]["custom"].push_back({{"name",m.key()},{"value",m.value()}});
        baseline["morphs"]["sculpt"]=Json::array();baseline["morphs"]["sculptDivisor"]=10000;
        if(e.custom.contains("sculpt"))for(const auto& host:e.custom["sculpt"]) {
            // Exact host path and model vertex count must match a loaded target part.
            bool compatible=false;auto* base=actor->GetActorBase();auto* face=actor->GetFaceNode();
            for(unsigned i=0;base&&i<base->numHeadParts;++i)if(auto* part=base->headParts[i];part&&face) {
                auto* geom=face->GetObjectByName(part->formEditorID);
                auto* fod=geom?geom->GetExtraData<RE::BSFaceGenBaseMorphExtraData>("FOD"):nullptr;
                for(const auto& morph:part->morphs)if(fod&&morph.GetModel()&&host.value("host","")==morph.GetModel()&&host.value("vertices",0U)==fod->modelVertexCount)compatible=true;
            }
            if(compatible)baseline["morphs"]["sculpt"].push_back(host);
        }
        auto name=std::format("heir_{:08X}.jslot",actor->GetFormID());auto path=Cache()/name;
        {std::ofstream out(path);out<<baseline.dump();}
        auto relative=std::string("SKSE\\Plugins\\SkyrimDynasty\\Cache\\")+name;
        presets->LoadPreset(relative.c_str(),nullptr,actor,Skee::IPresetInterface::kPresetApplyFace);
        std::error_code ec;std::filesystem::remove(path,ec);
    }catch(const std::exception& ex){SKSE::log::warn("External appearance restore skipped: {}",ex.what());}
}
}
