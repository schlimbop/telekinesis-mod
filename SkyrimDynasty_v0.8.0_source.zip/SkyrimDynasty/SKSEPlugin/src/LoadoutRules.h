#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
namespace Dynasty::Equipment {
enum class Kind { Armor, Weapon, Ammo };
struct Item { std::uint32_t id{},mask{}; Kind kind{}; int type{}; float quality{}; bool bolt{}; };
inline bool TwoHanded(int t) { return t==5||t==6||t==7||t==9; }
template<class RNG> std::vector<std::uint32_t> Select(const std::vector<Item>& pool,int role,float quality,RNG& rng) {
    std::vector<std::uint32_t> result; std::uint32_t occupied=0; int weapon=0;
    auto pick=[&](auto eligible) -> const Item* {
        std::vector<const Item*> choices;std::vector<double> weights;
        for(const auto& item:pool)if(eligible(item)) {
            double w=0.08+std::exp(-3.0*std::abs(item.quality-quality));
            if(item.kind==Kind::Weapon) {
                const bool favored=(role==1&&(item.type>=1&&item.type<=6))||(role==2&&(item.type==7||item.type==9))||(role==3&&item.type==8)||(role==4&&item.type==2)||(role==5&&(item.type==3||item.type==4));
                w*=favored?12.0:0.3;
            } else if(item.kind==Kind::Armor) {
                const int favored=(role==1?2:(role==3||role==5?0:1));w*=item.type==favored?3.0:1.0;
            }
            choices.push_back(&item);weights.push_back(w);
        }
        if(choices.empty())return nullptr;
        return choices[std::discrete_distribution<std::size_t>(weights.begin(),weights.end())(rng)];
    };
    if(auto* w=pick([](const Item& i){return i.kind==Kind::Weapon;})){result.push_back(w->id);weapon=w->type;}
    auto armor=[&](std::uint32_t wanted) {
        if(occupied&wanted)return;
        if(auto* a=pick([&](const Item& i){return i.kind==Kind::Armor&&(i.mask&wanted)&&!(i.mask&occupied)&&(!(i.mask&512)||(!TwoHanded(weapon)&&weapon!=8));})) {
            result.push_back(a->id);occupied|=a->mask;
        }
    };
    // Cover the torso first. Multi-slot outfits cannot be overwritten by accessories.
    armor(4);for(auto slot:{128U,8U,1U,2U,32U,64U,512U})armor(slot);
    if(weapon==7||weapon==9)if(auto* a=pick([&](const Item& i){return i.kind==Kind::Ammo&&i.bolt==(weapon==9);})){result.push_back(a->id);}
    return result;
}
}
