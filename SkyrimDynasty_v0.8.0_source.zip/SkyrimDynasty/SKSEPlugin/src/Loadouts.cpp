#include "Genetics.h"
#include "LoadoutRules.h"
#include <cmath>
#include <mutex>
namespace Dynasty {
namespace {
using Equipment::Item;using Equipment::Kind;
std::vector<Item> itemPool;
std::once_flag poolOnce;
bool Eligible(RE::TESForm* f) {return f&&!f->IsDeleted()&&!(f->formFlags&(1U<<2))&&f->GetName()&&*f->GetName()&&!(f->formFlags&(1U<<12));}
void Scan() {
    auto* data=RE::TESDataHandler::GetSingleton();if(!data)return;
    for(auto* a:data->GetFormArray<RE::TESObjectARMO>())if(Eligible(a)&&!a->armorAddons.empty()) {
        auto mask=a->GetSlotMask().underlying();if(mask)itemPool.push_back({a->GetFormID(),mask,Kind::Armor,a->IsHeavyArmor()?2:a->IsLightArmor()?1:0,std::clamp(std::log1p(float(a->value))/9.0F,0.0F,1.0F),false});
    }
    for(auto* w:data->GetFormArray<RE::TESObjectWEAP>())if(Eligible(w)) {
        auto type=int(w->GetWeaponType());if(type>=1&&type<=9)itemPool.push_back({w->GetFormID(),0,Kind::Weapon,type,std::clamp(std::log1p(float(w->value))/9.0F,0.0F,1.0F),false});
    }
    for(auto* a:data->GetFormArray<RE::TESAmmo>())if(Eligible(a)&&!a->GetRuntimeData().data.flags.all(RE::AMMO_DATA::Flag::kNonPlayable)&&a->GetRuntimeData().data.projectile)itemPool.push_back({a->GetFormID(),0,Kind::Ammo,0,std::clamp(std::log1p(float(a->value))/5.0F,0.0F,1.0F),a->IsBolt()});
    SKSE::log::info("Installed equipment pool: {} playable forms",itemPool.size());
}
bool Wearable(RE::TESObjectARMO* armor,RE::Actor* actor) {
    if(!armor||!actor||!actor->GetRace())return false;
    const auto sex=actor->GetActorBase()->GetSex()==RE::SEX::kFemale?1:0;
    for(auto* addon:armor->armorAddons)if(addon&&addon->IsValidRace(actor->GetRace())) {
        auto* model=addon->bipedModels[sex].GetModel();if(model&&*model)return true;
    }
    return false;
}
int OwnedSlot(RE::Actor* actor) {
    auto* data=RE::TESDataHandler::GetSingleton();if(!data||!actor)return -1;
    for(int i=0;i<32;++i)for(unsigned first:{0x900U,0x940U})if(data->LookupForm<RE::TESNPC>(first+i,"DynastyHeirs.esp")==actor->GetActorBase())return i;
    return -1;
}
RE::TESCombatStyle* OwnedStyle(int slot) {return slot>=0&&slot<32?RE::TESDataHandler::GetSingleton()->LookupForm<RE::TESCombatStyle>(0xA00+slot,"DynastyHeirs.esp"):nullptr;}
}
std::vector<RE::TESForm*> GeneticsEngine::GenerateLoadout(RE::Actor* actor,int slot,bool reroll) {
    std::lock_guard lock(mutex_);std::vector<RE::TESForm*> result;
    if(!actor||slot<0||slot>=32||!GetGenome(actor)||actor->IsPlayerRef()||OwnedSlot(actor)!=slot)return result;
    std::call_once(poolOnce,Scan);auto& e=extras_[actor->GetFormID()];e.slot=slot;
    if(e.items.empty()||reroll) {
        if(!e.role)ChooseCombatRole(actor,0);
        std::vector<Item> compatible;compatible.reserve(itemPool.size());
        for(const auto& i:itemPool)if(i.kind!=Kind::Armor||Wearable(RE::TESForm::LookupByID<RE::TESObjectARMO>(i.id),actor))compatible.push_back(i);
        e.items=Equipment::Select(compatible,e.role,settings_.quality,rng_);
    }
    RestoreCombatRole(actor);
    for(auto id:e.items)if(auto* f=RE::TESForm::LookupByID(id))result.push_back(f);
    return result;
}
RE::BGSOutfit* GeneticsEngine::PrepareOutfit(RE::Actor* actor) {
    std::lock_guard lock(mutex_);if(!actor||actor->IsPlayerRef())return nullptr;
    auto it=extras_.find(actor->GetFormID());if(it==extras_.end()||it->second.slot<0||it->second.slot>=32)return nullptr;
    auto* outfit=RE::TESDataHandler::GetSingleton()->LookupForm<RE::BGSOutfit>(0xA40+it->second.slot,"DynastyHeirs.esp");if(!outfit)return nullptr;
    outfit->outfitItems.clear();
    for(auto id:it->second.items)if(auto* a=RE::TESForm::LookupByID<RE::TESObjectARMO>(id);a&&Wearable(a,actor))outfit->outfitItems.push_back(a);
    return outfit;
}
void GeneticsEngine::ChooseCombatRole(RE::Actor* actor,int role) {
    std::lock_guard lock(mutex_);if(!actor||actor->IsPlayerRef()||!GetGenome(actor))return;
    auto slot=OwnedSlot(actor);if(slot<0)return;
    auto& e=extras_[actor->GetFormID()];e.slot=slot;
    if(role<1||role>5) {
        auto skill=[&](int n){return actor->AsActorValueOwner()->GetBaseActorValue(static_cast<RE::ActorValue>(6+n));};
        std::array<double,5> weights{5+skill(0)+skill(1)+skill(3),5+2*skill(2),5+skill(14)+skill(13)+skill(16),5+skill(9)+skill(7)+skill(6),5+skill(4)+skill(10)+skill(17)};
        role=int(std::discrete_distribution<int>(weights.begin(),weights.end())(rng_))+1;
    }
    e.role=role;e.style=0;e.spells.clear();
    std::vector<RE::TESCombatStyle*> templates;
    for(auto* style:RE::TESDataHandler::GetSingleton()->GetFormArray<RE::TESCombatStyle>())if(style&&!style->IsDeleted()) {
        auto* owned=OwnedStyle(e.slot);if(style==owned)continue;
        // Use ground styles. Dragon/flying-only templates are unsuitable for humanoids.
        if(style->generalData.meleeScoreMult>0||style->generalData.rangedScoreMult>0||style->generalData.magicScoreMult>0) {
            auto* file=style->GetFile(0);if(file&&std::string_view(file->fileName)=="DynastyHeirs.esp")continue;
            templates.push_back(style);
        }
    }
    if(!templates.empty())e.style=templates[std::uniform_int_distribution<std::size_t>(0,templates.size()-1)(rng_)]->GetFormID();
    for(auto& v:e.styleMix)v=settings_.randomCombat?std::uniform_real_distribution<float>(0.65F,1.45F)(rng_):1.0F;
    RestoreCombatRole(actor);
    if(auto g=GetGenome(actor);g&&lineage_.contains(g->logicalID))lineage_[g->logicalID].specialty=std::array{"Undecided","Warrior","Archer","Mage","Rogue","Craftsman"}[role];
}
void GeneticsEngine::RestoreCombatRole(RE::Actor* actor) {
    std::lock_guard lock(mutex_);if(!actor||actor->IsPlayerRef())return;
    auto it=extras_.find(actor->GetFormID());if(it==extras_.end())return;auto& e=it->second;
    auto* target=OwnedStyle(e.slot);auto* source=RE::TESForm::LookupByID<RE::TESCombatStyle>(e.style);if(!target||!source)return;
    target->generalData=source->generalData;target->meleeData=source->meleeData;target->closeRangeData=source->closeRangeData;target->longRangeData=source->longRangeData;target->flightData={};target->flags=source->flags;
    auto& g=target->generalData;
    g.offensiveMult=std::clamp(g.offensiveMult*e.styleMix[0],0.2F,2.0F);g.defensiveMult=std::clamp(g.defensiveMult*e.styleMix[1],0.2F,2.0F);
    g.groupOffensiveMult=e.styleMix[2];g.meleeScoreMult=(e.role==1||e.role==4||e.role==5?2.0F:0.4F)*e.styleMix[3];
    g.magicScoreMult=(e.role==3?3.0F:0.1F)*e.styleMix[4];g.rangedScoreMult=(e.role==2?3.0F:0.3F)*e.styleMix[5];g.staffScoreMult=(e.role==3?2.0F:0.3F)*e.styleMix[6];g.shoutScoreMult=0;g.unarmedScoreMult=0.1F;
    target->closeRangeData.circleMult=e.styleMix[7];target->longRangeData.strafeMult=e.styleMix[8];g.avoidThreatChance=std::clamp(0.3F*e.styleMix[9],0.0F,1.0F);
    actor->GetActorBase()->SetCombatStyle(target);
}
std::vector<RE::SpellItem*> GeneticsEngine::CombatSpells(RE::Actor* actor) {
    std::lock_guard lock(mutex_);std::vector<RE::SpellItem*> result;if(!actor||actor->IsPlayerRef())return result;
    auto& e=extras_[actor->GetFormID()];if(e.role!=3)return result;
    if(e.spells.empty()) {
        // Combat spells only: exclude abilities, rituals and scripted/quest effects.
        std::vector<RE::SpellItem*> choices;
        for(auto* spell:RE::TESDataHandler::GetSingleton()->GetFormArray<RE::SpellItem>())if(spell&&!spell->IsDeleted()&&spell->GetSpellType()==RE::MagicSystem::SpellType::kSpell&&spell->GetAssociatedSkill()==RE::ActorValue::kDestruction&&spell->GetDelivery()==RE::MagicSystem::Delivery::kAimed) {
            bool safe=!spell->effects.empty();
            for(auto* effect:spell->effects)if(!effect||!effect->baseEffect||effect->baseEffect->data.archetype==RE::EffectSetting::Archetype::kScript||effect->baseEffect->data.minimumSkill>actor->AsActorValueOwner()->GetBaseActorValue(RE::ActorValue::kDestruction))safe=false;
            if(safe)choices.push_back(spell);
        }
        std::shuffle(choices.begin(),choices.end(),rng_);for(std::size_t i=0;i<std::min<std::size_t>(2,choices.size());++i)e.spells.push_back(choices[i]->GetFormID());
    }
    for(auto id:e.spells)if(auto* f=RE::TESForm::LookupByID<RE::SpellItem>(id))result.push_back(f);return result;
}
}
