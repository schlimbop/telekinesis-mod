#include "Genetics.h"

#include <algorithm>
#include <array>
#include <format>
#include <string_view>
#include <cmath>

namespace Dynasty
{
    namespace
    {
        constexpr float kMutationChance = 0.02F;
        constexpr float kMutationSigma = 0.025F;

        constexpr std::uint32_t kRecordType = 'DYNG';
        constexpr std::uint32_t kRecordVersion = 2;

        float Clamp01(float v)
        {
            return std::clamp(v, 0.0F, 1.0F);
        }

        template <class T, std::size_t N>
        const T& Pick(std::mt19937_64& rng, const std::array<T, N>& values)
        {
            std::uniform_int_distribution<std::size_t> pick(0, N - 1);
            return values[pick(rng)];
        }
    }

    GeneticsEngine& GeneticsEngine::GetSingleton()
    {
        static GeneticsEngine singleton;
        return singleton;
    }

    GeneticsEngine::GeneticsEngine() :
        rng_(std::random_device{}())
    {}

    std::uint64_t GeneticsEngine::NextID()
    {
        return nextID_++;
    }

    float GeneticsEngine::ChooseAllele(const DiploidFloat& locus)
    {
        std::bernoulli_distribution coin(0.5);
        return coin(rng_) ? locus.a : locus.b;
    }

    float GeneticsEngine::Mutate(float value)
    {
        std::bernoulli_distribution mutate(kMutationChance);

        if (!mutate(rng_)) {
            return Clamp01(value);
        }

        std::normal_distribution<float> noise(0.0F, kMutationSigma);
        return Clamp01(value + noise(rng_));
    }

    DiploidFloat GeneticsEngine::BreedLocus(
        const DiploidFloat& a,
        const DiploidFloat& b)
    {
        return {
            Mutate(ChooseAllele(a)),
            Mutate(ChooseAllele(b))
        };
    }

    float GeneticsEngine::Phenotype(const DiploidFloat& locus) const
    {
        return Clamp01((locus.a * 0.70F) + (locus.b * 0.30F));
    }

    Genome GeneticsEngine::MakeFounderGenome(RE::Actor* actor)
    {
        std::lock_guard lock(mutex_);
        std::uniform_real_distribution<float> base(0.30F, 0.70F);

        Genome g;
        g.logicalID = NextID();

        auto locus = [&]() {
            return DiploidFloat{ base(rng_), base(rng_) };
        };

        auto* npc = actor && actor->GetActorBase() ? actor->GetActorBase()->GetRootFaceNPC() : nullptr;
        auto faceLocus = [&](std::size_t i) {
            float v = npc && npc->faceData ? npc->faceData->morphs[i] : 0.0F;
            v = std::isfinite(v) ? std::clamp(v, -1.0F, 1.0F) : 0.0F;
            return DiploidFloat{(v + 1.0F) * 0.5F, (v + 1.0F) * 0.5F};
        };
        g.jawWidth = faceLocus(3);
        g.chinHeight = faceLocus(15);
        g.noseLength = faceLocus(0);
        g.noseWidth = faceLocus(1);
        g.eyeSpacing = faceLocus(8);
        g.eyeSize = faceLocus(17);
        g.cheekHeight = faceLocus(5);
        g.browHeight = faceLocus(9);
        float actualHeight = actor && actor->GetActorBase() ? actor->GetActorBase()->height * actor->GetScale() : 1.0F;
        float normalHeight = std::clamp((actualHeight - 0.85F) / 0.30F, 0.0F, 1.0F);
        g.height = {normalHeight, normalHeight};

        g.intelligence = locus();
        g.physique = locus();
        g.magicalAffinity = locus();

        if (actor && actor->GetActorBase()) {
            g.sex =
                actor->GetActorBase()->GetSex() == RE::SEX::kFemale ?
                Sex::Female :
                Sex::Male;
        }

        return g;
    }

    Genome GeneticsEngine::Breed(const Genome& a, const Genome& b)
    {
        std::lock_guard lock(mutex_);
        Genome child;
        child.logicalID = NextID();

        child.jawWidth = BreedLocus(a.jawWidth, b.jawWidth);
        child.chinHeight = BreedLocus(a.chinHeight, b.chinHeight);
        child.noseLength = BreedLocus(a.noseLength, b.noseLength);
        child.noseWidth = BreedLocus(a.noseWidth, b.noseWidth);
        child.eyeSpacing = BreedLocus(a.eyeSpacing, b.eyeSpacing);
        child.eyeSize = BreedLocus(a.eyeSize, b.eyeSize);
        child.cheekHeight = BreedLocus(a.cheekHeight, b.cheekHeight);
        child.browHeight = BreedLocus(a.browHeight, b.browHeight);
        child.height = BreedLocus(a.height, b.height);

        child.intelligence = BreedLocus(a.intelligence, b.intelligence);
        child.physique = BreedLocus(a.physique, b.physique);
        child.magicalAffinity = BreedLocus(a.magicalAffinity, b.magicalAffinity);

        std::bernoulli_distribution sexCoin(0.5);
        child.sex = sexCoin(rng_) ? Sex::Female : Sex::Male;

        return child;
    }

    bool GeneticsEngine::AttachGenome(RE::Actor* actor, Genome genome)
    {
        std::lock_guard lock(mutex_);
        if (!actor) {
            return false;
        }

        genomes_[actor->GetFormID()] = std::move(genome);
        return true;
    }

    bool GeneticsEngine::TransferGenome(RE::Actor* oldActor, RE::Actor* newActor)
    {
        std::lock_guard lock(mutex_);
        if (!oldActor || !newActor) {
            return false;
        }

        const auto it = genomes_.find(oldActor->GetFormID());
        if (it == genomes_.end()) {
            return false;
        }

        Genome genome = it->second;
        genome.sex =
            newActor->GetActorBase() &&
            newActor->GetActorBase()->GetSex() == RE::SEX::kFemale ?
            Sex::Female :
            Sex::Male;

        if (auto face = faces_.find(oldActor->GetFormID()); face != faces_.end()) {
            auto inherited = face->second;
            faces_.erase(face);
            faces_[newActor->GetFormID()] = std::move(inherited);
        }
        genomes_.erase(it);
        genomes_[newActor->GetFormID()] = genome;
        auto talent = talents_.find(oldActor->GetFormID());
        if (talent != talents_.end()) {
            // Copy before insertion: unordered_map insertion may rehash.
            TalentGenome inherited = talent->second;
            talents_.erase(talent);
            talents_[newActor->GetFormID()] = std::move(inherited);
        }
        return true;
    }

    std::optional<Genome> GeneticsEngine::GetGenome(RE::Actor* actor) const
    {
        std::lock_guard lock(mutex_);
        if (!actor) {
            return std::nullopt;
        }

        const auto it = genomes_.find(actor->GetFormID());
        if (it == genomes_.end()) {
            return std::nullopt;
        }

        return it->second;
    }

    std::string GeneticsEngine::Describe(RE::Actor* actor) const
    {
        std::lock_guard lock(mutex_);
        const auto genome = GetGenome(actor);

        if (!genome) {
            return "No dynasty genome";
        }

        return std::format(
            "ID={} jaw=({:.3f},{:.3f}) noseLength=({:.3f},{:.3f}) "
            "height=({:.3f},{:.3f}) intelligence=({:.3f},{:.3f}) "
            "magic=({:.3f},{:.3f})",
            genome->logicalID,
            genome->jawWidth.a,
            genome->jawWidth.b,
            genome->noseLength.a,
            genome->noseLength.b,
            genome->height.a,
            genome->height.b,
            genome->intelligence.a,
            genome->intelligence.b,
            genome->magicalAffinity.a,
            genome->magicalAffinity.b);
    }

    std::string GeneticsEngine::GenerateName(bool female)
    {
        std::lock_guard lock(mutex_);
        static const std::array<std::string_view, 16> prefixes{
            "Al", "Arn", "Bryn", "Dag", "Eir", "Frey", "Gun", "Hjal",
            "Ing", "Rag", "Sig", "Tor", "Val", "Yng", "Skal", "Hal"
        };

        static const std::array<std::string_view, 12> maleSuffixes{
            "ar", "bjorn", "grim", "mar", "mund", "rik",
            "sten", "var", "vald", "rek", "olf", "mir"
        };

        static const std::array<std::string_view, 12> femaleSuffixes{
            "a", "dis", "hild", "ja", "run", "rid",
            "vild", "yng", "na", "la", "ra", "frid"
        };

        const auto prefix = Pick(rng_, prefixes);
        const auto suffix = female ?
            Pick(rng_, femaleSuffixes) :
            Pick(rng_, maleSuffixes);

        return std::string(prefix) + std::string(suffix);
    }

    float GeneticsEngine::HeightScale(RE::Actor* actor) const
    {
        std::lock_guard lock(mutex_);
        const auto genome = GetGenome(actor);
        if (!genome) {
            return 1.0F;
        }

        const float p = Phenotype(genome->height);
        return 0.85F + (p * 0.30F);
    }

    void GeneticsEngine::Save(SKSE::SerializationInterface* intfc) const
    {
        std::lock_guard lock(mutex_);
        if (!intfc || !intfc->OpenRecord(kRecordType, kRecordVersion)) {
            return;
        }

        const std::uint32_t count =
            static_cast<std::uint32_t>(genomes_.size());

        intfc->WriteRecordData(count);
        intfc->WriteRecordData(nextID_);

        for (const auto& [actorFormID, genome] : genomes_) {
            intfc->WriteRecordData(actorFormID);
            intfc->WriteRecordData(genome);
        }
        SaveTalents(intfc);
        SaveAppearance(intfc);
        SaveFeatures(intfc);
    }

    void GeneticsEngine::Load(SKSE::SerializationInterface* intfc)
    {
        std::lock_guard lock(mutex_);
        ClearTalents();
        faces_.clear();
        genomes_.clear();
        extras_.clear();
        lineage_.clear();
        settings_ = {};

        if (!intfc) {
            return;
        }

        std::uint32_t type = 0;
        std::uint32_t version = 0;
        std::uint32_t length = 0;

        while (intfc->GetNextRecordInfo(type, version, length)) {
            if (type == 'DYCF' || type == 'DYHS' || type == 'DYLD') {
                LoadFeatures(intfc, type, version);
                continue;
            }
            if (type == 'DYFA') {
                LoadAppearance(intfc, version);
                continue;
            }
            if (type == 'DYTL') {
                LoadTalentsRecord(intfc, version);
                continue;
            }
            if (type != kRecordType || version > kRecordVersion) {
                continue;
            }

            std::uint32_t count = 0;
            std::uint64_t loadedNextID = 1;

            if (intfc->ReadRecordData(count) != sizeof(count)) {
                continue;
            }

            if (version >= 2) {
                if (intfc->ReadRecordData(loadedNextID) != sizeof(loadedNextID)) {
                    loadedNextID = 1;
                }
            }

            nextID_ = std::max<std::uint64_t>(loadedNextID, 1);

            for (std::uint32_t i = 0; i < count; ++i) {
                RE::FormID oldActorID = 0;
                Genome genome{};

                if (intfc->ReadRecordData(oldActorID) != sizeof(oldActorID)) {
                    break;
                }

                if (intfc->ReadRecordData(genome) != sizeof(genome)) {
                    break;
                }

                RE::FormID actorID = oldActorID;
                if (!intfc->ResolveFormID(oldActorID, actorID)) {
                    continue;
                }

                if (genome.parentAFormID != 0) {
                    RE::FormID resolved = genome.parentAFormID;
                    if (intfc->ResolveFormID(genome.parentAFormID, resolved)) {
                        genome.parentAFormID = resolved;
                    }
                }

                if (genome.parentBFormID != 0) {
                    RE::FormID resolved = genome.parentBFormID;
                    if (intfc->ResolveFormID(genome.parentBFormID, resolved)) {
                        genome.parentBFormID = resolved;
                    }
                }

                genomes_[actorID] = genome;
                nextID_ = std::max(nextID_, genome.logicalID + 1);
            }
        }
    }

    void GeneticsEngine::Revert()
    {
        std::lock_guard lock(mutex_);
        ClearTalents();
        faces_.clear();
        genomes_.clear();
        extras_.clear();
        lineage_.clear();
        settings_ = {};
        nextID_ = 1;
    }
}
