#include "Genetics.h"
#include <sstream>
#include <cmath>
#include <climits>
namespace Dynasty {
namespace {
constexpr std::array<const char*,18> skills{"One-handed","Two-handed","Archery","Block","Smithing","Heavy armour","Light armour","Pickpocket","Lockpicking","Sneak","Alchemy","Speech","Alteration","Conjuration","Destruction","Illusion","Restoration","Enchanting"};
constexpr std::array<const char*,6> roles{"Undecided","Warrior","Archer","Mage","Rogue","Craftsman"};
std::string Name(RE::TESForm* f) { return f && f->GetName() ? f->GetName() : "Unknown"; }
Json Encode(const LineageEntry& e) {
    return {{"id",e.id},{"father",e.father},{"mother",e.mother},{"generation",e.generation},{"status",e.status},{"actor",e.actor},{"name",e.name},{"fatherName",e.fatherName},{"motherName",e.motherName},{"race",e.race},{"home",e.home},{"specialty",e.specialty},{"skills",e.skills}};
}
void Write(SKSE::SerializationInterface* stream, std::uint32_t type, const Json& j) {
    auto text=j.dump(); if (text.size()>UINT32_MAX || !stream->OpenRecord(type,1)) return;
    auto size=static_cast<std::uint32_t>(text.size()); stream->WriteRecordData(size); stream->WriteRecordData(text.data(),size);
}
}
DynastySettings GeneticsEngine::Settings() const { std::lock_guard lock(mutex_); return settings_; }
float GeneticsEngine::GetSetting(std::string key) const {
    std::lock_guard lock(mutex_);
    if(key=="livingLimit")return float(settings_.livingLimit);
    if(key=="inheritance")return settings_.inheritance;
    if(key=="quality")return settings_.quality;
    if(key=="femaleChance")return settings_.femaleChance;
    if(key=="effects")return settings_.effects;
    if(key=="safePerks")return settings_.safePerks;
    if(key=="externalAppearance")return settings_.externalAppearance;
    if(key=="randomCombat")return settings_.randomCombat;
    return 0;
}
void GeneticsEngine::SetSetting(std::string key,float value) {
    std::lock_guard lock(mutex_); if(!std::isfinite(value))return;
    if(key=="livingLimit")settings_.livingLimit=std::clamp(int(value),1,32);
    else if(key=="inheritance")settings_.inheritance=std::clamp(value,0.0F,2.0F);
    else if(key=="quality")settings_.quality=std::clamp(value,0.0F,1.0F);
    else if(key=="femaleChance")settings_.femaleChance=std::clamp(value,0.0F,1.0F);
    else if(key=="effects")settings_.effects=value>=0.5F;
    else if(key=="safePerks")settings_.safePerks=value>=0.5F;
    else if(key=="externalAppearance")settings_.externalAppearance=value>=0.5F;
    else if(key=="randomCombat")settings_.randomCombat=value>=0.5F;
}
void GeneticsEngine::RecordBirth(RE::Actor* actor,RE::Actor* father,RE::Actor* mother) {
    std::lock_guard lock(mutex_); auto g=GetGenome(actor); if(!g)return;
    for(auto* parent:{father,mother})if(auto pg=GetGenome(parent);pg&&!lineage_.contains(pg->logicalID)) {
        LineageEntry e; e.id=pg->logicalID;e.actor=parent->GetFormID();e.name=parent->GetDisplayFullName();e.race=Name(parent->GetRace());e.status=3;for(int i=0;i<18;++i)e.skills[i]=std::clamp(parent->AsActorValueOwner()->GetBaseActorValue(static_cast<RE::ActorValue>(6+i)),0.0F,100.0F);lineage_[e.id]=e;
    }
    auto& e=lineage_[g->logicalID]; if(e.id)return;
    e.id=g->logicalID;e.actor=actor->GetFormID();e.name=actor->GetDisplayFullName();e.race=Name(actor->GetRace());
    if(auto pg=GetGenome(father)){e.father=pg->logicalID;e.fatherName=father->GetDisplayFullName();}
    if(auto pg=GetGenome(mother)){e.mother=pg->logicalID;e.motherName=mother->GetDisplayFullName();}
    e.generation=1+std::max(lineage_.contains(e.father)?lineage_[e.father].generation:0,lineage_.contains(e.mother)?lineage_[e.mother].generation:0);
    auto t=talents_.find(actor->GetFormID());if(t!=talents_.end())e.skills=t->second.skills;
    e.specialty=roles[std::clamp(extras_[actor->GetFormID()].role,0,5)];
}
void GeneticsEngine::RecordHome(RE::Actor* actor,std::string home) {
    std::lock_guard lock(mutex_);if(auto g=GetGenome(actor);g&&lineage_.contains(g->logicalID))lineage_[g->logicalID].home=home.substr(0,256);
}
void GeneticsEngine::RetireFeatures(RE::Actor* actor) {
    if(auto g=GetGenome(actor);g&&lineage_.contains(g->logicalID)) {
        auto& e=lineage_[g->logicalID];if(e.status!=2){e.status=1;e.actor=0;}
    }
    extras_.erase(actor->GetFormID());
}
void GeneticsEngine::InheritSuccessorFeatures(RE::Actor* heir) {
    auto* player=RE::PlayerCharacter::GetSingleton();
    if(auto it=extras_.find(heir->GetFormID());it!=extras_.end()){extras_[player->GetFormID()]=it->second;extras_[player->GetFormID()].lookApplied=false;}
    if(auto g=GetGenome(heir);g&&lineage_.contains(g->logicalID)){auto& e=lineage_[g->logicalID];e.status=2;e.actor=player->GetFormID();}
}
std::string GeneticsEngine::HeirSummary(RE::Actor* actor) const {
    std::lock_guard lock(mutex_);if(!actor)return "Unavailable";
    std::ostringstream out;out<<actor->GetDisplayFullName()<<" | "<<Name(actor->GetRace());
    auto x=extras_.find(actor->GetFormID());if(x!=extras_.end())out<<" | "<<roles[std::clamp(x->second.role,0,5)];
    out<<" | level "<<actor->GetLevel();
    std::array<std::pair<float,int>,18> ranked{};
    for(int i=0;i<18;++i)ranked[i]={actor->AsActorValueOwner()->GetBaseActorValue(static_cast<RE::ActorValue>(6+i)),i};
    std::sort(ranked.rbegin(),ranked.rend());
    for(int i=0;i<3;++i)out<<" | "<<skills[ranked[i].second]<<" "<<int(ranked[i].first);
    if(auto g=GetGenome(actor);g&&lineage_.contains(g->logicalID)) {
        const auto& e=lineage_.at(g->logicalID);out<<"\nGeneration "<<e.generation<<"; parents: "<<e.fatherName<<" / "<<e.motherName;
        if(!e.home.empty())out<<"\nHome: "<<e.home;
    }
    out<<"\nEquipped: ";bool first=true;
    for(auto& [item,data]:actor->GetInventory())if(item&&data.second&&data.second->IsWorn()) {
        if(!first)out<<", ";out<<Name(item);first=false;
    }
    if(first)out<<"None";
    auto talent=talents_.find(actor->GetFormID());if(talent!=talents_.end())out<<"\nInherited perks: "<<talent->second.perks.size();

    return out.str();
}
int GeneticsEngine::JournalCount() const {std::lock_guard lock(mutex_);return int(std::min<std::size_t>(lineage_.size(),INT_MAX));}
std::string GeneticsEngine::JournalLabel(int index) const {
    std::lock_guard lock(mutex_);if(index<0||std::size_t(index)>=lineage_.size())return "";
    auto it=lineage_.begin();std::advance(it,index);const auto& e=it->second;
    return std::format("{} | G{} | {}",e.name,e.generation,e.status==0?"Alive":e.status==1?"Deceased":e.status==2?"Successor":"Founder");
}
std::string GeneticsEngine::JournalDetails(int index) const {
    std::lock_guard lock(mutex_);if(index<0||std::size_t(index)>=lineage_.size())return "";
    auto it=lineage_.begin();std::advance(it,index);const auto& e=it->second;
    if(e.actor&&e.status!=1)if(auto* actor=RE::TESForm::LookupByID<RE::Actor>(e.actor);actor&&e.status!=3&&GetGenome(actor)&&GetGenome(actor)->logicalID==e.id)return HeirSummary(actor);
    std::ostringstream out;out<<e.name<<" | "<<e.race<<" | "<<e.specialty<<"\nGeneration "<<e.generation<<"; lineage #"<<e.id<<"\nParents: "<<e.fatherName<<" (#"<<e.father<<") / "<<e.motherName<<" (#"<<e.mother<<")\nHome: "<<e.home;
    for(int i=0;i<18;++i)out<<"\n"<<skills[i]<<": "<<int(e.skills[i]);return out.str();
}
void GeneticsEngine::SaveFeatures(SKSE::SerializationInterface* stream) const {
    Write(stream,'DYCF',{{"livingLimit",settings_.livingLimit},{"inheritance",settings_.inheritance},{"quality",settings_.quality},{"femaleChance",settings_.femaleChance},{"effects",settings_.effects},{"safePerks",settings_.safePerks},{"externalAppearance",settings_.externalAppearance},{"randomCombat",settings_.randomCombat}});
    for(const auto& [id,e]:lineage_)Write(stream,'DYHS',Encode(e));
    for(const auto& [id,e]:extras_)Write(stream,'DYLD',{{"actor",id},{"slot",e.slot},{"role",e.role},{"style",e.style},{"styleMix",e.styleMix},{"items",e.items},{"spells",e.spells},{"custom",e.custom}});
}
void GeneticsEngine::LoadFeatures(SKSE::SerializationInterface* stream,std::uint32_t type,std::uint32_t version) {
    if(version!=1)return;std::uint32_t size{};if(stream->ReadRecordData(size)!=4||size>4*1024*1024)return;
    std::string text(size,'\0');if(stream->ReadRecordData(text.data(),size)!=size)return;
    try {auto j=Json::parse(text);
        if(type=='DYCF'){for(auto key:{"livingLimit","inheritance","quality","femaleChance","effects","safePerks","externalAppearance","randomCombat"})if(j.contains(key))SetSetting(key,j[key].is_boolean()?float(j[key].get<bool>()):j[key].get<float>());}
        if(type=='DYHS') {LineageEntry e;e.id=j.at("id");e.father=j.at("father");e.mother=j.at("mother");e.generation=j.at("generation");e.status=j.at("status");e.actor=j.at("actor");e.name=j.at("name");e.fatherName=j.at("fatherName");e.motherName=j.at("motherName");e.race=j.at("race");e.home=j.at("home");e.specialty=j.at("specialty");e.skills=j.at("skills").get<std::array<float,18>>();
            if(e.id&&e.generation>=0&&e.status>=0&&e.status<=3&&e.name.size()<1024&&e.fatherName.size()<1024&&e.motherName.size()<1024&&e.race.size()<1024&&e.home.size()<1024&&std::all_of(e.skills.begin(),e.skills.end(),[](float v){return std::isfinite(v)&&v>=0&&v<=100;})){RE::FormID resolved{};e.actor=e.actor&&stream->ResolveFormID(e.actor,resolved)?resolved:0;lineage_[e.id]=std::move(e);}}
        if(type=='DYLD'){RE::FormID id{},old=j.at("actor");if(!stream->ResolveFormID(old,id))return;HeirFeatures e;e.slot=j.at("slot");e.role=j.at("role");e.style=j.at("style");e.styleMix=j.at("styleMix").get<std::array<float,10>>();e.items=j.at("items").get<std::vector<RE::FormID>>();e.spells=j.at("spells").get<std::vector<RE::FormID>>();e.custom=j.at("custom");
            if(e.slot<0||e.slot>=32||e.role<0||e.role>5||e.items.size()>20||e.spells.size()>4||!e.custom.is_object())return;
            for(auto* list:{&e.items,&e.spells}){for(auto& form:*list){RE::FormID resolved{};form=stream->ResolveFormID(form,resolved)?resolved:0;}std::erase(*list,0);}
            RE::FormID resolved{};e.style=e.style&&stream->ResolveFormID(e.style,resolved)?resolved:0;
            if(std::all_of(e.styleMix.begin(),e.styleMix.end(),[](float v){return std::isfinite(v)&&v>=0.1F&&v<=3.0F;}))extras_[id]=std::move(e);
        }
    }catch(const Json::exception& e){SKSE::log::warn("Ignored invalid dynasty feature record: {}",e.what());}
}
}
