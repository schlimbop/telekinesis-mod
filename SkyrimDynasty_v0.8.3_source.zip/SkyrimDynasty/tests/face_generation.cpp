#include "InheritanceRules.h"
#include "FacePaintRules.h"
#include <cstdlib>
#include <iostream>
#define CHECK(expr) do { if (!(expr)) { std::cerr << #expr << " failed\n"; return EXIT_FAILURE; } } while(false)
int main() {
    using namespace Dynasty;
    std::mt19937_64 rng(781921);
    unsigned raceA=0,raceB=0,mutations=0,low=0,high=0,hair=0,paint=0,preset=0;
    for (unsigned i=0;i<20000;++i) {
        auto race=ParentalRace(13746,13742,rng);
        CHECK(race==13746 || race==13742); raceA+=race==13746; raceB+=race==13742;
        CHECK(ParentalRace(13746,13746,rng)==13746);
        float allele=FaceAllele(-0.7F,-0.3F,rng);
        CHECK(std::isfinite(allele) && allele>=-1 && allele<=1);
        low+=allele==-0.7F; high+=allele==-0.3F; mutations+=allele!=-0.7F && allele!=-0.3F;
        CHECK(FaceAllele(-1,-1,rng)>=-1 && FaceAllele(1,1,rng)<=1);
        hair+=Chance(kHairColourMutationChance,rng); paint+=Chance(kFacePaintChance,rng);
        auto shape=FacePreset(2,2,(1U<<2)|(1U<<9)|(1U<<15),rng);
        CHECK(shape==2 || shape==9 || shape==15); preset+=shape!=2;
        auto mixed=FacePreset(31,0,(1U<<4)|(1U<<12),rng); CHECK(mixed==4 || mixed==12);
        CHECK(FacePreset(2,2,1U<<2,rng)==2);
        CHECK(FacePreset(2,2,0,rng)==2);
    }
    CHECK(raceA>9700 && raceA<10300 && raceB>9700 && raceB<10300);
    CHECK(mutations>1700 && mutations<2300 && low>8500 && high>8500);
    CHECK(hair>800 && hair<1200 && paint>4600 && paint<5400 && preset>2700 && preset<3300);
    // Stored mutant alleles are valid inputs for subsequent generations.
    bool inheritedMutant=false;
    for(unsigned i=0;i<100;++i) inheritedMutant|=FaceAllele(0.137F,0.8F,rng)==0.137F;
    CHECK(inheritedMutant);
    const std::array<std::uint8_t,4> skin{210,190,170,255},colour{10,20,30,255};
    CHECK(PaintPixel(skin,colour,{0,0,0,255},1)==skin);
    CHECK(PaintPixel(skin,colour,{255,255,255,0},1)==skin);
    CHECK(PaintPixel(skin,colour,{255,255,255,255},1)==colour);
    CHECK(PaintPixel(skin,colour,{255,255,255,255},0)==skin);
    auto half=PaintPixel(skin,colour,{255,255,255,255},0.5F);
    CHECK(half[0]==110 && half[1]==105 && half[2]==100 && half[3]==255);
    std::cout<<"20,000 births: race balance, parental DNA, mutations, valid presets, hair/paint rates and seam-safe paint passed\n";
}
