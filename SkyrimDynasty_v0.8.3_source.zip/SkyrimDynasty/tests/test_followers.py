"""Execute the shipped follower routines with mocked cells, actors and quest aliases."""
from types import SimpleNamespace
import unittest
from test_lifecycle import load_function

class Actor:
    def __init__(self,cell='road',world='Tamriel',interior=False,distance=200):
        self.cell=cell;self.world=world;self.interior=interior;self.distance=distance
        self.dead=False;self.disabled=False;self.loaded=True
        self.moves=[];self.evaluations=0;self.teammate=False;self.restrained=False;self.offset=True
    def IsDead(self):return self.dead
    def IsDisabled(self):return self.disabled
    def Is3DLoaded(self):return self.loaded
    def GetWorldSpace(self):return self.world
    def GetParentCell(self):return self.cell
    def IsInInterior(self):return self.interior
    def GetDistance(self,other):return self.distance
    def MoveTo(self,target,*offset):
        self.moves.append((target,offset));self.cell=target.cell;self.world=target.world
        self.interior=target.interior;self.distance=200
    def ClearKeepOffsetFromActor(self):self.offset=False
    def SetRestrained(self,value):self.restrained=value
    def SetPlayerTeammate(self,value,*args):self.teammate=value
    def SetRelationshipRank(self,*args):pass
    def SetFactionRank(self,*args):pass
    def EvaluatePackage(self):self.evaluations+=1
    def GetDisplayName(self):return 'Heir'

class Alias:
    def __init__(self):self.ref=None
    def GetReference(self):return self.ref
    def GetActorReference(self):return self.ref
    def Clear(self):self.ref=None
    def ForceRefTo(self,actor):self.ref=actor

class Followers(unittest.TestCase):
    def setUp(self):
        self.aliases=[Alias() for i in range(32)]
        self.player=Actor();self.cancelled=[]
        self.env=dict(PlayerRef=self.player,followerQuest=SimpleNamespace(
            GetAlias=lambda i:self.aliases[i],IsRunning=lambda:True),
            HeirFaction=object(),HeirRefs=[None]*32,BehaviourStates=[0]*32,Stages=[3]*32,
            GreetingPending=[True]*32,GreetingCompleted=[False]*32,SlotBusy=[False]*32,HomeMarkers=[None]*32,successionBusy=False,
            GreetingQuest=SimpleNamespace(CancelForHeir=self.cancelled.append),
            Debug=SimpleNamespace(Notification=lambda text:None),InitialiseArrays=lambda:None)
        self.env['FindHeirIndex']=lambda actor:self.env['HeirRefs'].index(actor) if actor in self.env['HeirRefs'] else -1
        for name in ['ClearFollowerAlias','ApplyFollowerBehaviour','MaintainFollowers','RecruitHeir','WaitHere','DismissHeir','RestoreBehaviour']:
            load_function(name,self.env)
    def heir(self,index,state=1,**kwargs):
        actor=Actor(**kwargs);self.env['HeirRefs'][index]=actor;self.env['BehaviourStates'][index]=state
        return actor
    def test_multiple_recruits_get_real_follow_alias_and_clear_legacy_offset(self):
        for i in [0,1,31]:
            actor=self.heir(i,0);self.env['RecruitHeir'](i)
            self.assertIs(self.aliases[i].ref,actor)
            self.assertTrue(actor.teammate);self.assertFalse(actor.offset or actor.restrained)
            self.assertEqual(actor.evaluations,1)
            self.assertFalse(self.env['GreetingPending'][i]);self.assertTrue(self.env['GreetingCompleted'][i])
        self.assertEqual(len(self.cancelled),3)
    def test_door_same_location_different_interior_and_worldspace_recover(self):
        for i,kwargs in enumerate([dict(cell='inn',world=None,interior=True),
                dict(cell='road2',world='Solstheim'),dict(cell='road2',distance=9000)]):
            actor=self.heir(i,**kwargs)
            self.env['MaintainFollowers']()
            self.assertEqual(len(actor.moves),1)
            self.assertEqual(actor.cell,self.player.cell)
        self.env['MaintainFollowers']()
        self.assertEqual([len(self.env['HeirRefs'][i].moves) for i in range(3)],[1,1,1])
    def test_adjacent_exteriors_and_nearby_followers_walk_normally(self):
        actor=self.heir(0,cell='adjacent exterior',distance=800)
        self.env['MaintainFollowers']()
        self.assertEqual(actor.moves,[]);self.assertIs(self.aliases[0].ref,actor)
    def test_fast_travel_moves_all_followers_but_leaves_wait_home_dismissed(self):
        for i in range(8):self.heir(i,1 if i<5 else i-3,distance=20000)
        self.env['MaintainFollowers']()
        self.assertEqual([len(a.moves) for a in self.env['HeirRefs'][:8]],[1,1,1,1,1,0,0,0])
        self.assertEqual(len({a.moves[0][1] for a in self.env['HeirRefs'][:5]}),5)
    def test_wait_dismiss_and_restore_drop_aliases_and_stop_catchup(self):
        for command in ['WaitHere','DismissHeir']:
            actor=self.heir(0,distance=20000);self.env['RecruitHeir'](0)
            self.env[command](0);self.env['MaintainFollowers']()
            self.assertIsNone(self.aliases[0].ref);self.assertFalse(actor.teammate)
            self.assertEqual(actor.moves,[])
        actor=self.heir(0,1);self.env['RestoreBehaviour'](actor)
        self.assertIs(self.aliases[0].ref,actor);self.assertTrue(actor.teammate)
        self.env['BehaviourStates'][0]=3;self.env['RestoreBehaviour'](actor)
        self.assertIsNone(self.aliases[0].ref);self.assertFalse(actor.teammate)
    def test_dead_disabled_juvenile_and_busy_never_teleport(self):
        for i in range(4):self.heir(i,distance=20000);self.aliases[i].ref=self.env['HeirRefs'][i]
        self.env['HeirRefs'][0].dead=True;self.env['HeirRefs'][1].disabled=True
        self.env['Stages'][2]=2;self.env['SlotBusy'][3]=True
        self.env['MaintainFollowers']()
        self.assertEqual([a.moves for a in self.env['HeirRefs'][:4]],[[]]*4)
        for i in [0,2,3]:self.assertIsNone(self.aliases[i].ref)
    def test_loading_dead_player_and_succession_defer_recovery(self):
        actor=self.heir(0,distance=20000)
        self.player.loaded=False;self.env['MaintainFollowers']()
        self.player.loaded=True;self.player.dead=True;self.env['MaintainFollowers']()
        self.player.dead=False;self.env['successionBusy']=True;self.env['MaintainFollowers']()
        self.assertEqual(actor.moves,[])
        self.env['successionBusy']=False;self.env['MaintainFollowers']()
        self.assertEqual(len(actor.moves),1)

if __name__=='__main__':unittest.main()
