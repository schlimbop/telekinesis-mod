#include "FaceMask.h"
#include <cstdlib>
#include <iostream>
#define CHECK(expr) do { if (!(expr)) { std::cerr << #expr << " failed\n"; return EXIT_FAILURE; } } while(false)
int main() {
    using namespace DirectX;
    // Deliberately no CoInitialize: this is also safe on Skyrim's render task.
    ScratchImage original;
    CHECK(SUCCEEDED(original.Initialize2D(DXGI_FORMAT_B8G8R8A8_UNORM,64,64,1,1)));
    auto* image=original.GetImage(0,0,0);
    for(std::size_t y=0;y<64;++y) for(std::size_t x=0;x<64;++x) {
        auto* p=image->pixels+y*image->rowPitch+x*4;
        p[0]=p[1]=p[2]=x<32?0:255;p[3]=255;
    }
    for(auto format:{DXGI_FORMAT_B8G8R8A8_UNORM,DXGI_FORMAT_BC1_UNORM,DXGI_FORMAT_BC3_UNORM}) {
        ScratchImage compressed;const Image* source=image;
        if(IsCompressed(format)) {
            CHECK(SUCCEEDED(Compress(*image,format,TEX_COMPRESS_DEFAULT,0.5F,compressed)));
            source=compressed.GetImage(0,0,0);
        }
        Blob dds;CHECK(SUCCEEDED(SaveToDDSMemory(*source,DDS_FLAGS_NONE,dds)));
        ScratchImage decoded;
        CHECK(Dynasty::DecodeFaceMask({static_cast<const std::uint8_t*>(dds.GetBufferPointer()),dds.GetBufferSize()},decoded));
        const auto* result=decoded.GetImage(0,0,0);
        CHECK(result && result->width==512 && result->height==512 && result->format==DXGI_FORMAT_R8G8B8A8_UNORM);
        auto* outside=result->pixels+100*result->rowPitch+100*4;
        auto* inside=result->pixels+100*result->rowPitch+400*4;
        CHECK(outside[0]==0 && outside[3]==255 && inside[0]==255 && inside[3]==255);
    }
    const std::uint8_t invalid[]{0,1,2,3};ScratchImage empty;
    CHECK(!Dynasty::DecodeFaceMask(invalid,empty));
    std::cout<<"DDS BGRA/BC1/BC3 decoding, conversion, resize and invalid-input rejection pass without COM\n";
}
