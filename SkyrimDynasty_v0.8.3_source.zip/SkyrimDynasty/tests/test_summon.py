from types import SimpleNamespace as NS
import unittest
from test_lifecycle import load_function
class SummonTests(unittest.TestCase):
    def run_summon(self,effects=True,portal=True,dead=False,loaded=True):
        events=[]
        class Ref:
            def MoveTo(self,*args):events.append(('portal_move',args))
            def Disable(self):events.append(('portal_disable',))
            def Delete(self):events.append(('portal_delete',))
        class Actor:
            def IsDead(self):return dead
            def SetAlpha(self,value,*args):events.append(('alpha',value))
            def MoveTo(self,*args):events.append(('heir_move',args))
            def Enable(self,*args):events.append(('enable',))
            def Is3DLoaded(self):return loaded
        actor=Actor()
        def place(*args):events.append(('portal',args));return Ref() if portal else None
        assets={0x7cd55:object(),0xcf79f:NS(Play=lambda *args:events.append(('shader',))),
            0x4e793:NS(Play=lambda *args:events.append(('sound',)) or 17)}
        env=dict(PlayerRef=NS(PlaceAtMe=place),Game=NS(GetForm=assets.get),
            DynastyNative=NS(GetSetting=lambda key:effects,RefreshAppearance=lambda a:events.append(('face',))),
            EquipRandomAdultLoadout=lambda a:events.append(('equip',)),Utility=NS(Wait=lambda t:events.append(('wait',t))),
            Sound=NS(StopInstance=lambda n:events.append(('stop',n))))
        load_function('SummonBesidePlayer',env);env['SummonBesidePlayer'](actor)
        return events
    def test_portal_sound_shader_cover_equipped_reveal_and_cleanup(self):
        e=self.run_summon();names=[x[0] for x in e]
        reveal=e.index(('alpha',1.0))
        for name in ['face','equip','portal','portal_move','shader','sound']:self.assertLess(names.index(name),reveal)
        self.assertLess(reveal,names.index('portal_delete'))
        self.assertIn(('stop',17),e)
    def test_effect_setting_is_respected_without_leaving_invisible_actor(self):
        e=self.run_summon(False);self.assertIn(('alpha',1.0),e)
        self.assertFalse(any(x[0] in ['portal','sound','shader'] for x in e))
    def test_failed_portal_and_slow_3d_still_restore_visibility(self):
        e=self.run_summon(portal=False,loaded=False);self.assertIn(('alpha',1.0),e)
        self.assertEqual(sum(x==('wait',0.1) for x in e),30)
        self.assertNotIn(('shader',),e)
    def test_dead_actor_is_untouched(self):self.assertEqual(self.run_summon(dead=True),[])
