#include "PlayerAppearance.h"
#include <cstring>
#include <iostream>
#define CHECK(expr) do { if (!(expr)) { std::cerr << #expr << " failed\n"; return EXIT_FAILURE; } } while (false)
int main() {
    using Runtime = REL::Module::Runtime;
    struct Layout { REL::Version version; Runtime runtime; std::size_t masks; };
    for (const auto& layout : {
        Layout{{1,5,97,0}, Runtime::SE, 0xB10},
        Layout{{1,6,353,0}, Runtime::AE, 0xB10},
        Layout{{1,6,629,0}, Runtime::AE, 0xB18},
        Layout{{1,6,1170,0}, Runtime::AE, 0xB18},
        Layout{{1,7,99,0}, Runtime::AE, 0xB20},
        Layout{{1,7,104,0}, Runtime::AE, 0xB20}}) {
        CHECK(REL::Module::mock(layout.version, layout.runtime, L"TintLayoutTest.exe", 0x1000));
        alignas(16) std::array<std::byte, 0x1400> storage{};
        auto* player = reinterpret_cast<RE::PlayerCharacter*>(storage.data());
        auto* expected = reinterpret_cast<RE::BSTArray<RE::TintMask*>*>(storage.data() + layout.masks);
        CHECK(Dynasty::PlayerTintMasks(player) == expected);
        // On 1.7.104, the old accessor treats the array count at B30 as an overlay pointer.
        if (layout.version >= REL::Version{1,7,99,0}) {
            const std::uintptr_t staleOverlay = 0x21;
            std::memcpy(storage.data() + 0xB30, &staleOverlay, sizeof(staleOverlay));
            CHECK(Dynasty::PlayerTintMasks(player) == expected);
        }
        alignas(8) std::array<std::byte, sizeof(RE::BSTArray<RE::TintMask*>)> overlayStorage{};
        auto* overlay = reinterpret_cast<RE::BSTArray<RE::TintMask*>*>(overlayStorage.data());
        std::memcpy(storage.data() + layout.masks + sizeof(*expected), &overlay, sizeof(overlay));
        CHECK(Dynasty::PlayerTintMasks(player) == overlay);
        REL::Module::reset();
    }
    CHECK(Dynasty::PlayerTintMasks(nullptr) == nullptr);
    std::cout << "Player tint fallback/overlay layouts passed for six Skyrim runtimes, including the 0x21 crash regression\n";
}
