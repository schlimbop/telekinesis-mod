#pragma once
#include "Genetics.h"
namespace Dynasty {
std::string BuildFaceTintTexture(RE::FormID actor, const FaceGenome& face);
bool ApplyFaceTintTexture(RE::BSGeometry* geometry, RE::BSLightingShaderProperty* shader,
    RE::BSLightingShaderMaterialBase* material, const std::string& path);
void ClearFaceTintTextures();
void ForgetFaceTintTexture(RE::FormID actor);
}
