#pragma once

#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>

#include <cstdint>
#include <array>
#include <mutex>
#include <vector>
#include <optional>
#include <random>
#include <string>
#include <unordered_map>

#include "Features.h"

namespace Dynasty
{
    enum class Sex : std::uint8_t
    {
        Male = 0,
        Female = 1
    };

    struct DiploidFloat
    {
        float a{ 0.5F };
        float b{ 0.5F };
    };

    struct Genome
    {
        std::uint64_t logicalID{ 0 };

        DiploidFloat jawWidth;
        DiploidFloat chinHeight;
        DiploidFloat noseLength;
        DiploidFloat noseWidth;
        DiploidFloat eyeSpacing;
        DiploidFloat eyeSize;
        DiploidFloat cheekHeight;
        DiploidFloat browHeight;
        DiploidFloat height;

        DiploidFloat intelligence;
        DiploidFloat physique;
        DiploidFloat magicalAffinity;

        RE::FormID parentAFormID{ 0 };
        RE::FormID parentBFormID{ 0 };

        Sex sex{ Sex::Male };
    };

    struct FaceGenome
    {
        std::array<DiploidFloat, 19> morphs{};
        std::array<float, 19> expression{};
        std::array<std::int32_t, 4> presets{};
        RE::SEX sex{RE::SEX::kMale};
        bool needsMigration{false};
        RE::FormID race{}, hairColor{}, faceTexture{}, skin{}, farSkin{};
        std::uint32_t bodyColor{}, hairRGB{0xFF404040};
        float weight{50.0F};
        std::vector<RE::FormID> headParts;
        std::vector<RE::TESNPC::Layer> tints;
    };

    struct TalentGenome
    {
        std::array<float, 18> skills{};
        std::vector<RE::FormID> perks;
    };

    class GeneticsEngine
    {
    public:
        static GeneticsEngine& GetSingleton();

        Genome MakeFounderGenome(RE::Actor* actor);
        Genome Breed(const Genome& parentA, const Genome& parentB);

        bool AttachGenome(RE::Actor* actor, Genome genome);
        bool TransferGenome(RE::Actor* oldActor, RE::Actor* newActor);
        std::optional<Genome> GetGenome(RE::Actor* actor) const;

        std::string Describe(RE::Actor* actor) const;
        std::string GenerateName(bool female);
        float HeightScale(RE::Actor* actor) const;

        bool CaptureAppearance(RE::Actor* heir, RE::Actor* a, RE::Actor* b);
        bool ApplyAppearance(RE::Actor* actor);
        bool RefreshAppearance(RE::Actor* actor);
        RE::TESRace* InheritedRace(RE::Actor* actor) const;
        void SaveAppearance(SKSE::SerializationInterface* stream) const;
        void LoadAppearance(SKSE::SerializationInterface* stream, std::uint32_t version);

        bool CaptureTalents(RE::Actor* child, RE::Actor* player, RE::Actor* mother);
        bool PrepareAdult(RE::Actor* child, RE::TESNPC* base);
        bool ApplyInheritedSkills(RE::Actor* actor);
        bool RestoreInheritedPerks(RE::Actor* actor);

        void ForgetActor(RE::Actor* actor);
        bool AdoptHeir(RE::Actor* heir);
        void ResetBasePerks(RE::TESNPC* base);

        DynastySettings Settings() const;
        float GetSetting(std::string key) const;
        void SetSetting(std::string key, float value);
        std::vector<RE::TESForm*> GenerateLoadout(RE::Actor* actor, int slot, bool reroll);
        std::vector<RE::TESForm*> RemoveInvalidLoadoutItems(RE::Actor* actor);
        RE::BGSOutfit* PrepareOutfit(RE::Actor* actor);
        std::vector<RE::SpellItem*> CombatSpells(RE::Actor* actor);
        void ChooseCombatRole(RE::Actor* actor, int role);
        void RestoreCombatRole(RE::Actor* actor);
        std::string HeirSummary(RE::Actor* actor) const;
        void RecordBirth(RE::Actor* actor, RE::Actor* father, RE::Actor* mother);
        void RecordHome(RE::Actor* actor, std::string home);
        int JournalCount() const;
        std::string JournalLabel(int index) const;
        std::string JournalDetails(int index) const;
        void CaptureExternalLook(RE::Actor* actor, RE::Actor* father, RE::Actor* mother);
        void ApplyExternalLook(RE::Actor* actor);
        static void ConnectAppearanceBridge();
        void SaveFeatures(SKSE::SerializationInterface* stream) const;
        void LoadFeatures(SKSE::SerializationInterface* stream, std::uint32_t type, std::uint32_t version);

        void Save(SKSE::SerializationInterface* intfc) const;
        void Load(SKSE::SerializationInterface* intfc);
        void Revert();

    private:
        DynastySettings settings_;
        std::unordered_map<RE::FormID, HeirFeatures> extras_;
        std::map<std::uint64_t, LineageEntry> lineage_;
        void RetireFeatures(RE::Actor* actor);
        void InheritSuccessorFeatures(RE::Actor* heir);
        GeneticsEngine();
        bool ApplyPerks(RE::TESNPC* base, const TalentGenome& talent);
        void SaveTalents(SKSE::SerializationInterface* stream) const;
        void LoadTalentsRecord(SKSE::SerializationInterface* stream, std::uint32_t version);
        void ClearTalents();
        std::unordered_map<RE::FormID, FaceGenome> faces_;
        std::unordered_map<RE::FormID, TalentGenome> talents_;
        std::unordered_map<RE::FormID, std::vector<RE::FormID>> appliedBasePerks_;

        float ChooseAllele(const DiploidFloat& locus);
        DiploidFloat BreedLocus(const DiploidFloat& a, const DiploidFloat& b);
        float Mutate(float value);
        float Phenotype(const DiploidFloat& locus) const;
        std::uint64_t NextID();

        mutable std::recursive_mutex mutex_;
        mutable std::mt19937_64 rng_;
        std::unordered_map<RE::FormID, Genome> genomes_;
        std::uint64_t nextID_{ 1 };
    };
}
