#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
namespace Dynasty {
constexpr float InheritedSkill(float player, float mother, float variation) {
    return std::clamp((player + mother) * 0.5F + variation, 0.0F, 100.0F);
}
inline float NormaliseFaceMorph(float v) {
    return std::isfinite(v) && std::abs(v) < 100.0F ? std::clamp(v, -1.0F, 1.0F) : 0.0F;
}
inline float ExpressFaceMorph(float a, float b) {
    return std::clamp((NormaliseFaceMorph(a) + NormaliseFaceMorph(b)) * 0.5F, -1.0F, 1.0F);
}
inline float InheritedTrait(float a, float b, float dominance, float variation = 0.0F) {
    return std::clamp(std::lerp(NormaliseFaceMorph(a), NormaliseFaceMorph(b),
        std::clamp(dominance, 0.0F, 1.0F)) + variation, -1.0F, 1.0F);
}
inline constexpr double kFaceMutationChance = 0.10;
inline constexpr double kPresetMutationChance = 0.15;
inline constexpr double kHairColourMutationChance = 0.05;
inline constexpr double kFacePaintChance = 0.25;
inline bool Chance(double probability, std::mt19937_64& rng) {
    return std::bernoulli_distribution(probability)(rng);
}
inline std::uint32_t ParentalRace(std::uint32_t a, std::uint32_t b, std::mt19937_64& rng) {
    return a == b || Chance(0.5, rng) ? a : b;
}
inline float FaceAllele(float a, float b, std::mt19937_64& rng) {
    float value = NormaliseFaceMorph(Chance(0.5, rng) ? a : b);
    if (Chance(kFaceMutationChance, rng)) {
        float delta = std::clamp(std::normal_distribution<float>(0.0F, 0.12F)(rng), -0.3F, 0.3F);
        value = NormaliseFaceMorph(value + delta);
    }
    return value;
}
inline std::int32_t FacePreset(std::int32_t a, std::int32_t b, std::uint32_t flags, std::mt19937_64& rng) {
    auto value = Chance(0.5, rng) ? a : b;
    if (!flags) return std::clamp(value, 0, 31);
    bool valid = value >= 0 && value < 32 && (flags & (1U << value));
    if (valid && !Chance(kPresetMutationChance, rng)) return value;
    std::vector<std::int32_t> choices;
    for (int i = 0; i < 32; ++i) if ((flags & (1U << i)) && (!valid || i != value)) choices.push_back(i);
    return choices.empty() ? value : choices[std::uniform_int_distribution<std::size_t>(0, choices.size()-1)(rng)];
}
constexpr bool InheritPerk(bool player, bool mother, bool coin) {
    return (player && mother) || ((player || mother) && coin);
}
}
