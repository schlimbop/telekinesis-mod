#pragma once
#include <algorithm>
#include <cmath>
#include <array>
#include <cstdint>
namespace Dynasty {
inline std::array<std::uint8_t, 4> PaintPixel(std::array<std::uint8_t, 4> skin,
    const std::array<std::uint8_t, 4>& colour, const std::array<std::uint8_t, 4>& mask, float opacity) {
    // Skyrim's vanilla warpaint DDS stores coverage in RGB, with opaque alpha.
    float coverage = (mask[0] / 255.0F) * (mask[3] / 255.0F) * std::clamp(opacity, 0.0F, 1.0F);
    for (unsigned c=0;c<3;++c) skin[c]=static_cast<std::uint8_t>(std::lerp(float(skin[c]),float(colour[c]),coverage));
    skin[3]=255; return skin;
}
}
