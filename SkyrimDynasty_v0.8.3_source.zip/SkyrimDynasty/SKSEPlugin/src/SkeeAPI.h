#pragma once
// ABI declarations from expired6978/SKSE64Plugins skee64/IPluginInterface.h.
// Only the published interface map is used. No SKEE object layouts or offsets.
#include <RE/Skyrim.h>
namespace Dynasty::Skee {
using namespace RE;
using skee_u64=std::uint64_t;using skee_u32=std::uint32_t;
class IPluginInterface
{
public:
	IPluginInterface() { };
	virtual ~IPluginInterface() { };

	virtual skee_u32 GetVersion() = 0;
	virtual void Revert() = 0;
};

class IInterfaceMap 
{
public:
	virtual IPluginInterface * QueryInterface(const char * name) = 0;
	virtual bool AddInterface(const char * name, IPluginInterface * pluginInterface) = 0;
	virtual IPluginInterface * RemoveInterface(const char * name) = 0;
};

struct InterfaceExchangeMessage
{
	enum
	{
		kMessage_ExchangeInterface = 0x9E3779B9
	};

	IInterfaceMap * interfaceMap = nullptr;
};

class IBodyMorphInterface : public IPluginInterface
{
public:
	enum
	{
		kPluginVersion1 = 1,
		kPluginVersion2,
		kPluginVersion3,
		kPluginVersion4,
		kPluginVersion5, // Added AddMorphShapeCallback
		kCurrentPluginVersion = kPluginVersion5,
		kSerializationVersion1 = 1,
		kSerializationVersion2,
		kSerializationVersion3,
		kSerializationVersion = kSerializationVersion3
	};
	class MorphKeyVisitor
	{
	public:
		virtual void Visit(const char*, float) = 0;
	};

	class StringVisitor
	{
	public:
		virtual void Visit(const char*) = 0;
	};

	class ActorVisitor
	{
	public:
		virtual void Visit(TESObjectREFR*) = 0;
	};

	class MorphValueVisitor
	{
	public:
		virtual void Visit(TESObjectREFR *, const char*, const char*, float) = 0;
	};
	
	class MorphVisitor
	{
	public:
		virtual void Visit(TESObjectREFR *, const char*) = 0;
	};

	virtual void SetMorph(TESObjectREFR * actor, const char * morphName, const char * morphKey, float relative) = 0;
	virtual float GetMorph(TESObjectREFR * actor, const char * morphName, const char * morphKey) = 0;
	virtual void ClearMorph(TESObjectREFR * actor, const char * morphName, const char * morphKey) = 0;

	virtual float GetBodyMorphs(TESObjectREFR * actor, const char * morphName) = 0;
	virtual void ClearBodyMorphNames(TESObjectREFR * actor, const char * morphName) = 0;

	virtual void VisitMorphs(TESObjectREFR * actor, MorphVisitor & visitor) = 0;
	virtual void VisitKeys(TESObjectREFR * actor, const char * name, MorphKeyVisitor & visitor) = 0;
	virtual void VisitMorphValues(TESObjectREFR * actor, MorphValueVisitor & visitor) = 0;

	virtual void ClearMorphs(TESObjectREFR * actor) = 0;

	virtual void ApplyVertexDiff(TESObjectREFR * refr, NiAVObject * rootNode, bool erase = false) = 0;

	virtual void ApplyBodyMorphs(TESObjectREFR * refr, bool deferUpdate = true) = 0;
	virtual void UpdateModelWeight(TESObjectREFR * refr, bool immediate = false) = 0;

	virtual void SetCacheLimit(skee_u64 limit) = 0;
	virtual bool HasMorphs(TESObjectREFR * actor) = 0;
	virtual skee_u32 EvaluateBodyMorphs(TESObjectREFR * actor) = 0;

	virtual bool HasBodyMorph(TESObjectREFR * actor, const char * morphName, const char * morphKey) = 0;
	virtual bool HasBodyMorphName(TESObjectREFR * actor, const char * morphName) = 0;
	virtual bool HasBodyMorphKey(TESObjectREFR * actor, const char * morphKey) = 0;
	virtual void ClearBodyMorphKeys(TESObjectREFR * actor, const char * morphKey) = 0;
	virtual void VisitStrings(StringVisitor & visitor) = 0;
	virtual void VisitActors(ActorVisitor & visitor) = 0;
	virtual skee_u64 ClearMorphCache() = 0;

	// This callback occurs after RM alters the vertex buffer of the shape, but before it copies it to other partitions, and before re-upload to GPU
	// Order controls the execution order of registered callbacks, descending order
	using MorphShapeCallback = void (*)(TESObjectREFR* refr, NiAVObject* rootNode, BSGeometry* geometry, NiSkinPartition* skinPartition, NiBinaryExtraData* unmodifiedVertexBuffer);
	virtual void AddMorphShapeCallback(MorphShapeCallback cb, skee_u64 order = 0) = 0;
};

class IPresetInterface : public IPluginInterface
{
public:
	enum
	{
		kPluginVersion1 = 1,
		kCurrentPluginVersion = kPluginVersion1,
	};

	enum ApplyTypes
	{
		kPresetApplyFace = (0 << 0),
		kPresetApplyOverrides = (1 << 0),
		kPresetApplyBodyMorphs = (1 << 1),
		kPresetApplyTransforms = (1 << 2),
		kPresetApplySkinOverrides = (1 << 3),
		kPresetApplyAll = kPresetApplyFace | kPresetApplyOverrides | kPresetApplyBodyMorphs | kPresetApplyTransforms | kPresetApplySkinOverrides
	};

	// FilePath e.g. SKSE\\Plugins\\CharGen\\Exported\\name.jslot
	// TintPath e.g. Textures\\CharGen\\Exported\\name.dds
	// TintPath optional but recommended for correct look

	virtual bool SavePreset(const char* filePath, const char* tintPath, Actor* actor) = 0;
	virtual bool LoadPreset(const char* filePath, const char* tintPath, Actor* actor, ApplyTypes applyTypes = kPresetApplyAll) = 0; // Details may be saved to the TESNPC, make sure this character is unique!
};


}
