#include "FaceTint.h"
#include "FacePaintRules.h"
#include <DirectXTex.h>
#include <filesystem>
#include <format>
namespace Dynasty {
namespace {
namespace fs=std::filesystem;
constexpr std::size_t size=512;
using Asset=RE::TESRace::FaceRelatedData::TintAsset;
fs::path Cache() {
    return fs::path(REL::Module::get().filePath().data()).parent_path()/"Data"/"textures"/"SkyrimDynasty"/"Cache";
}
std::string TexturePath(const char* name) {
    std::string path=name?name:"";
    std::replace(path.begin(),path.end(),'/','\\');
    if (path.size()<9 || _strnicmp(path.c_str(),"textures\\",9)!=0) path="textures\\"+path;
    return path;
}
bool ReadMask(const std::string& path, DirectX::ScratchImage& output) {
    RE::BSResourceNiBinaryStream stream(path);
    if (!stream.good() || !stream.stream || stream.stream->totalSize<128 || stream.stream->totalSize>32*1024*1024) return false;
    std::vector<std::uint8_t> data(stream.stream->totalSize);
    if (!stream.read(data.data(),static_cast<std::uint32_t>(data.size()))) return false;
    DirectX::ScratchImage loaded,decoded,converted;
    DirectX::TexMetadata metadata{};
    if (FAILED(DirectX::LoadFromDDSMemory(data.data(),data.size(),DirectX::DDS_FLAGS_NONE,&metadata,loaded)) ||
        metadata.width>2048 || metadata.height>2048 || metadata.arraySize!=1 || metadata.dimension!=DirectX::TEX_DIMENSION_TEXTURE2D) return false;
    auto* image=loaded.GetImage(0,0,0); if (!image) return false;
    if (DirectX::IsCompressed(image->format)) {
        if (FAILED(DirectX::Decompress(*image,DXGI_FORMAT_R8G8B8A8_UNORM,decoded))) return false;
        image=decoded.GetImage(0,0,0);
    }
    if (image->format!=DXGI_FORMAT_R8G8B8A8_UNORM) {
        if (FAILED(DirectX::Convert(*image,DXGI_FORMAT_R8G8B8A8_UNORM,DirectX::TEX_FILTER_DEFAULT,0.5F,converted))) return false;
        image=converted.GetImage(0,0,0);
    }
    return SUCCEEDED(DirectX::Resize(*image,size,size,DirectX::TEX_FILTER_LINEAR,output));
}
void Hash(std::uint64_t& hash, std::uint32_t value) {
    for (unsigned i=0;i<4;++i) {hash^=value&255;hash*=1099511628211ULL;value>>=8;}
}
}
std::string BuildFaceTintTexture(RE::FormID actor, const FaceGenome& face) {
    try {
        auto* race=RE::TESForm::LookupByID<RE::TESRace>(face.race);
        auto* racialFace=race?race->faceRelatedData[face.sex]:nullptr;
        if (!racialFace || !racialFace->tintMasks) return {};
        std::vector<std::pair<const Asset*,const RE::TESNPC::Layer*>> paints;
        std::uint64_t hash=14695981039346656037ULL;Hash(hash,face.bodyColor);Hash(hash,face.race);Hash(hash,unsigned(face.sex));
        for (const auto& layer:face.tints) if (layer.interpolationValue) for (auto* asset:*racialFace->tintMasks)
            if (asset && asset->texture.index==layer.tintIndex && asset->texture.skinTone==Asset::TintLayer::SkinTone::kPaint) {
                paints.push_back({asset,&layer});Hash(hash,layer.tintIndex);Hash(hash,layer.interpolationValue);
                Hash(hash,unsigned(layer.tintColor.red)|(unsigned(layer.tintColor.green)<<8)|(unsigned(layer.tintColor.blue)<<16));
                for (char c:std::string(asset->texture.file.textureName.c_str())) Hash(hash,static_cast<unsigned char>(c));
            }
        if (paints.empty()) return {};
        auto name=std::format("DYNA_{:08X}_{:016X}.dds",actor,hash);
        auto folder=Cache();auto destination=folder/name;
        if (!fs::exists(destination)) {
            DirectX::ScratchImage painted;
            if (FAILED(painted.Initialize2D(DXGI_FORMAT_R8G8B8A8_UNORM,size,size,1,1))) return {};
            auto* image=painted.GetImage(0,0,0);
            const std::array<std::uint8_t,4> skin{std::uint8_t(face.bodyColor),std::uint8_t(face.bodyColor>>8),std::uint8_t(face.bodyColor>>16),255};
            for (std::size_t y=0;y<size;++y) for(std::size_t x=0;x<size;++x)
                std::copy(skin.begin(),skin.end(),image->pixels+y*image->rowPitch+x*4);
            bool applied=false;
            for (auto [asset,layer]:paints) {
                DirectX::ScratchImage mask;
                if (!ReadMask(TexturePath(asset->texture.file.textureName.c_str()),mask)) {
                    SKSE::log::warn("Cannot read heir paint mask {}",asset->texture.file.textureName.c_str());continue;
                }
                const auto* pixels=mask.GetImage(0,0,0);
                const std::array<std::uint8_t,4> colour{layer->tintColor.red,layer->tintColor.green,layer->tintColor.blue,255};
                for (std::size_t y=0;y<size;++y) for(std::size_t x=0;x<size;++x) {
                    auto* target=image->pixels+y*image->rowPitch+x*4;
                    const auto* source=pixels->pixels+y*pixels->rowPitch+x*4;
                    auto value=PaintPixel({target[0],target[1],target[2],target[3]},colour,{source[0],source[1],source[2],source[3]},layer->interpolationValue/100.0F);
                    std::copy(value.begin(),value.end(),target);
                }
                applied=true;
            }
            if (!applied) return {};
            fs::create_directories(folder);
            if (FAILED(DirectX::SaveToDDSFile(*image,DirectX::DDS_FLAGS_NONE,destination.c_str()))) return {};
            SKSE::log::info("Generated painted face tint for {:08X}: {}",actor,name);
        }
        return "SkyrimDynasty\\Cache\\"+name;
    } catch(const std::exception& ex) {
        SKSE::log::warn("Heir face paint skipped safely: {}",ex.what());return {};
    }
}
bool ApplyFaceTintTexture(RE::BSGeometry* geometry, RE::BSLightingShaderProperty* shader,
    RE::BSLightingShaderMaterialBase* material, const std::string& path) {
    auto* original=material->GetTextureSet().get();
    if (!original) return false;
    RE::NiPointer<RE::BSShaderTextureSet> textures(RE::BSShaderTextureSet::Create());
    if (!textures) return false;
    for(unsigned i=0;i<RE::BSTextureSet::Texture::kTotal;++i) {
        auto type=static_cast<RE::BSTextureSet::Texture>(i);
        textures->SetTexturePath(type,original->GetTexturePath(type));
    }
    textures->SetTexturePath(RE::BSTextureSet::Texture::kMultilayer,path.c_str());
    auto* painted=RE::BSLightingShaderMaterialBase::CreateMaterial<RE::BSLightingShaderMaterialFacegen>();
    if (!painted) return false;
    painted->CopyBaseMembers(material);
    painted->ClearTextures();painted->OnLoadTextureSet(0,textures.get());
    bool ready=painted->tintTexture!=nullptr;
    if (ready) {
        shader->SetFlags(RE::BSShaderProperty::EShaderPropertyFlag8::kFace,true);
        shader->SetFlags(RE::BSShaderProperty::EShaderPropertyFlag8::kFaceGenRGBTint,false);
        shader->SetMaterial(painted,true);shader->SetupGeometry(geometry);shader->FinishSetupGeometry(geometry);
    }
    painted->~BSLightingShaderMaterialFacegen();
    RE::MemoryManager::GetSingleton()->GetThreadScrapHeap()->Deallocate(painted);
    return ready;
}
void ClearFaceTintTextures() {
    std::error_code ec;auto folder=Cache();
    if (!fs::is_directory(folder,ec)) return;
    for (const auto& entry:fs::directory_iterator(folder,ec)) {
        auto name=entry.path().filename().string();
        if (entry.is_regular_file(ec) && name.starts_with("DYNA_") && entry.path().extension()==".dds") fs::remove(entry.path(),ec);
    }
}
void ForgetFaceTintTexture(RE::FormID actor) {
    std::error_code ec;auto folder=Cache();
    if (!fs::is_directory(folder,ec)) return;
    auto prefix=std::format("DYNA_{:08X}_",actor);
    for(const auto& entry:fs::directory_iterator(folder,ec))
        if (entry.is_regular_file(ec) && entry.path().filename().string().starts_with(prefix) && entry.path().extension()==".dds") fs::remove(entry.path(),ec);
}
}
