#pragma once
#include <DirectXTex.h>
#include <cstdint>
#include <span>
namespace Dynasty {
inline constexpr std::size_t kFaceTintSize=512;
inline bool DecodeFaceMask(std::span<const std::uint8_t> data, DirectX::ScratchImage& output) {
    if (data.size()<128 || data.size()>32*1024*1024) return false;
    DirectX::ScratchImage loaded,decoded,converted;
    DirectX::TexMetadata metadata{};
    if (FAILED(DirectX::LoadFromDDSMemory(data.data(),data.size(),DirectX::DDS_FLAGS_NONE,&metadata,loaded)) ||
        metadata.width>2048 || metadata.height>2048 || metadata.arraySize!=1 || metadata.dimension!=DirectX::TEX_DIMENSION_TEXTURE2D) return false;
    auto* image=loaded.GetImage(0,0,0); if (!image) return false;
    if (DirectX::IsCompressed(image->format)) {
        if (FAILED(DirectX::Decompress(*image,DXGI_FORMAT_R8G8B8A8_UNORM,decoded))) return false;
        image=decoded.GetImage(0,0,0);
    }
    // Skyrim's render task need not initialise COM/WIC. Use the CPU path explicitly.
    if (image->format!=DXGI_FORMAT_R8G8B8A8_UNORM) {
        if (FAILED(DirectX::Convert(*image,DXGI_FORMAT_R8G8B8A8_UNORM,DirectX::TEX_FILTER_FORCE_NON_WIC,0.5F,converted))) return false;
        image=converted.GetImage(0,0,0);
    }
    return SUCCEEDED(DirectX::Resize(*image,kFaceTintSize,kFaceTintSize,
        DirectX::TEX_FILTER_LINEAR|DirectX::TEX_FILTER_FORCE_NON_WIC,output));
}
}
