#pragma once
#include "PCH.h"

namespace Dynasty {
inline RE::BSTArray<RE::TintMask*>* PlayerTintMasks(RE::PlayerCharacter* player) {
    if (!player || REL::Module::IsVR()) return nullptr;
    // GetTintList in CommonLib v10.1.0 misses the additional 1.7.99 layout shift.
    auto& data = player->GetPlayerRuntimeData();
    return data.overlayTintMasks ? data.overlayTintMasks : &data.tintMasks;
}
}
