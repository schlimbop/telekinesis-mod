#include "Genetics.h"

#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <algorithm>

namespace
{
    constexpr std::uint32_t kSerializationID = 'DYNA';

    bool CreateGenome(
        RE::StaticFunctionTag*,
        RE::Actor* child,
        RE::Actor* parentA,
        RE::Actor* parentB)
    {
        if (!child || !parentA || !parentB) {
            return false;
        }

        auto& engine = Dynasty::GeneticsEngine::GetSingleton();

        auto ga = engine.GetGenome(parentA);
        if (!ga) {
            ga = engine.MakeFounderGenome(parentA);
            engine.AttachGenome(parentA, *ga);
        }

        auto gb = engine.GetGenome(parentB);
        if (!gb) {
            gb = engine.MakeFounderGenome(parentB);
            engine.AttachGenome(parentB, *gb);
        }

        auto childGenome = engine.Breed(*ga, *gb);
        childGenome.sex = child->GetActorBase()->GetSex() == RE::SEX::kFemale ?
            Dynasty::Sex::Female : Dynasty::Sex::Male;
        childGenome.parentAFormID = parentA->GetFormID();
        childGenome.parentBFormID = parentB->GetFormID();

        if (!engine.CaptureTalents(child, parentA, parentB) ||
            !engine.CaptureAppearance(child, parentA, parentB)) {
            SKSE::log::error("Inheritance capture failed for actor {:08X}", child->GetFormID());
            return false;
        }
        SKSE::log::info("Created adult inheritance for {:08X}; parents {:08X}, {:08X}",
            child->GetFormID(), parentA->GetFormID(), parentB->GetFormID());
        bool attached=engine.AttachGenome(child, std::move(childGenome));
        if(attached) {
            auto h=child->GetHandle(),a=parentA->GetHandle(),b=parentB->GetHandle();
            SKSE::GetTaskInterface()->AddTask([h,a,b](){auto heir=h.get(),father=a.get(),mother=b.get();if(heir&&father&&mother)Dynasty::GeneticsEngine::GetSingleton().CaptureExternalLook(heir.get(),father.get(),mother.get());});
        }
        return attached;
    }

    bool TransferGenome(
        RE::StaticFunctionTag*,
        RE::Actor* oldActor,
        RE::Actor* newActor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().TransferGenome(oldActor, newActor);
    }

    bool ApplyInheritedAppearance(
        RE::StaticFunctionTag*,
        RE::Actor* actor,
        std::int32_t)
    {
        if (!actor) {
            return false;
        }

        return Dynasty::GeneticsEngine::GetSingleton().ApplyAppearance(actor);
    }

    bool RefreshAppearance(RE::StaticFunctionTag*, RE::Actor* actor) {
        if (!actor) return false;
        auto handle = actor->GetHandle();
        SKSE::GetTaskInterface()->AddTask([handle]() {
            if (auto ref = handle.get()) Dynasty::GeneticsEngine::GetSingleton().RefreshAppearance(ref.get());
        });
        return true;
    }

    bool IsReady(RE::StaticFunctionTag*) { return true; }
    RE::TESRace* GetInheritedRace(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().InheritedRace(actor);
    }

    std::string GetGenomeDebugString(
        RE::StaticFunctionTag*,
        RE::Actor* actor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().Describe(actor);
    }

    std::string GenerateName(
        RE::StaticFunctionTag*,
        RE::Actor*,
        bool female)
    {
        return Dynasty::GeneticsEngine::GetSingleton().GenerateName(female);
    }

    float GetInheritedHeightScale(
        RE::StaticFunctionTag*,
        RE::Actor* actor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().HeightScale(actor);
    }

    bool PrepareAdult(RE::StaticFunctionTag*, RE::Actor* child, RE::TESNPC* base) {
        return Dynasty::GeneticsEngine::GetSingleton().PrepareAdult(child, base);
    }
    bool ApplyInheritedSkills(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().ApplyInheritedSkills(actor);
    }
    bool RestoreInheritedPerks(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().RestoreInheritedPerks(actor);
    }

    void ForgetActor(RE::StaticFunctionTag*, RE::Actor* actor) {
        Dynasty::GeneticsEngine::GetSingleton().ForgetActor(actor);
    }
    bool AdoptHeir(RE::StaticFunctionTag*, RE::Actor* heir) {
        return Dynasty::GeneticsEngine::GetSingleton().AdoptHeir(heir);
    }
    bool CopyHeirAppearance(RE::StaticFunctionTag*, RE::Actor*) {
        return Dynasty::GeneticsEngine::GetSingleton().ApplyAppearance(RE::PlayerCharacter::GetSingleton());
    }


    float GetSetting(RE::StaticFunctionTag*,std::string key){return Dynasty::GeneticsEngine::GetSingleton().GetSetting(key);}
    void SetSetting(RE::StaticFunctionTag*,std::string key,float value){Dynasty::GeneticsEngine::GetSingleton().SetSetting(key,value);}
    std::vector<RE::TESForm*> GenerateLoadout(RE::StaticFunctionTag*,RE::Actor* actor,int slot,bool reroll){return Dynasty::GeneticsEngine::GetSingleton().GenerateLoadout(actor,slot,reroll);}
    std::vector<RE::TESForm*> RemoveInvalidLoadoutItems(RE::StaticFunctionTag*,RE::Actor* actor){return Dynasty::GeneticsEngine::GetSingleton().RemoveInvalidLoadoutItems(actor);}
    RE::BGSOutfit* PrepareOutfit(RE::StaticFunctionTag*,RE::Actor* actor){return Dynasty::GeneticsEngine::GetSingleton().PrepareOutfit(actor);}
    std::vector<RE::SpellItem*> CombatSpells(RE::StaticFunctionTag*,RE::Actor* actor){return Dynasty::GeneticsEngine::GetSingleton().CombatSpells(actor);}
    void ChooseCombatRole(RE::StaticFunctionTag*,RE::Actor* actor,int role){Dynasty::GeneticsEngine::GetSingleton().ChooseCombatRole(actor,role);}
    void RestoreCombatRole(RE::StaticFunctionTag*,RE::Actor* actor){Dynasty::GeneticsEngine::GetSingleton().RestoreCombatRole(actor);}
    std::string HeirSummary(RE::StaticFunctionTag*,RE::Actor* actor){return Dynasty::GeneticsEngine::GetSingleton().HeirSummary(actor);}
    void RecordBirth(RE::StaticFunctionTag*,RE::Actor* actor,RE::Actor* a,RE::Actor* b){Dynasty::GeneticsEngine::GetSingleton().RecordBirth(actor,a,b);}
    void RecordHome(RE::StaticFunctionTag*,RE::Actor* actor,std::string name){Dynasty::GeneticsEngine::GetSingleton().RecordHome(actor,name);}
    int JournalCount(RE::StaticFunctionTag*){return Dynasty::GeneticsEngine::GetSingleton().JournalCount();}
    std::string JournalLabel(RE::StaticFunctionTag*,int index){return Dynasty::GeneticsEngine::GetSingleton().JournalLabel(index);}
    std::string JournalDetails(RE::StaticFunctionTag*,int index){return Dynasty::GeneticsEngine::GetSingleton().JournalDetails(index);}

    bool RegisterPapyrus(RE::BSScript::IVirtualMachine* vm)
    {
        vm->RegisterFunction("GetSetting", "DynastyNative", GetSetting);
        vm->RegisterFunction("SetSetting", "DynastyNative", SetSetting);
        vm->RegisterFunction("GenerateLoadout", "DynastyNative", GenerateLoadout);
        vm->RegisterFunction("RemoveInvalidLoadoutItems", "DynastyNative", RemoveInvalidLoadoutItems);
        vm->RegisterFunction("PrepareOutfit", "DynastyNative", PrepareOutfit);
        vm->RegisterFunction("CombatSpells", "DynastyNative", CombatSpells);
        vm->RegisterFunction("ChooseCombatRole", "DynastyNative", ChooseCombatRole);
        vm->RegisterFunction("RestoreCombatRole", "DynastyNative", RestoreCombatRole);
        vm->RegisterFunction("HeirSummary", "DynastyNative", HeirSummary);
        vm->RegisterFunction("RecordBirth", "DynastyNative", RecordBirth);
        vm->RegisterFunction("RecordHome", "DynastyNative", RecordHome);
        vm->RegisterFunction("JournalCount", "DynastyNative", JournalCount);
        vm->RegisterFunction("JournalLabel", "DynastyNative", JournalLabel);
        vm->RegisterFunction("JournalDetails", "DynastyNative", JournalDetails);
        vm->RegisterFunction("RefreshAppearance", "DynastyNative", RefreshAppearance);
        vm->RegisterFunction("IsReady", "DynastyNative", IsReady);
        vm->RegisterFunction("GetInheritedRace", "DynastyNative", GetInheritedRace);
        vm->RegisterFunction("ForgetActor", "DynastyNative", ForgetActor);
        vm->RegisterFunction("AdoptHeir", "DynastyNative", AdoptHeir);
        vm->RegisterFunction("CopyHeirAppearance", "DynastyNative", CopyHeirAppearance);
        vm->RegisterFunction("PrepareAdult", "DynastyNative", PrepareAdult);
        vm->RegisterFunction("ApplyInheritedSkills", "DynastyNative", ApplyInheritedSkills);
        vm->RegisterFunction("RestoreInheritedPerks", "DynastyNative", RestoreInheritedPerks);
        vm->RegisterFunction("CreateGenome", "DynastyNative", CreateGenome);
        vm->RegisterFunction("TransferGenome", "DynastyNative", TransferGenome);
        vm->RegisterFunction("ApplyInheritedAppearance", "DynastyNative", ApplyInheritedAppearance);
        vm->RegisterFunction("GetGenomeDebugString", "DynastyNative", GetGenomeDebugString);
        vm->RegisterFunction("GenerateName", "DynastyNative", GenerateName);
        vm->RegisterFunction("GetInheritedHeightScale", "DynastyNative", GetInheritedHeightScale);
        return true;
    }

    void SaveCallback(SKSE::SerializationInterface* intfc)
    {
        Dynasty::GeneticsEngine::GetSingleton().Save(intfc);
    }

    void LoadCallback(SKSE::SerializationInterface* intfc)
    {
        Dynasty::GeneticsEngine::GetSingleton().Load(intfc);
    }

    void RevertCallback(SKSE::SerializationInterface*)
    {
        Dynasty::GeneticsEngine::GetSingleton().Revert();
    }
}

SKSEPluginLoad(const SKSE::LoadInterface* skse)
{
    SKSE::Init(skse);

    auto* papyrus = SKSE::GetPapyrusInterface();
    if (!papyrus || !papyrus->Register(RegisterPapyrus)) {
        return false;
    }

    auto* serialization = SKSE::GetSerializationInterface();
    if (!serialization) {
        return false;
    }

    serialization->SetUniqueID(kSerializationID);
    serialization->SetSaveCallback(SaveCallback);
    serialization->SetLoadCallback(LoadCallback);
    serialization->SetRevertCallback(RevertCallback);

    if(auto* messaging=SKSE::GetMessagingInterface())messaging->RegisterListener([](SKSE::MessagingInterface::Message* message){
        if(message->type==SKSE::MessagingInterface::kPostPostLoad)Dynasty::GeneticsEngine::ConnectAppearanceBridge();
    });
    return true;
}
