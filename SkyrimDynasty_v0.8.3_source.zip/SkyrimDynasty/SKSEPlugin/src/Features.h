#pragma once
#include <nlohmann/json.hpp>
#include <map>
namespace Dynasty {
using Json = nlohmann::json;
struct DynastySettings {
    int livingLimit{32}; float inheritance{1.0F}, quality{0.5F}, femaleChance{0.5F};
    bool effects{true}, safePerks{true}, externalAppearance{true}, randomCombat{true};
};
struct HeirFeatures {
    int slot{-1}, role{0}; RE::FormID style{};
    std::array<float,10> styleMix{1,1,1,1,1,1,1,1,1,1};
    std::vector<RE::FormID> items, spells;
    Json custom = Json::object();
    bool lookApplied{false};
};
struct LineageEntry {
    std::uint64_t id{}, father{}, mother{}; int generation{0}, status{0};
    RE::FormID actor{}; std::string name, fatherName, motherName, race, home, specialty;
    std::array<float,18> skills{};
};
}
