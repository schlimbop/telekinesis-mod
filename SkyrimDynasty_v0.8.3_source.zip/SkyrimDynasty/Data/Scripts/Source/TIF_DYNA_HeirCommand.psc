Scriptname TIF_DYNA_HeirCommand extends TopicInfo Hidden
Int Property Action Auto
Function Fragment_0(ObjectReference akSpeakerRef)
    Actor speaker = akSpeakerRef as Actor
    DynastyHeirDialogueQuest conversations = GetOwningQuest() as DynastyHeirDialogueQuest
    if conversations != None
        conversations.Command(speaker, Action)
    endif
EndFunction
