Scriptname DynastyNative Hidden Native

Bool Function CreateGenome(Actor akChild, Actor akParentA, Actor akParentB) Global Native
Bool Function TransferGenome(Actor akOldActor, Actor akNewActor) Global Native
Bool Function ApplyInheritedAppearance(Actor akActor, Int aiHeirIndex) Global Native
String Function GetGenomeDebugString(Actor akActor) Global Native
String Function GenerateName(Actor akActor, Bool abFemale) Global Native
Float Function GetInheritedHeightScale(Actor akActor) Global Native

Bool Function PrepareAdult(Actor akChild, ActorBase akAdultBase) Global Native
Bool Function ApplyInheritedSkills(Actor akActor) Global Native
Bool Function RestoreInheritedPerks(Actor akActor) Global Native

Function ForgetActor(Actor akActor) Global Native
Bool Function AdoptHeir(Actor akHeir) Global Native
Bool Function CopyHeirAppearance(Actor akHeir) Global Native

Bool Function IsReady() Global Native
Race Function GetInheritedRace(Actor akActor) Global Native

Bool Function RefreshAppearance(Actor akActor) Global Native

Float Function GetSetting(String key) Global Native
Function SetSetting(String key, Float value) Global Native
Form[] Function GenerateLoadout(Actor heir, Int slot, Bool reroll = False) Global Native
Outfit Function PrepareOutfit(Actor heir) Global Native
Spell[] Function CombatSpells(Actor heir) Global Native
Function ChooseCombatRole(Actor heir, Int role) Global Native
Function RestoreCombatRole(Actor heir) Global Native
String Function HeirSummary(Actor heir) Global Native
Function RecordBirth(Actor heir, Actor father, Actor mother) Global Native
Function RecordHome(Actor heir, String home) Global Native
Int Function JournalCount() Global Native
String Function JournalLabel(Int index) Global Native
String Function JournalDetails(Int index) Global Native

Form[] Function RemoveInvalidLoadoutItems(Actor akActor) Global Native
