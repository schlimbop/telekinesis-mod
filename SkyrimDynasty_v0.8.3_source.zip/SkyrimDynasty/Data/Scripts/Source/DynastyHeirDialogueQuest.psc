Scriptname DynastyHeirDialogueQuest extends Quest
Quest Property ManagerQuest Auto
ReferenceAlias Property Report Auto
Function Command(Actor speaker, Int action)
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if manager != None
        manager.HeirCommand(speaker, action)
    endif
EndFunction
