Scriptname DynastyPlayerAlias extends ReferenceAlias

Quest Property ManagerQuest Auto

Event OnInit()
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if manager != None
        manager.RestoreAllBehaviours()
        RegisterForSingleUpdate(5.0)
    endif
EndEvent

Event OnPlayerLoadGame()
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if manager != None
        manager.RecoverSuccessionOnLoad()
        manager.RestoreAllBehaviours()
        RegisterForSingleUpdate(5.0)
    endif
EndEvent

Event OnUpdate()
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if manager != None
        manager.RefreshSuccessionGuard()
        manager.MaintainFollowers()
    endif
    RegisterForSingleUpdate(5.0)
EndEvent

Event OnLocationChange(Location akOldLoc, Location akNewLoc)
    RegisterForSingleUpdate(0.5)
EndEvent

Event OnEnterBleedout()
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if manager != None
        manager.BeginSuccession()
    endif
EndEvent
