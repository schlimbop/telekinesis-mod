#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
namespace Dynasty::Equipment {
enum class Kind { Armor, Weapon, Ammo };
struct Item { std::uint32_t id{},mask{}; Kind kind{}; int type{}; float quality{}; bool bolt{}; std::uint32_t family{}; };
// Head/body/hands/feet cannot be hidden unless a matching rendered addon replaces them.
inline bool ArmorModelCovers(std::uint32_t mask,std::uint32_t visible) {
    constexpr std::uint32_t bodyParts=1U|4U|8U|128U;
    return (mask&visible)!=0 && (visible&(mask&bodyParts))==(mask&bodyParts);
}
inline bool CanGenerateArmor(std::uint32_t mask,std::uint32_t visible) {
    // Full-head replacement helmets hide the inherited head in the reported setup.
    // Keep generated faces visible; ordinary open-face helmets/circlets remain eligible.
    return !(mask&1U) && ArmorModelCovers(mask,visible);
}
inline bool TwoHanded(int t) { return t==5||t==6||t==7||t==9; }
inline bool RoleWeapon(int role,int type) {
    if(role==1)return type==1||type==3||type==4||type==5||type==6;
    if(role==2)return type==7||type==9;
    if(role==3)return type==8;
    if(role==4)return type==1||type==2;
    if(role==5)return type==2||type==3||type==4;
    return true;
}
inline bool PhysicalArmor(const Item& i){return (i.mask&(1U|2U|4U|8U|128U))!=0;}
template<class RNG> std::vector<std::uint32_t> Select(const std::vector<Item>& pool,int role,float quality,RNG& rng,bool coherent=true) {
    std::vector<std::uint32_t> result; std::uint32_t occupied=0; int weapon=0,armorType=-1;std::uint32_t family=0;
    auto pick=[&](auto eligible) -> const Item* {
        std::vector<const Item*> choices;std::vector<double> weights;
        for(const auto& item:pool)if(eligible(item)) {
            double w=0.08+std::exp(-3.0*std::abs(item.quality-quality));
            if(item.kind==Kind::Weapon) {
                const bool favored=(role==1&&(item.type>=1&&item.type<=6))||(role==2&&(item.type==7||item.type==9))||(role==3&&item.type==8)||(role==4&&item.type==2)||(role==5&&(item.type==3||item.type==4));
                w*=favored?12.0:0.3;
            } else if(item.kind==Kind::Armor) {
                const int favored=(role==1?2:(role==3||role==5?0:1));w*=item.type==favored?3.0:1.0;
            }
            if(coherent&&family&&item.family==family)w*=8.0;
            choices.push_back(&item);weights.push_back(w);
        }
        if(choices.empty())return nullptr;
        return choices[std::discrete_distribution<std::size_t>(weights.begin(),weights.end())(rng)];
    };
    const bool roleWeapons=coherent&&std::any_of(pool.begin(),pool.end(),[&](const Item& i){return i.kind==Kind::Weapon&&RoleWeapon(role,i.type);});
    if(auto* w=pick([&](const Item& i){return i.kind==Kind::Weapon&&(!roleWeapons||RoleWeapon(role,i.type));})){result.push_back(w->id);weapon=w->type;}
    auto armorCompatible=[&](const Item& i){return !coherent||armorType<0||!PhysicalArmor(i)||i.type==armorType||i.type==0;};
    auto armor=[&](std::uint32_t wanted) {
        if(occupied&wanted)return;
        const int preferred=role==1?2:role==2||role==4?1:0;
        auto available=[&](const Item& i){return i.kind==Kind::Armor&&(i.mask&wanted)&&!(i.mask&occupied)&&armorCompatible(i)&&(!(i.mask&512)||(!TwoHanded(weapon)&&weapon!=8));};
        const bool exact=coherent&&std::any_of(pool.begin(),pool.end(),[&](const Item& i){return available(i)&&i.type==(wanted==4?preferred:armorType);});
        if(auto* a=pick([&](const Item& i){return available(i)&&(!exact||i.type==(wanted==4?preferred:armorType));})) {
            result.push_back(a->id);occupied|=a->mask;if(wanted==4){armorType=a->type;family=a->family;}
        }
    };
    // Cover the torso first. Multi-slot outfits cannot be overwritten by accessories.
    armor(4);for(auto slot:{128U,8U,1U,2U,32U,64U,512U})armor(slot);
    // Mod accessories can occupy any biped slot, not just the vanilla jewellery slots.
    for(int n=0;n<3;++n)if(auto* a=pick([&](const Item& i){return i.kind==Kind::Armor&&armorCompatible(i)&&!(i.mask&occupied)&&(!(i.mask&512)||(!TwoHanded(weapon)&&weapon!=8));})) {
        result.push_back(a->id);occupied|=a->mask;
    }
    if(weapon==7||weapon==9)if(auto* a=pick([&](const Item& i){return i.kind==Kind::Ammo&&i.bolt==(weapon==9);})){result.push_back(a->id);}
    return result;
}
}
