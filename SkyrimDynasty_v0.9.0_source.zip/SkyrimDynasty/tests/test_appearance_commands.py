"""Execute shipped appearance-command orchestration; no game or file mutations."""
from types import SimpleNamespace
import unittest
from test_lifecycle import load_function
class Actor:
    def __init__(self):self.dead=False;self.combat=False;self.hostile=False;self.loaded=True;self.queued=0
    def IsDead(self):return self.dead
    def IsInCombat(self):return self.combat
    def IsHostileToActor(self,p):return self.hostile
    def Is3DLoaded(self):return self.loaded
    def QueueNiNodeUpdate(self):self.queued+=1
    def GetDisplayName(self):return 'Heir'
class AppearanceCommands(unittest.TestCase):
    def setUp(self):
        self.actor=Actor();self.calls=[];self.ready=True
        native=SimpleNamespace(RepairAppearance=self.repair,RefreshAppearance=lambda a:self.calls.append(('refresh',a)))
        self.env=dict(GetHeir=lambda i:self.actor if i==0 else None,PlayerRef=object(),DynastyNative=native,
            Debug=SimpleNamespace(Notification=lambda s:None))
        load_function('RepairHeirAppearance',self.env)
    def repair(self,a,mode):self.calls.append(('repair',a,mode));return self.ready
    def test_each_mode_only_repairs_selected_heir_and_refreshes_3d(self):
        for mode in range(3):
            self.calls=[];self.actor.queued=0;self.env['RepairHeirAppearance'](0,mode)
            self.assertEqual(self.calls,[('repair',self.actor,mode),('refresh',self.actor)])
            self.assertEqual(self.actor.queued,1)
    def test_dead_hostile_combat_and_unloaded_are_untouched(self):
        for field in ['dead','hostile','combat','loaded']:
            setattr(self.actor,field,field!='loaded');self.env['RepairHeirAppearance'](0,1)
            self.assertEqual(self.calls,[]);self.assertEqual(self.actor.queued,0)
            setattr(self.actor,field,field=='loaded')
    def test_failed_native_repair_does_not_queue_or_refresh(self):
        self.ready=False;self.env['RepairHeirAppearance'](0,0)
        self.assertEqual(self.calls,[('repair',self.actor,0)]);self.assertEqual(self.actor.queued,0)
    def test_empty_slot_and_invalid_mode_are_untouched(self):
        self.env['RepairHeirAppearance'](1,0)
        for mode in [-1,3,65535]:self.env['RepairHeirAppearance'](0,mode)
        self.assertEqual(self.calls,[]);self.assertEqual(self.actor.queued,0)
