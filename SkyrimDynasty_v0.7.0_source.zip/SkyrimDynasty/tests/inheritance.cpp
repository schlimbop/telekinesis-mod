#include "InheritanceRules.h"
#include <cstdlib>
#include <iostream>
#define CHECK(expr) do { if (!(expr)) { std::cerr << #expr << " failed\n"; return EXIT_FAILURE; } } while (false)
int main() {
    using namespace Dynasty;
    CHECK(NormaliseFaceMorph(3.402823466e+38F) == 0.0F);
    CHECK(NormaliseFaceMorph(std::nanf("")) == 0.0F);
    CHECK(ExpressFaceMorph(-1.0F, 1.0F) == 0.0F);
    CHECK(std::abs(ExpressFaceMorph(0.6F, 0.2F) - 0.4F) < 0.00001F);
    CHECK(ExpressFaceMorph(0.6F, 0.2F) == ExpressFaceMorph(0.2F, 0.6F));
    CHECK(InheritedTrait(-1.0F, 1.0F, 0.0F) == -1.0F);
    CHECK(InheritedTrait(-1.0F, 1.0F, 1.0F) == 1.0F);
    CHECK(InheritedTrait(-1.0F, 1.0F, 0.2F) < InheritedTrait(-1.0F, 1.0F, 0.8F));
    CHECK(InheritedTrait(1.0F, 1.0F, 0.2F, 0.1F) == 1.0F);
    CHECK(InheritedTrait(-1.0F, -1.0F, 0.2F, -0.1F) == -1.0F);
    CHECK(std::abs(InheritedTrait(-0.6F, 0.8F, 0.2F) - InheritedTrait(0.8F, -0.6F, 0.8F)) < 0.00001F);
    CHECK(InheritedSkill(100, 20, 0) == 60);
    CHECK(InheritedSkill(20, 100, 0) == 60);
    CHECK(InheritedSkill(100, 100, 5) == 100);
    CHECK(InheritedSkill(0, 0, -5) == 0);
    CHECK(InheritedSkill(20, 100, -5) == 55);
    for (bool coin : {false, true}) {
        CHECK(!InheritPerk(false, false, coin));
        CHECK(InheritPerk(true, true, coin));
        CHECK(InheritPerk(true, false, coin) == coin);
        CHECK(InheritPerk(false, true, coin) == coin);
    }
    std::cout << "Inheritance boundary and parent symmetry checks passed\n";
}
