Scriptname DynastyNative Hidden Native

Bool Function CreateGenome(Actor akChild, Actor akParentA, Actor akParentB) Global Native
Bool Function TransferGenome(Actor akOldActor, Actor akNewActor) Global Native
Bool Function ApplyInheritedAppearance(Actor akActor, Int aiHeirIndex) Global Native
String Function GetGenomeDebugString(Actor akActor) Global Native
String Function GenerateName(Actor akActor, Bool abFemale) Global Native
Float Function GetInheritedHeightScale(Actor akActor) Global Native

Bool Function PrepareAdult(Actor akChild, ActorBase akAdultBase) Global Native
Bool Function ApplyInheritedSkills(Actor akActor) Global Native
Bool Function RestoreInheritedPerks(Actor akActor) Global Native

Function ForgetActor(Actor akActor) Global Native
Bool Function AdoptHeir(Actor akHeir) Global Native
Bool Function CopyHeirAppearance(Actor akHeir) Global Native

Bool Function IsReady() Global Native
Race Function GetInheritedRace(Actor akActor) Global Native

Bool Function RefreshAppearance(Actor akActor) Global Native
