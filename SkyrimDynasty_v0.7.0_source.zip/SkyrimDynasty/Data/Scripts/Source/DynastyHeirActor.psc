Scriptname DynastyHeirActor extends Actor

Quest Property ManagerQuest Auto

Event OnInit()
    BlockActivation(True)
    RegisterForNiNodeUpdate()
EndEvent

Event OnActivate(ObjectReference akActionRef)
    if akActionRef != Game.GetPlayer()
        return
    endif

    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest

    if manager != None && manager.IsAdultHeir(self)
        manager.ShowHeirInteraction(self)
    else
        Activate(Game.GetPlayer(), True)
    endif
EndEvent

Event OnDeath(Actor akKiller)
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    BlockActivation(False)
    if manager != None
        manager.NotifyHeirDeath(self)
    endif
EndEvent

Event OnLoad()
    RegisterForNiNodeUpdate()
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if manager != None
        manager.RefreshHeirVisuals(self)
    endif
EndEvent

Event OnNiNodeUpdate(ObjectReference akActor)
    if akActor == self && !IsDead()
        DynastyNative.RefreshAppearance(self)
    endif
EndEvent
