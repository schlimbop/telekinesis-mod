#include "Genetics.h"
#include "InheritanceRules.h"
#include <cmath>
#include <cctype>
#include <memory>

namespace Dynasty {
namespace {
using HP = RE::BGSHeadPart;
using Part = HP::HeadPartType;
std::uint32_t Pack(RE::Color c) {
    return std::uint32_t(c.red) | (std::uint32_t(c.green) << 8) |
        (std::uint32_t(c.blue) << 16) | (std::uint32_t(c.alpha) << 24);
}
RE::Color Unpack(std::uint32_t c) {
    return RE::Color(c & 255, (c >> 8) & 255, (c >> 16) & 255, 255);
}
RE::Color Blend(RE::Color a, RE::Color b, float mix) {
    RE::Color result;
    for (std::size_t i = 0; i < 3; ++i)
        result[i] = static_cast<std::uint8_t>(std::clamp(std::lerp(float(a[i]), float(b[i]), mix), 0.0F, 255.0F));
    result.alpha = 255;
    return result;
}
RE::FormID ID(RE::TESForm* form) { return form ? form->GetFormID() : 0; }
bool Owned(RE::TESNPC* base) {
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!base || !data) return false;
    for (auto first : {0x900U, 0x940U})
        for (unsigned i = 0; i < 32; ++i)
            if (data->LookupForm<RE::TESNPC>(first + i, "DynastyHeirs.esp") == base) return true;
    return false;
}
std::string Lower(const char* text) {
    std::string out = text ? text : "";
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) { return char(std::tolower(c)); });
    return out;
}
bool SameHeadFamily(RE::TESRace* a, RE::TESRace* b, RE::SEX sex) {
    if (!a || !b) return false;
    if (a == b) return true;
    auto* pa = a->GetHeadPartByType(Part::kFace, sex);
    auto* pb = b->GetHeadPartByType(Part::kFace, sex);
    if (!pa || !pb) return false;
    auto mesh = Lower(pa->GetModel());
    return !mesh.empty() && mesh == Lower(pb->GetModel()) &&
        Lower(pa->morphs[HP::MorphIndex::kRaceMorph].GetModel()) ==
        Lower(pb->morphs[HP::MorphIndex::kRaceMorph].GetModel());
}
bool Compatible(HP* part, RE::TESRace* race, RE::SEX sex, RE::TESRace* donor = nullptr) {
    if (!part || part->IsExtraPart()) return false;
    const auto flag = sex == RE::SEX::kFemale ? HP::Flag::kFemale : HP::Flag::kMale;
    if (part->flags.any(HP::Flag::kMale, HP::Flag::kFemale) && !part->flags.any(flag)) return false;
    if (!part->validRaces || part->validRaces->HasForm(race)) return true;
    // Face diffuse/normal maps must follow the same racial skin family as the body.
    if (part->type == Part::kFace) return false;
    // Human/elf cosmetic restrictions do not imply incompatible mesh topology.
    // Never put a beast head/eyes on a human skeleton merely to retain a colour.
    return donor && part->validRaces->HasForm(donor) && SameHeadFamily(race, donor, sex);
}
std::string StyleName(HP* part) {
    auto name = Lower(part->GetFormEditorID());
    for (const std::string word : {"female", "male"}) {
        auto pos = name.find(word);
        if (pos != std::string::npos) name.erase(pos, word.size());
    }
    return name;
}
HP* Counterpart(HP* source, RE::TESRace* race, RE::TESRace* donor, RE::SEX sex,
    std::mt19937_64& rng) {
    if (Compatible(source, race, sex, donor)) return source;
    if (!source) return nullptr;
    std::vector<HP*> best;
    int bestScore = -1;
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!data) return nullptr;
    for (auto* part : data->GetFormArray<HP>()) {
        if (!Compatible(part, race, sex, donor) || part->type != source->type) continue;
        int score = 0;
        // Opposite-sex eyes preserve the actual iris texture rather than defaulting blue.
        if (source->textureSet && part->textureSet) {
            if (Lower(source->textureSet->GetTexturePath(RE::BSTextureSet::Texture::kDiffuse)) ==
                Lower(part->textureSet->GetTexturePath(RE::BSTextureSet::Texture::kDiffuse))) score += 100;
        }
        auto from = StyleName(source), to = StyleName(part);
        if (!from.empty() && from == to) score += 200;
        for (const std::string word : {"long", "short", "braid", "ponytail", "bald", "shaved", "mohawk"})
            if (from.find(word) != std::string::npos && to.find(word) != std::string::npos) score += 20;
        if (score > bestScore) { best.clear(); bestScore = score; }
        if (score == bestScore) best.push_back(part);
    }
    if (best.empty()) return nullptr;
    return best[std::uniform_int_distribution<std::size_t>(0, best.size() - 1)(rng)];
}
FaceGenome ReadFace(RE::Actor* actor) {
    FaceGenome out;
    auto* base = actor->GetActorBase();
    auto* face = base->GetRootFaceNPC();
    out.sex = base->GetSex();
    out.race = ID(actor->GetRace());
    out.bodyColor = Pack(face->bodyTintColor);
    out.weight = std::clamp(base->weight, 0.0F, 100.0F);
    if (face->faceData) {
        for (unsigned i = 0; i < 19; ++i) {
            float v = NormaliseFaceMorph(face->faceData->morphs[i]);
            out.morphs[i] = {v, v}; out.expression[i] = v;
        }
        std::copy_n(face->faceData->parts, 4, out.presets.begin());
    }
    if (face->headRelatedData) {
        out.hairColor = ID(face->headRelatedData->hairColor);
        out.faceTexture = ID(face->headRelatedData->faceDetails);
    }
    if (auto* race = actor->GetRace(); race && race->faceRelatedData[out.sex] && !out.hairColor)
        out.hairColor = ID(race->faceRelatedData[out.sex]->defaultHairColor);
    auto** parts = face->HasOverlays() ? face->GetBaseOverlays() : face->headParts;
    auto count = face->HasOverlays() ? face->GetNumBaseOverlays() : std::uint32_t(std::max<int>(0, face->numHeadParts));
    if (parts) for (unsigned i = 0; i < std::min(count, 64U); ++i)
        if (parts[i] && !parts[i]->IsExtraPart()) out.headParts.push_back(ID(parts[i]));
    if (face->tintLayers) for (auto* layer : *face->tintLayers)
        if (layer && out.tints.size() < 128) out.tints.push_back(*layer);
    if (actor == RE::PlayerCharacter::GetSingleton()) {
        if (auto* masks = RE::PlayerCharacter::GetSingleton()->GetTintList())
            for (auto* mask : *masks)
                if (mask && mask->type == RE::TintMask::Type::kSkinTone) out.bodyColor = Pack(mask->color);
    }
    return out;
}
std::int32_t ValidPreset(RE::TESRace::FaceRelatedData* face, unsigned index, std::int32_t value) {
    if (index == 1) return -1; // Skyrim's unused brow preset field.
    const unsigned variant = index == 0 ? 0 : index == 2 ? 2 : 3;
    const auto flags = face->availableMorphs[variant].morphFlags;
    if (value >= 0 && value < 32 && (flags & (1U << value))) return value;
    // Some custom races do not publish their morph availability table.
    if (!flags) return std::clamp(value, 0, 31);
    for (unsigned i = 0; i < 32; ++i) if (flags & (1U << i)) return i;
    return 0;
}
}

bool GeneticsEngine::CaptureAppearance(RE::Actor* heir, RE::Actor* parentA, RE::Actor* parentB) {
    std::lock_guard lock(mutex_);
    if (!heir || !parentA || !parentB || !heir->GetActorBase() ||
        !parentA->GetActorBase() || !parentB->GetActorBase()) return false;
    auto read = [&](RE::Actor* actor) {
        auto it = faces_.find(actor->GetFormID());
        return it == faces_.end() || it->second.needsMigration ? ReadFace(actor) : it->second;
    };
    const auto a = read(parentA), b = read(parentB);
    std::bernoulli_distribution coin(0.5);
    std::uniform_real_distribution<float> dominance(0.0F, 1.0F);
    std::normal_distribution<float> variation(0.0F, 0.025F);
    const auto& racialParent = coin(rng_) ? a : b;
    auto* race = RE::TESForm::LookupByID<RE::TESRace>(racialParent.race);
    const auto sex = heir->GetActorBase()->GetSex();
    if (!race || race->IsChildRace() || !race->faceRelatedData[sex]) return false;
    FaceGenome result;
    result.race = racialParent.race; result.sex = sex;
    result.weight = std::clamp(std::lerp(a.weight, b.weight, dominance(rng_)) + variation(rng_) * 100.0F, 0.0F, 100.0F);
    // One shared RGB value is used for the rendered face, neck, hands and body.
    result.bodyColor = Pack(Blend(Unpack(a.bodyColor), Unpack(b.bodyColor), dominance(rng_)));
    result.hairColor = coin(rng_) ? a.hairColor : b.hairColor;
    if (!result.hairColor) result.hairColor = a.hairColor ? a.hairColor : b.hairColor;
    auto* raceFace = race->faceRelatedData[sex];
    result.faceTexture = ID(raceFace->defaultFaceDetailsTextureSet);
    // Race supplies a coherent skin/texture family. Tone is inherited independently.
    result.skin = ID(race->skin); result.farSkin = 0;
    for (unsigned i = 0; i < 19; ++i) {
        result.morphs[i] = {NormaliseFaceMorph(ChooseAllele(a.morphs[i])), NormaliseFaceMorph(ChooseAllele(b.morphs[i]))};
        result.expression[i] = InheritedTrait(result.morphs[i].a, result.morphs[i].b,
            dominance(rng_), std::clamp(variation(rng_), -0.075F, 0.075F));
    }
    for (unsigned i = 0; i < 4; ++i)
        result.presets[i] = ValidPreset(raceFace, i, coin(rng_) ? a.presets[i] : b.presets[i]);
    for (unsigned type = 0; type < unsigned(Part::kTotal); ++type) {
        if (type == unsigned(Part::kScar)) continue;
        const auto& first = coin(rng_) ? a : b; // Roll separately for eyes, hair and eyebrows.
        const auto& second = &first == &a ? b : a;
        HP* selected = nullptr;
        for (const auto* candidate : {&first, &second}) {
            auto* donor = RE::TESForm::LookupByID<RE::TESRace>(candidate->race);
            for (auto id : candidate->headParts) {
                auto* part = RE::TESForm::LookupByID<HP>(id);
                if (part && part->type == static_cast<Part>(type)) {
                    selected = Counterpart(part, race, donor, sex, rng_);
                    if (selected) break;
                }
            }
            if (selected) break;
        }
        if (!selected) selected = race->GetHeadPartByType(static_cast<Part>(type), sex);
        if (selected) result.headParts.push_back(ID(selected));
    }
    if (result.headParts.empty()) return false;
    if (raceFace->tintMasks) for (auto* asset : *raceFace->tintMasks) {
        if (!asset || asset->texture.skinTone != RE::TESRace::FaceRelatedData::TintAsset::TintLayer::SkinTone::kSkinTone) continue;
        RE::TESNPC::Layer layer{};
        layer.tintIndex = asset->texture.index;
        layer.tintColor = Unpack(result.bodyColor); layer.interpolationValue = 100;
        result.tints.push_back(layer);
        break;
    }
    SKSE::log::info("Inherited phenotype {:08X}: parents {:08X}/{:08X}; race {:08X}; skin {:08X}; hair {:08X}; nose/eye/mouth {}/{}/{}; jaw {:.3f}",
        heir->GetFormID(), parentA->GetFormID(), parentB->GetFormID(), result.race, result.bodyColor,
        result.hairColor, result.presets[0], result.presets[2], result.presets[3], result.expression[3]);
    faces_[heir->GetFormID()] = std::move(result);
    return true;
}

RE::TESRace* GeneticsEngine::InheritedRace(RE::Actor* actor) const {
    std::lock_guard lock(mutex_);
    if (!actor) return nullptr;
    auto it = faces_.find(actor->GetFormID());
    return it == faces_.end() ? nullptr : RE::TESForm::LookupByID<RE::TESRace>(it->second.race);
}

bool GeneticsEngine::ApplyAppearance(RE::Actor* actor) {
    std::lock_guard lock(mutex_);
    if (!actor) return false;
    auto it = faces_.find(actor->GetFormID());
    auto* base = actor->GetActorBase();
    if (it == faces_.end() || !base || (!Owned(base) && actor != RE::PlayerCharacter::GetSingleton())) return false;
    if (it->second.needsMigration) {
        auto genome = GetGenome(actor);
        auto* a = genome ? RE::TESForm::LookupByID<RE::Actor>(genome->parentAFormID) : nullptr;
        auto* b = genome ? RE::TESForm::LookupByID<RE::Actor>(genome->parentBFormID) : nullptr;
        if (a && b && CaptureAppearance(actor, a, b)) {
            it = faces_.find(actor->GetFormID());
            SKSE::log::info("Migrated v0.6 parental phenotype for {:08X}", actor->GetFormID());
        } else {
            it->second.needsMigration = false;
            it->second.sex = base->GetSex();
        }
    }
    const auto& face = it->second;
    auto* race = RE::TESForm::LookupByID<RE::TESRace>(face.race);
    if (!race) return false;
    std::vector<HP*> parts;
    for (auto id : face.headParts) {
        auto* part = RE::TESForm::LookupByID<HP>(id);
        if (part) {
            parts.push_back(part);
            for (auto* extra : part->extraParts)
                if (extra && std::find(parts.begin(), parts.end(), extra) == parts.end()) parts.push_back(extra);
        }
    }
    if (parts.empty() || parts.size() > 127) return false;
    auto** allocated = RE::calloc<HP*>(parts.size());
    if (!allocated) return false;
    std::copy(parts.begin(), parts.end(), allocated);
    RE::free(base->headParts);
    base->headParts = allocated;
    base->numHeadParts = static_cast<std::int8_t>(parts.size());
    base->faceNPC = nullptr;
    if (auto genome = GetGenome(actor)) {
        if (genome->sex == Sex::Female) base->actorData.actorBaseFlags.set(RE::ACTOR_BASE_DATA::Flag::kFemale);
        else base->actorData.actorBaseFlags.reset(RE::ACTOR_BASE_DATA::Flag::kFemale);
    }
    base->race = race;
    if (!base->faceData) base->faceData = RE::calloc<RE::TESNPC::FaceData>(1);
    if (!base->faceData) return false;
    for (unsigned i = 0; i < 19; ++i)
        base->faceData->morphs[i] = face.expression[i];
    std::copy(face.presets.begin(), face.presets.end(), base->faceData->parts);
    base->weight = face.weight;
    base->bodyTintColor = Unpack(face.bodyColor);
    base->skin = RE::TESForm::LookupByID<RE::TESObjectARMO>(face.skin);
    base->farSkin = RE::TESForm::LookupByID<RE::TESObjectARMO>(face.farSkin);
    base->SetHairColor(RE::TESForm::LookupByID<RE::BGSColorForm>(face.hairColor));
    base->SetFaceTexture(RE::TESForm::LookupByID<RE::BGSTextureSet>(face.faceTexture));
    if (!base->tintLayers) {
        // This object becomes owned by TESNPC; use Skyrim's allocator.
        auto* layers = RE::calloc<RE::BSTArray<RE::TESNPC::Layer*>>(1);
        if (!layers) return false;
        base->tintLayers = std::construct_at(layers);
    }
    for (auto* layer : *base->tintLayers) RE::free(layer);
    base->tintLayers->clear();
    for (const auto& saved : face.tints) {
        auto* layer = RE::calloc<RE::TESNPC::Layer>(1);
        if (layer) { *layer = saved; base->tintLayers->push_back(layer); }
    }
    if (actor != RE::PlayerCharacter::GetSingleton()) {
        // Levelled/non-unique NPCs use live FaceGen, not a stale exported head NIF.
        base->actorData.actorBaseFlags.reset(RE::ACTOR_BASE_DATA::Flag::kUnique);
        base->actorData.actorBaseFlags.set(RE::ACTOR_BASE_DATA::Flag::kIsChargenFacePreset);
    }
    if (actor == RE::PlayerCharacter::GetSingleton()) {
        // Player rendering reads a separate per-player tint list, not NPC tintLayers.
        auto* player = RE::PlayerCharacter::GetSingleton();
        auto* masks = player->GetTintList();
        auto* racialFace = race->faceRelatedData[base->GetSex()];
        if (masks) for (auto* mask : *masks) {
            if (!mask) continue;
            mask->alpha = 0.0F; // Do not retain the predecessor's cosmetics.
            if (mask->type == RE::TintMask::Type::kSkinTone) {
                mask->color = Unpack(face.bodyColor);
                mask->alpha = 1.0F;
                continue;
            }
            if (!racialFace || !racialFace->tintMasks) continue;
            for (const auto& layer : face.tints) {
                for (auto* asset : *racialFace->tintMasks) {
                    if (asset && asset->texture.index == layer.tintIndex &&
                        asset->texture.skinTone.underlying() == mask->type.underlying()) {
                        mask->color = layer.tintColor;
                        mask->alpha = layer.interpolationValue / 100.0F;
                    }
                }
            }
        }
    }
    base->AddChange(RE::TESNPC::ChangeFlags::kFace | RE::TESNPC::ChangeFlags::kRace);
    SKSE::log::info("Applied parental face: actor {:08X}, race {:08X}, {} head parts, {} tint layers",
        actor->GetFormID(), face.race, parts.size(), face.tints.size());
    return true; // Papyrus queues the 3D update after this function returns.
}

// RGB skin material refresh follows the engine API pattern used by Papyrus Extender.
// See THIRD_PARTY_NOTICES.txt for attribution and GPL-3.0 licensing. Only our heirs/successor enter here.
bool GeneticsEngine::RefreshAppearance(RE::Actor* actor) {
    std::lock_guard lock(mutex_);
    if (!actor || !actor->Is3DLoaded() || !ApplyAppearance(actor)) return false;
    auto it = faces_.find(actor->GetFormID());
    if (it == faces_.end()) return false;
    const auto& face = it->second;
    auto* base = actor->GetActorBase();
    auto* root = actor->Get3D(false);
    auto* faceNode = actor->GetFaceNode();
    auto* part = base->GetCurrentHeadPartByType(Part::kFace);
    if (!root || !faceNode || !part) return false;
    // Same native call as SKSE RegenerateHead: rebuild the inherited face morphs.
    RE::BSFaceGenManager::GetSingleton()->PrepareHeadPartForShaders(faceNode, part, base);
    const RE::NiColor skin(Unpack(face.bodyColor));
    bool tinted = false;
    RE::BSVisit::TraverseScenegraphGeometries(faceNode, [&](RE::BSGeometry* geometry) {
        auto* shader = geometry->lightingShaderProp_cast();
        auto* material = shader ? static_cast<RE::BSLightingShaderMaterialBase*>(shader->material) : nullptr;
        if (material && material->GetFeature() == RE::BSShaderMaterial::Feature::kFaceGen) {
            auto* rgb = RE::BSLightingShaderMaterialBase::CreateMaterial<RE::BSLightingShaderMaterialFacegenTint>();
            if (rgb) {
                rgb->CopyBaseMembers(material);
                rgb->tintColor = skin;
                shader->SetFlags(RE::BSShaderProperty::EShaderPropertyFlag8::kFace, false);
                shader->SetFlags(RE::BSShaderProperty::EShaderPropertyFlag8::kFaceGenRGBTint, true);
                shader->SetMaterial(rgb, true);
                shader->SetupGeometry(geometry);
                shader->FinishSetupGeometry(geometry);
                rgb->~BSLightingShaderMaterialFacegenTint();
                RE::MemoryManager::GetSingleton()->GetThreadScrapHeap()->Deallocate(rgb);
                tinted = true;
            }
        } else if (material && material->GetFeature() == RE::BSShaderMaterial::Feature::kFaceGenRGBTint) {
            static_cast<RE::BSLightingShaderMaterialFacegenTint*>(material)->tintColor = skin;
            tinted = true;
        }
        return RE::BSVisit::BSVisitControl::kContinue;
    });
    root->UpdateBodyTint(skin);
    if (auto* hair = RE::TESForm::LookupByID<RE::BGSColorForm>(face.hairColor))
        root->UpdateHairColor(RE::NiColor(hair->color));
    base->UpdateNeck(faceNode);
    SKSE::log::info("Rendered phenotype {:08X}: matched head/body RGB {:08X}; face material {}",
        actor->GetFormID(), face.bodyColor, tinted ? "ready" : "unavailable");
    return tinted;
}

void GeneticsEngine::SaveAppearance(SKSE::SerializationInterface* stream) const {
    if (!stream->OpenRecord('DYFA', 2)) return;
    auto count = static_cast<std::uint32_t>(faces_.size());
    stream->WriteRecordData(count);
    for (const auto& [id, f] : faces_) {
        stream->WriteRecordData(id); stream->WriteRecordData(f.morphs); stream->WriteRecordData(f.expression);
        stream->WriteRecordData(f.sex); stream->WriteRecordData(f.presets);
        for (auto form : {f.race, f.hairColor, f.faceTexture, f.skin, f.farSkin}) stream->WriteRecordData(form);
        stream->WriteRecordData(f.bodyColor); stream->WriteRecordData(f.weight);
        auto parts = static_cast<std::uint32_t>(f.headParts.size()); stream->WriteRecordData(parts);
        for (auto form : f.headParts) stream->WriteRecordData(form);
        auto tints = static_cast<std::uint32_t>(f.tints.size()); stream->WriteRecordData(tints);
        for (const auto& t : f.tints) {
            stream->WriteRecordData(Pack(t.tintColor)); stream->WriteRecordData(t.tintIndex);
            stream->WriteRecordData(t.preset); stream->WriteRecordData(t.interpolationValue);
        }
    }
}
void GeneticsEngine::LoadAppearance(SKSE::SerializationInterface* stream, std::uint32_t version) {
    if (version < 1 || version > 2) return;
    auto read = [&](auto& value) { return stream->ReadRecordData(value) == sizeof(value); };
    auto resolve = [&](RE::FormID& id) {
        if (!id) return;
        RE::FormID result{};
        id = stream->ResolveFormID(id, result) ? result : 0;
    };
    std::uint32_t count{};
    if (!read(count) || count > 128) return;
    for (unsigned n = 0; n < count; ++n) {
        RE::FormID id{}; FaceGenome f;
        if (!read(id) || !read(f.morphs)) return;
        if (version >= 2) {
            if (!read(f.expression) || !read(f.sex)) return;
            if (f.sex != RE::SEX::kMale && f.sex != RE::SEX::kFemale) return;
        } else {
            f.needsMigration = true;
            for (unsigned i = 0; i < 19; ++i) f.expression[i] = ExpressFaceMorph(f.morphs[i].a, f.morphs[i].b);
        }
        if (!read(f.presets)) return;
        for (auto* form : {&f.race, &f.hairColor, &f.faceTexture, &f.skin, &f.farSkin})
            if (!read(*form)) return;
        if (!read(f.bodyColor) || !read(f.weight)) return;
        std::uint32_t size{};
        if (!read(size) || size > 64) return;
        for (unsigned i = 0; i < size; ++i) {
            RE::FormID form{}; if (!read(form)) return; resolve(form);
            if (form) f.headParts.push_back(form);
        }
        if (!read(size) || size > 128) return;
        for (unsigned i = 0; i < size; ++i) {
            RE::TESNPC::Layer t{}; std::uint32_t color{};
            if (!read(color) || !read(t.tintIndex) || !read(t.preset) || !read(t.interpolationValue)) return;
            t.tintColor = Unpack(color); t.interpolationValue = std::min<std::uint16_t>(100, t.interpolationValue);
            f.tints.push_back(t);
        }
        resolve(id);
        for (auto* form : {&f.race, &f.hairColor, &f.faceTexture, &f.skin, &f.farSkin}) resolve(*form);
        bool valid = std::isfinite(f.weight) && f.weight >= 0.0F && f.weight <= 100.0F;
        for (auto& locus : f.morphs) {
            valid &= std::isfinite(locus.a) && std::isfinite(locus.b) &&
                std::abs(locus.a) <= 1.0F && std::abs(locus.b) <= 1.0F;
        }
        for (float value : f.expression) valid &= std::isfinite(value) && std::abs(value) <= 1.0F;
        if (valid && id && f.race && !f.headParts.empty()) faces_[id] = std::move(f);
    }
}
}
