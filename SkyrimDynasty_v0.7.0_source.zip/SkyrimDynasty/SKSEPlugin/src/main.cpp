#include "Genetics.h"

#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <algorithm>

namespace
{
    constexpr std::uint32_t kSerializationID = 'DYNA';

    bool CreateGenome(
        RE::StaticFunctionTag*,
        RE::Actor* child,
        RE::Actor* parentA,
        RE::Actor* parentB)
    {
        if (!child || !parentA || !parentB) {
            return false;
        }

        auto& engine = Dynasty::GeneticsEngine::GetSingleton();

        auto ga = engine.GetGenome(parentA);
        if (!ga) {
            ga = engine.MakeFounderGenome(parentA);
            engine.AttachGenome(parentA, *ga);
        }

        auto gb = engine.GetGenome(parentB);
        if (!gb) {
            gb = engine.MakeFounderGenome(parentB);
            engine.AttachGenome(parentB, *gb);
        }

        auto childGenome = engine.Breed(*ga, *gb);
        childGenome.sex = child->GetActorBase()->GetSex() == RE::SEX::kFemale ?
            Dynasty::Sex::Female : Dynasty::Sex::Male;
        childGenome.parentAFormID = parentA->GetFormID();
        childGenome.parentBFormID = parentB->GetFormID();

        if (!engine.CaptureTalents(child, parentA, parentB) ||
            !engine.CaptureAppearance(child, parentA, parentB)) {
            SKSE::log::error("Inheritance capture failed for actor {:08X}", child->GetFormID());
            return false;
        }
        SKSE::log::info("Created adult inheritance for {:08X}; parents {:08X}, {:08X}",
            child->GetFormID(), parentA->GetFormID(), parentB->GetFormID());
        return engine.AttachGenome(child, std::move(childGenome));
    }

    bool TransferGenome(
        RE::StaticFunctionTag*,
        RE::Actor* oldActor,
        RE::Actor* newActor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().TransferGenome(oldActor, newActor);
    }

    bool ApplyInheritedAppearance(
        RE::StaticFunctionTag*,
        RE::Actor* actor,
        std::int32_t)
    {
        if (!actor) {
            return false;
        }

        return Dynasty::GeneticsEngine::GetSingleton().ApplyAppearance(actor);
    }

    bool RefreshAppearance(RE::StaticFunctionTag*, RE::Actor* actor) {
        if (!actor) return false;
        auto handle = actor->GetHandle();
        SKSE::GetTaskInterface()->AddTask([handle]() {
            if (auto ref = handle.get()) Dynasty::GeneticsEngine::GetSingleton().RefreshAppearance(ref.get());
        });
        return true;
    }

    bool IsReady(RE::StaticFunctionTag*) { return true; }
    RE::TESRace* GetInheritedRace(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().InheritedRace(actor);
    }

    std::string GetGenomeDebugString(
        RE::StaticFunctionTag*,
        RE::Actor* actor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().Describe(actor);
    }

    std::string GenerateName(
        RE::StaticFunctionTag*,
        RE::Actor*,
        bool female)
    {
        return Dynasty::GeneticsEngine::GetSingleton().GenerateName(female);
    }

    float GetInheritedHeightScale(
        RE::StaticFunctionTag*,
        RE::Actor* actor)
    {
        return Dynasty::GeneticsEngine::GetSingleton().HeightScale(actor);
    }

    bool PrepareAdult(RE::StaticFunctionTag*, RE::Actor* child, RE::TESNPC* base) {
        return Dynasty::GeneticsEngine::GetSingleton().PrepareAdult(child, base);
    }
    bool ApplyInheritedSkills(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().ApplyInheritedSkills(actor);
    }
    bool RestoreInheritedPerks(RE::StaticFunctionTag*, RE::Actor* actor) {
        return Dynasty::GeneticsEngine::GetSingleton().RestoreInheritedPerks(actor);
    }

    void ForgetActor(RE::StaticFunctionTag*, RE::Actor* actor) {
        Dynasty::GeneticsEngine::GetSingleton().ForgetActor(actor);
    }
    bool AdoptHeir(RE::StaticFunctionTag*, RE::Actor* heir) {
        return Dynasty::GeneticsEngine::GetSingleton().AdoptHeir(heir);
    }
    bool CopyHeirAppearance(RE::StaticFunctionTag*, RE::Actor*) {
        return Dynasty::GeneticsEngine::GetSingleton().ApplyAppearance(RE::PlayerCharacter::GetSingleton());
    }

    bool RegisterPapyrus(RE::BSScript::IVirtualMachine* vm)
    {
        vm->RegisterFunction("RefreshAppearance", "DynastyNative", RefreshAppearance);
        vm->RegisterFunction("IsReady", "DynastyNative", IsReady);
        vm->RegisterFunction("GetInheritedRace", "DynastyNative", GetInheritedRace);
        vm->RegisterFunction("ForgetActor", "DynastyNative", ForgetActor);
        vm->RegisterFunction("AdoptHeir", "DynastyNative", AdoptHeir);
        vm->RegisterFunction("CopyHeirAppearance", "DynastyNative", CopyHeirAppearance);
        vm->RegisterFunction("PrepareAdult", "DynastyNative", PrepareAdult);
        vm->RegisterFunction("ApplyInheritedSkills", "DynastyNative", ApplyInheritedSkills);
        vm->RegisterFunction("RestoreInheritedPerks", "DynastyNative", RestoreInheritedPerks);
        vm->RegisterFunction("CreateGenome", "DynastyNative", CreateGenome);
        vm->RegisterFunction("TransferGenome", "DynastyNative", TransferGenome);
        vm->RegisterFunction("ApplyInheritedAppearance", "DynastyNative", ApplyInheritedAppearance);
        vm->RegisterFunction("GetGenomeDebugString", "DynastyNative", GetGenomeDebugString);
        vm->RegisterFunction("GenerateName", "DynastyNative", GenerateName);
        vm->RegisterFunction("GetInheritedHeightScale", "DynastyNative", GetInheritedHeightScale);
        return true;
    }

    void SaveCallback(SKSE::SerializationInterface* intfc)
    {
        Dynasty::GeneticsEngine::GetSingleton().Save(intfc);
    }

    void LoadCallback(SKSE::SerializationInterface* intfc)
    {
        Dynasty::GeneticsEngine::GetSingleton().Load(intfc);
    }

    void RevertCallback(SKSE::SerializationInterface*)
    {
        Dynasty::GeneticsEngine::GetSingleton().Revert();
    }
}

SKSEPluginLoad(const SKSE::LoadInterface* skse)
{
    SKSE::Init(skse);

    auto* papyrus = SKSE::GetPapyrusInterface();
    if (!papyrus || !papyrus->Register(RegisterPapyrus)) {
        return false;
    }

    auto* serialization = SKSE::GetSerializationInterface();
    if (!serialization) {
        return false;
    }

    serialization->SetUniqueID(kSerializationID);
    serialization->SetSaveCallback(SaveCallback);
    serialization->SetLoadCallback(LoadCallback);
    serialization->SetRevertCallback(RevertCallback);

    return true;
}
