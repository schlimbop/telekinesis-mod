#pragma once
#include <algorithm>
#include <cmath>
namespace Dynasty {
constexpr float InheritedSkill(float player, float mother, float variation) {
    return std::clamp((player + mother) * 0.5F + variation, 0.0F, 100.0F);
}
inline float NormaliseFaceMorph(float v) {
    return std::isfinite(v) && std::abs(v) < 100.0F ? std::clamp(v, -1.0F, 1.0F) : 0.0F;
}
inline float ExpressFaceMorph(float a, float b) {
    return std::clamp((NormaliseFaceMorph(a) + NormaliseFaceMorph(b)) * 0.5F, -1.0F, 1.0F);
}
inline float InheritedTrait(float a, float b, float dominance, float variation = 0.0F) {
    return std::clamp(std::lerp(NormaliseFaceMorph(a), NormaliseFaceMorph(b),
        std::clamp(dominance, 0.0F, 1.0F)) + variation, -1.0F, 1.0F);
}
constexpr bool InheritPerk(bool player, bool mother, bool coin) {
    return (player && mother) || ((player || mother) && coin);
}
}
