#include "Genetics.h"
#include "InheritanceRules.h"
#include <algorithm>
#include <cmath>

namespace Dynasty {
namespace {
constexpr std::uint32_t kMaxPerks = 16384;
bool IsOwnedAdultBase(RE::TESNPC* base) {
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!data || !base) return false;
    for (RE::FormID first : {0x900U, 0x940U}) {
        for (RE::FormID i = 0; i < 32; ++i) {
            if (data->LookupForm<RE::TESNPC>(first + i, "DynastyHeirs.esp") == base) return true;
        }
    }
    return false;
}
}

bool GeneticsEngine::CaptureTalents(RE::Actor* child, RE::Actor* player, RE::Actor* mother) {
        std::lock_guard lock(mutex_);
    if (!child || !player || !mother) return false;
    TalentGenome result;
    std::uniform_real_distribution<float> variation(-5.0F, 5.0F);
    for (std::size_t i = 0; i < result.skills.size(); ++i) {
        auto av = static_cast<RE::ActorValue>(6 + i); // OneHanded through Enchanting
        float a = player->AsActorValueOwner()->GetBaseActorValue(av);
        float b = mother->AsActorValueOwner()->GetBaseActorValue(av);
        if (!std::isfinite(a) || !std::isfinite(b)) return false;
        result.skills[i] = InheritedSkill(a, b, variation(rng_));
    }
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!data) return false;
    std::bernoulli_distribution inherit(0.5);
    for (auto* perk : data->GetFormArray<RE::BGSPerk>()) {
        if (!perk) continue;
        bool a = player->HasPerk(perk);
        bool b = mother->HasPerk(perk);
        if (InheritPerk(a, b, inherit(rng_))) result.perks.push_back(perk->GetFormID());
    }
    if (result.perks.size() > kMaxPerks) return false;
    talents_[child->GetFormID()] = std::move(result);
    return true;
}

bool GeneticsEngine::ApplyPerks(RE::TESNPC* base, const TalentGenome& talent) {
    if (!IsOwnedAdultBase(base)) return false; // Never edit the player, mother or shared vanilla base.
    auto& added = appliedBasePerks_[base->GetFormID()];
    for (auto id : talent.perks) {
        auto* perk = RE::TESForm::LookupByID<RE::BGSPerk>(id);
        if (perk && !base->GetPerkIndex(perk).has_value()) {
            if (base->AddPerk(perk, 0)) added.push_back(id);
        }
    }
    return true;
}

bool GeneticsEngine::PrepareAdult(RE::Actor* child, RE::TESNPC* base) {
        std::lock_guard lock(mutex_);
    if (!child || !IsOwnedAdultBase(base)) return false;
    auto it = talents_.find(child->GetFormID());
    if (it == talents_.end()) return false;
    ResetBasePerks(base); // A recycled slot must not accumulate a former heir's perks.
    bool applied = ApplyPerks(base, it->second);
    if (applied && child->GetActorBase() == base) child->ApplyPerksFromBase();
    return applied;
}

bool GeneticsEngine::ApplyInheritedSkills(RE::Actor* actor) {
        std::lock_guard lock(mutex_);
    if (!actor) return false;
    auto it = talents_.find(actor->GetFormID());
    if (it == talents_.end()) return false;
    for (std::size_t i = 0; i < it->second.skills.size(); ++i)
        actor->AsActorValueOwner()->SetBaseActorValue(static_cast<RE::ActorValue>(6 + i), it->second.skills[i]);
    return true;
}

bool GeneticsEngine::RestoreInheritedPerks(RE::Actor* actor) {
        std::lock_guard lock(mutex_);
    if (!actor) return false;
    auto it = talents_.find(actor->GetFormID());
    auto* base = actor->GetActorBase();
    if (it == talents_.end() || !IsOwnedAdultBase(base)) return false;
    auto count = base->perkCount;
    if (!ApplyPerks(base, it->second)) return false;
    if (base->perkCount != count) actor->ApplyPerksFromBase();
    return true;
}

void GeneticsEngine::SaveTalents(SKSE::SerializationInterface* stream) const {
    if (!stream->OpenRecord('DYTL', 1)) return;
    auto count = static_cast<std::uint32_t>(talents_.size());
    stream->WriteRecordData(count);
    for (const auto& [id, talent] : talents_) {
        stream->WriteRecordData(id);
        stream->WriteRecordData(talent.skills);
        auto perks = static_cast<std::uint32_t>(talent.perks.size());
        stream->WriteRecordData(perks);
        for (auto perk : talent.perks) stream->WriteRecordData(perk);
    }
}

void GeneticsEngine::LoadTalentsRecord(SKSE::SerializationInterface* stream, std::uint32_t version) {
    if (version != 1) return;
    std::uint32_t count = 0;
    if (stream->ReadRecordData(count) != sizeof(count) || count > 128) return;
    for (std::uint32_t i = 0; i < count; ++i) {
        RE::FormID oldID = 0, id = 0;
        TalentGenome talent;
        std::uint32_t perks = 0;
        if (stream->ReadRecordData(oldID) != sizeof(oldID) ||
            stream->ReadRecordData(talent.skills) != sizeof(talent.skills) ||
            stream->ReadRecordData(perks) != sizeof(perks) || perks > kMaxPerks) return;
        for (std::uint32_t n = 0; n < perks; ++n) {
            RE::FormID oldPerk = 0, perk = 0;
            if (stream->ReadRecordData(oldPerk) != sizeof(oldPerk)) return;
            if (stream->ResolveFormID(oldPerk, perk)) talent.perks.push_back(perk);
        }
        bool valid = std::all_of(talent.skills.begin(), talent.skills.end(), [](float v) {
            return std::isfinite(v) && v >= 0.0F && v <= 100.0F;
        });
        if (valid && stream->ResolveFormID(oldID, id)) talents_[id] = std::move(talent);
    }
}

void GeneticsEngine::ResetBasePerks(RE::TESNPC* base) {
    if (!IsOwnedAdultBase(base)) return;
    auto it = appliedBasePerks_.find(base->GetFormID());
    if (it == appliedBasePerks_.end()) return;
    for (auto id : it->second) {
        if (auto* perk = RE::TESForm::LookupByID<RE::BGSPerk>(id)) base->RemovePerk(perk);
    }
    appliedBasePerks_.erase(it);
}

void GeneticsEngine::ForgetActor(RE::Actor* actor) {
    std::lock_guard lock(mutex_);
    if (!actor || actor == RE::PlayerCharacter::GetSingleton()) return;
    ResetBasePerks(actor->GetActorBase());
    faces_.erase(actor->GetFormID());
    talents_.erase(actor->GetFormID());
    genomes_.erase(actor->GetFormID());
}

bool GeneticsEngine::AdoptHeir(RE::Actor* heir) {
    std::lock_guard lock(mutex_);
    auto* player = RE::PlayerCharacter::GetSingleton();
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!player || !data || !heir || heir == player || heir->IsDead() ||
        !IsOwnedAdultBase(heir->GetActorBase())) return false;
    const auto genome = GetGenome(heir);
    if (!genome || !talents_.contains(heir->GetFormID()) ||
        !heir->GetActorBase()->headParts || heir->GetActorBase()->numHeadParts <= 0) return false;
    TalentGenome current;
    for (std::size_t i = 0; i < current.skills.size(); ++i) {
        auto value = heir->AsActorValueOwner()->GetBaseActorValue(static_cast<RE::ActorValue>(6 + i));
        if (!std::isfinite(value)) return false;
        current.skills[i] = std::clamp(value, 0.0F, 100.0F);
    }
    for (auto* perk : data->GetFormArray<RE::BGSPerk>()) {
        if (perk && heir->HasPerk(perk)) current.perks.push_back(perk->GetFormID());
    }
    if (current.perks.size() > kMaxPerks) return false;
    // Set sex before Papyrus SetRace creates the player's matching racial appearance.
    using Flag = RE::ACTOR_BASE_DATA::Flag;
    if (heir->GetActorBase()->GetSex() == RE::SEX::kFemale)
        player->GetActorBase()->actorData.actorBaseFlags.set(Flag::kFemale);
    else player->GetActorBase()->actorData.actorBaseFlags.reset(Flag::kFemale);
    player->GetActorBase()->AddChange(RE::TESNPC::ChangeFlags::kGender);
    // Validate before changing the player. The reference remains 0x14 for quests.
    if (auto face = faces_.find(heir->GetFormID()); face != faces_.end())
        faces_[player->GetFormID()] = face->second;
    genomes_[player->GetFormID()] = *genome;
    talents_[player->GetFormID()] = current;
    for (auto* perk : data->GetFormArray<RE::BGSPerk>()) {
        if (!perk) continue;
        bool owned = player->HasPerk(perk), wanted = heir->HasPerk(perk);
        if (owned && !wanted) player->RemovePerk(perk);
        if (!owned && wanted) player->AddPerk(perk);
    }
    ApplyInheritedSkills(player);
    for (auto av : {RE::ActorValue::kHealth, RE::ActorValue::kMagicka, RE::ActorValue::kStamina}) {
        auto value = heir->AsActorValueOwner()->GetBaseActorValue(av);
        if (std::isfinite(value)) player->AsActorValueOwner()->SetBaseActorValue(av, std::max(value, 1.0F));
    }
    return true;
}

void GeneticsEngine::ClearTalents() {
    for (const auto& [id, perks] : appliedBasePerks_) {
        auto* base = RE::TESForm::LookupByID<RE::TESNPC>(id);
        if (!base) continue;
        for (auto perkID : perks) {
            if (auto* perk = RE::TESForm::LookupByID<RE::BGSPerk>(perkID)) base->RemovePerk(perk);
        }
    }
    appliedBasePerks_.clear();
    talents_.clear();
}
}
