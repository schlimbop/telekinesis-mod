# Known limitations — 0.7.0

- Visual/gameplay verification in Skyrim is pending. Compilation and mocked engine tests cannot prove appearance, equipment visibility or compatibility with the installed mod list.
- Inheritance reads native NPC face records and player skin tint. RaceMenu-only sculpts, overlays, custom body sliders and externally baked replacement head geometry cannot be reconstructed from those records. No universal RaceMenu bridge is included.
- One parental race controls the skeleton and coherent skin texture family. Human/elf cosmetic eyes and compatible hair may cross race restrictions; beast/human geometry is not spliced. Elf ears follow the inherited racial face, independently of the inherited skin tone.
- RGB face rendering omits facial paint/cosmetic tint maps to avoid missing/stale FaceTint DDS data. Scars, dirt, warpaint and makeup are not genetic. Custom texture sets with intrinsically different head/body diffuse colours can still require a compatibility patch.
- Hair styles with no opposite-sex counterpart use the closest compatible identifier/style, or a compatible racial part. Parent custom hair/sculpt data without usable native records cannot be reproduced exactly.
- The native face co-save is versioned. Version 0.6 appearance is migrated once if its parents can be resolved. Keep a backup ESS/SKSE pair before upgrading.
- The 32 living-heir cap is reusable. Corpse cleanup is handled by Skyrim. Following uses teammate/offset behaviour; residence is a persistent wait marker rather than a daily schedule.
- Succession uses essential-player bleedout interception. Forced script deaths and other death-alternative mods may require compatibility work.
