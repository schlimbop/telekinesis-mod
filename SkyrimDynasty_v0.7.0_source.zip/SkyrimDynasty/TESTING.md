# v0.7 visual acceptance checks — still require Skyrim

1. Replace the old Vortex install fully, deploy and restart through SKSE. Back up the ESS/SKSE save pair.
2. With a Nord player, generate multiple heirs from different human mothers and a Dunmer mother. Check faces differ, each heir has visible armour plus a weapon, and appearance reflects parental eye/hair/skin traits.
3. Inspect face, neck, hands and exposed body in neutral daylight. The face must not be black or a different tone from the body. Inspect opposite-sex hair/eyes, equipment after arrival and after leaving/re-entering the cell.
4. For the Nord/Dunmer pairing, check elf-shaped heirs can have lighter inherited skin and that compatible red-eye inheritance is possible. It is random; no single birth guarantees a specific combination.
5. Save, exit Skyrim, reload: each heir must keep the same face, hair, colour, outfit choice, name, skills/perks, home and behaviour. Changed equipment must not be rerolled or refilled.
6. Load a v0.6 save with living heirs: verify one-time appearance migration and outfit backfill. Kill an heir, generate another and verify the freed slot works. Check succession still consumes the chosen living adult NPC and transfers identity/equipment.

SkyrimDynasty.log records parental IDs, race, skin RGB, hair form, facial presets and a sample morph, plus whether a loaded face material was refreshed. Papyrus logs record saved loadout assignment. Logs establish code execution; screenshots/gameplay establish visible correctness.
