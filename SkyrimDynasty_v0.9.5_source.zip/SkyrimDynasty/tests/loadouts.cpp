#include "LoadoutRules.h"
#include <cassert>
#include <set>
#include <map>
#include <iostream>
using namespace Dynasty::Equipment;
int main() {
    // Real regression: Cheat Room's "Ring Equip Slot 30 - Head" uses the silver-ring
    // addon (slot 36). It passed the old "any model exists" check and hid the head.
    assert(!ArmorModelCovers(1,64));
    assert(!ArmorModelCovers(4,64));
    assert(!ArmorModelCovers(1U<<21,64));
    assert(!ArmorModelCovers(1,0)); // No addon model for this race/sex.
    assert(!ArmorModelCovers(1|4,4)); // Body addon cannot replace a suppressed head.
    assert(ArmorModelCovers(0x3003,1)); // Vanilla full Imperial/Daedric helmet.
    assert(ArmorModelCovers(0x1002,0x2002)); // Iron helmet may intentionally hide hair/ears.
    assert(ArmorModelCovers(4|8|128,4|8|128)); // Multiple valid addons cover an outfit.
    assert(ArmorModelCovers(1U<<25,1U<<25)); // Custom accessory slots still work.
    assert(!CanGenerateArmor(0x3003,1)); // Reported headless full-face helmet case.
    assert(CanGenerateArmor(0x1002,0x2002)); // Open-face Iron helmet.
    assert(CanGenerateArmor(0x1000,0x1000)); // Circlet keeps the inherited face visible.
    assert(!CanGenerateArmor(4,64)); // Head policy must not bypass the coverage filter.
    std::vector<Item> pool;
    for(std::uint32_t mod:{0U,0x02000000U,0xFE001000U}) {
        for(auto [id,mask]:std::vector<std::pair<std::uint32_t,std::uint32_t>>{{1,4},{2,4|8|128},{3,8},{4,128},{5,1|2},{6,512},{7,64},{8,1U<<25}})
            pool.push_back({mod+id,mask,Kind::Armor,int(id%3),float(id)/8,false});
        for(int type=1;type<=9;++type)pool.push_back({mod+100+std::uint32_t(type),0,Kind::Weapon,type,float(type)/10,false});
        pool.push_back({mod+200,0,Kind::Ammo,0,0.2F,false});pool.push_back({mod+201,0,Kind::Ammo,0,0.9F,true});
    }
    std::map<std::uint32_t,Item> lookup;for(auto i:pool)lookup[i.id]=i;
    std::set<std::vector<std::uint32_t>> kits;std::set<std::uint32_t> selected;
    std::mt19937_64 rng(1234);
    for(int n=0;n<10000;++n) {
        auto kit=Select(pool,1+n%5,float(n%101)/100,rng,false);kits.insert(kit);std::uint32_t slots=0;int weapon=0,ammo=0;
        for(auto id:kit){selected.insert(id);const auto& i=lookup.at(id);
            if(i.kind==Kind::Weapon)weapon=i.type;
            if(i.kind==Kind::Armor){assert(!(slots&i.mask));slots|=i.mask;}
            if(i.kind==Kind::Ammo){ammo++;assert(i.bolt==(weapon==9));assert(weapon==7||weapon==9);}
        }
        assert(slots&4);if(TwoHanded(weapon)||weapon==8)assert(!(slots&512));
        assert(ammo==int(weapon==7||weapon==9));assert(kit.size()<=kMaxLoadoutItems);
    }
    assert(kits.size()>1000);assert(selected.size()==pool.size());
    assert(Select({},1,0.5F,rng).empty());
    // The identical seed reconstructs an identical selection; save restoration does not call Select.
    std::mt19937_64 a(9),b(9);assert(Select(pool,3,.7F,a)==Select(pool,3,.7F,b));
    // A hundred enchantment records of the same mesh must not crowd out one unique design.
    std::vector<Item> duplicates;
    for(std::uint32_t id=1;id<=100;++id)duplicates.push_back({id,0,Kind::Weapon,1,.5F,false,0,1000});
    duplicates.push_back({101,0,Kind::Weapon,1,.5F,false,0,2000});
    int distinct=0;
    for(int n=0;n<4000;++n)distinct+=Select(duplicates,1,.5F,rng)[0]==101;
    assert(distinct>1700&&distinct<2300);
    // Unseen visuals win even when the old item has the strongest role/price preference.
    std::vector<Item> prefer{{1,0,Kind::Weapon,1,.5F,false,0,10},{2,0,Kind::Weapon,1,.5F,false,0,10},{3,0,Kind::Weapon,8,1.F,false,0,20}};
    for(int n=0;n<100;++n)assert(Select(prefer,1,.5F,rng,true,{1})[0]==3);
    assert(!Select(prefer,1,.5F,rng,true,{1,2,3}).empty());
    // Thousands of forms, including duplicate enchantments and normal/ESL plugin IDs.
    std::vector<Item> large;std::uint32_t next=0xFE001001;
    for(std::uint32_t design=1;design<=300;++design) {
        for(int variant=0;variant<5;++variant)large.push_back({next++,0,Kind::Weapon,1+int(design%9),float(design%101)/100,false,0,10000+design});
        for(auto mask:{4U,8U,128U,2U})for(int variant=0;variant<4;++variant)
            large.push_back({next++,mask,Kind::Armor,int(design%3),float(design%101)/100,false,design%10,20000+1000*mask+design});
    }
    large.push_back({next++,0,Kind::Ammo,0,.5F,false});large.push_back({next++,0,Kind::Ammo,0,.5F,true});
    std::map<std::uint32_t,Item> largeLookup;for(const auto& i:large)largeLookup[i.id]=i;
    std::vector<std::uint32_t> recent;std::set<std::uint64_t> seenWeapons,seenTorsos;
    for(int n=0;n<250;++n) {
        auto kit=Select(large,1,.5F,rng,true,recent);
        std::set<std::uint64_t> prior;
        for(auto id:recent)prior.insert(AppearanceKey(largeLookup.at(id)));
        std::uint32_t mask=0;int type=-1,weapon=0;
        for(auto id:kit) {
            const auto& i=largeLookup.at(id);
            if(i.kind==Kind::Weapon){weapon=i.type;assert(!prior.contains(AppearanceKey(i)));seenWeapons.insert(AppearanceKey(i));}
            if(i.kind==Kind::Armor){assert(!(mask&i.mask));mask|=i.mask;
                if(i.mask&4){type=i.type;assert(!prior.contains(AppearanceKey(i)));seenTorsos.insert(AppearanceKey(i));}
                else assert(i.type==type);
            }
            if(i.kind==Kind::Ammo)assert(i.bolt==(weapon==9)&&(weapon==7||weapon==9));
        }
        assert(mask&4);RememberEquipment(recent,kit);assert(recent.size()<=512);
    }
    assert(seenWeapons.size()>140&&seenTorsos.size()>140);
    // A small bikini pack must compete with a thousand distinct cuirasses, not just enchantment clones.
    std::vector<Item> sources;
    for(std::uint32_t n=1;n<=1000;++n)sources.push_back({n,4,Kind::Armor,1,.5F,false,0,n,1});
    sources.push_back({1001,4,Kind::Armor,1,.5F,false,0,1001,2});
    int fair=0;
    for(int n=0;n<2000;++n)fair+=Select(sources,2,.5F,rng).front()==1001;
    assert(fair>850&&fair<1150);
    int small=0;std::vector<std::uint32_t> sourceHistory;
    for(int n=0;n<2000;++n) {
        auto kit=Select(sources,2,.5F,rng,true,sourceHistory);
        small+=kit.front()==1001;RememberEquipment(sourceHistory,kit);
    }
    assert(small<10); // History favours fresh designs without starving the smaller source.
    // Actual LABikini/Dread Sovereign accessory slots: thong, shoulders, tassets, bra and bracers.
    std::vector<Item> modular{{1,4,Kind::Armor,1,.5F,false,0,1,2}};
    std::uint32_t custom=4;std::uint32_t nextPart=2;
    for(auto mask:{0x400000U,0x8000000U,0x80000U,0x8000U,0x4000000U,0x800000U,0x1000000U,0x40000000U}) {
        modular.push_back({nextPart++,mask,Kind::Armor,1,.5F,false,0,nextPart,2});custom|=mask;
    }
    auto modularKit=Select(modular,2,.5F,rng);std::uint32_t actual=0;
    for(auto id:modularKit)for(const auto& i:modular)if(i.id==id){assert(!(actual&i.mask));actual|=i.mask;}
    assert((actual&4)&&modularKit.size()==1+kMaxModularPieces); // Bounded modular pieces, never every free slot.
    // Every biped bit terminates, respects overlaps and fits the save-load bound, including bit 31.
    std::vector<Item> allSlots;
    for(unsigned bit=0;bit<32;++bit)allSlots.push_back({bit+1,1U<<bit,Kind::Armor,1,.5F,false});
    allSlots.push_back({100,0,Kind::Armor,1,.5F,false}); // Malformed zero slot cannot stall the loop.
    allSlots.push_back({101,0,Kind::Weapon,1,.5F,false});
    auto full=Select(allSlots,1,.5F,rng);assert(full.size()<=kMaxArmorPieces+2);
    assert(std::find(full.begin(),full.end(),100)==full.end());
    // Multi-slot outfits still exclude conflicting modular pieces.
    modular.push_back({99,custom,Kind::Armor,1,.5F,false,0,99,3});
    for(int n=0;n<200;++n) {
        std::uint32_t used=0;
        for(auto id:Select(modular,2,.5F,rng))for(const auto& i:modular)if(i.id==id){assert(!(used&i.mask));used|=i.mask;}
        assert(used&4);
    }
    // A fresh kit must change the current torso/weapon when a different visual exists.
    std::vector<Item> reroll{{1,4,Kind::Armor,1,.5F,false,0,100,1},{2,4,Kind::Armor,1,.5F,false,0,200,2},
        {3,0,Kind::Weapon,1,.5F,false,0,300,1},{4,0,Kind::Weapon,1,.5F,false,0,400,2}};
    for(int n=0;n<100;++n) {
        auto kit=Select(reroll,1,.5F,rng,true,{1,2,3,4},{1,3});
        assert(kit==std::vector<std::uint32_t>({4,2}));
    }
    // A tiny source cannot repeat its familiar mesh while the large source has unseen alternatives.
    for(int n=0;n<100;++n)assert(Select(sources,2,.5F,rng,true,{1001}).front()!=1001);
    // Slot-remapped copies of the torso's same mesh must not be layered on top.
    std::vector<Item> copies{{1,4,Kind::Armor,1,.5F,false,0,50,1},{2,1U<<22,Kind::Armor,1,.5F,false,0,50,1}};
    assert(Select(copies,1,.5F,rng).size()==1);
    // Circlets/open headwear win over identified masks and cannot stack with another hat.
    std::vector<Item> hats{{1,4,Kind::Armor,1,.5F,false},{2,2,Kind::Armor,1,.5F,false,0,20,1,true},
        {3,0x1000,Kind::Armor,1,.5F,false,0,30,1,false},{4,0x800,Kind::Armor,1,.5F,false,0,40,1,false}};
    for(int n=0;n<300;++n) {
        auto kit=Select(hats,1,.5F,rng);int head=0;
        for(auto id:kit)if(id!=1){++head;assert(id!=2);}
        assert(head==1);
    }
    std::cout<<"Broad loadouts passed: 6302-form pool, recent-model avoidance, variant/source balancing, uncapped modular slots, all roles/types, slots and ammunition\n";

}
