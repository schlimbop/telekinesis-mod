#include "Genetics.h"
#include "LoadoutRules.h"
#include "EquipmentFilters.h"
#include <fstream>
#include <filesystem>
#include <unordered_set>
#include <cmath>
#include <mutex>
namespace Dynasty {
namespace {
using Equipment::Item;using Equipment::Kind;
std::vector<Item> itemPool;
std::once_flag poolOnce;
Equipment::Filters filters;std::unordered_set<RE::FormID> excludedForms;
void ReadFilters() {
    auto path=std::filesystem::path(REL::Module::get().filePath().data()).parent_path()/"Data"/"SKSE"/"Plugins"/"SkyrimDynastyEquipment.json";
    try {
        if(!std::filesystem::exists(path))return;
        if(std::filesystem::file_size(path)>1024*1024)throw std::runtime_error("Equipment filter exceeds 1MB");
        std::ifstream in(path);filters=Equipment::DecodeFilters(Json::parse(in));
        for(const auto& [plugin,local]:filters.forms)if(auto* f=RE::TESDataHandler::GetSingleton()->LookupForm(local,plugin))excludedForms.insert(f->GetFormID());
    }catch(const std::exception& ex){filters={};excludedForms.clear();SKSE::log::warn("Equipment filter ignored: {}",ex.what());}
}
bool Excluded(RE::TESForm* form) {
    if(excludedForms.contains(form->GetFormID()))return true;
    auto* file=form->GetFile(0);return file&&std::find(filters.plugins.begin(),filters.plugins.end(),Equipment::LowerPlugin(file->fileName))!=filters.plugins.end();
}
std::uint32_t Material(RE::TESObjectARMO* armor) {
    for(auto* k:armor->GetKeywords())if(k) {
        const char* editor=k->GetFormEditorID();if(!editor)continue;std::string name=editor;
        if(name.starts_with("ArmorMaterial")) {std::uint32_t hash=2166136261U;for(unsigned char c:name)hash=(hash^c)*16777619U;return hash;}
    }
    return 0;
}
void HashNumber(std::uint64_t& hash,std::uint64_t value) {
    for(int i=0;i<8;++i){hash=(hash^(value&255U))*1099511628211ULL;value>>=8;}
}
void HashPath(std::uint64_t& hash,const char* path) {
    if(path)for(;*path;++path){auto c=static_cast<unsigned char>(*path);if(c=='/')c='\\';hash=(hash^std::tolower(c))*1099511628211ULL;}
    HashNumber(hash,0);
}
void HashModel(std::uint64_t& hash,const RE::TESModelTextureSwap& model) {
    HashPath(hash,model.GetModel());
    for(std::uint32_t i=0;model.alternateTextures&&i<model.numAlternateTextures;++i) {
        const auto& texture=model.alternateTextures[i];
        if(texture.textureSet)for(unsigned slot=0;slot<RE::BSTextureSet::Texture::kTotal;++slot)
            HashPath(hash,texture.textureSet->GetTexturePath(static_cast<RE::BSTextureSet::Texture>(slot)));
        HashNumber(hash,texture.index3D);
    }
}
std::uint64_t WeaponVisual(RE::TESObjectWEAP* weapon) {
    std::uint64_t hash=14695981039346656037ULL;HashNumber(hash,1);HashModel(hash,*weapon);return hash;
}
std::uint32_t Source(RE::TESForm* form) {
    auto* file=form->GetFile(0);if(!file)return 0;
    std::uint32_t hash=2166136261U;
    for(const auto c:Equipment::LowerPlugin(file->fileName))hash=(hash^static_cast<unsigned char>(c))*16777619U;
    return hash;
}
bool Eligible(RE::TESForm* f) {return f&&!Excluded(f)&&!f->IsDeleted()&&!(f->formFlags&(1U<<2))&&f->GetName()&&*f->GetName()&&!(f->formFlags&(1U<<12));}
void Scan() {
    auto* data=RE::TESDataHandler::GetSingleton();if(!data)return;ReadFilters();
    for(auto* a:data->GetFormArray<RE::TESObjectARMO>())if(Eligible(a)&&a->GetPlayable()&&!a->armorAddons.empty()) {
        auto mask=a->GetSlotMask().underlying();if(mask)itemPool.push_back({a->GetFormID(),mask,Kind::Armor,a->IsHeavyArmor()?2:a->IsLightArmor()?1:0,std::clamp(std::log1p(float(a->value))/9.0F,0.0F,1.0F),false,Material(a)});
    }
    for(auto* w:data->GetFormArray<RE::TESObjectWEAP>())if(Eligible(w)&&w->GetPlayable()&&w->GetModel()&&*w->GetModel()) {
        auto type=int(w->GetWeaponType());if(type>=1&&type<=9)itemPool.push_back({w->GetFormID(),0,Kind::Weapon,type,std::clamp(std::log1p(float(w->value))/9.0F,0.0F,1.0F),false,0,WeaponVisual(w)});
    }
    for(auto* a:data->GetFormArray<RE::TESAmmo>())if(Eligible(a)&&!a->GetRuntimeData().data.flags.all(RE::AMMO_DATA::Flag::kNonPlayable)&&a->GetRuntimeData().data.projectile)itemPool.push_back({a->GetFormID(),0,Kind::Ammo,0,std::clamp(std::log1p(float(a->value))/5.0F,0.0F,1.0F),a->IsBolt()});
    for(auto& item:itemPool)if(auto* form=RE::TESForm::LookupByID(item.id))item.source=Source(form);
    auto count=[&](Kind kind){return std::count_if(itemPool.begin(),itemPool.end(),[&](const Item& i){return i.kind==kind;});};
    SKSE::log::info("Installed equipment pool: {} armour, {} weapons, {} ammunition forms",count(Kind::Armor),count(Kind::Weapon),count(Kind::Ammo));
}
bool Wearable(RE::TESObjectARMO* armor,RE::Actor* actor,std::uint64_t* visual=nullptr) {
    if(!armor||!actor||!actor->GetRace())return false;
    const auto sex=actor->GetActorBase()->GetSex()==RE::SEX::kFemale?1:0;
    std::uint32_t visible=0;std::uint64_t hash=14695981039346656037ULL;HashNumber(hash,2);
    for(auto* addon:armor->armorAddons)if(addon&&addon->IsValidRace(actor->GetRace())) {
        auto* model=addon->bipedModels[sex].GetModel();
        if(model&&*model){visible|=addon->GetSlotMask().underlying();if(visual)HashModel(hash,addon->bipedModels[sex]);}
    }
    if(visual)*visual=hash;
    return Equipment::CanGenerateArmor(armor->GetSlotMask().underlying(),visible);
}
int OwnedSlot(RE::Actor* actor) {
    auto* data=RE::TESDataHandler::GetSingleton();if(!data||!actor)return -1;
    for(int i=0;i<32;++i)for(unsigned first:{0x900U,0x940U})if(data->LookupForm<RE::TESNPC>(first+i,"DynastyHeirs.esp")==actor->GetActorBase())return i;
    return -1;
}
RE::TESCombatStyle* OwnedStyle(int slot) {return slot>=0&&slot<32?RE::TESDataHandler::GetSingleton()->LookupForm<RE::TESCombatStyle>(0xA00+slot,"DynastyHeirs.esp"):nullptr;}
}
std::vector<RE::TESForm*> GeneticsEngine::GenerateLoadout(RE::Actor* actor,int slot,bool reroll) {
    std::lock_guard lock(mutex_);std::vector<RE::TESForm*> result;
    if(!actor||slot<0||slot>=32||!GetGenome(actor)||actor->IsPlayerRef()||OwnedSlot(actor)!=slot)return result;
    std::call_once(poolOnce,Scan);auto& e=extras_[actor->GetFormID()];e.slot=slot;
    if(e.items.empty()||reroll) {
        if(!e.role)ChooseCombatRole(actor,0);
        std::vector<Item> compatible;compatible.reserve(itemPool.size());
        for(const auto& i:itemPool) {
            auto* form=RE::TESForm::LookupByID(i.id);
            const auto value=form?form->GetGoldValue():0;
            if(value<0||!Equipment::WithinValueLimit(std::uint32_t(value),filters.maxGoldValue,settings_.gearValueLimit))continue;
            auto candidate=i;
            if(i.kind==Kind::Armor) {
                auto name=Equipment::LowerPlugin(form->GetName());
                candidate.coversFace=name.find("mask")!=std::string::npos||name.find("full helm")!=std::string::npos||name.find("faceguard")!=std::string::npos||name.find("balaclava")!=std::string::npos||name.find("veil")!=std::string::npos;
            }
            if(i.kind!=Kind::Armor||Wearable(RE::TESForm::LookupByID<RE::TESObjectARMO>(i.id),actor,&candidate.visual))compatible.push_back(candidate);
        }
        auto recent=equipmentHistory_;
        for(const auto& [id,other]:extras_)recent.insert(recent.end(),other.items.begin(),other.items.end());
        auto chosen=Equipment::Select(compatible,e.role,settings_.quality,rng_,settings_.coherentGear,recent,e.items);
        const bool torso=std::any_of(chosen.begin(),chosen.end(),[&](auto id){return std::any_of(compatible.begin(),compatible.end(),[&](const Item& i){return i.id==id&&i.kind==Kind::Armor&&(i.mask&4);});});
        if(!torso){SKSE::log::warn("No compatible torso in filtered loadout for {:08X}; existing kit preserved",actor->GetFormID());return result;}
        e.items=std::move(chosen);
        Equipment::RememberEquipment(equipmentHistory_,e.items);
        auto count=[&](Kind kind){return std::count_if(compatible.begin(),compatible.end(),[&](const Item& i){return i.kind==kind;});};
        SKSE::log::info("Varied equipment pool for {:08X}: {} armour, {} weapons, {} ammo; {} chosen; {} recent entries",actor->GetFormID(),count(Kind::Armor),count(Kind::Weapon),count(Kind::Ammo),e.items.size(),equipmentHistory_.size());
        for(auto id:e.items)if(auto* form=RE::TESForm::LookupByID(id)) {
            auto* file=form->GetFile(0);auto* armor=form->As<RE::TESObjectARMO>();
            SKSE::log::info("Generated kit item for {:08X}: {:08X} ({}) from {}; slots {:08X}",actor->GetFormID(),id,form->GetName(),file?file->fileName:"dynamic",armor?armor->GetSlotMask().underlying():0U);
        }
    }
    RestoreCombatRole(actor);
    for(auto id:e.items)if(auto* f=RE::TESForm::LookupByID(id))result.push_back(f);
    return result;
}
std::vector<RE::TESForm*> GeneticsEngine::RemoveInvalidLoadoutItems(RE::Actor* actor) {
    std::lock_guard lock(mutex_);std::vector<RE::TESForm*> removed;
    if(!actor||actor->IsPlayerRef()||OwnedSlot(actor)<0)return removed;
    auto it=extras_.find(actor->GetFormID());if(it==extras_.end())return removed;
    std::erase_if(it->second.items,[&](RE::FormID id) {
        auto* armor=RE::TESForm::LookupByID<RE::TESObjectARMO>(id);
        if(!armor||Wearable(armor,actor))return false;
        removed.push_back(armor);
        SKSE::log::warn("Removing invalid generated equipment {:08X} ({}) from heir {:08X}: head replacement or mismatched model coverage for slots {:08X}",
            id,armor->GetName(),actor->GetFormID(),armor->GetSlotMask().underlying());
        return true;
    });
    return removed;
}
RE::BGSOutfit* GeneticsEngine::PrepareOutfit(RE::Actor* actor) {
    std::lock_guard lock(mutex_);if(!actor||actor->IsPlayerRef())return nullptr;
    auto it=extras_.find(actor->GetFormID());if(it==extras_.end()||it->second.slot<0||it->second.slot>=32)return nullptr;
    auto* outfit=RE::TESDataHandler::GetSingleton()->LookupForm<RE::BGSOutfit>(0xA40+it->second.slot,"DynastyHeirs.esp");if(!outfit)return nullptr;
    outfit->outfitItems.clear();
    for(auto id:it->second.items)if(auto* a=RE::TESForm::LookupByID<RE::TESObjectARMO>(id);a&&Wearable(a,actor))outfit->outfitItems.push_back(a);
    return outfit;
}
void GeneticsEngine::ChooseCombatRole(RE::Actor* actor,int role) {
    std::lock_guard lock(mutex_);if(!actor||actor->IsPlayerRef()||!GetGenome(actor))return;
    auto slot=OwnedSlot(actor);if(slot<0)return;
    auto& e=extras_[actor->GetFormID()];e.slot=slot;
    if(role<1||role>5) {
        auto skill=[&](int n){return actor->AsActorValueOwner()->GetBaseActorValue(static_cast<RE::ActorValue>(6+n));};
        std::array<double,5> weights{5+skill(0)+skill(1)+skill(3),5+2*skill(2),5+skill(14)+skill(13)+skill(16),5+skill(9)+skill(7)+skill(6),5+skill(4)+skill(10)+skill(17)};
        role=int(std::discrete_distribution<int>(weights.begin(),weights.end())(rng_))+1;
    }
    e.role=role;e.style=0;e.spells.clear();
    std::vector<RE::TESCombatStyle*> templates;
    for(auto* style:RE::TESDataHandler::GetSingleton()->GetFormArray<RE::TESCombatStyle>())if(style&&!style->IsDeleted()) {
        auto* owned=OwnedStyle(e.slot);if(style==owned)continue;
        // Use ground styles. Dragon/flying-only templates are unsuitable for humanoids.
        if(style->generalData.meleeScoreMult>0||style->generalData.rangedScoreMult>0||style->generalData.magicScoreMult>0) {
            auto* file=style->GetFile(0);if(file&&std::string_view(file->fileName)=="DynastyHeirs.esp")continue;
            templates.push_back(style);
        }
    }
    if(!templates.empty())e.style=templates[std::uniform_int_distribution<std::size_t>(0,templates.size()-1)(rng_)]->GetFormID();
    for(auto& v:e.styleMix)v=settings_.randomCombat?std::uniform_real_distribution<float>(0.65F,1.45F)(rng_):1.0F;
    RestoreCombatRole(actor);
    EarnPerks(actor,0);
    if(auto g=GetGenome(actor);g&&lineage_.contains(g->logicalID))lineage_[g->logicalID].specialty=std::array{"Undecided","Warrior","Archer","Mage","Rogue","Craftsman"}[role];
}
void GeneticsEngine::RestoreCombatRole(RE::Actor* actor) {
    std::lock_guard lock(mutex_);if(!actor||actor->IsPlayerRef()||OwnedSlot(actor)<0)return;
    auto it=extras_.find(actor->GetFormID());if(it==extras_.end())return;
    if(!ValidPersonality(it->second.personality)) {
        auto genome=GetGenome(actor);auto* a=genome?RE::TESForm::LookupByID<RE::Actor>(genome->parentAFormID):nullptr;
        auto* b=genome?RE::TESForm::LookupByID<RE::Actor>(genome->parentBFormID):nullptr;
        CapturePersonality(actor,a?a:actor,b?b:actor);
        it=extras_.find(actor->GetFormID());
    }
    auto& e=it->second;
    if(ValidPersonality(e.personality)) {
        auto* base=actor->GetActorBase();base->SetAggressionLevel(static_cast<RE::ACTOR_AGGRESSION>(PersonalityAggression(e.personality)));
        base->SetConfidenceLevel(static_cast<RE::ACTOR_CONFIDENCE>(PersonalityConfidence(e.personality)));
        actor->AsActorValueOwner()->SetBaseActorValue(RE::ActorValue::kAggression,float(PersonalityAggression(e.personality)));
        actor->AsActorValueOwner()->SetBaseActorValue(RE::ActorValue::kConfidence,float(PersonalityConfidence(e.personality)));
        base->AddChange(RE::TESNPC::ChangeFlags::kAIData);
    }
    auto* target=OwnedStyle(e.slot);auto* source=RE::TESForm::LookupByID<RE::TESCombatStyle>(e.style);if(!target||!source)return;
    target->generalData=source->generalData;target->meleeData=source->meleeData;target->closeRangeData=source->closeRangeData;target->longRangeData=source->longRangeData;target->flightData={};target->flags=source->flags;
    auto& g=target->generalData;
    g.offensiveMult=std::clamp(g.offensiveMult*e.styleMix[0],0.2F,2.0F);g.defensiveMult=std::clamp(g.defensiveMult*e.styleMix[1],0.2F,2.0F);
    g.groupOffensiveMult=e.styleMix[2];g.meleeScoreMult=(e.role==1||e.role==4||e.role==5?2.0F:0.4F)*e.styleMix[3];
    g.magicScoreMult=(e.role==3?3.0F:0.1F)*e.styleMix[4];g.rangedScoreMult=(e.role==2?3.0F:0.3F)*e.styleMix[5];g.staffScoreMult=(e.role==3?2.0F:0.3F)*e.styleMix[6];g.shoutScoreMult=0;g.unarmedScoreMult=0.1F;
    target->closeRangeData.circleMult=e.styleMix[7];target->longRangeData.strafeMult=e.styleMix[8];g.avoidThreatChance=std::clamp(0.3F*e.styleMix[9],0.0F,1.0F);
    if(ValidPersonality(e.personality)) {
        const auto& p=e.personality;
        g.offensiveMult=std::clamp(g.offensiveMult*(0.65F+0.7F*p.aggression),0.2F,2.0F);
        g.defensiveMult=std::clamp(g.defensiveMult*(1.25F-0.5F*p.bravery),0.2F,2.0F);
        g.meleeScoreMult*=1.5F-0.75F*p.distance;g.rangedScoreMult*=0.5F+p.distance;
        g.avoidThreatChance=std::clamp(0.6F-0.45F*p.bravery,0.0F,1.0F);
        target->closeRangeData.fallbackMult=0.25F+1.5F*p.distance;
        target->closeRangeData.flankDistanceMult=0.5F+1.5F*p.distance;
    }
    actor->GetActorBase()->SetCombatStyle(target);
}
std::vector<RE::SpellItem*> GeneticsEngine::CombatSpells(RE::Actor* actor) {
    std::lock_guard lock(mutex_);std::vector<RE::SpellItem*> result;if(!actor||actor->IsPlayerRef())return result;
    auto& e=extras_[actor->GetFormID()];if(e.role!=3)return result;
    if(e.spells.empty()) {
        // Combat spells only: exclude abilities, rituals and scripted/quest effects.
        std::vector<RE::SpellItem*> choices;
        for(auto* spell:RE::TESDataHandler::GetSingleton()->GetFormArray<RE::SpellItem>())if(spell&&!spell->IsDeleted()&&spell->GetSpellType()==RE::MagicSystem::SpellType::kSpell&&spell->GetAssociatedSkill()==RE::ActorValue::kDestruction&&spell->GetDelivery()==RE::MagicSystem::Delivery::kAimed) {
            bool safe=!spell->effects.empty();
            for(auto* effect:spell->effects)if(!effect||!effect->baseEffect||effect->baseEffect->data.archetype==RE::EffectSetting::Archetype::kScript||effect->baseEffect->data.minimumSkill>actor->AsActorValueOwner()->GetBaseActorValue(RE::ActorValue::kDestruction))safe=false;
            if(safe)choices.push_back(spell);
        }
        std::shuffle(choices.begin(),choices.end(),rng_);for(std::size_t i=0;i<std::min<std::size_t>(2,choices.size());++i)e.spells.push_back(choices[i]->GetFormID());
    }
    for(auto id:e.spells)if(auto* f=RE::TESForm::LookupByID<RE::SpellItem>(id))result.push_back(f);return result;
}
}
