Scriptname DynastyMCM extends SKI_ConfigBase
Quest Property ManagerQuest Auto
Int[] optionIds
String[] settingKeys
Int[] heirOptions
Int[] journalOptions
Int previousOption
Int nextOption
Int journalPage = 0
Int gearLimitOption
Int coherentOption
Int dnaSelectOption
Int dnaSummaryOption
Int[] dnaTraitOptions
Int selectedDNASlot = 0

Event OnConfigInit()
    ModName = "Skyrim Dynasty"
    Pages = new String[5]
    Pages[0] = "Settings"
    Pages[1] = "Living heirs"
    Pages[2] = "Lineage"
    Pages[3] = "Appearance DNA"
    Pages[4] = "Appearance tools"
EndEvent

Int Function GetVersion()
    return 901
EndFunction

Event OnVersionUpdate(Int version)
    OnConfigInit()
EndEvent

Event OnPageReset(String page)
    SetCursorFillMode(TOP_TO_BOTTOM)
    optionIds = new Int[8]
    settingKeys = new String[8]
    settingKeys[0] = "livingLimit"
    settingKeys[1] = "inheritance"
    settingKeys[2] = "quality"
    settingKeys[3] = "femaleChance"
    settingKeys[4] = "effects"
    settingKeys[5] = "safePerks"
    settingKeys[6] = "externalAppearance"
    settingKeys[7] = "randomCombat"
    heirOptions = new Int[32]
    journalOptions = new Int[10]
    Int i = 0
    while i < 32
        heirOptions[i] = -1
        i += 1
    endwhile
    i = 0
    while i < 10
        journalOptions[i] = -1
        i += 1
    endwhile
    gearLimitOption = -1
    coherentOption = -1
    dnaSelectOption = -1
    dnaSummaryOption = -1
    dnaTraitOptions = new Int[19]
    previousOption = -1
    nextOption = -1
    if page == "" || page == "Settings"
        AddHeaderOption("Dynasty settings")
        optionIds[0] = AddSliderOption("Living heir limit", DynastyNative.GetSetting("livingLimit"), "{0}")
        optionIds[1] = AddSliderOption("Skill / external morph inheritance", DynastyNative.GetSetting("inheritance") * 100.0, "{0}%")
        optionIds[2] = AddSliderOption("Equipment quality bias", DynastyNative.GetSetting("quality") * 100.0, "{0}%")
        optionIds[3] = AddSliderOption("Female heir probability", DynastyNative.GetSetting("femaleChance") * 100.0, "{0}%")
        optionIds[4] = AddToggleOption("Summon effect and sound", DynastyNative.GetSetting("effects") > 0.5)
        optionIds[5] = AddToggleOption("Filter story and hidden perks", DynastyNative.GetSetting("safePerks") > 0.5)
        optionIds[6] = AddToggleOption("Compatible RaceMenu morphs", DynastyNative.GetSetting("externalAppearance") > 0.5)
        optionIds[7] = AddToggleOption("Randomize combat behaviour", DynastyNative.GetSetting("randomCombat") > 0.5)
        coherentOption = AddToggleOption("Coherent role equipment", DynastyNative.GetSetting("coherentGear") > 0.5)
        gearLimitOption = AddSliderOption("Maximum item gold value (0 = unlimited)", DynastyNative.GetSetting("gearValueLimit"), "{0}")
    elseif page == "Living heirs" || page == "Appearance tools"
        DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
        AddHeaderOption("Select to inspect or recall for appearance preview")
        i = 0
        while i < 32
            Actor heir = manager.GetHeir(i)
            if heir != None && !heir.IsDead()
                if page == "Appearance tools"
                    heirOptions[i] = AddMenuOption(heir.GetDisplayName(), "Choose appearance action")
                else
                    heirOptions[i] = AddTextOption(heir.GetDisplayName(), "Inspect / recall")
                endif
            endif
            i += 1
        endwhile
    elseif page == "Appearance DNA"
        DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
        Actor selected = manager.GetHeir(selectedDNASlot)
        if selected == None || selected.IsDead()
            selectedDNASlot = -1
            i = 0
            while i < 32 && selectedDNASlot < 0
                Actor candidate = manager.GetHeir(i)
                if candidate != None && !candidate.IsDead()
                    selectedDNASlot = i
                endif
                i += 1
            endwhile
            selected = manager.GetHeir(selectedDNASlot)
        endif
        if selected != None && !selected.IsDead()
            dnaSelectOption = AddMenuOption("Heir", selected.GetDisplayName())
            dnaSummaryOption = AddTextOption("Parents and inherited feature groups", "View report")
            AddHeaderOption("A / B alleles = expression; * marks a new mutation")
            i = 0
            while i < 19
                dnaTraitOptions[i] = AddTextOption(DynastyNative.DNATraitName(i), DynastyNative.DNATrait(selected, i))
                i += 1
            endwhile
        else
            AddHeaderOption("No living heirs to inspect")
        endif
    elseif page == "Lineage"
        Int total = DynastyNative.JournalCount()
        if journalPage * 10 >= total
            journalPage = 0
        endif
        AddHeaderOption("Lineage: " + total + " people | page " + (journalPage + 1))
        i = 0
        while i < 10 && journalPage * 10 + i < total
            journalOptions[i] = AddTextOption(DynastyNative.JournalLabel(journalPage * 10 + i), "Details")
            i += 1
        endwhile
        previousOption = AddTextOption("Previous page", "")
        nextOption = AddTextOption("Next page", "")
    endif
EndEvent

Event OnOptionSliderOpen(Int option)
    if option == gearLimitOption && gearLimitOption >= 0
        SetSliderDialogStartValue(DynastyNative.GetSetting("gearValueLimit"))
        SetSliderDialogDefaultValue(0.0)
        SetSliderDialogRange(0.0, 100000.0)
        SetSliderDialogInterval(250.0)
        return
    endif
    Int i = 0
    while i < 4
        if optionIds[i] == option
            Float current = DynastyNative.GetSetting(settingKeys[i])
            if i == 0
                SetSliderDialogStartValue(current)
                SetSliderDialogDefaultValue(32.0)
                SetSliderDialogRange(1.0, 32.0)
                SetSliderDialogInterval(1.0)
            else
                SetSliderDialogStartValue(current * 100.0)
                SetSliderDialogDefaultValue(50.0)
                if i == 1
                    SetSliderDialogDefaultValue(100.0)
                    SetSliderDialogRange(0.0, 200.0)
                else
                    SetSliderDialogRange(0.0, 100.0)
                endif
                SetSliderDialogInterval(5.0)
            endif
            return
        endif
        i += 1
    endwhile
EndEvent

Event OnOptionSliderAccept(Int option, Float value)
    if option == gearLimitOption && gearLimitOption >= 0
        DynastyNative.SetSetting("gearValueLimit", value)
        SetSliderOptionValue(option, value, "{0}")
        return
    endif
    Int i = 0
    while i < 4
        if optionIds[i] == option
            if i == 0
                DynastyNative.SetSetting(settingKeys[i], value)
                SetSliderOptionValue(option, value, "{0}")
            else
                DynastyNative.SetSetting(settingKeys[i], value / 100.0)
                SetSliderOptionValue(option, value, "{0}%")
            endif
            return
        endif
        i += 1
    endwhile
EndEvent

Event OnOptionSelect(Int option)
    if option == coherentOption && coherentOption >= 0
        Bool enabled = DynastyNative.GetSetting("coherentGear") < 0.5
        DynastyNative.SetSetting("coherentGear", enabled as Float)
        SetToggleOptionValue(option, enabled)
        return
    endif
    if CurrentPage == "Appearance DNA"
        DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
        Actor heir = manager.GetHeir(selectedDNASlot)
        if heir != None && !heir.IsDead()
            if option == dnaSummaryOption
                ShowMessage(DynastyNative.DNAReport(heir), False)
            endif
        endif
        return
    endif
    Int i = 4
    if CurrentPage == "Settings" || CurrentPage == ""
        while i < 8
            if optionIds[i] == option
                Bool enabled = DynastyNative.GetSetting(settingKeys[i]) < 0.5
                DynastyNative.SetSetting(settingKeys[i], enabled as Float)
                SetToggleOptionValue(option, enabled)
                return
            endif
            i += 1
        endwhile
    elseif CurrentPage == "Living heirs"
        i = 0
        DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
        while i < 32
            if heirOptions[i] == option
                Actor heir = manager.GetHeir(i)
                if heir != None && !heir.IsDead()
                    if ShowMessage(DynastyNative.HeirSummary(heir), True, "Recall for preview", "Close")
                        manager.RecallHeir(i)
                    endif
                endif
                return
            endif
            i += 1
        endwhile
    elseif CurrentPage == "Lineage"
        if option == previousOption
            if journalPage > 0
                journalPage -= 1
            endif
            ForcePageReset()
            return
        elseif option == nextOption
            if (journalPage + 1) * 10 < DynastyNative.JournalCount()
                journalPage += 1
            endif
            ForcePageReset()
            return
        endif
        i = 0
        while i < 10
            if journalOptions[i] == option
                ShowMessage(DynastyNative.JournalDetails(journalPage * 10 + i), False)
                return
            endif
            i += 1
        endwhile
    endif
EndEvent

Event OnOptionMenuOpen(Int option)
    DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
    if CurrentPage == "Appearance DNA" && option == dnaSelectOption
        String[] choices = new String[32]
        Int i = 0
        while i < 32
            Actor heir = manager.GetHeir(i)
            choices[i] = "-- empty --"
            if heir != None && !heir.IsDead()
                choices[i] = heir.GetDisplayName()
            endif
            i += 1
        endwhile
        SetMenuDialogOptions(choices)
        SetMenuDialogStartIndex(selectedDNASlot)
        SetMenuDialogDefaultIndex(selectedDNASlot)
    elseif CurrentPage == "Appearance tools"
        String[] choices = new String[3]
        choices[0] = "Restore saved inherited appearance"
        choices[1] = "Randomise hairstyle only"
        choices[2] = "Reroll facial paint only"
        SetMenuDialogOptions(choices)
        SetMenuDialogStartIndex(0)
        SetMenuDialogDefaultIndex(0)
    endif
EndEvent

Event OnOptionMenuAccept(Int option, Int choice)
    if CurrentPage == "Appearance DNA" && option == dnaSelectOption
        selectedDNASlot = choice
        ForcePageReset()
    elseif CurrentPage == "Appearance tools"
        Int i = 0
        DynastyLifecycleQuest manager = ManagerQuest as DynastyLifecycleQuest
        while i < 32
            if heirOptions[i] == option
                manager.RepairHeirAppearance(i, choice)
                return
            endif
            i += 1
        endwhile
    endif
EndEvent

Event OnOptionHighlight(Int option)
    if CurrentPage == "Appearance DNA"
        SetInfoText("A is the player parent, B the NPC parent at birth. Numbers show saved alleles and expressed shape. * marks a mutation. Parent/group history is unavailable for legacy heirs.")
        return
    elseif CurrentPage == "Appearance tools"
        SetInfoText("Select a nearby loaded heir. Repairs and cosmetic rerolls preserve facial genes, skills, inventory and following/home orders. Combat and hostile actors are excluded.")
        return
    elseif option == coherentOption
        SetInfoText("Future kits favour role weapons, one armour class and matching material families. Installed items remain available across suitable roles. Existing kits are kept until replaced.")
        return
    elseif option == gearLimitOption
        SetInfoText("Optional strict gold-value ceiling for future gear, including enchantment value. Zero is unlimited. Very low limits can leave no compatible outfit. Gold value does not measure every mod item's power.")
        return
    endif
    if CurrentPage == "Settings" || CurrentPage == ""
        if option == optionIds[0]
            SetInfoText("Limits living heirs only. Death and succession free slots. Lowering this never removes existing heirs.")
        elseif option == optionIds[1]
            SetInfoText("Applies to future inherited skills and compatible external morphs. Native parental face and colour inheritance remains enabled.")
        elseif option == optionIds[2]
            SetInfoText("Biases future item choices toward inexpensive or valuable gear. Every eligible installed item remains possible. Existing kits stay unchanged.")
        elseif option == optionIds[6]
            SetInfoText("Optional RaceMenu bridge. Body sliders require morph-enabled meshes. Custom face/sculpt transfer requires a compatible exposed Preset interface; unmatched topology is skipped.")
        else
            SetInfoText("Saved per game. Equipment and combat changes apply to future heirs; existing heirs can change role through dialogue.")
        endif
    else
        SetInfoText("Lineage persists after death or succession. Recall moves a living heir beside you and orders them to wait.")
    endif
EndEvent
